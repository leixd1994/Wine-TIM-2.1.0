(function(e) {
    var t = {};
    function a(n) {
        if (t[n]) return t[n].exports;
        var i = t[n] = {
            exports: {},
            id: n,
            loaded: false
        };
        e[n].call(i.exports, i, i.exports, a);
        i.loaded = true;
        return i.exports;
    }
    a.m = e;
    a.c = t;
    a.p = "//s1.url.cn/qqun/pan/clt_filetab/js/";
    return a(0);
})([ function(e, t, a) {
    "use strict";
    savePoint("start");
    window.G = {};
    G.flagThumb = true;
    G.flagUploadTemp = false;
    G.flagHeightChrome = /chrome\/([2|3]\d)/gi.test(window.navigator.userAgent);
    G.canOpenFolder = window.external && window.external.openFolder;
    G.ifFileExist = window.external && window.external.isFileExist;
    G.flagIsVip = false;
    G.handler = {};
    G.cMap = {};
    G.pList = [];
    G.cList = [];
    G.compList = [];
    G.selectRow = {};
    G.previewCache = {};
    G.activeElement;
    G.oldVersion = false;
    G.folderVersion = 5461;
    G.nowFolder = "/";
    G.folderNum = 0;
    G.appid = 4;
    G.canCreateFolder = false;
    G.mac = false;
    var n = a(3);
    var i = a(4);
    var r = a(5);
    var o = a(6);
    var l = a(7);
    var s = a(10);
    var f = a(11);
    var c = a(14);
    var d = a(15);
    var u = a(12);
    var p = a(13);
    var v = a(8);
    var m = a(2);
    var h = a(9);
    var g = s.getParameter("debug");
    var w = decodeURIComponent(s.getParameter("webParams"));
    G.downFast = window.external && window.external.downloadByXF;
    G.fileMap = function() {
        var e = [];
        return function() {
            e[G.module()] = e[G.module()] || {};
            return e[G.module()];
        };
    }();
    G.folderMap = function() {
        var e = [];
        return function() {
            var t = G.module();
            if (t === 1 || t === 2 || t === 3) {
                t = 0;
            }
            e[t] = e[t] || {};
            return e[t];
        };
    }();
    G.module = function() {
        var e = 0;
        var t = {
            0: "首页",
            1: "文件夹内",
            2: "成员文件列表",
            3: "搜索结果页"
        };
        return function(a) {
            if (a === undefined) {
                return e;
            } else if (t[a]) {
                if (a !== 3) {
                    $("#inputSearch").val("");
                }
                return e = a;
            } else {
                console.log("illegal module");
            }
        };
    }();
    G.scrollHandler = function() {
        var e = [];
        return function(t) {
            var a = G.module();
            if (t) {
                return e[a] = t;
            } else {
                e[a] = e[a] || function() {};
                e[a]();
            }
        };
    }();
    G.checkHttps = function() {
        var e = location.href;
        return e.indexOf("https://") >= 0 ? true : false;
    };
    G.getReportInfo = function(e) {
        if (e.orcType === 1) {
            var t = G.module() === 1 ? 1 : 0;
            var a = $("#" + e.domid);
            var n = a.attr("idx");
            var i = t;
            if (typeof n !== "undefined") {
                i += "_" + n;
            }
            var r = e.uin === G.info.uin ? 1 : 2;
            return {
                ver1: e.isDown ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: r,
                ver4: encodeURIComponent(e.fname),
                ver5: encodeURIComponent(e.filetype),
                ver6: i
            };
        } else if (e.orcType === 2) {
            var o = 0;
            var l = $("#" + e.domid);
            var s = l.attr("idx");
            var f = o;
            if (typeof s !== "undefined") {
                f += "_" + s;
            }
            var c = G.info.uin === e.uin ? 1 : 2;
            return {
                ver1: e.filenum === e.downNum ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: c,
                ver4: encodeURIComponent(e.name),
                ver5: f
            };
        }
        return false;
    };
    function b() {
        if (navigator.userAgent.indexOf("Mac OS X") >= 0) {
            G.mac = true;
            $("#inputSearch").attr("placeholder", "");
            $("#navTopFolder").attr("data-action", "menu.filenum");
            $(".refresh-icon").attr("data-action", "menu.refresh").click(function() {
                window.location.reload();
            });
        } else {
            $("#inputSearch").attr("placeholder", "搜索");
        }
    }
    function _() {
        b();
        G.info = n.getInfo();
        i.init();
        f.init();
        o.init();
        p.init();
        m.action(w);
        if (localVersion === "isLocal") {
            report("offlinePage");
        }
    }
    _();
}, , function(e, t, a) {
    "use strict";
    var n = a(25);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(14);
    var l = a(15);
    var s = a(12);
    var f = a(8);
    var c = function u(e) {
        if (e === "") {
            f.init();
        } else {
            try {
                e = JSON.parse(e);
            } catch (t) {
                f.init();
                return;
            }
        }
        if (e.action === "fileList") {
            var a = e.params;
            a = (typeof a === "undefined" ? "undefined" : (0, i.default)(a)) === "object" ? a : {};
            var n = a.folderId;
            if (n === "/") {
                f.init();
            } else {
                o["folder.open"](n, a.fname);
            }
        } else if (e.action === "search") {
            var r = e.params;
            r = (typeof r === "undefined" ? "undefined" : (0, i.default)(r)) === "object" ? r : {};
            var c = r.keyword;
            $("#inputSearch").val(c);
            var d = r.files[0];
            s.search(undefined, function(e) {
                var t = true;
                var a = false;
                return function() {
                    if (t) {
                        l["file.getAttr"](e, c);
                        t = false;
                    }
                    if (!a) {
                        var n = "#" + ("/" + e["busId"] + e["fileId"]).replace(/\//gi, "-");
                        $(n).last().remove();
                        a = true;
                    }
                };
            }(d));
        }
    };
    var d = function p() {
        window.addEventListener("storage", function(e) {
            if (e.key !== "notifyOtherGroup") {
                return;
            }
            var t = {};
            try {
                t = JSON.parse(e.newValue);
            } catch (e) {
                console.log("decode JSON fail");
                return;
            }
            if (t.gc !== G.info.gc) {
                return;
            }
            var a = t.webParams;
            c(a);
        });
    }();
    e.exports = {
        action: c
    };
}, function(e, t, a) {
    "use strict";
    var n = a(10), i = a(59);
    function r() {
        var e = n.getUin();
        var t = n.getParameter("gid");
        var a = function() {
            var a = "refresh_" + e + "_" + t;
            if (n.getCookie(a) * 1) {
                n.getCookie(a);
                return true;
            }
            return false;
        }();
        if (!/^\d+$/.test(t)) {
            t = parseInt(t, 10);
            if (isNaN(t)) {
                t = "0";
            }
        }
        var r = n.getParameter("visitor");
        var o = r === "1";
        var l = i.getVersion().version;
        var s = {
            uin: parseInt(e),
            gc: parseInt(t),
            isVisitor: o,
            nickName: i.getNickName(e),
            fromRefresh: a,
            version: l
        };
        return s;
    }
    e.exports = {
        getInfo: r
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = void 0;
    var l = void 0;
    var s = void 0;
    var f = [];
    var c = window.localStorage;
    var d = {};
    function u() {
        if (!o) {
            o = "lp" + G.info.gc + "-" + G.info.uin;
        }
        if (!s) {
            s = "tips" + G.info.gc + "-" + G.info.uin;
        }
        if (!l) {
            l = "clist" + G.info.gc + "-" + G.info.uin;
        }
        return o;
    }
    function p(e) {
        try {
            c.setItem(s, e);
        } catch (t) {
            c.clear();
            c.setItem(s, e);
        }
    }
    function v() {
        return c.getItem(s);
    }
    function m(e) {
        d[e.filepath] = e.localpath;
        f.push(e);
        try {
            c.setItem(o, (0, i.default)(d));
            c.setItem(l, (0, i.default)(f));
        } catch (t) {
            c.clear();
            c.setItem(o, (0, i.default)(d));
            c.setItem(l, (0, i.default)(f));
        }
    }
    function h(e) {
        if (e.orcType === 1) {
            delete d[e.filepath];
        } else {
            delete d[e.id];
        }
        try {
            c.setItem(o, (0, i.default)(d));
        } catch (t) {
            c.clear();
            c.setItem(o, (0, i.default)(d));
        }
    }
    function g(e) {
        return d[e] || false;
    }
    function w(e) {
        var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "push";
        if (t === "push") {
            f.push(e);
        } else if (t === "delete") {
            f = f.filter(function(t) {
                return e.localpath !== t.localpath;
            });
        }
        try {
            c.setItem(l, (0, i.default)(f));
        } catch (a) {
            c.clear();
            c.setItem(l, (0, i.default)(f));
        }
    }
    function b() {
        var e = c.getItem(l);
        if (e === null) {
            return false;
        }
        try {
            return JSON.parse(e);
        } catch (t) {
            return false;
        }
    }
    function _() {
        c.removeItem(l);
    }
    function k() {
        o = u();
        var e = c.getItem(o);
        if (e) {
            d = JSON.parse(e);
        }
    }
    e.exports = {
        set: m,
        remove: h,
        check: g,
        init: k,
        setTips: p,
        getTips: v,
        clearClist: _,
        getClist: b,
        setClist: w
    };
}, function(e, t, a) {
    "use strict";
    a(60);
}, function(e, t, a) {
    "use strict";
    var n = a(32);
    var i = a(33);
    var r = a(34);
    var o = a(35);
    var l = a(4);
    var s = a(36);
    var f = a(59);
    var c = $(G.handler);
    window.client = f;
    function d() {
        for (var e in r) {
            if (r.hasOwnProperty(e)) {
                c.bind("box." + e, r[e]);
            }
        }
    }
    function u() {
        var e = f.getTaskListAdv();
        var t = l.getClist();
        G.pList = s.cleanMap(e.map);
        G.compList = t;
        if (G.compList) {
            for (var a = 0, n = G.compList.length; a < n; a++) {
                var i = G.compList[a];
                var r = o.getData(i.filepath);
                if (!r) {
                    i.id = i.filepath;
                    o.addData(i);
                }
            }
        }
        d();
    }
    e.exports = {
        init: u
    };
}, function(e, t, a) {
    "use strict";
    var n = a(97), i = a(10), r = $(G.handler), o;
    var l = a(59);
    var s = {
        fail: "fail",
        wait: "wait",
        suc: "suc",
        alert: "new-alert"
    }, f, c;
    function d(e, t) {
        var a = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
        if (G.mac) {
            if (e === "fail") {
                l.alert(2, "提示", t);
            }
        } else {
            if (!o) {
                var i = {
                    cls: s[e],
                    text: t
                };
                var r = n(i);
                $("body").append(r);
                o = $("#toastDom");
                f = o.find(".toast-icon");
                c = o.find(".toast-message");
            } else {
                f.attr("class", "icons-" + s[e] + " toast-icon");
                c.text(t);
            }
            o.addClass("open");
            if (a) {
                setTimeout(function() {
                    u();
                }, 1e3);
            }
        }
    }
    function u() {
        if (o) {
            o.removeClass("open");
        }
    }
    r.bind("toast.show", function(e, t) {
        if (t && t.type && t.text) {
            d(t.type, t.text, t.autoHide);
        }
    });
    r.bind("toast.hide", function(e, t) {
        u();
    });
    e.exports = {
        show: d,
        hide: u
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(76);
    var l = a(98);
    var s = a(99);
    var f = a(40);
    var c = a(35);
    var d = a(10);
    var u = a(34);
    var p = $("#fileListDom");
    var v = $("#fileNumText");
    var m = $("#groupSize");
    var h = $("#groupSizeBar");
    var g = a(91);
    var w = $(G.handler);
    var b = true;
    var _ = void 0;
    G.renderListFuncSingtons = {};
    G.getListFuncSingtons = {};
    G.searchFuncSingtons = {};
    w.bind("file.thumbUpdate", function(e, t) {
        var a = $("#" + t.domid);
        if (a.length && t.previewObj && t.previewObj.url) {
            var n = t.previewObj.url + "&pictype=scaled&size=50*50";
            var i = new Image();
            i.onload = function() {
                a.find(".files-pic").css("background-image", "url(" + n + ")").addClass("thumb");
            };
            i.onerror = function() {
                console.log("缩略图加载失败!", n);
            };
            i.src = n;
            report("imgurl");
        }
    });
    w.bind("file.dataUpdate", function(e, t) {
        var a = $("#" + t.domid);
        if (t.remoteType === 1) {
            a.removeClass("temp");
        }
        if (t.newFilePath) {
            a.attr("data-path", t.newFilePath);
        }
        a.find(".file-info .name").text(t.fnameEsc);
    });
    var k = function q() {
        var e = G.module();
        var t = function r(e) {
            return '<section class="file-list" id="' + e + '"></section>';
        };
        var a = function o() {
            var e = c.getData(G.nowFolder);
            var a = e.domid;
            var n = $("#list" + a);
            if (n.length > 0) {
                return n;
            } else {
                p.after(t("list" + a));
                n = $("#list" + a);
                return n;
            }
        };
        var n = function l() {
            var e = $("#searchFileDom");
            if (e.length > 0) {
                return e;
            } else {
                p.after(t("searchFileDom"));
                e = $("#searchFileDom");
                return e;
            }
        };
        var i = function s() {
            var e = $("#userFileDom");
            if (e.length > 0) {
                return e;
            } else {
                p.after(t("userFileDom"));
                e = $("#userFileDom");
                return e;
            }
        };
        $(".file-list").hide();
        switch (e) {
          case 0:
            return p.show();
            break;

          case 1:
            return a().show();
            break;

          case 3:
            return n().show();
            break;

          case 2:
            return i().show();
            break;
        }
    };
    G.getDomPanel = k;
    function y() {
        if (G.nowFolder !== "/" && G.mac) {
            if (G.info.isAdmin) {
                $("#createFolder").show();
            } else {
                $("#box").addClass("one");
            }
            return;
        }
        v.text(G.file.allnum).attr("aria-label", "共" + G.file.allnum + "个文件");
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        h.css("width", e + "%");
        if (G.file.capacityused) {
            m.text(G.file.capacityused + "/" + G.file.capacitytotal);
        } else {
            m.text("未知/未知");
        }
        if (G.nowFolder === "/") {
            $("#fileNum").removeClass("hide");
        }
        if (G.info.isAdmin) {
            $("#createFolder").show();
        } else {
            $("#box").addClass("one");
        }
    }
    function x(e) {
        var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        var a = true;
        return function(e) {
            A(true);
            var n = k();
            if (!e || e.file.length === 0 && e.folder.length === 0) {
                F();
                y();
                a = false;
                return;
            }
            b = false;
            if (G.info.isVisitor) {
                t.actionHide = true;
            }
            var i = l({
                list: e.file,
                renderParams: t
            });
            var r = l({
                list: e.folder,
                renderParams: t
            });
            if (a) {
                y();
                a = false;
                n.html(r);
                n.append(i);
            } else {
                var o = $(".fold").last();
                if (o.length > 0) {
                    o.after(r);
                } else {
                    n.append(r);
                }
                n.append(i);
            }
            n.find(".list-item").each(function(e) {
                this.setAttribute("idx", e);
            });
            if (!window._timePoints["show"]) {
                savePoint("show");
                var s = {
                    20: window._timePoints["css"],
                    21: window._timePoints["zepto"],
                    22: window._timePoints["js"],
                    23: window._timePoints["start"]
                };
                if (localVersion === "isLocal") {
                    s[25] = window._timePoints["show"];
                } else if (typeof nodeCost !== "undefined") {
                    s[26] = window._timePoints["show"];
                } else {
                    s[24] = window._timePoints["show"];
                }
                QReport.huatuo({
                    appid: 10016,
                    flag1: 1772,
                    flag2: 1,
                    flag3: 1,
                    speedTime: s
                });
            }
        };
    }
    function F() {
        var e = G.getDomPanel();
        if (!e.find(".list-item").length) {
            var t = s();
            e.html(t);
        }
    }
    function T(e) {
        if (G.nowFolder !== "/") {
            return;
        }
        var t = l({
            list: [ e ]
        });
        if (p.find(".icons-empty").length === 0) {
            p.prepend(t);
        } else {
            p.html(t);
        }
    }
    function C(e) {
        if (e) {
            if (e.domid) {
                var t = e.domid;
                d.removeEase($("#" + t));
            } else if (e.id) {
                var a = e.id;
                d.removeEase($("[data-path=" + a + "]"));
            }
        }
        setTimeout(F, 500);
    }
    function S(e) {
        var t = G.getDomPanel();
        var a = t.find(".fold").last();
        var n = l({
            list: [ e ]
        });
        if (G.info.version < G.folderVersion) {
            if (e.parentId === "/" && G.nowFolder === "/") {
                if (a.length) {
                    a.after(n);
                } else {
                    t.prepend(n);
                }
            }
        } else {
            if (a.length) {
                a.after(n);
            } else if (G.folder !== "/" && t.find(".icons-empty").length === 0) {
                t.prepend(n);
            } else {
                t.html(n);
            }
        }
        g.renderSpace();
    }
    function M(e) {
        var t = $("#folder" + e.folderid);
        var a = l({
            list: [ e ]
        });
        t.prepend(a);
    }
    function j(e) {
        if (e) {
            var t = e.domid;
            console.log(t);
            d.removeEase($("#" + t));
        }
        setTimeout(F, 500);
    }
    function R(e) {
        if (e.orcType === 2) {
            C(e);
        } else {
            j(e);
        }
    }
    var D = function z() {
        var e = {
            filterUin: G.info.uin,
            filterCode: 4
        };
        var t = o.getList(e);
        t(function(e) {
            u.firstRender();
        }, function(e) {});
    };
    function O(e, t) {
        o.setAllSpace(function(t) {
            P();
            e && e(t);
        }, t);
    }
    function P() {
        if (G.nowFolder !== "/") {
            return;
        }
        m.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        if (G.file.capacitytotal) {
            $("#ariaSpace").attr("aril-label", "已用容量" + G.file.capacityused + "共" + G.file.capacitytotal);
        } else {
            $("#ariaSpace").attr("aril-label", "已用容量未知G,共未知G");
        }
        var e = parseInt(G.file.cu / G.file.ct * 100);
        h.css("width", e + "%");
        $("#fileNum").removeClass("hide");
    }
    function L(e) {
        var t = e || {};
        var a = t.container || "#folderOrSearchResult";
        var n = t.succ;
        var r = t.searchParams || {};
        var o = (0, i.default)(r);
        if (G.searchFuncSingtons[o] == undefined) {
            G.searchFuncSingtons[o] = f.search(r);
        }
        G.searchFuncSingtons[o](function(e) {
            if (G.renderListFuncSingtons[folderId] == undefined) {
                G.renderListFuncSingtons[folderId] = x(a);
            }
            G.renderListFuncSingtons[folderId](e);
            n && n(e);
        }, function() {});
    }
    var I = function B() {
        var e = false;
        var t = void 0;
        return function(a) {
            var n = a || {};
            var r = n.paramsFilter || {};
            var l = n.container || "#fileListDom";
            var s = n.succ;
            var f = n.fail;
            e = (0, i.default)(t) !== (0, i.default)(r);
            var c = t = r;
            $("body").attr("data-mode", "folder");
            if (G.nowFolder !== "/") {
                $("body").addClass("folder-module");
            } else {
                $("body").removeClass("folder-module");
            }
            return G.scrollHandler(function() {
                if (e || G.getListFuncSingtons[c] == undefined) {
                    G.getListFuncSingtons[c] = o.getList(r);
                }
                G.getListFuncSingtons[c](function(t) {
                    if (e || G.renderListFuncSingtons[c] == undefined) {
                        e = false;
                        G.renderListFuncSingtons[c] = x(l, n.renderParams);
                    }
                    if (r.filterCode === 3) {
                        var a = t.file;
                        for (var i = a.length - 1; i >= 0; i--) {
                            var o = a[i];
                            if (o.parentId && G.folderMap()[o.parentId]) {
                                t.file[i].folderName = G.folderMap()[o.parentId].fnameEsc;
                            }
                        }
                    }
                    G.renderListFuncSingtons[c](t);
                    A(true);
                    s && s(t);
                }, function(e) {
                    A(true);
                    e && console.log(e);
                    if (e.ec !== 1e3) {
                        var t = "拉取文件列表失败";
                        if (b) {
                            if (G.mac) {
                                t += "，请稍后重试";
                            } else {
                                t += '，请稍后<a onclick="window.location.reload();">重试</a>';
                            }
                        }
                        w.trigger("toast.show", {
                            type: "fail",
                            text: t,
                            autoHide: !b
                        });
                    }
                    if (e && e.fc && e.fc === 1) {
                        return;
                    }
                }, function(e) {
                    return function() {
                        e();
                    };
                }(A));
            });
        };
    }();
    function N(e) {
        I(e)();
        D();
        if (!G.file || !G.file.ct) {
            O();
        }
    }
    function E(e) {
        var t = void 0;
        if (e.orcType === 1) {
            t = $('.list-item[data-path="' + e.filepath + '"]');
            t.find(".downloadtime").text(e.down + "次下载");
        } else {
            t = $("#" + e.domid);
            if (e.toFirst) {
                t.remove();
                T(e);
                return;
            } else {
                t = $("#" + e.domid);
                if (e.filenum) {
                    t.find(".file-size").text(e.filenum + "个文件").attr("title", e.filenum + "个文件");
                }
            }
            t.find(".uploadtime").text(e.mtStr + " 更新").attr("title", e.mtStr + " 更新");
        }
        if (e.status !== "downloadcomplete") {
            t.find(".name").html(e.name);
        }
        if (e.status === "uploadcomplete" || e.status === "downloadcomplete") {
            t.addClass("succ");
            var a = "打开";
            if (G.mac) {
                a = "";
            }
            t.find(".btn-left").removeClass("downing").addClass("open").html('<i class="open"></i>' + a);
            if (e.orcType === 1) {
                t.find(".btn-left").attr("data-action", "file.openFolder");
            }
        } else if (!e.isDown && !e.isDowning) {
            if (e.orcType === 1) {
                var n = "下载";
                if (G.mac) {
                    n = "";
                }
                t.find(".btn-left").attr("data-action", "file.download").removeClass("open").addClass("down").html('<i class="down"></i>' + n);
            }
            t.removeClass("succ");
        } else if (e.isDowning) {
            if (G.mac) {
                t.find(".btn-left").addClass("downing");
            } else {
                t.find(".btn-left").addClass("downing").html("下载中");
            }
        }
    }
    function A(e) {
        if (!_) {
            $("body").append('<div class="loader" id="loaderDom"><div class="loading"></div></div>');
            _ = $("#loaderDom");
        }
        if (e) {
            _.removeClass("open");
        } else {
            _.addClass("open");
        }
    }
    e.exports = {
        init: N,
        appendFold: T,
        removeFold: C,
        appendFile: S,
        appendFileToFolder: M,
        updateRow: E,
        search: L,
        renderSpace: P,
        removeRow: R,
        getList: I,
        renderList: x,
        showLoad: A,
        getDomPanel: k
    };
}, function(e, t, a) {
    "use strict";
    var n = a(38);
    var i = $(G.handler);
    var r = function l() {
        n.getFileCount(function(e) {
            if (G.file.isFull) {
                $(".icons-upload-1").addClass("disabled");
                $(".icons-new-folder-1").addClass("icons-new-folder-2");
                o();
            } else {
                $(".icons-upload-1").removeClass("disabled");
                $(".icons-new-folder-1").removeClass("icons-new-folder-2");
                o();
            }
        });
    };
    var o = function s(e) {
        if (G.file.isTooMany) {
            $("#alertTips").addClass("not-opacity");
            if (!G.info.isAdmin) {
                $("#alertTips").html('<div class="more-file-info"><i class="icons-alert"></i>文件数已超出上限，无法显示文件夹。</div><div class="more-file-tips">请提醒群主或管理员清除</div>');
            } else if (G.info.isMaster) {
                $("#alertTips").html('<div class="more-file-info"><i class="icons-alert"></i>文件数已超出上限，无法显示文件夹。</div><div class="more-file-tips">请自行清理或<a class="auto-delete-file" data-action="file.autoClear">自动删除旧文件</a></div>');
            } else if (G.info.isAdmin) {
                $("#alertTips").html('<div class="more-file-info"><i class="icons-alert"></i>文件数已超出上限，无法显示文件夹。请尽快处理</div>');
            }
        } else {
            $("#alertTips").html('<a href="http://kf.qq.com/faq/120511jiYzIJ140828eimiAR.html" target="_blank" data-action="tips.close">【网络正能量倡议书】腾讯呼吁网友共建绿色QQ群 抵制色情、反动等违法信息。</a><div class="close" data-action="tips.close"></div>').removeClass("not-opacity");
        }
    };
    i.bind("filecount.getrole", o);
    e.exports = {
        init: r
    };
}, function(e, t, a) {
    "use strict";
    var n = a(37);
    var i = l(n);
    var r = a(25);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    e.exports = function() {
        var e = function y(e) {
            var t = new RegExp("(?:^|;+|\\s+)" + e + "=([^;]*)"), a = document.cookie.match(t);
            return !a ? "" : a[1];
        };
        var t = function x() {
            var t = e("uin");
            if (!t) {
                return 0;
            }
            t += "";
            return t.replace(/^[\D0]+/g, "");
        };
        var a = function F(e, t) {
            t = t || location.href;
            var a = new RegExp("(\\?|#|&)" + e + "=([^&^#]*)(&|#|$)"), n = t.match(a);
            return decodeURIComponent(!n ? "" : n[2]);
        };
        var n = function T(e) {
            e += "";
            return e.replace(/^[ 　]*/gi, "");
        };
        var r = function C(e, t) {
            var a = t || 3;
            e += "";
            e = n(e);
            var i = e.match(/[^\x00-\xff]/g) || [];
            var r = e.replace(/[^\x00-\xff]/g, "");
            return parseInt(i.length * a + r.length);
        };
        function l(e, t) {
            var a = 0;
            for (var n = 0; n < e.length; n++) {
                var i = e.charAt(n);
                encodeURI(i).length > 2 ? a += 1 : a += .5;
                if (a >= t) {
                    var r = a == t ? n + 1 : n;
                    return e.substr(0, r);
                    break;
                }
            }
            return e;
        }
        function s(e) {
            var t = 0;
            for (var a = 0; a < e.length; a++) {
                var n = e.charAt(a);
                encodeURI(n).length > 2 ? t += 1 : t += .5;
            }
            return t;
        }
        var f = function S(e, t, a) {
            var n = r(e, 3);
            if (n < t || n > a) {
                return false;
            }
            return true;
        };
        var c = function $(e, t) {
            var t = t || 10;
            var a = r(e);
            var n = t - a;
            return n >= 0 ? n : 0;
        };
        var d = function M(e, t) {};
        window.onerror = function(e, t, a) {};
        function u(e) {
            if (e && e.length > 0) {
                e.addClass("remove-ease");
                setTimeout(function() {
                    e.remove();
                }, 300);
            }
        }
        var p = function j(e, t) {
            return function(a) {
                var n = arguments.length;
                if (t) a = Object(a);
                if (n < 2 || a == null) return a;
                for (var i = 1; i < n; i++) {
                    var r = arguments[i], o = e(r), l = o.length;
                    for (var s = 0; s < l; s++) {
                        var f = o[s];
                        if (!t || a[f] === void 0) a[f] = r[f];
                    }
                }
                return a;
            };
        };
        var v = function R(e) {
            var t = typeof e === "undefined" ? "undefined" : (0, o.default)(e);
            return t === "function" || t === "object" && !!e;
        };
        var m = function D(e) {
            if (!v(e)) return [];
            var t = [];
            for (var a in e) {
                t.push(a);
            }
            return t;
        };
        var h = p(m);
        function g() {
            var e = {};
            var t = (0, i.default)(G.folderMap());
            for (var a = t.length - 1; a >= 0; a--) {
                var n = G.folderMap()[t[a]];
                if (n) {
                    e[n.fnameEsc] = n;
                }
            }
            var r = "新建文件夹";
            var o = 1;
            while (e[r] !== undefined) {
                r = "新建文件夹(" + o + ")";
                o++;
            }
            return r;
        }
        var w = function O(e, t) {
            if (e.length <= 1) {
                return e;
            }
            var a = Math.floor(e.length / 2);
            var n = e.splice(a, 1)[0];
            var i = [];
            var r = [];
            for (var o = 0; o < e.length; o++) {
                if (e[o]) {
                    if (e[o][t] > n[t]) {
                        i.push(e[o]);
                    } else {
                        r.push(e[o]);
                    }
                }
            }
            return O(i, t).concat([ n ], O(r, t));
        };
        function b(e, t) {
            t.map(function(e) {
                return e.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1");
            });
            var a = "(" + t.join("|") + ")";
            var n = e.split(new RegExp(a, "i"));
            return n;
        }
        function _(e, t) {
            for (var a = t.length - 1; a >= 0; a--) {
                t[a] = ("" + t[a]).toUpperCase();
            }
            var n = [];
            for (var i = e.length - 1; i >= 0; i--) {
                if (t.indexOf(e[i].toUpperCase()) !== -1) {
                    n[i] = '<span class="match-word">' + e[i] + "</span>";
                } else {
                    n[i] = e[i];
                }
            }
            return n.join("");
        }
        function k(e, t) {
            var a = b(e, t);
            return _(a, t);
        }
        return {
            getCookie: e,
            getUin: t,
            getParameter: a,
            getLen: r,
            changeLen: c,
            checkLength: f,
            checkLen: d,
            extend: h,
            removeEase: u,
            subString: l,
            quickSortByObjectAttr: w,
            getFolderNameDefault: g,
            heightLight: k
        };
    }();
}, function(e, t, a) {
    "use strict";
    var n = a(39).getHandlerTasks();
    var i = a(77);
    var r = a(78);
    var o = $(G.handler);
    function l(e) {
        var t = $(this).data("action");
        if (t == "folder.download") {
            console.log(this.getBoundingClientRect());
        }
        if (t) {
            var a = n[t];
            if (typeof a === "function") {
                a.call(this);
            }
        } else {
            o.trigger("box.hide");
        }
    }
    function s(e) {
        var t = $(this).data("keyup");
        if (t) {
            var a = n[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function f(e) {
        var t = $(this).data("keydown");
        if (t) {
            var a = n[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function c(e) {
        var t = $(this).data("blur");
        if (t) {
            var a = n[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function d() {
        this.inputStart = true;
    }
    function u() {
        var e = this;
        setTimeout(function() {
            e.inputStart = false;
        }, 200);
    }
    function p(e) {
        var t = $(e.target);
        if (t.parents("#box").length === 0 && t.data("action") !== "box.toggle") {
            o.trigger("box.hide");
        }
    }
    function v(e) {
        var t = $(this).data("focus");
        if (t) {
            var a = n[t];
            if (typeof a === "function") {
                a.call(this, event);
            }
        }
    }
    function m() {
        $(document).on("click", "[data-action]", l);
        $("body").on("click", p);
        $(document).on("keyup", "[data-keyup]", s);
        $(document).on("keydown", "[data-keydown]", f);
        $(document).on("focus", "[data-focus]", v);
        $(document).on("blur", "[data-blur]", c);
        $(document).on("compositionstart", "[data-cstart]", d);
        $(document).on("compositionend", "[data-cend]", u);
        $("body").on("click", function(e) {
            i["menu.hide"](e.target);
        });
        $(window).on("load", function() {
            $(".scroll-dom").scroll(function() {
                var e = $(window);
                var t = e.height();
                var a = $(".scroll-dom").scrollTop();
                var n = $(".scroll-dom .file-list:visible").children(".list-item");
                var i = n.length * n.first().height();
                var r = 30;
                if (r + a >= i - t) {
                    G.scrollHandler && G.scrollHandler();
                }
            });
        });
    }
    e.exports = {
        init: m
    };
}, function(e, t, a) {
    "use strict";
    var n = a(25);
    var i = l(n);
    var r = a(26);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = a(40);
    var f = a(41);
    var c = a(98);
    var d = a(35);
    var u = a(10);
    var p = a(8);
    G.renderOtherGroupResultFuncSingtons = {};
    function v(e) {
        e = u.extend({
            selfGroupResultNum: 0,
            otherGroupResultNum: 0
        }, e);
        var t = [ '<div class="search-empty"><div class="search-icon-dom">', '<div class="icons-search-empty"></div>', '<span class="empty-desc">很遗憾，', '没有找到与"', G.searchKeyword, '"相关的文件</span></div></div>' ];
        if (e.selfGroupResultNum === 0 && e.otherGroupResultNum !== 0) {
            t[1] = "";
            t[3] = "在本群中" + t[3];
            t[0] = '<div id="selfNoResult" class="search-empty"><div>';
        }
        if (e.selfGroupResultNum !== 0 && e.otherGroupResultNum === 0) {
            t[1] = "";
            t = [ '<div id="otherNoResult" class="search-empty"><div >', "</div></div>" ];
        }
        var a = t.join("");
        return a;
    }
    function m(e) {
        var t = $(".other-group-result-desc");
        t.prev().find("dl").css("border-bottom-width", e);
        t.prev().find("div").css("border-bottom-width", e);
    }
    function h() {
        var e = true;
        var t = {
            dataSelfGroupLen: 0,
            dataOtherGroupLen: 0
        };
        return function(a, n) {
            var i = G.getDomPanel();
            if (!a || !n) {
                return;
            }
            t["dataSelfGroupLen"] += a.length;
            t["dataOtherGroupLen"] += n.length;
            var r = v({
                selfGroupResultNum: t.dataSelfGroupLen,
                otherGroupResultNum: t.dataOtherGroupLen
            });
            var o = void 0;
            if (t["dataSelfGroupLen"] !== 0) {
                o = c({
                    list: a,
                    renderParams: {
                        actionHide: false,
                        getByUinHide: false,
                        searchModule: true
                    },
                    batchMode: false
                });
            } else {
                o = r;
            }
            var l = c({
                list: n,
                renderParams: {
                    actionHide: true,
                    getByUinHide: true
                },
                batchMode: false
            });
            var s = '<div class="other-group-result-desc"><span>其他群搜索结果</span></div>';
            if (parseInt($("#searchReasult").text()) === t.dataSelfGroupLen) {
                l = r;
                s = "";
            }
            if (t.dataSelfGroupLen == 25 && t.dataOtherGroupLen === 0) {
                l = "";
            }
            if (G.mac) {
                s = "";
            }
            if (e) {
                report("showSearchRes");
                i.html("");
                var f = [ o, s, l ];
                var d = "100%";
                if (t.dataSelfGroupLen === 0 && t.dataOtherGroupLen === 0) {
                    f = [ r ];
                } else if (t.dataSelfGroupLen === 0 && t.dataOtherGroupLen !== 0) {
                    d = "200px";
                }
                i.html(f.join(""));
                $(".search-empty").css("height", d).attr("data-len", t.dataSelfGroupLen);
                m(0);
                e = false;
                if (t.dataSelfGroupLen !== 0 && t.dataOtherGroupLen === 0) {
                    var u = i.height() - t.dataSelfGroupLen * 64 - 25;
                    if (u < 200) {
                        u = 200;
                    }
                    $("#otherNoResult").css("height", u + "px");
                }
            } else {
                var p = $(".other-group-result-desc");
                m("1px");
                if (t.dataSelfGroupLen === 0) {
                    o = "";
                }
                p.before(o);
                i.append(l);
                if (t.dataSelfGroupLen !== 0 && t.dataOtherGroupLen === 0) {
                    var h = i.height() - t.dataSelfGroupLen * 64 - 25;
                    if (h < 200) {
                        h = 200;
                    }
                    $("#otherNoResult").css("height", h + "px");
                }
                m(0);
            }
        };
    }
    function g() {
        var e = false;
        var t = undefined;
        return function(a, n) {
            var r = G.searchKeyword = $.trim($("#inputSearch").val()) || "";
            if (!(a && a.keyCode == 13 || a == undefined) || r === "") {
                return;
            }
            report("doSearch");
            $("body").attr("data-mode", "search");
            G.scrollHandler(function() {
                var a = G.searchKeyword = $("#inputSearch").val() || "";
                var r = {
                    key_word: a
                };
                e = G.module() !== 3 || (0, o.default)(t) != (0, o.default)(r);
                G.module(3);
                t = r;
                var l = function m(t, a) {
                    console.log(a);
                    if (e || G.renderListFuncSingtons[a] == undefined) {
                        G.renderListFuncSingtons[a] = h();
                    }
                    function i(e) {
                        e = e || [];
                        function t(e) {
                            return e.gc === G.info.gc;
                        }
                        function a(e) {
                            return e.gc !== G.info.gc;
                        }
                        var n = {
                            ut: "upload_time",
                            owner_name: "uin_name"
                        };
                        var i = function r(e) {
                            var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
                                filters: {
                                    selfGroupFilter: function r() {},
                                    otherGroupFilter: function o() {}
                                }
                            };
                            function a(e, t, a) {
                                e = e.filter(t);
                                var i = {};
                                for (var r = e.length - 1; r >= 0; r--) {
                                    var o = e[r];
                                    i[o.id] = o;
                                }
                                var l = d.setFileList(e, n);
                                var s = l.file;
                                for (var f = s.length - 1; f >= 0; f--) {
                                    var c = s[f].fp;
                                    var p = G.fileMap()["/" + s[f].busid + c];
                                    var v = i[c].match_word;
                                    s[f].name = u.heightLight(p.name, v);
                                    s[f].suf = u.heightLight(p.suf, v);
                                    if (a) {
                                        s[f].otherGroupName = i[c]["group_name"];
                                        s[f].gc = i[c]["gc"];
                                    }
                                }
                                return s;
                            }
                            var i = {
                                selfGroupResult: a(e, t.filters.selfGroupFilter),
                                otherGroupResult: a(e, t.filters.otherGroupFilter, true)
                            };
                            return i;
                        };
                        return i(e, {
                            filters: {
                                selfGroupFilter: t,
                                otherGroupFilter: a
                            }
                        });
                    }
                    var r = i(t.file_list);
                    G.renderListFuncSingtons[a](r.selfGroupResult, r.otherGroupResult);
                    n && n();
                    p.showLoad(true);
                };
                var f = {
                    succ: function g(e, t) {
                        l(e, t);
                    },
                    fail: function w() {
                        if (e) {
                            var t = "100%";
                            var a = G.getDomPanel();
                            a.html(v());
                            $(".search-empty").css("height", t || "160px");
                        }
                        p.showLoad(true);
                    },
                    beforeRequest: function(e) {
                        return function() {
                            e();
                        };
                    }(p.showLoad),
                    searchParams: r,
                    isNew: e
                };
                if ((typeof nodeData === "undefined" ? "undefined" : (0, i.default)(nodeData)) === "object") {
                    var c = {
                        key_word: nodeData.key_word,
                        search_type: 0,
                        app_id: 4
                    };
                    l(nodeData, c);
                    nodeData = false;
                } else {
                    s.search(f);
                }
            });
            G.scrollHandler();
        };
    }
    e.exports = {
        search: g()
    };
}, function(e, t, a) {
    "use strict";
    var n = a(41);
    var i = a(42);
    var r = $(G.handler);
    var o = function f() {
        n.checkVip().done(function(e) {
            if (e && e.vinfo && e.vinfo.supervip) {
                G.flagIsVip = true;
            } else {
                G.flagIsVip = false;
            }
            i.showQQVip();
        }).fail(function(e) {
            i.showQQVip();
        });
    };
    var l = function c() {
        i.show();
        r.trigger("menu.hide");
    };
    var s = function d() {
        report("openVip");
        if (G.activeElement) {
            G.activeElement.focus();
        }
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    e.exports = {
        init: o,
        "vip.show": l,
        "vip.open": s
    };
}, function(e, t, a) {
    "use strict";
    var n = $("#folderPanel");
    var i = a(79);
    var r = a(43);
    var o = a(44);
    var l = a(45);
    var s = a(46);
    var f = a(47);
    var c = a(48);
    var d = a(49);
    var u = a(10);
    var p = a(80);
    var v = $(G.handler);
    var m = a(50);
    var h = a(7);
    function g() {}
    function w() {
        report("clkCreateFolder");
        if (G.file.isFull) {
            return h.show(G.mac ? "fail" : "alert", "文件数已达到上限");
        }
        if (!G.canCreateFolder) {
            v.trigger("toast.show", {
                type: "new-alert",
                text: "文件夹个数已达上限"
            });
            return;
        }
        i.show(n, {
            title: "新建文件夹",
            tips: "请输入文件夹名称",
            showValue: u.getFolderNameDefault(),
            action: "folder.createFolder"
        });
        $(".new-name").focus();
    }
    function b(e) {
        report("renameFolder");
        console.log(G.selectRow);
        i.show(n, {
            title: "重命名",
            tips: "请输入文件夹的新名称",
            action: "folder.renameFolder",
            showValue: G.selectRow.fnameEsc
        });
    }
    function _() {
        i.hide(n);
        if (G.activeElement) {
            G.activeElement.focus();
        }
    }
    function k() {}
    function y() {}
    function y() {
        n.find(".btn-ok").attr("data-action", "folder.createOK");
    }
    function x() {
        if (event && event.keyCode !== 13) {
            m["input.keyup"].call(this, event);
            return;
        }
        var e = $('[data-keyup="folderTree.create"]');
        if (!e.length) {
            callback && callback();
            return;
        }
        var t = e.val();
        var a = m.folderName(t);
        if (!a) {
            return;
        }
        r.createFolder();
    }
    e.exports = {
        "folder.openfolder": p.openByFolder,
        "folder.property": f.show,
        "folder.create": w,
        "folder.panelhide": _,
        "folder.show": k,
        "folder.showmove": y,
        "folder.toDelete": y,
        "folder.createFolder": r.createFolder,
        "folder.deleteFolder": o.deleteFolder,
        "folder.renameFolder": l.renameFolder,
        "folder.showDeleteFolder": o.showDeleteFolder,
        "folder.showRenameFolder": b,
        "folder.open": c.renderFolder,
        "folder.download": s.download,
        "input.createFolder": x
    };
}, function(e, t, a) {
    "use strict";
    var n = a(61);
    var i = a(62);
    var r = a(80);
    var o = a(63);
    var l = a(64);
    var s = a(65);
    var f = a(66);
    var c = a(67);
    var d = a(68);
    var u = a(69);
    var p = a(70);
    var v = a(71);
    var m = a(72);
    var h = a(73);
    var g = a(74);
    var w = a(75);
    var b = a(35);
    function _() {
        var e = $(this).parents(".list-item");
        var t = e.data("path");
        var a = void 0;
        var n = b.getData(t);
        if (n.orcType === 2) {
            a = "fold";
        } else if (n.orcType == 1) {
            a = "file";
        }
        G.selectRow = n || {};
        G.selectRow.path = t;
        G.selectRow.type = a;
        G.selectRows = [ G.selectRow ];
    }
    e.exports = {
        "file.batchDelete": v.remove,
        "batch.removeAction": v.removeAction,
        "file.batchMove": v.move,
        "file.batchDownload": v.down,
        "batch.downloadAction": v.downloadAction,
        "file.batchSaveAs": v.save,
        "file.selectAll": p.selectAll,
        "file.select": p.select,
        "file.check": p.check,
        "file.exitBatch": p.exit,
        "file.upload": i.upload,
        "file.batchUpload": i.bupload,
        "file.openFolder": r.openByPath,
        "file.openFolderInBox": r.openByMenu,
        "file.showRename": o.showFileRename,
        "file.renameFile": o.renameFile,
        "file.saveAs": m.save,
        "file.download": l.download,
        "file.downloadBatch": l.downloadBatch,
        "file.preview": c.preview,
        "file.menupreview": c.menupreview,
        "file.jubao": u,
        "file.permanent": g,
        "file.delete": f.removeOne,
        "file.deleteBatch": f.removeBatch,
        "file.forward": s.forward,
        "file.forwardMobile": s.toMobile,
        "file.showUpload": i.showUpload,
        "file.showMove": d.showMove,
        "file.move": d.move,
        "upload.noTips": i.noTips,
        "upload.cUpload": i.cupload,
        "file.getByUin": h.byUin,
        "file.getAttr": w,
        "qq.update": i.update,
        "file.aria": _,
        "file.autoClear": n.clickClearFile,
        "file.doClearFile": n.doClearFile
    };
}, , , , , , , , , , function(e, t, a) {
    "use strict";
    t.__esModule = true;
    var n = a(29);
    var i = s(n);
    var r = a(28);
    var o = s(r);
    var l = typeof o.default === "function" && typeof i.default === "symbol" ? function(e) {
        return typeof e;
    } : function(e) {
        return e && typeof o.default === "function" && e.constructor === o.default && e !== o.default.prototype ? "symbol" : typeof e;
    };
    function s(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    t.default = typeof o.default === "function" && l(i.default) === "symbol" ? function(e) {
        return typeof e === "undefined" ? "undefined" : l(e);
    } : function(e) {
        return e && typeof o.default === "function" && e.constructor === o.default && e !== o.default.prototype ? "symbol" : typeof e === "undefined" ? "undefined" : l(e);
    };
}, function(e, t, a) {
    e.exports = {
        "default": a(92),
        __esModule: true
    };
}, , function(e, t, a) {
    e.exports = {
        "default": a(95),
        __esModule: true
    };
}, function(e, t, a) {
    e.exports = {
        "default": a(94),
        __esModule: true
    };
}, , , function(e, t, a) {
    "use strict";
    var n = a(110), i = a(34);
    function r(e, t) {
        var a = t;
        if (!n.check(a)) {
            n.add(a);
        }
        i.addBoxRow(a);
    }
    $(G.handler).bind("client.addTask", r);
}, function(e, t, a) {
    "use strict";
    var n = a(110), i = a(34);
    function r(e, t) {
        var a = t;
        i.updateBoxRow(a);
    }
    $(G.handler).bind("client.updateTask", r);
}, function(e, t, a) {
    "use strict";
    var n = a(125);
    var i = a(10);
    var r = $("#boxNum");
    var o = $("#boxListDom");
    var l = $(G.handler);
    var s = false;
    var f = 0;
    var c = true;
    var d = false;
    function u(e) {
        var t = o.find('[data-path="' + e + '"]');
        if (t.length > 0 && !t.hasClass("complete")) {
            return t;
        }
        return false;
    }
    function p(e) {
        var t = o.find('[data-id="' + e + '"]');
        if (t.length > 0 && !t.hasClass("complete")) {
            return t;
        }
        return false;
    }
    function v(e) {
        if (e.type === 1 || e.type === "upload") {
            return p(e.taskId);
        } else if (e.orcType === 2) {
            return p(e.taskId);
        } else {
            return u(e.filepath);
        }
    }
    function m(e) {
        var t = v(e);
        if (e.status === "remove") {
            f--;
            i.removeEase(t);
            b();
            return;
        }
        var a = n({
            list: [ e ]
        });
        if (t) {
            t.replaceWith(a);
        }
        if (e.status === "uploadcomplete" || e.status === "downloadcomplete") {
            $("#boxTitle").attr("class", "box-title tri");
            f--;
            b();
        }
    }
    function h(e) {
        var t = v(e);
        console.log("更新", e, t);
        d = true;
        if (t.length > 0) {
            return;
        }
        var a = n({
            list: [ e ]
        });
        s = true;
        f++;
        b();
        o.prepend(a);
        o.removeClass("empty");
    }
    function g(e) {}
    function w(e, t) {}
    function b() {
        if (f < 0) {
            f = 0;
        }
        if (f) {
            r.text(f).addClass("small");
        } else {
            r.text(f).removeClass("small");
        }
    }
    function _() {
        d = false;
    }
    function k(e, t) {
        var a = n(t);
        if (s) {
            o.append(a);
        } else {
            o.html(a);
        }
    }
    var y = function C(e) {
        var t = [];
        var a = [];
        for (var n = 0, i = e.length; n < i; n++) {
            if ($.inArray(e[n].id, t) < 0 && $.inArray(e[n].filepath, t) < 0) {
                if (e[n].id) {
                    t.push(e[n].id);
                }
                if (e[n].filepath) {
                    t.push(e[n].filepath);
                }
                a.push(e[n]);
            }
        }
        return a;
    };
    function x() {
        if (!c) {
            return;
        }
        c = false;
        var e = [];
        var t = G.cList;
        var a = G.pList;
        var n = G.compList;
        t = t.concat(a);
        var i = t.length;
        e = t;
        if (n) {
            e = t.concat(n);
        }
        e = y(e);
        f = i;
        b();
        k(null, {
            list: e
        });
        if (e.length > 0) {
            o.removeClass("empty");
        }
        if (n.length > 0) {
            $("#boxTitle").attr("class", "box-title tri");
        } else {}
    }
    function F() {
        i.removeEase(o.find(".complete"));
        if (G.mac) {
            var e = o.find(".err");
            var t = e.length;
            for (var a = 0; a < t; a++) {
                var n = e.eq(a);
                var r = n.data("id");
                l.trigger("task.removeOne", r);
                i.removeEase(n);
            }
        }
        setTimeout(function() {
            if (o.find(".file2").length === 0) {
                o.addClass("empty");
            }
        }, 500);
        $("#boxTitle").attr("class", "box-title empty");
    }
    function T(e) {
        var t = o.find('[data-path="' + e.filepath + '"]');
        t.find(".go-folder").addClass("disable");
    }
    e.exports = {
        updateBoxRow: m,
        addBoxRow: h,
        removeBoxRow: g,
        cleanBox: w,
        render: k,
        firstRender: x,
        updateBoxNum: b,
        clearComplete: F,
        removePoint: _,
        removeOpenFolder: T
    };
}, function(e, t, a) {
    "use strict";
    var n = a(25);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(113);
    var l = a(122);
    var s = a(170);
    var f = a(110);
    var c = a(165);
    var d = a(10);
    var u = a(36);
    var p = a(4);
    var v = $(G.handler);
    var m = {};
    var h = false;
    var g = $("#groupSize");
    var w = $("#groupSizeBar");
    function b() {
        if (G.nowFolder !== "/") {
            return;
        }
        g.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        w.css("width", e + "%");
        $("#fileNum").removeClass("hide");
    }
    e.exports = m;
    function _(e) {
        e += "";
        return e.replace(/\//gi, "-");
    }
    m.updateFile = function(e, t) {
        if (t === "rename" && e) {}
        if (t === "permanent" && e) {
            delete G.fileMap()[e.filepath];
            if (e.id) {
                delete G.fileMap()[e.id];
            }
            G.fileMap()[e.newFilePath] = e;
            e.filepath = e.newFilePath;
        }
    };
    m.updateFolder = function(e) {
        delete G.folderMap()[e.id];
        e.modify_time = Math.ceil(new Date().getTime() / 1e3);
        e.mt = e.modify_time;
        e.mtStr = l.getDateStr(e.modify_time);
        G.folderMap()[e.id] = e;
        return e;
    };
    m.filterFolder = function(e) {
        var t = {
            fname: e.name,
            fnameEsc: s.decode(e.name),
            name: e.name,
            id: e.id,
            icon: "folder",
            ct: e.create_time,
            ctStr: l.getDateStr(e.create_time),
            mt: e.modify_time,
            mtStr: l.getDateStr(e.modify_time),
            uin: e.owner_uin || G.info.uin,
            filenum: e.size,
            nick: e.owner_name || G.info.nickName,
            mnick: e.modify_name || G.info.nickName,
            muin: e.modify_uin || G.info.uin,
            orcType: e.type || 2,
            domid: _(e.id),
            downNum: 0
        };
        var a = p.check(t.id);
        if (a) {
            t.localpath = a;
            t.succ = true;
        }
        return t;
    };
    m.addData = function(e) {
        if (!e) {
            return;
        }
        if (e.orcType === 2) {
            G.folderMap()[e.id] = e;
        } else {
            G.fileMap()[e.filepath] = e;
        }
    };
    m.getData = function(e) {
        return G.folderMap()[e] || G.fileMap()[e] || false;
    };
    m.deleteData = function(e) {
        if (G.folderMap()[e]) {
            delete G.folderMap()[e];
        }
        if (G.fileMap()[e]) {
            var t = m.getFile(e);
            delete G.fileMap()(t.filepath);
            t.id && delete G.fileMap()(t.id);
        }
    };
    m.remove = function(e) {
        if (G.folderMap()[e]) {
            delete G.folderMap()[e];
        }
        var t = G.fileMap()[e];
        if (t) {
            t.isRemoved = true;
            delete G.fileMap()[e];
            delete G.fileMap()[t.filepath];
        }
    };
    m.getFile = function(e, t) {
        return G.fileMap()[e] || G.fileMap()[t] || false;
    };
    m.getTask = function(e) {
        return G.cMap[e] || false;
    };
    m.setAllNum = function(e) {
        var t = "total_cnt";
        if (!G.file) {
            G.file = {};
        }
        G.file.allnum = e.total || 0;
    };
    m.setFileCount = function(e) {
        if (!G.file) {
            G.file = {};
        }
        G.file.fileCount = e.file_count || 0;
        G.file.isTooMany = e.is_too_many;
        G.file.isFull = e.is_full;
    };
    m.setAllSpace = function j(e) {
        if (!G.file) {
            G.file = {};
        }
        G.file.capacitytotal = o.getSize(e.totalSpace);
        G.file.capacityused = o.getSize(e.usedSpace);
        G.file.ct = e.totalSpace;
        G.file.cu = e.usedSpace;
    };
    m.removeAllNum = function(e) {
        if (G.file.allnum) {
            G.file.allnum--;
        }
        if (e.remoteType === 1) {
            G.file.cu -= e.size;
            G.file.capacityused = o.getSize(G.file.cu);
        }
    };
    m.addAllNum = function(e) {};
    m.updateAllNum = function(e) {
        var t = {
            files: [],
            action: ""
        };
        e = d.extend(t, e);
        var a = e.action;
        var n = e.files;
        var i = 0;
        for (var r = n.length - 1; r >= 0; r--) {
            i += n[r].size;
        }
        if (a === "add") {
            G.file.allnum = G.file.allnum + n.length;
            G.file.cu += i;
        } else if (a === "remove") {
            G.file.allnum = G.file.allnum - n.length;
            G.file.cu -= i;
        } else {
            console.log("illegal action");
        }
        b();
    };
    m.setRole = function(e) {
        if (h) {
            return;
        }
        h = true;
        var t = e.userRole || 0;
        var n = e.openFlag || 0;
        var i = 0;
        var r = 0;
        var o = false;
        var l = e.userRole === 3 ? true : false;
        if (t >= 1 && t !== 4) {
            i = 1;
            t === 1 && (r = 1);
            o = true;
        } else if (t === 3 && n === 1) {
            l = true;
        }
        G.info.isAdmin = i;
        G.info.isMaster = r;
        G.info.isVisitor = l;
        G.info.isPublic = n;
        G.canCreateFolder = o;
        report("enter", n);
        report("showSearchBtn");
        var s = a(9);
        s.init();
        $("body").addClass("auth" + G.info.isAdmin);
    };
    function k(e) {
        var t = {};
        for (var a in e) {
            t[a] = e[a];
        }
        return t;
    }
    m.task2file = function(e) {
        var t = e;
        var a = t.filepath.substr(1, 3);
        a = parseInt(a);
        var n = parseInt(new Date().getTime() / 1e3, 10);
        var i = o.getFileName(t.filename);
        if (t.status !== "downloadcomplete") {
            t.name = i.filename_name;
            t.fname = t.filename;
            t.nameEsc = s.decode(i.filename_name);
            t.folderid = _(t.folderpath);
            t.down = 0;
            t.filepath = t.filepath;
            t.fp = t.filepath.substr(4);
            t.domid = _(t.filepath);
            t.busid = a;
            t.filetype = o.getType(i.filename_suc);
            t.uin = G.info.uin;
            t.nick = G.info.nickName;
            t.upsize = t.filesize;
            t.temp = a == 102 ? false : true;
            t.ttl = 86400;
            t.ct = n;
            t.ctStr = l.dayStr(n);
            t.mt = n;
            t.mtStr = l.dayStr(n);
            t.type = 1;
            t.succ = true;
            t.admin = true;
            t.isDown = true;
            t.remove = true;
            t.rename = true;
            t.size = t.size;
            t.remoteType = a === 102 ? 1 : 2;
            t.parentId = t.folderpath || "/";
        } else {
            var r = void 0;
            var f = t.id;
            if (t.downloadtasktype === 1) {
                r = k(G.folderMap()[t.filepath]);
            } else {
                r = k(G.fileMap()[t.filepath]);
            }
            t = $.extend(true, r, t);
            t.taskId = f;
            t.isDown = true;
            t.succ = true;
            t.domid = _(t.filepath);
        }
        if (G.cMap[t.id]) {
            delete G.cMap[t.id];
        }
        if (G.cMap[t.filepath]) {
            delete G.cMap[t.filepath];
        }
        if (t.orcType === 2) {
            t.id = t.filepath;
        }
        m.addData(t);
        return t;
    };
    m.setFileList = function(e, t) {
        if (!G.cMap) {
            G.cMap = {};
        }
        var a = [];
        var n = [];
        var i = [];
        var r = [];
        t = d.extend({
            fn: "name",
            t: "bus_id",
            uin: "owner_uin",
            dt: "download_times",
            ut: "create_time",
            mt: "modify_time",
            lp: "local_path",
            ufs: "upload_size",
            fp: "id",
            fs: "size",
            owner_name: "owner_name"
        }, t);
        var u = t.fn;
        var h = t.t;
        var g = t.uin;
        var w = t.dt;
        var b = t.ut;
        var k = t.mt;
        var x = t.lp;
        var F = t.ufs;
        var T = t.fp;
        var C = t.fs;
        var $ = t.owner_name;
        e = e || [];
        for (var M = 0, j = e.length; M < j; M++) {
            var R = e[M];
            if (R.type === undefined) {
                R.type = 1;
            }
            if (R.type === 1) {
                var D = o.getFileName(R[u]);
                var O = {
                    t: R[h],
                    exp: R.exp || 0,
                    lp: R[x],
                    busid: R[h],
                    fname: R[u],
                    fnameEsc: s.decode(R[u]),
                    name: D.filename_name,
                    nameEsc: s.decode(D.filename_name),
                    suf: D.filename_suf,
                    icon: o.getIcon(D.filename_suf),
                    domid: _("/" + R[h] + R[T]),
                    filepath: "/" + R[h] + R[T],
                    fp: R[T],
                    admin: false,
                    filetype: o.getType(D.filename_suf),
                    uin: R[g],
                    nick: R[$],
                    size: R[C],
                    sizeStr: o.getSize(R[C]),
                    upsize: R[F],
                    temp: R[h] === 104 ? true : false,
                    down: R[w],
                    ct: R[b],
                    ctStr: l.dayStr(R[b]),
                    mt: R[k],
                    parentId: R["parent_id"],
                    mtStr: l.dayStr(R[k]),
                    orcType: R.type,
                    safeType: R["safe_type"],
                    remove: false,
                    rename: false,
                    isDown: false
                };
                O.admin = y(R[g]);
                if (O.admin) {
                    O.remove = true;
                    O.rename = true;
                }
                O = S(O);
                var P = p.check(O.filepath);
                if (P) {
                    O.isDown = true;
                    O.localpath = P;
                    O.succ = true;
                    report("showOpenFile", G.module());
                } else {
                    report("showDownloadBtn", G.module());
                }
                if (O.safeType) {
                    var L = G.getReportInfo(O);
                    L.ver3 = L.ver4;
                    L.ver4 = L.ver5;
                    L.ver5 = L.ver6;
                    delete L.ver6;
                    reportNew("blackExp", L);
                }
                if (O.result === 3 && !G.previewCache[O.filepath]) {
                    a.push(O);
                }
                if (G.previewCache[O.filepath]) {
                    O.previewObj = G.previewCache[O.filepath];
                }
                G.fileMap()[O.filepath] = O;
                if (R[C] === R[F]) {
                    n.push(O);
                } else if (R[g] === G.info.uin) {
                    f.add(O);
                    i.push(O);
                }
            } else {
                var I = m.filterFolder(R);
                G.folderNum++;
                m.addData(I);
                r.push(I);
                report("showOpenFile", G.module());
            }
        }
        G.topFolder = {
            fname: "群文件",
            fnameEsc: "群文件",
            id: "/",
            icon: "folder",
            mt: 0,
            mtStr: 0,
            uin: 0,
            filenum: 0,
            nick: 0,
            type: 2
        };
        if (i.length > 0) {
            G.cList = i;
            v.trigger("box.renderNum");
        }
        if (a.length > 0) {
            c.getThumb(a);
        }
        if (r.length > 0) {
            report("folderNum", G.module(), r.length);
        }
        report("showSeeBtn", G.module());
        return {
            file: n,
            folder: r
        };
    };
    function y(e) {
        if (G.info.isAdmin || e === G.info.uin) {
            return true;
        } else {
            return false;
        }
    }
    function x(e) {
        if (G.info.isAdmin || e === G.info.uin) {
            return true;
        } else {
            return false;
        }
    }
    function F() {
        return !G.info.isVisitor;
    }
    var T = 1;
    var C = 2;
    function S(e) {
        var t = 0;
        if (!e || typeof e.name === "undefined") {
            console.log(!e, !e.name);
            return;
        }
        if (e.filepath) {
            e.filepath = e.filepath.replace(/\\\//g, "/");
        }
        if (!e.remoteType) {
            switch (e.busid) {
              case 102:
                e.remoteType = T;
                break;

              case 104:
              case 105:
                e.remoteType = C;
                break;

              default:
                e.remoteType = T;
            }
        }
        if (e.lp) {
            if (G.mac) {
                e.localpath = s.decode(e.lp);
            } else {
                e.localpath = s.decode(e.lp).replace(/\\|\//g, "\\\\");
            }
        }
        if (e.upsize < e.size) {
            if (e.uin === G.info.uin) {
                e.type = "continueupload";
                e.status = "continue";
                e.canContinueUpload = true;
                e.taskStarttime = e.ct;
                e.styles = "upload pause";
                e.csize = e.upsize;
                e.csizeStr = o.getSize(e.upsize);
                e.cPercent = 0;
                if (e.upsize && e.size) {
                    e.cPercent = 100 * e.upsize / e.size;
                }
                e.notComplete = true;
                e.result = 1;
                u.parse(e);
            }
        } else {
            e.result = 2;
            if (e.auditflag > 0) {
                console.warn("auditFlag", e);
            }
            var a = e.name;
            var n = e.size;
            var i = e.ct;
            if (!e.down) {
                e.down = 0;
            }
            if (e.filetype === "图片") {
                e.result = 3;
                if (!G.info.isVisitor) {
                    e.preview = true;
                }
            }
            if (e.remoteType === C && e.isAdmin) {
                e.canForever = true;
            }
            var r = 0;
            if (n < 1024 * 100) {
                r = 5;
            } else if (n < 1024 * 1024) {
                r = 4;
            } else if (n < 1024 * 1024 * 10) {
                r = 3;
            } else if (n < 1024 * 1024 * 50) {
                r = 2;
            } else if (n < 1024 * 1024 * 100) {
                r = 1;
            }
            var l = [];
            if (e.isAdmin) {
                e.canDelete = true;
                e.canRename = true;
                l.push("can_delete=1 ");
                l.push("can_rename=1 ");
            }
            if (e.preview) {
                l.push("can_preview=1 ");
            }
            if (e.canForever) {
                l.push("can_forever=1 ");
            }
            e.canDo = l.join("");
            e.showMore = "";
            if (e.canDo === "") {
                e.showMore = "disable_more";
            }
            e.sizeType = r;
            if (!e.styleTemp) {
                e.styleTemp = "";
            }
            if (!e.styleIssucc) {
                e.styleIssucc = "";
            }
            e.expireStr = "";
            e.fileTitle = e.filename;
            if (e.remotetype === C) {
                e.styleTemp = "temp";
                e.expireStr = d.getExpriesDayNum(e.ttl) + "天后到期";
                e.fileTitle += " (临时文件：剩余" + data.getExpriesDayNum(e.ttl) + "天)";
            }
        }
        return e;
    }
    var M = function() {
        var e = window.external && window.external.getPreviewSuffixConfig && window.external.getPreviewSuffixConfig();
        if (e === null) {
            e = {
                content: []
            };
        }
        if (typeof e === "string") {
            try {
                e = JSON.parse(e);
            } catch (t) {}
        }
        if ((typeof e === "undefined" ? "undefined" : (0, i.default)(e)) !== "object") {
            e = {
                content: []
            };
        }
        var a = {};
        if (e = e.content) {
            var n = function l(t, n) {
                var i = e[t].suffix, r = e[t].maxsize;
                var o = i.split(".");
                o.forEach(function(e, t, n) {
                    if (e) {
                        a[e] = r;
                    }
                });
            };
            for (var r = 0, o = e.length; r < o; r++) {
                n(r, o);
            }
        }
        return function(e, t) {
            var n = void 0;
            if ((n = a[e]) && t <= n) {
                return true;
            }
        };
    }();
    m.clearComplete = function() {
        f.clearComplete();
    };
}, function(e, t, a) {
    "use strict";
    var n = a(113);
    var i = a(111);
    var r = a(112);
    var o = {};
    var l = {};
    function s(e) {
        try {
            if (!e) {
                return;
            }
            if (!G.cMap) {
                G.cMap = {};
            }
            e.taskId = e.id;
            if (e.taskId) {
                G.cMap[e.taskId] = e;
            }
            if (e.filepath) {
                G.cMap[e.filepath] = e;
            }
            var t = i.getType(e.type);
            i.check(t, e.status);
            var a = i.getWord(t, e.status);
            var n = i.getClass(t, e.status);
            if (n === "scan") {
                if (e.cPercent) {
                    a += e.cPercent + "%";
                }
                e.cPercent = 0;
                n = "pre";
            } else if (n === "pre") {
                e.cPercent = 0;
            } else if (n === "pause" || n === "continue") {
                if (e.csizeStr) {
                    a += e.csizeStr;
                }
                if (e.sizeStr) {
                    a += "/" + e.sizeStr;
                }
            } else if (n === "err") {
                e.cPercent = 0;
                if (e.status.indexOf("securityfail") >= 0) {
                    a = "<i class='warn'></i>" + getErrorWording(e);
                    if (e.securityattri >= 1 && e.securityattri <= 5) {
                        a += "<i class='security'></i>";
                    }
                } else {
                    if (e.errorcode == -1e3) {
                        a = "该文件已被删除";
                    }
                    a = "<i class='warn'></i>" + a;
                }
            } else if (n === "progress") {
                if (e.speedStr) {
                    a += e.speedStr;
                }
                var r = void 0;
                if (e.speed) {
                    var l = Math.ceil((e.filesize - e.completesize) / e.speed);
                    var s = Math.floor(l / 3600);
                    var f = Math.floor(l % 3600 / 60);
                    l = Math.floor(l % 60);
                    if (s < 10) {
                        s = "0" + s;
                    }
                    if (f < 10) {
                        f = "0" + f;
                    }
                    if (l < 10) {
                        l = "0" + l;
                    }
                    r = "<span class='lefttime'>" + s + ":" + f + ":" + l + "</span>";
                } else {}
                if (o[e.filepath]) {
                    var c = new Date() - o[e.filepath];
                    if (c > 3e3 && r) {
                        a += r;
                    }
                } else if (e.filepath) {
                    o[e.filepath] = new Date();
                }
            } else if (n === "complete") {
                e.cPercent = 100;
                a += e.sizeStr;
            } else {
                e.c_percent = 0;
            }
            e.wording = a;
            e.styleType = t;
            if (t === "continueupload") {
                e.styleType = "upload";
            }
            e.styleStatus = n;
            if (e.failedFileList && e.failedFileList.length > 0) {
                e.styles = e.styleType;
            } else {
                e.styles = e.styleType + " " + e.styleStatus;
            }
        } catch (d) {
            console.warn("parse", d, e);
        }
    }
    function f(e) {
        e.taskId = e.id;
        if (e.downloadtasktype === 1) {
            e.filepath = e.folderpath;
            e.orcType = 2;
            e.icon = "folder";
            if (G.mac) {
                e.name = e.filename;
            } else {
                e.name = n.getFolderName(e.localpath);
            }
            e.filename = e.name;
            e.filelist = [];
            if (!e.status) {
                e.status = "downloadprogress";
            }
            e.filesize = e.foldersize;
        } else {
            e.orcType = 1;
        }
        if (!e.fnameEsc) {
            e.fnameEsc = e.filename;
        }
        e.speedStr = "";
        e.wording = "";
        e.csizeStr = "";
        e.updateFlag = true;
        var t = e.filename;
        var a = e.filesize;
        var i = e.createtime;
        e.speedStr = n.getSize(e.speed);
        if (e.speedStr === 0) {
            e.speedStr = "";
        } else {
            e.speedStr += "/S";
        }
        if (e.size === undefined) {
            e.size = e.completesize;
        }
        e.sizeStr = n.getSize(a);
        e.csizeStr = n.getSize(e.completesize);
        var r = 0;
        if (e.completesize > 0 && e.filesize > 0) {
            r = Math.round(e.completesize * 100 / e.filesize);
        }
        e.cPercent = r;
        var o = t.lastIndexOf(".");
        if (o >= 0) {
            e.name = t.substr(0, o);
            e.suf = t.substr(o);
        } else {
            e.name = t;
            e.suf = "";
        }
        if (!e.icon) {
            e.icon = n.getIcon(e.suf);
        }
        s(e);
        return e;
    }
    function c(e) {
        var t = [];
        for (var a in e) {
            var n = e[a];
            n = f(n);
            if (n.downloadtasktype !== 2) {
                t.push(n);
            } else {
                var i = u(n.fordertaskid);
                if (i) {
                    if (!i.fileTaskList) {
                        i.fileTaskList = [];
                    }
                    i.fileTaskList.push(n.id);
                }
            }
        }
        return t;
    }
    function d(e) {
        var t = [];
        for (var a in G.cMap) {
            var n = G.cMap[a];
            if (n.foldertaskid === e || n.folderpath === e) {
                t.push(n);
            }
        }
        return t;
    }
    function u(e) {
        return G.cMap[e] || false;
    }
    e.exports = {
        get: f,
        getFolderTask: d,
        getOneTask: u,
        parse: s,
        cleanMap: c
    };
}, function(e, t, a) {
    e.exports = {
        "default": a(96),
        __esModule: true
    };
}, function(e, t, a) {
    "use strict";
    var n = a(41);
    var i = a(35);
    var r = {};
    e.exports = r;
    r.getFileCount = function(e, t) {
        n.getFileCount().done(function(t) {
            i.setFileCount(t);
            e(t);
        }).fail(function(e) {
            console.log(e);
        });
    };
}, function(e, t, a) {
    "use strict";
    var n = [ a(14), a(15), a(77), a(114), a(115), a(116), a(117), a(12), a(50), a(118), a(13), a(119) ];
    function i() {
        var e = {};
        for (var t = 0; t < n.length; t++) {
            var a = n[t];
            var i = void 0;
            for (i in a) {
                if (a.hasOwnProperty(i)) {
                    e[i] = a[i];
                }
            }
        }
        e["tips.close"] = function() {
            $("#alertTips").remove();
        };
        return e;
    }
    e.exports = {
        getHandlerTasks: i
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = {};
    var l = a(41);
    var s = a(35);
    var f = a(10);
    e.exports = o;
    G.searchFuncSingtons = {};
    o.search = function c(e) {
        var e = e || {};
        var t = e.succ;
        var a = e.fail;
        var n = e.beforeRequest;
        var r = e.isNew;
        var o = f.extend({
            key_word: "",
            search_type: 0,
            app_id: 4
        }, e.searchParams);
        if (G.mac) {
            o.app_id = 7;
        }
        var s = false;
        var c = (0, i.default)(o);
        if (r || G.searchFuncSingtons[c] == undefined) {
            G.searchFuncSingtons[c] = function() {
                var e = 25;
                var t = undefined;
                var a = 0;
                return function(i, f) {
                    if (a) {
                        console.log("no more items");
                        return;
                    }
                    if (s === true) {
                        return;
                    }
                    o["cookie"] = t;
                    o["count"] = e;
                    n && n();
                    s = true;
                    l.search(o).done(function(e) {
                        if (r) {
                            $("#searchReasult").text(e.total);
                            $(".nav").addClass("hide");
                            $("#searchNav").removeClass("hide");
                        }
                        a = e.is_end;
                        t = e.cookie;
                        i && i(e, c);
                        s = false;
                        $("#navTopFolder").addClass("selected");
                    }).fail(function(e) {
                        f && f(e);
                        s = false;
                        $("#searchReasult").text(0);
                        $(".nav").addClass("hide");
                        $("#searchNav").removeClass("hide");
                        $("#navTopFolder").addClass("selected");
                    });
                };
            }();
        }
        G.searchFuncSingtons[c](t, a);
    };
    window.search = o.search;
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(120);
    var l = {};
    e.exports = l;
    var s = "//pan.qun.qq.com/cgi-bin/group_file/";
    var f = {
        checkVip: "//pan.qun.qq.com/cgi-bin/get_vip_id",
        checkOneFile: "//pan.qun.qq.com/cgi-bin/checkAuditFlag",
        rename: "//pan.qun.qq.com/cgi-bin/rename",
        list: "//pan.qun.qq.com/cgi-bin/filelist",
        path: "//pan.qun.qq.com/cgi-bin/thumbnail",
        del: "//pan.qun.qq.com/cgi-bin/del_bat",
        permanent: "//pan.qun.qq.com/cgi-bin/permanent"
    };
    var c = {
        getFileList: s + "get_file_list",
        renameFolder: s + "rename_folder",
        getFileInfo: s + "get_file_info",
        createFolder: s + "create_folder",
        deleteFolder: s + "delete_folder",
        renameFile: s + "rename_file",
        deleteFile: s + "delete_file",
        moveFile: s + "move_file",
        fileSearch: s + "search_file",
        getSpace: s + "get_group_space",
        previewFile: "//pan.qun.qq.com/cgi-bin/thumbnail",
        permanent: "//pan.qun.qq.com/cgi-bin/permanent",
        checkOneFile: "//pan.qun.qq.com/cgi-bin/checkAuditFlag",
        getFileAttr: s + "get_file_attr",
        checkVip: "//pan.qun.qq.com/cgi-bin/get_vip_info",
        getFileCount: s + "get_file_count",
        cleanFile: s + "clean_file"
    };
    l.setPermanent = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.permanent,
            type: "POST",
            data: e
        });
    };
    l.getFileList = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.getFileList,
            type: "GET",
            data: e
        });
    };
    l.deleteFile = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        if (e.bus_id) {
            e.file_list = (0, i.default)({
                file_list: [ {
                    gc: G.info.gc,
                    app_id: G.appid,
                    bus_id: e.bus_id,
                    file_id: e.file_id,
                    parent_folder_id: e.parent_folder_id
                } ]
            });
        }
        return o.ajax({
            url: c.deleteFile,
            type: "POST",
            data: e
        });
    };
    l.renameFile = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.renameFile,
            type: "POST",
            data: e
        });
    };
    l.moveFile = function(e) {
        var t = {};
        t.file_list = (0, i.default)({
            file_list: e
        });
        if (!t.gc) {
            t.gc = G.info.gc;
        }
        return o.ajax({
            url: c.moveFile,
            type: "POST",
            data: t
        });
    };
    l.createFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.createFolder,
            type: "POST",
            data: e
        });
    };
    l.deleteFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.createFolder,
            type: "POST",
            data: e
        });
    };
    l.renameFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.renameFolder,
            type: "POST",
            data: e
        });
    };
    l.deleteFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.deleteFolder,
            type: "POST",
            data: e
        });
    };
    l.getPreview = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.previewFile,
            type: "POST",
            data: e
        });
    };
    l.checkOneFile = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.checkOneFile + "?_=" + new Date().getTime(),
            type: "POST",
            data: e
        });
    };
    l.search = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.fileSearch,
            type: "GET",
            data: e
        });
    };
    l.getSpace = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.getSpace,
            type: "GET",
            data: e
        });
    };
    l.getFileAttr = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.getFileAttr,
            type: "GET",
            data: e
        });
    };
    l.checkVip = function() {
        var e = {
            gc: G.info.gc
        };
        return o.ajax({
            type: "GET",
            data: e,
            url: c.checkVip + "?_=" + new Date().getTime()
        });
    };
    l.getFileCount = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        if (!e.bus_id) {
            e.bus_id = 0;
        }
        return o.ajax({
            url: c.getFileCount,
            type: "GET",
            data: e
        });
    };
    l.cleanFile = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: c.cleanFile,
            type: "POST",
            data: e
        });
    };
}, function(e, t, a) {
    "use strict";
    var n = $("#qqVip");
    var i = $("#openVip");
    function r() {
        if (G.flagIsVip) {
            n.html('<i class="icons-vip"></i>极速下载特权</a>').addClass("is-vip");
        }
    }
    function o() {
        if (G.flagIsVip) {
            i.find(".tips-msg").text("尊贵的QQ超级会员，您已获得群文件极速下载特权，快去下载文件体验吧！");
            i.find(".btn-ok").remove();
        }
        i.addClass("open");
        i.find(".btn-ok").focus();
    }
    e.exports = {
        showQQVip: r,
        show: o
    };
}, function(e, t, a) {
    "use strict";
    var n = $("#folderPanel");
    var i = a(8);
    var r = a(121);
    var o = a(41);
    var l = a(79);
    var s = a(35);
    var f = a(9);
    var c = $(G.handler);
    function d() {
        var e = $.trim(n.find(".new-name").val());
        var t = {
            parent_id: "/",
            name: e
        };
        o.createFolder(t).done(function(e) {
            var t = s.filterFolder(e.folder_info);
            G.folderNum++;
            report("createFolderSuc");
            s.addData(t);
            i.appendFold(t);
            l.hideAll();
            c.trigger("toast.show", {
                type: "suc",
                text: "新建文件夹成功"
            });
            f.init();
        }).fail(function(e) {
            if (e.ec === 405) {
                G.canCreateFolder = false;
            }
            r.showError(e.ec, n);
            report("newFolderError");
        });
    }
    e.exports = {
        createFolder: d
    };
}, function(e, t, a) {
    "use strict";
    var n = a(8);
    var i = a(41);
    var r = a(35);
    var o = $(G.handler);
    var l = a(4);
    var s = a(9);
    function f(e) {
        if (e.errorCode === 0 && e.ret) {
            var t = {
                id: G.selectRow.id
            };
            i.deleteFolder(t).done(function(e) {
                if (e.ec) {
                    client.alert(2, "提示", "删除文件夹失败");
                    return;
                }
                G.canCreateFolder = true;
                var t = G.folderMap()[G.selectRow.id];
                G.folderNum--;
                if (G.folderNum < 0) {
                    G.folderNum = 0;
                }
                r.remove(t.id);
                n.removeRow(t);
                l.setClist(t, "delete");
                o.trigger("toast.show", {
                    type: "suc",
                    text: "删除文件夹成功"
                });
                s.init();
                report("delFolderSuc");
            }).fail(function(e) {
                client.alert(2, "提示", "删除文件夹失败");
                report("delFolderError");
            });
        }
    }
    function c() {
        o.trigger("menu.hide");
        if (!G.selectRow) {
            return;
        }
        report("deleteFolder", G.module());
        var e = client.confirm(2, "提示", "你确定要删除" + G.selectRow.fnameEsc + "以及文件夹内的所有文件吗？");
        if (e) {
            f(e);
        }
    }
    e.exports = {
        showDeleteFolder: c,
        deleteFolder: f
    };
}, function(e, t, a) {
    "use strict";
    var n = $("#folderPanel");
    var i = a(8);
    var r = a(121);
    var o = a(41);
    var l = a(79);
    var s = a(35);
    var f = a(122);
    var c = $(G.handler);
    function d() {
        c.trigger("menu.hide");
        if (!G.selectRow) {
            return;
        }
        var e = $.trim(n.find(".new-name").val());
        var t = G.selectRow.id;
        var a = {
            folder_id: t,
            new_name: e
        };
        o.renameFolder(a).done(function(a) {
            var n = G.folderMap()[t];
            n.fname = e;
            n.fnameEsc = e;
            n.name = e;
            n.modify_time = Math.ceil(new Date().getTime() / 1e3);
            n = s.updateFolder(n);
            $("[data-path='" + t + "']").find(".name").html(e);
            c.trigger("toast.show", {
                type: "suc",
                text: "重命名文件夹成功"
            });
            i.updateRow(n);
            l.hideAll();
        }).fail(function(e) {
            r.showError(e.ec, n);
            report("renameFolderError");
        });
        return true;
    }
    e.exports = {
        renameFolder: d
    };
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = a(4);
    var r = $(G.handler);
    var o = G.folderVersion;
    function l() {
        if (i.getTips()) {} else {
            report("showOldVersion");
            s();
        }
    }
    function s() {
        $("#updateQQ").addClass("open");
        $("#updateQQTips").text("当前版本不支持文件夹下载功能，请升级QQ至最新版本后体验");
        $("#updateQQ").find("input.btn-notips").attr("data-action", "panel.close");
    }
    function f(e) {
        var t = document.createElement("div");
        var a = this.getBoundingClientRect();
        var n = function r() {
            var e = document.height;
            var t = G.getDomPanel();
            var a = t[0].scrollHeight;
            if (a + 52 > e) {
                return true;
            }
            return false;
        };
        t.innerHTML = '<div class="img"></div>';
        t.className = "file-animate files-" + e.icon;
        var i = window.innerWidth - a.left - 76;
        if (G.info.isAdmin) {
            i += 47;
        }
        if (n()) {
            i -= 20;
        }
        if (G.mac) {
            i = 177;
        }
        t.style.right = i + "px";
        t.style.top = a.top - 20 + "px";
        document.body.appendChild(t);
        setTimeout(function() {
            document.body.removeChild(t);
        }, 1500);
    }
    function c() {
        var e = G.selectRow;
        if (G.info.version < o) {
            l();
            return;
        }
        report("downloadFolder");
        if (e) {
            f.call(this, e);
            var t = e.path;
            var a = e.fnameEsc;
            client.addDownloadTask(t, a, 0, true, true);
        }
        r.trigger("menu.hide");
    }
    e.exports = {
        download: c
    };
}, function(e, t, a) {
    "use strict";
    var n = $("#folderPropertyPanel");
    var i = a(123);
    var r = $(G.handler);
    function o() {
        report("propFolder");
        i.render(n, G.selectRow);
        n.addClass("open");
        r.trigger("menu.hide");
        n.find(".aria-hide")[0].focus();
    }
    e.exports = {
        show: o
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(8);
    var l = a(35);
    var s = a(123);
    function f(e, t) {
        e = e || $(this).data("path");
        report("clkFolder", G.module());
        if (G.mac) {
            $(".mac-file-top").removeClass("user-module");
        }
        if ((G.module() == 0 || G.module() == 1) && e === G.nowFolder) {
            return;
        }
        G.module(e === "/" ? 0 : 1);
        if (e === "/") {
            $(".mac-return").addClass("disable");
        } else {
            $(".mac-return").removeClass("disable");
        }
        G.nowFolder = e;
        var a = undefined;
        if (e === "/") {
            a = Math.random();
        }
        function n(a) {
            var n = l.getData(e);
            if (t) {
                n = {
                    fnameEsc: t
                };
            }
            s.updataFolderHeader(n);
            var r = location.hash;
            r = decodeURIComponent(r);
            location.hash = r.replace(/&webParams={.+}/, "") + "&webParams=" + encodeURIComponent((0, 
            i.default)({
                action: "fileList",
                params: {
                    folderId: G.nowFolder,
                    fname: n.fnameEsc
                }
            }));
        }
        o.getList({
            paramsFilter: {
                folderId: e,
                random: a
            },
            succ: n
        })();
    }
    e.exports = {
        renderFolder: f
    };
}, function(e, t, a) {
    "use strict";
    var n = $("#move-file-panel");
    function i() {
        n.addClass("open");
    }
    function r() {
        n.removeClass("open");
    }
    function o() {
        n.removeClass("open");
    }
    function l() {
        console.log("ok move file");
    }
    function s() {
        console.log("move file create folder");
    }
    function f(e, t) {
        var a = $(e.target).closest(".folder-list-item");
        $(".folder-list-item").removeClass("active");
        a.addClass("active");
    }
    e.exports = {
        oveFileOpen: i,
        moveFileClose: r,
        moveFileCancel: o,
        moveFileOk: l,
        moveFileCreateFolder: s,
        fileActive: f
    };
}, function(e, t, a) {
    "use strict";
    var n = a(10);
    var i = 48;
    var r = a(43);
    function o(e) {
        var t = false;
        var a = new RegExp('^[^/\\\\:?*"<>|]+$');
        t = a.test(e);
        console.log("reg", a.test(e));
        return t;
    }
    function l() {
        var e = $.trim(this.value);
        if (e.length > i && !input) {
            this.value = e.substr(0, i);
        }
        return;
    }
    function s(e) {
        var t = this.inputStart;
        var a = this.value;
        var r = $(this).parents(".panel-overlay");
        var l = $(this).parent().find(".bubble");
        var s = $("#folderPanel .btn-ok").data("action");
        if ($.trim(a) === "") {
            $(this).parent().find(".error-message").removeClass("show");
            r.find(".btn-ok").prop("disabled", true);
            l.hide();
            return;
        }
        if (!o(a)) {
            var f = '文件夹名称不能包含 \\ / : * ? " < > |';
            if (s === "file.renameFile") {
                f = '文件名称不能包含 \\ / : * ? " < > |';
            }
            $(this).parent().find(".error-message").text(f).addClass("show");
            l.html('<span class="bot"></span><span class="top"></span>' + f).show();
            r.find(".btn-ok").prop("disabled", true);
        } else {
            $(this).parent().find(".error-message").removeClass("show");
            l.hide();
        }
        if (a.length === 0) {
            r.find(".btn-ok").prop("disabled", true);
        } else if (a.length !== 0 && o(a)) {
            r.find(".btn-ok").prop("disabled", false);
        }
        if (a.length > i && !t) {
            this.value = a.substr(0, i);
        }
        if ($("#folderPanel [data-action]").length) {
            if (e && e.keyCode == 13 && !t) {
                $("#folderPanel [data-action]").click();
            }
        }
        return;
        if (n.getLen(a) > i && !t) {
            this.value = n.subString(a, 16);
        }
    }
    function f() {
        $("#folderPanel .error-message").removeClass("show");
    }
    e.exports = {
        "input.keyup": s,
        "input.focus": f,
        "input.blur": l,
        folderName: o
    };
}, , , , , , , , , function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = l(n);
    var r = a(25);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = top.external;
    function f() {
        var e = void 0;
        if (window.external && s.getTaskList) {
            e = s.getTaskList();
            if (typeof e !== "string") {
                e = "";
            }
        } else {}
        return e;
    }
    function c() {
        var e = {};
        if (window.external && s.getTaskList) {
            var t = s.getTaskList();
            if (typeof t !== "string") {
                t = "";
            }
            if (t === "") {
                e.map = {};
                e.status = "busy";
            } else if (t === "{}") {
                e.map = {};
                e.status = "ok";
                e.empty = true;
            } else {
                try {
                    e.map = JSON.parse(t);
                } catch (a) {
                    console.error("客户端接口getTaskList返回的数据有问题?parse出错[" + t + "]");
                }
                if ((0, o.default)(e.map) === "object" && e.map !== null) {
                    e.status = "ok";
                } else {
                    e.map = {};
                    e.status = "parseerror";
                }
            }
        } else {
            e = {
                map: {},
                status: "ok",
                empty: true
            };
        }
        return e;
    }
    function d() {
        var e = void 0;
        if (window.external && s.getCompleteTaskList) {
            e = s.getCompleteTaskList();
            if (e === null) {
                e = "";
            }
        } else {
            console.log("task相关接口不存在 getTaskList");
        }
        return e;
    }
    function u() {
        var e = {};
        if (window.external && s.getCompleteTaskList) {
            var t = s.getCompleteTaskList();
            if (typeof t !== "string") {
                t = "";
            }
            if (t === "") {
                e.map = {};
                e.status = "busy";
            } else if (t === "{}") {
                e.map = {};
                e.status = "ok";
                e.empty = true;
            } else {
                try {
                    e.map = JSON.parse(t);
                } catch (a) {
                    console.error("客户端接口getCompleteTaskList返回的数据有问题?parse出错[" + t + "]");
                }
                if ((0, o.default)(e.map) === "object" && e.map !== null) {
                    e.status = "ok";
                } else {
                    e.map = {};
                    e.status = "parseerror";
                }
            }
        } else {
            e = {
                map: {},
                status: "ok",
                empty: true
            };
        }
        return e;
    }
    function p(e) {
        if (window.external && s.getTaskInfo) {
            var t = s.getTaskInfo(e);
        } else {}
        return ret;
    }
    function v(e, t) {
        var a = void 0;
        if (!e) {
            e = 1;
        }
        if (window.g_flag_upload_temp) {
            e = 2;
        }
        if ("addUploadTask" in s) {
            a = s.addUploadTask(e, t);
        } else {}
        return a;
    }
    function m(e, t, a, n, i) {
        var r = void 0;
        if (window.external && s.addDownloadTask) {
            a = a + "";
            r = s.addDownloadTask(e, t, a, n, i || false);
        } else {
            r = -1;
        }
        return r;
    }
    function h(e) {
        var t = void 0;
        if (window.external && s.downloadFiles) {
            t = s.downloadFiles((0, i.default)(e));
            console.debug(t);
        } else {
            t = -1;
        }
        return t;
    }
    function g(e, t, a) {
        var n = void 0;
        if (window.external && s.downloadByXF) {
            a = a + "";
            n = s.downloadByXF(e, t, a);
            console.debug(n);
        } else {
            n = -1;
        }
        return n;
    }
    function w(e, t, a) {
        var n = void 0;
        if (window.external && s.forwardFile) {
            n = s.forwardFile(t, e, a);
        } else {
            n = -1;
        }
        return n;
    }
    function b(e, t, a) {
        var n = void 0;
        if (window.external && s.forwardFileToDataLine) {
            n = s.forwardFileToDataLine(t, e, a);
        } else {
            n = -1;
        }
        return n;
    }
    function _(e, t, a, n) {
        var i = void 0;
        console.log("client", e, t, a, n);
        if (window.external && s.addContinueUploadTask) {
            i = s.addContinueUploadTask(e, t, a, n);
            console.log(i);
        } else {
            i = -1;
        }
        return i;
    }
    function k(e) {
        var t = void 0;
        if (window.external && s.removeTask) {
            t = s.removeTask(e);
        } else {
            console.log("task相关接口不存在 addContinueUploadTask");
            t = -1;
        }
        return t;
    }
    function y(e) {
        var t = void 0;
        if (window.external && s.removeCompleteTask) {
            t = s.removeCompleteTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function x(e) {
        var t = void 0;
        if (window.external && s.pauseTask) {
            t = s.pauseTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function F(e) {
        var t = void 0;
        if (window.external && s.resumeTask) {
            t = s.resumeTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function T() {
        var e = top.external && top.external.CallHummerApi;
        if (e) {
            var t = void 0;
            try {
                t = e.apply(this, arguments);
                t = JSON.parse(t);
                return t;
            } catch (a) {
                return false;
            }
        }
        return false;
    }
    function C() {
        if (G.mac) {
            try {
                var e = s.getVersion();
                return {
                    errorCode: 0,
                    version: e
                };
            } catch (t) {
                return {
                    errorCode: 1,
                    version: 0
                };
            }
        } else {
            return T("IM.GetVersion");
        }
    }
    function S() {
        if (window["G_DEBUG"]) {
            return true;
        }
        var e = T("Contact.IsOnline");
        if (e) {
            return T("Contact.IsOnline").online;
        } else {
            return false;
        }
    }
    function $(e, t) {
        t = t || 1;
        return T("Contact.OpenContactInfoCard", '{ "uin" : "' + e + '", "tabId" : ' + t + " }");
    }
    function M(e, t) {
        t = t || 1;
        return T("Group.OpenGroupInfoCard", '{ "groupId" : "' + e + '", "tabId" : ' + t + " }");
    }
    function j(e, t) {
        var a = (0, i.default)({
            gc: "" + e,
            webParams: t
        });
        return T("Group.OpenGroupFile", a);
    }
    var R = null;
    function D(e) {
        if (R) {
            return R;
        }
        var t = {
            uin: e + ""
        };
        t = (0, i.default)(t);
        var a = T("Contact.GetNickName", t);
        if (a && a.errorCode === 0 && a.nickName) {
            R = a.nickName;
        }
        if (G.mac) {
            try {
                R = s.getNickName(e);
            } catch (n) {
                R = e;
            }
        }
        if (!R) {
            return e;
        }
        return R;
    }
    function O() {
        return T("IM.GetClientKey");
    }
    function P(e) {
        e += "&pictype=scaled&size=1024*1024";
        var t = void 0;
        if (G.mac) {
            t = window.external && window.external.previewPicture(e);
        } else {
            t = T("Misc.OpenWebPic", '{"url":"' + e + '"}');
        }
        return t;
    }
    function L(e, t) {
        window.external && window.external.previewFile(e, t);
    }
    function I() {
        var e = u();
        if (e.map) {
            for (var t in e.map) {
                var a = e.map[t];
                if (a.id) {
                    var n = y(a.id);
                    if (n === -1) {
                        console.warn("移除完成任务失败！");
                    }
                }
            }
        }
    }
    function N(e, t, a) {
        if (G.mac) {
            return window.alert(a);
        } else {
            return T("Window.Alert", '{ "iconType" : ' + e + ', "title" : "' + t + '", "text" : "' + a + '" }');
        }
    }
    function E(e, t, a) {
        if (G.mac) {
            var n = window.confirm(a);
            return {
                errorCode: 0,
                ret: n
            };
        } else {
            return T("Window.Confirm", '{ "iconType" : ' + e + ', "title" : "' + t + '", "text" : "' + a + '" }');
        }
    }
    function A() {
        var e = void 0;
        if (window.external && s.getUploadFiles) {
            e = s.getUploadFiles();
        } else {
            e = -1;
        }
        return e;
    }
    function q(e, t, a) {
        if (!a) {
            a = 1;
        }
        var n = void 0;
        if (window.external && s.uploadFiles) {
            n = s.uploadFiles(e, t, a);
        } else {
            n = -1;
        }
        return n;
    }
    function z(e) {
        var t = void 0;
        if (!remotetype) {
            remotetype = 1;
        }
        if (window.external && s.setUploadFileRemotePath) {
            t = s.setUploadFileRemotePath(e);
        } else {
            t = -1;
        }
        return t;
    }
    function B(e) {
        var t = void 0;
        console.log(e);
        if (window.external && s.addMultiDownloadTasks) {
            t = s.addMultiDownloadTasks(e);
        } else {
            t = -1;
        }
        return t;
    }
    e.exports = {
        getVersion: C,
        getBatchFiles: A,
        batchUpload: q,
        setUploadFileRemotePath: z,
        getTaskListAdv: c,
        getCompleteTaskListAdv: u,
        addUploadTask: v,
        addDownloadTask: m,
        addDownloadFast: g,
        addContinueUploadTask: _,
        removeTask: k,
        removeCompleteTask: y,
        pauseTask: x,
        resumeTask: F,
        getTaskInfo: p,
        forwardFile: w,
        forwardFileToDataLine: b,
        callHummerApi: T,
        getNickName: D,
        isOnline: S,
        getClientKey: O,
        preview: P,
        previewFile: L,
        clearClist: I,
        alert: N,
        confirm: E,
        openGroupInfoCard: M,
        openGroupFile: j,
        addMultiDownloadTasks: B
    };
}, function(e, t, a) {
    (function(e) {
        "use strict";
        var t = a(26);
        var n = i(t);
        function i(e) {
            return e && e.__esModule ? e : {
                "default": e
            };
        }
        var r = a(10);
        var o = a(181);
        var l = {
            enter: {
                monitor: 2057388,
                mac: 2162523,
                tdw: [ "home", "exp" ]
            },
            clkGroupFile: {
                monitor: 2057389,
                tdw: [ "home", "Clk_grpfiles" ]
            },
            clkFiles: {
                monitor: 2057390,
                tdw: [ "home", "Clk_files" ]
            },
            openVip: {
                monitor: 2057391,
                tdw: [ "home", "Clk_open" ]
            },
            clkFeed: {
                monitor: 2057392,
                tdw: [ "home", "Clk_feed" ]
            },
            clkRefresh: {
                monitor: 2057393,
                tdw: [ "home", "Clk_refresh" ]
            },
            forward: {
                monitor: 0,
                tdw: [ "home", "Clk_towards_mac" ]
            },
            back: {
                monitor: 0,
                tdw: [ "home", "Clk_back" ]
            },
            folder: {
                monitor: 2057394,
                tdw: [ "file", "exp" ]
            },
            propFolder: {
                monitor: 2057401,
                tdw: [ "file", "Clk_property" ]
            },
            folderBtnShow: {
                monitor: 2057396,
                tdw: [ "file", "exp_create" ]
            },
            clkCreateFolder: {
                monitor: 2057397,
                tdw: [ "file", "Clk_create" ]
            },
            createFolderSuc: {
                monitor: 2057398,
                tdw: [ "file", "create_suc" ]
            },
            renameFolder: {
                monitor: 2057400,
                tdw: [ "file", "Clk_rename" ]
            },
            clkFolderMore: {
                monitor: 2057399,
                tdw: [ "file", "Clk_more" ]
            },
            downloadFolder: {
                monitor: 2057399,
                tdw: [ "file", "Clk_down" ]
            },
            deleteFolder: {
                monitor: 2057402,
                tdw: [ "file", "Clk_delete" ]
            },
            returnHome: {
                monitor: 2057395,
                tdw: [ "file", "Clk_home" ]
            },
            folderTree: {
                monitor: 2057403,
                tdw: [ "file", "exp_select" ]
            },
            createFolderInTree: {
                monitor: 2057404,
                tdw: [ "file", "select_create" ]
            },
            createFolderInTreeSuc: {
                monitor: 2057405,
                tdw: [ "file", "select_suc" ]
            },
            memberFileShow: {
                monitor: 2057406,
                tdw: [ "mber_file", "exp" ]
            },
            memberClkFolder: {
                monitor: 2057407,
                tdw: [ "mber_file", "Clk_name" ]
            },
            memberReturnHome: {
                monitor: 2057408,
                tdw: [ "mber_file", "Clk_home" ]
            },
            uploadShow: {
                monitor: 2057409,
                tdw: [ "oper_file", "exp_button" ]
            },
            clkUpload: {
                monitor: 2057410,
                tdw: [ "oper_file", "Clk_button" ]
            },
            clkFolder: {
                monitor: 2057411,
                tdw: [ "oper_file", "Clk_category" ]
            },
            showOpenFile: {
                monitor: 2057412,
                tdw: [ "oper_file", "exp_open" ]
            },
            clkOpenFile: {
                monitor: 2057413,
                tdw: [ "oper_file", "Clk_open" ]
            },
            showDownloadBtn: {
                monitor: 2057414,
                tdw: [ "oper_file", "exp_download" ]
            },
            clkDownloadBtn: {
                monitor: 2057415,
                tdw: [ "oper_file", "Clk_download" ]
            },
            showSeeBtn: {
                monitor: 2057416,
                tdw: [ "oper_file", "exp_see" ]
            },
            clkShowBtn: {
                monitor: 2057417,
                tdw: [ "oper_file", "Clk_see" ]
            },
            clkMore: {
                monitor: 2057418,
                tdw: [ "oper_file", "Clk_more" ]
            },
            clkUnMore: {
                monitor: 2057419,
                tdw: [ "oper_file", "Clk_un_more" ]
            },
            clkSaveAs: {
                monitor: 2057420,
                tdw: [ "oper_file", "Clk_save" ]
            },
            clkRepost: {
                monitor: 2057421,
                tdw: [ "oper_file", "Clk_repost" ]
            },
            clkPhone: {
                monitor: 2057422,
                tdw: [ "oper_file", "Clk_phone" ]
            },
            clkRenameFile: {
                monitor: 2057423,
                tdw: [ "oper_file", "Clk_rename" ]
            },
            clkForever: {
                monitor: 2057424,
                tdw: [ "oper_file", "Clk_forever" ]
            },
            clkJubao: {
                monitor: 2057425,
                tdw: [ "oper_file", "Clk_report" ]
            },
            clkDeleteFile: {
                monitor: 2057426,
                tdw: [ "oper_file", "Clk_delete" ]
            },
            clkShowInFolder: {
                monitor: 2057427,
                tdw: [ "oper_file", "Clk_show" ]
            },
            showSelectAll: {
                monitor: 2057428,
                tdw: [ "all_oper", "exp_box" ]
            },
            clkSelectAll: {
                monitor: 2057429,
                tdw: [ "all_oper", "Clk_select" ]
            },
            showBatch: {
                monitor: 2057430,
                tdw: [ "all_oper", "exp_mode" ]
            },
            clkBatch: {
                monitor: 2057431,
                tdw: [ "all_oper", "Clk_all" ]
            },
            batchSaveAs: {
                monitor: 2057432,
                tdw: [ "all_oper", "Clk_save" ]
            },
            batchDownload: {
                monitor: 2057433,
                tdw: [ "all_oper", "Clk_download" ]
            },
            batchDelete: {
                monitor: 2057434,
                tdw: [ "all_oper", "Clk_delete" ]
            },
            batchDeleteSuc: {
                monitor: 2057435,
                tdw: [ "all_oper", "suc_delete" ]
            },
            batchMove: {
                monitor: 2057436,
                tdw: [ "all_oper", "Clk_move" ]
            },
            batchMoveSuc: {
                monitor: 2057437,
                tdw: [ "all_oper", "suc_move" ]
            },
            showTask: {
                monitor: 2057438,
                tdw: [ "task", "exp" ]
            },
            clkTask: {
                monitor: 2057439,
                tdw: [ "task", "Clk_task" ]
            },
            showOneTask: {
                monitor: 2057440,
                tdw: [ "task", "exp_category" ]
            },
            clkTaskName: {
                monitor: 2057441,
                tdw: [ "task", "Clk_name" ]
            },
            showTaskShow: {
                monitor: 2057442,
                tdw: [ "task", "exp_see" ]
            },
            clkTaskShow: {
                monitor: 2057443,
                tdw: [ "task", "Clk_see" ]
            },
            showTaskPause: {
                monitor: 2057444,
                tdw: [ "task", "exp_start" ]
            },
            clkTaskPause: {
                monitor: 2057445,
                tdw: [ "task", "Clk_stop" ]
            },
            showTaskDelete: {
                monitor: 2057446,
                tdw: [ "task", "exp_delete" ]
            },
            clkTaskDelete: {
                monitor: 2057447,
                tdw: [ "task", "Clk_delete" ]
            },
            taskExp: {
                monitor: 2057448,
                tdw: [ "task", "exp_tips" ]
            },
            clkTaskExp: {
                monitor: 2057449,
                tdw: [ "task", "Clk_tips" ]
            },
            showSearchBtn: {
                monitor: 2057450,
                tdw: [ "search", "exp_button" ]
            },
            clkSearchBtn: {
                monitor: 2057451,
                tdw: [ "search", "Clk_button" ]
            },
            doSearch: {
                monitor: 2057452,
                tdw: [ "search", "Clk_search" ]
            },
            showSearchRes: {
                monitor: 2057453,
                tdw: [ "search", "exp_result" ]
            },
            clkSearchRes: {
                monitor: 2057454,
                tdw: [ "search", "Clk_result" ]
            },
            clkSearchName: {
                monitor: 2057455,
                tdw: [ "search", "Clk_name" ]
            },
            showFolderMove: {
                monitor: 2057456,
                tdw: [ "oper_file", "exp_move" ]
            },
            clkFolderMove: {
                monitor: 2057457,
                tdw: [ "oper_file", "Clk_move" ]
            },
            moveFileSuc: {
                monitor: 2057458,
                tdw: [ "oper_file", "move_suc" ]
            },
            showOldVersion: {
                monitor: 2057459,
                tdw: [ "oper_file", "exp_upgradetips" ]
            },
            clkUpdateQQ: {
                monitor: 2057460,
                tdw: [ "oper_file", "Clk_upgrade" ]
            },
            clkNotRemind: {
                monitor: 2057461,
                tdw: [ "oper_file", "Clk_nomoreremind" ]
            },
            showMoveFail: {
                monitor: 2057462,
                tdw: [ "oper_file", "exp_movefail" ]
            },
            delFolderSuc: {
                monitor: 2057463,
                tdw: [ "oper_file", "delete_suc" ]
            },
            jsError: {
                monitor: 2069233
            },
            getListError: {
                monitor: 2069234
            },
            delFileError: {
                monitor: 2069235
            },
            moveFileError: {
                monitor: 2069236
            },
            renameFileError: {
                monitor: 2069237
            },
            newFolderError: {
                monitor: 2069238
            },
            renameFolderError: {
                monitor: 2069239
            },
            delFolderError: {
                monitor: 2069240
            },
            cgiTimeout: {
                monitor: 2069241
            },
            offlinePage: {
                monitor: 2069242
            },
            nodePage: {
                monitor: 2069243
            },
            folderNum: {
                tdw: [ "file", "exp_folder" ]
            },
            imgurl: {
                monitor: 2200307
            },
            fileDownload: {
                monitor: 2366516,
                tdw: [ "oper_file", "down_in" ]
            },
            blackExp: {
                monitor: 2370085,
                tdw: [ "black", "exp_foul" ]
            },
            blackTips: {
                monitor: 2370086,
                tdw: [ "black", "exp_tip" ]
            },
            blackDelete: {
                monitor: 2370087,
                tdw: [ "black", "delete" ]
            }
        };
        var s = "Grp_pcfiles";
        window.badjsReport = o.createReport({
            id: 1033
        });
        function f() {
            var e = window.webkitPerformance ? window.webkitPerformance : window.performance, t = [ "navigationStart", "unloadEventStart", "unloadEventEnd", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "requestStart", "responseStart", "responseEnd", "domLoading", "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart", "loadEventEnd" ], a, n, i;
            if (e && (a = e.timing)) {
                if (!a.domContentLoadedEventStart) {
                    t.splice(15, 2, "domContentLoadedStart", "domContentLoadedEnd");
                }
                var r = [];
                for (i = 0, n = t.length; i < n; i++) {
                    r[i] = a[t[i]];
                }
                QReport.huatuo({
                    appid: 10016,
                    flag1: 1772,
                    flag2: 1,
                    flag3: 1,
                    speedTime: r
                });
            }
        }
        function c() {
            var e = /\/\/(s[\d]*\.url\.cn|[\w\.\d]*\.qq.com|report\.url\.cn)/i;
            if (window.performance && window.performance.getEntries) {
                var t = window.performance.getEntries();
                for (var a = 0, i = t.length; a < i; a++) {
                    var r = t[a].name;
                    if (!e.test(r)) {
                        QReport.monitor(2154095);
                        badjsReport.info((0, n.default)({
                            "被劫持": r
                        }));
                    }
                }
            }
        }
        window.addEventListener("load", function() {
            f();
            c();
        });
        window.addEventListener("error", function() {
            report("jsError");
        });
        var d = r.getParameter("gid");
        window.reportNew = function(t) {
            var a = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            if (l[t]) {
                var n = l[t];
                if (n.monitor) {
                    QReport.monitor(n.monitor);
                }
                if (n.mac) {
                    QReport.monitor(n.mac);
                }
                if (G.module) {
                    e = G.module();
                }
                if (n.tdw) {
                    var i = {
                        obj1: d,
                        opername: s,
                        module: n.tdw[0],
                        action: n.tdw[1]
                    };
                    if (G.mac) {
                        i.action = n.tdw[1] + "_mac";
                    }
                    i = $.extend(i, a);
                    QReport.tdw(i);
                }
            }
        };
        window.report = function(t) {
            var a = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
            var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
            var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
            var r = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
            if (l[t]) {
                var o = l[t];
                if (o.monitor) {
                    QReport.monitor(o.monitor);
                }
                if (o.mac) {
                    QReport.monitor(o.mac);
                }
                if (G.module) {
                    e = G.module();
                }
                if (o.tdw) {
                    var f = {
                        obj1: d,
                        opername: s,
                        module: o.tdw[0],
                        action: o.tdw[1]
                    };
                    if (G.mac) {
                        f.action = o.tdw[1] + "_mac";
                    }
                    if (a >= 0) {
                        f.ver1 = a;
                    }
                    if (n) {
                        f.ver2 = n;
                    }
                    QReport.tdw(f);
                }
            }
        };
    }).call(t, a(226)(e));
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.doClearFile = t.clickClearFile = undefined;
    var n = a(41);
    var i = l(n);
    var r = a(79);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = $("#cleanFile");
    var f = $("#cleanProg");
    var c = t.clickClearFile = function u() {
        console.log(1234);
        if (G.mac) {
            var e = client.confirm(2, "提示", "将为你保留最近的1500个文件和文件夹，并删除之前的所有文件\n注意:本操作不可恢复，请自行备份");
            if (e.errorCode === 0 && e.ret) {
                d();
            }
        } else {}
        o.default.showBatchPanel(s, {
            title: "提示",
            action: "file.doClearFile",
            text: '将为你保留最近的1500个文件和文件夹，并删除之前的所有文件<div class="warming">注意:本操作不可恢复，请自行备份</div>',
            okBtnText: "确定删除"
        });
    };
    var d = t.doClearFile = function p() {
        if (!G.mac) {
            o.default.hide(s);
            o.default.show(f);
        }
        i.default.cleanFile().done(function(e) {}).fail(function(e) {
            o.default.hide(f);
        });
        var e = 0;
        var t = function a() {
            i.default.getFileCount().done(function(t) {
                console.log(t);
                if (t.ec === 0 && !t.is_too_many) {
                    o.default.hide(f);
                    clearTimeout(e);
                    location.reload();
                } else {
                    e = setTimeout(a, 500);
                }
            }).fail(function(t) {
                console.log(t);
                e = setTimeout(a, 500);
            });
        };
        if (!G.mac) {
            t();
        }
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = l(n);
    var r = a(37);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = a(113);
    var f = a(59);
    var c = $("#upload-panel");
    var d = {
        folderTree: a(164),
        showFolderTreePanel: a(79).showFolderTreePanel,
        panel: a(79)
    };
    var u = a(4);
    var p = G.folderVersion;
    var v = a(117);
    var m = a(35);
    var h = a(7);
    var g = void 0;
    function w() {
        if (u.getTips()) {
            f.addUploadTask();
        } else {
            report("showOldVersion");
            $("#updateQQ").addClass("open");
            $("#updateQQTips").text("当前版本仅支持将文件上传至群文件首页，升级至QQ最新版本可上传文件至文件夹内。");
            $("#updateQQ").find("input.btn-notips").attr("data-action", "upload.cUpload");
        }
    }
    function b() {
        if (this.checked) {
            u.setTips(1);
            G.oldVersion = true;
            $("#headerBatch .store").addClass("disabled");
            report("clkNotRemind");
        } else {
            u.setTips(0);
        }
    }
    function _() {
        $("#updateQQ").removeClass("open");
        f.addUploadTask();
    }
    function k() {
        if (G.file.isFull) {
            return h.show(G.mac ? "fail" : "alert", "文件数已达到上限");
        }
        if (G.info.version < p) {
            w();
        } else {
            if (G.folderMap() && (0, o.default)(G.folderMap()).length > 0 || G.nowFolder !== "/") {
                f.getBatchFiles();
            } else {
                report("clkUpload", G.module());
                f.addUploadTask();
            }
        }
    }
    function y(e) {
        if (G.file.isFull) {
            return h.show(G.mac ? "fail" : "alert", "文件数已达到上限");
        }
        if (!g) {
            return;
        }
        var t = void 0;
        if (typeof e === "string") {
            report("clkUpload", 1);
            t = e;
        } else {
            t = G.folderTree.selected && G.folderTree.selected.id || "/";
        }
        if ($("#inputFolderNameInFolderTree").length > 0) {
            v["folderTree.create"](null, function() {
                t = G.folderTree.selected && G.folderTree.selected.id || "/";
                var e = f.batchUpload(t, (0, i.default)(g));
                g = null;
                d.panel.hideAll();
            });
        } else {
            var a = f.batchUpload(t, (0, i.default)(g));
            g = null;
            d.panel.hideAll();
        }
    }
    function x(e, t) {
        if (!t || t.length === 0) {
            return;
        }
        var a = void 0;
        a = e;
        var n = "上传到群文件？";
        if (a !== "/") {
            var r = m.getData(a);
            n = "上传到文件夹：" + r.fnameEsc + "？";
        }
        var o = f.confirm(1, "提示", n);
        if (o.errorCode === 0 && o.ret) {
            report("clkUpload", 1);
            var l = f.batchUpload(a, (0, i.default)(t));
            d.panel.hideAll();
        }
    }
    function F() {
        c.addClass("open");
    }
    function T(e) {
        var t = e[0];
        var a = e.length;
        var n = t.lastIndexOf("\\");
        var i = t.substr(n + 1);
        if (G.mac) {
            n = t.lastIndexOf("/");
            i = t.substr(n + 1);
        }
        console.log(t);
        var r = s.getFileName(i);
        if (a > 1) {
            return '<span class="name">' + r.filename_name + "</span><span>" + r.filename_suf + '</span>等<span class="blue">' + a + "</span>个文件";
        } else {
            return '<span class="name">' + r.filename_name + "</span><span>" + r.filename_suf + "</span>";
        }
    }
    function C(e) {
        g = e;
        if (G.nowFolder !== "/") {
            y(G.nowFolder);
            return;
        }
        var t = {
            title: "上传文件",
            firstFileName: T(e),
            action: "上传到：",
            destFolder: "群文件",
            okAction: "file.batchUpload"
        };
        d.showFolderTreePanel(t);
        var a = $("#containerFolderTreePanel");
        a.find("#folderTreePanel").addClass("open");
        report("folderTree", 0);
        return;
    }
    function S() {
        report("clkUpdateQQ");
    }
    e.exports = {
        batchuploadInFolder: x,
        upload: k,
        bupload: y,
        showUpload: C,
        noTips: b,
        cupload: _,
        update: S
    };
}, function(e, t, a) {
    "use strict";
    var n = a(79);
    var i = a(35);
    var r = a(8);
    var o = a(41);
    var l = a(170);
    var s = a(121);
    var f = a(59);
    var c = a(79);
    var d = $("#folderPanel");
    var u = $(G.handler);
    function p() {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkRenameFile", G.module());
        n.show(d, {
            title: "重命名",
            tips: "请为文件输入新名称",
            action: "file.renameFile",
            showValue: G.selectRow.nameEsc
        });
    }
    function v() {
        var e = d.find(".new-name").val();
        var t = G.selectRow;
        var a = {
            file_id: t.fp,
            app_id: G.appid,
            new_file_name: e + t.suf,
            bus_id: t.busid,
            parent_folder_id: G.nowFolder
        };
        o.renameFile(a).done(function(a) {
            if (a.ec === 0) {
                t.name = e;
                t.nameEsc = l.decode(e);
                t.fname = e + t.suf;
                t.fnameEsc = l.decode(t.fname);
                i.updateFile(t, "rename");
                r.updateRow(t);
                u.trigger("file.thumbUpdate", t);
            }
            c.hideAll();
        }).fail(function(e) {
            s.showError(e.ec, d);
            report("renameFileError");
        });
    }
    e.exports = {
        showFileRename: p,
        renameFile: v
    };
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = a(41);
    var r = a(8);
    var o = a(59);
    var l = $(G.handler);
    function s(e) {
        var t = document.createElement("div");
        var a = this.getBoundingClientRect();
        var n = function r() {
            var e = document.height;
            var t = G.getDomPanel();
            var a = t[0].scrollHeight;
            if (a + 52 > e) {
                return true;
            }
            return false;
        };
        t.innerHTML = '<div class="img"></div>';
        t.className = "file-animate files-" + e.icon;
        var i = window.innerWidth - a.left - 3;
        if (G.info.isAdmin && G.nowFolder === "/") {
            i += 37;
        }
        if (!n()) {
            i += 10;
        }
        if (G.mac) {
            i = 177;
        }
        t.style.right = i + "px";
        t.style.top = a.top - 20 + "px";
        document.body.appendChild(t);
        setTimeout(function() {
            document.body.removeChild(t);
        }, 1500);
    }
    function f() {
        var e = $(this).parents(".file");
        var t = e.data("path");
        var a = n.getData(t);
        var i = this;
        if (a.safeType) {
            var l = G.getReportInfo(a);
            l.ver3 = l.ver4;
            l.ver4 = l.ver5;
            l.ver5 = a.isDown ? 2 : 1;
            reportNew("blackTips", l);
            o.alert(2, "提示", "该文件存在安全风险，无法正常使用");
            return;
        }
        report("clkDownloadBtn", G.module());
        if (a) {
            var f = a.filepath;
            var c = a.fnameEsc;
            var d = a.size;
            a.isDowning = true;
            var u = {
                bs: a.t,
                fp: a.fp
            };
            s.call(i, a);
            r.updateRow(a);
            var p = $("#" + a.domid);
            var v = p.attr("idx");
            var m = G.module() + "_" + v;
            reportNew("fileDownload", {
                ver1: G.module(),
                ver2: 0,
                ver3: encodeURIComponent(a.name),
                ver4: encodeURIComponent(a.filetype),
                ver5: 0,
                ver6: m,
                ver7: G.info.role
            });
            o.addDownloadTask(f, c, d, true);
        }
    }
    function c(e) {
        var t = function r(e) {
            var t = e.filepath;
            var a = e.fnameEsc;
            var n = e.size;
            var i = {
                bs: e.t,
                fp: e.fp
            };
            o.addDownloadTask(t, a, n, true);
        };
        reportNew("fileDownload", {
            ver1: G.module(),
            ver2: 0,
            ver3: encodeURIComponent(e[0].name),
            ver4: encodeURIComponent(e[0].filetype),
            ver5: 4,
            ver6: G.module() + "_",
            ver7: G.info.role
        });
        for (var a = 0, n = e.length; a < n; a++) {
            var i = e[a];
            if (!i.succ) {
                t(i);
            }
        }
    }
    e.exports = {
        download: f,
        downloadBatch: c
    };
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = a(59);
    var r = a(116);
    var o = $(G.handler);
    function l() {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkRepost", G.module());
        var e = G.selectRow.path;
        var t = n.getFile(e);
        if (t) {
            var a = t.filepath;
            var r = t.fnameEsc;
            var l = t.size;
            i.forwardFile(r, a, l);
            o.trigger("menu.hide");
        } else {}
    }
    function s(e) {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkPhone", G.module());
        var t = G.selectRow.path;
        var a = n.getFile(t);
        if (a) {
            var r = a.filepath;
            var l = a.fnameEsc;
            var s = a.size;
            var f = i.forwardFileToDataLine(l, r, s);
            console.log(f);
            o.trigger("menu.hide");
        } else {}
    }
    e.exports = {
        forward: l,
        toMobile: s
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(35);
    var l = a(41);
    var s = a(59);
    var f = a(8);
    var c = a(113);
    var d = a(8);
    var u = a(116);
    var p = 2;
    var v = a(4);
    var m = a(9);
    var h = $(G.handler);
    function g() {
        if (this.classList.contains("disable")) {
            return;
        }
        h.trigger("menu.hide");
        report("clkDeleteFile", G.module());
        var e = G.selectRow.path;
        var t = o.getFile(e);
        if (t) {
            var a = s.confirm(2, "提示", "你确定要删除文件 " + t.fnameEsc + " 吗?");
            if (a.errorCode === 0 && a.ret) {
                var n = {
                    bus_id: parseInt(t.busid),
                    file_id: t.fp,
                    app_id: 4,
                    parent_folder_id: G.nowFolder
                };
                l.deleteFile(n).done(function(e) {
                    o.remove(t.filepath);
                    f.removeRow(t);
                    v.setClist(t, "delete");
                    o.updateAllNum({
                        files: [ t ],
                        action: "remove"
                    });
                    G.file.capacityused = c.getSize(G.file.cu);
                    d.renderSpace();
                    h.trigger("toast.show", {
                        type: "suc",
                        text: "删除成功"
                    });
                    m.init();
                    if (t.safeType) {
                        var a = G.getReportInfo(t);
                        a.ver6 = a.ver3;
                        a.ver3 = a.ver4;
                        a.ver4 = a.ver5;
                        a.ver5 = t.size;
                        reportNew("blackDelete", a);
                    }
                }).fail(function(e) {
                    s.alert(2, "提示", "删除失败");
                    report("delFileError");
                });
            }
        }
    }
    function w(e, t) {
        h.trigger("menu.hide");
        var a = [];
        var n = {};
        var r = 1;
        var u = 0;
        var g = 0;
        var w = function y() {
            u++;
            if (u === r) {
                G.scrollHandler && G.scrollHandler();
            }
        };
        var b = function x() {
            var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
            if (e.length === 0) {
                return;
            }
            var a = {};
            var n = [];
            for (var p = 0, h = e.length; p < h; p++) {
                n[p] = {
                    gc: parseInt(G.info.gc),
                    app_id: G.appid,
                    bus_id: e[p].busid,
                    file_id: e[p].fp,
                    parent_folder_id: G.nowFolder
                };
            }
            a.file_list = (0, i.default)({
                file_list: n
            });
            l.deleteFile(a).done(function(a) {
                var n = [];
                if (a.fail) {
                    n = a.fail;
                    for (var i = e.length - 1; i >= 0; i--) {
                        if ($.inArray(e[i].fp, n)) {
                            e.splice(i, 1);
                        }
                    }
                }
                report("batchDeleteSuc");
                var l = e.length;
                g += l;
                e.forEach(function(e) {
                    f.removeRow(e);
                    o.remove(e.filepath);
                    v.setClist(e, "delete");
                    if (e.safeType) {
                        var t = G.getReportInfo(e);
                        t.ver6 = t.ver3;
                        t.ver3 = t.ver4;
                        t.ver4 = t.ver5;
                        t.ver5 = e.size;
                        reportNew("blackDelete", t);
                    }
                });
                o.updateAllNum({
                    files: e,
                    action: "remove"
                });
                G.file.capacityused = c.getSize(G.file.cu);
                d.renderSpace();
                w(g);
                if (u === r) {
                    m.init();
                    t(g);
                }
            }).fail(function(e) {
                s.alert(2, "提示", "删除失败");
                $(G.handler).trigger("panel.hideAll");
                report("delFileError");
            });
        };
        e.forEach(function(e) {
            if (e.remove) {
                a.push(e);
                n[e.fp] = e;
            }
        });
        r = Math.ceil(a.length / p);
        if (r === 1) {
            b(a);
        } else {
            for (var _ = 0; _ < r; _++) {
                var k = a.slice(_ * p, (_ + 1) * p);
                b(k);
            }
        }
        return true;
    }
    e.exports = {
        removeOne: g,
        removeBatch: w
    };
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = a(59);
    var r = a(165);
    var o = $(G.handler);
    var l = [ "图片" ];
    function s(e) {
        e.usedTime++;
        o.trigger("toast.hide");
        i.preview(e.previewObj.url);
    }
    function f() {
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
        var t = void 0;
        var a = $(this);
        var f = void 0;
        if (e) {
            t = e;
        } else {
            var c = a.data("path");
            t = n.getFile(c);
            if (!t) {
                var d = G.selectRow.path;
                t = n.getFile(d);
            }
            if (!t) {
                var u = G.selectRow.path;
                t = n.getFile(u);
            }
        }
        if (!t) {
            return;
        }
        if (t.safeType) {
            var p = G.getReportInfo(t);
            p.ver3 = p.ver4;
            p.ver4 = p.ver5;
            p.ver5 = t.isDown ? 2 : 1;
            reportNew("blackTips", p);
            i.alert(2, "提示", "该文件存在安全风险，无法正常使用");
            return;
        }
        var v = t.filepath;
        var m = t.remotetype;
        var h = t.fnameEsc || t.fname;
        var g = t.size;
        var w = t.filetype;
        if ($.inArray(w, l) >= 0) {
            if (g > 20 * 1024 * 1024) {
                i.alert(2, "提示", "图片太大不支持预览，请直接下载");
            } else {
                t.usedTime++;
                o.trigger("toast.show", {
                    type: "wait",
                    text: "正在加载预览图…"
                });
                r.getOneThumb(t, s);
            }
        } else {
            try {
                i.previewFile(v, h);
            } catch (b) {
                console.log(b);
            }
        }
    }
    function c() {
        if (this.classList && this.classList.contains("disable")) {
            return;
        }
        o.trigger("menu.hide");
        var e = G.selectRow;
        if (e) {
            f(e);
        }
    }
    e.exports = {
        preview: f,
        menupreview: c
    };
}, function(e, t, a) {
    "use strict";
    var n = {
        folderTree: a(164),
        showFolderTreePanel: a(79).showFolderTreePanel
    };
    var i = a(41);
    var r = a(8);
    var o = a(121);
    var l = a(116);
    var s = a(117);
    var f = a(70);
    var c = a(35);
    var d = a(59);
    var u = $(G.handler);
    var p = 10;
    function v() {
        if (this.classList && this.classList.contains("disable")) {
            return;
        }
        var e = G.selectRows;
        if (!e) {
            badjsReport.info("无选择目标");
            return;
        }
        var t = {
            title: "移动文件",
            firstFileName: e[0].fname,
            fileNum: e.length,
            action: "移动到：",
            destFolder: G.nowFolder === "/" ? "群文件" : G.folderMap()[G.nowFolder].fname,
            okAction: "file.move"
        };
        n.showFolderTreePanel(t);
        var a = $("#containerFolderTreePanel");
        a.find(".active .aria-hide").eq(0).focus();
        report("folderTree", 1);
        report("clkFolderMove");
    }
    function m() {
        if (!G.selectRows) {
            return;
        }
        var e = G.selectRows;
        var t = [];
        var a = {};
        var n = G.folderTree.selected.id;
        if (n === G.nowFolder) {
            console.log("can not move to the same folder");
            u.trigger("toast.show", {
                type: "alert",
                text: "文件已在目标位置"
            });
            return;
        }
        for (var s = e.length; s--; ) {
            var d = c.getData(e[s].filepath);
            if (d && d.safeType) {
                e.splice(s, 1);
            }
        }
        for (var v = e.length - 1; v >= 0; v--) {
            var m = e[v];
            t.push({
                file_id: m.fp,
                bus_id: parseInt(m.busid),
                parent_folder_id: m.parentId,
                dest_folder_id: n,
                app_id: G.appid,
                gc: G.info.gc
            });
            a[e[v].fp] = e[v];
        }
        f.exit();
        console.log(e, t);
        var h = function x() {
            _++;
            if (_ >= b) {
                u.trigger("toast.hide");
            }
        };
        var g = function F() {
            var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
            if (e.length === 0) {
                return;
            }
            i.moveFile(e).done(function(t) {
                h();
                var i = e;
                if (t.fail) {
                    var o = [];
                    try {
                        o = JSON.parse(t.fail).fail;
                    } catch (s) {}
                    for (var f = o.length - 1; f >= 0; f--) {
                        if (a[o[f]]) {
                            i.splice(f, 1);
                        }
                    }
                }
                if (e.length > 1) {
                    report("batchMoveSuc");
                } else {
                    report("moveFileSuc");
                }
                for (var c = i.length - 1; c >= 0; c--) {
                    var d = i[c];
                    var u = "/" + d.bus_id + d.file_id;
                    d = G.fileMap()[u];
                    d.parentId = n;
                    r.removeRow(d);
                }
                var p = void 0;
                if (p = G.folderMap()[n]) {
                    p.filenum += i.length;
                    $('[id="' + p.domid + '"]').find(".file-size").html(p.filenum + "个文件");
                }
                r.removeFold(p);
                r.appendFold(p);
                l["panel.close"]();
                return;
            }).fail(function(e) {
                h();
                o.showError(e.ec);
                report("showMoveFail");
                report("moveFileError");
                console.log("fail", e);
            });
        };
        var w = t.length;
        var b = Math.ceil(w / p);
        var _ = 0;
        u.trigger("toast.show", {
            type: "wait",
            text: "正在移动文件",
            autoHide: false
        });
        if (b) {
            for (var k = 0; k < b; k++) {
                var y = t.slice(k * p, (k + 1) * p);
                g(y);
            }
        } else {
            h();
            l["panel.close"]();
        }
        return true;
    }
    function h() {
        s["folderTree.create"](null, m);
    }
    e.exports = {
        showMove: v,
        move: h
    };
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = a(167);
    var r = $(G.handler);
    function o() {
        var e = G.selectRow;
        report("clkJubao");
        if (e) {
            var t = "http://jubao.qq.com/cn/jubao?appname=im&subapp=group_file&jubaotype=article";
            if (G.checkHttps()) {
                t = "https://proxy.qun.qq.com/tx_tls_gate=jubao.qq.com/cn/jubao?appname=im&subapp=group_file&jubaotype=article";
            }
            t += "&impeachuin=" + G.info.uin;
            t += "&uin=" + e.uin;
            t += "&fid=" + e.fp;
            t += "&fname=" + encodeURIComponent(e.fnameEsc);
            t += "&ut=" + e.ct;
            t += "&fs=" + e.size;
            t += "&dt=" + e.down;
            t += "&t=" + e.t;
            t += "&mt=" + e.mt;
            t += "&exp=" + e.exp;
            t += "&gid=" + G.info.gc;
            i.show(encodeURI(t));
        }
        r.trigger("menu.hide");
    }
    e.exports = o;
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = $("#selectFileNum");
    function r(e) {
        i.text(e);
    }
    function o(e) {
        var t = false;
        var a = false;
        for (var i = 0, r = e.length; i < r; i++) {
            var o = e[i];
            var l = o.value;
            var s = n.getData(l);
            if (s.admin) {
                t = true;
            }
            if (!s.succ) {
                a = true;
            }
        }
        if (!t) {
            $("#batchDel").addClass("disabled");
            $("#batchMove").addClass("disabled");
        } else {
            $("#batchDel").removeClass("disabled");
            $("#batchMove").removeClass("disabled");
        }
        if (a) {
            $("#batchDown").removeClass("disabled");
        } else {
            $("#batchDown").addClass("disabled");
        }
    }
    function l() {
        if (G.mac) {
            return;
        }
        var e = G.getDomPanel()[0];
        var t = e.querySelectorAll(".cbox:checked");
        if (t.length) {
            report("showSelectAll");
            report("showBatch");
            $(".nav").removeClass("hide");
            $("body").addClass("batch-mode");
            $(".file.list-item").attr("data-action", "file.select");
            o(t);
            r(t.length);
        } else {
            $("body").removeClass("batch-mode");
            $(".file.list-item").attr("data-action", "");
        }
    }
    function s() {
        $("body").removeClass("batch-mode");
        $(".cbox").prop("checked", false);
        r(0);
    }
    function f() {
        var e = G.getDomPanel()[0];
        if (this.checked) {
            report("clkSelectAll");
            report("clkBatch");
            G.getDomPanel().find(".cbox").prop("checked", true);
            var t = e.querySelectorAll(".cbox:checked");
            r(t.length);
        } else {
            s();
        }
    }
    function c() {
        var e = G.getDomPanel()[0];
        var t = $(this).find(".cbox");
        if (!t.prop("checked")) {
            t.prop("checked", true);
        } else {
            t.prop("checked", false);
        }
        var a = e.querySelectorAll(".cbox:checked");
        r(a.length);
    }
    e.exports = {
        check: l,
        exit: s,
        selectAll: f,
        select: c
    };
}, function(e, t, a) {
    "use strict";
    var n = a(68);
    var i = a(64);
    var r = a(66);
    var o = a(72);
    var l = a(35);
    var s = a(79);
    var f = a(70);
    var c = $("#batchPanel");
    var d = a(4);
    var u = G.folderVersion;
    var p = 0;
    var v = 0;
    var m = 0;
    var h = 0;
    var g = [];
    function w(e) {
        if (d.getTips()) {} else {
            report("showOldVersion");
            b();
        }
    }
    function b() {
        $("#updateQQ").addClass("open");
        $("#updateQQTips").text("当前版本不支持批量另存功能，请升级QQ至最新版本后体验");
        $("#updateQQ").find("input.btn-notips").attr("data-action", "panel.close");
    }
    function _(e, t) {
        switch (e) {
          case 1:
            return '您选择了<span class="red">' + p + '</span>个文件,其中<span  class="red">' + m + '</span>个文件可以删除<br>您确定要删除这<span  class="red">' + m + "</span>个文件吗?";
            break;

          case 2:
            return "正在删除文件";
            break;

          case 3:
            return '已经成功删除<span class="red">' + t + "</span>个文件";
            break;
        }
    }
    function k() {
        p = 0;
        v = 0;
        m = 0;
        g = [];
    }
    function y() {
        var e = G.getDomPanel()[0];
        var t = e.querySelectorAll(".cbox:checked");
        var a = [];
        k();
        p = t.length;
        for (var n = 0, i = t.length; n < i; n++) {
            var r = t[n];
            var o = r.value;
            var s = l.getData(o);
            if (s) {
                if (s.remove) {
                    m++;
                }
                if (!s.succ) {
                    h++;
                }
                a.push(s);
            }
        }
        G.selectRows = a;
        return a;
    }
    function x() {}
    function F() {
        if (this.classList.contains("disabled")) {
            return;
        }
        report("batchDownload");
        s.hide(c);
        i.downloadBatch(y());
        f.exit();
    }
    function T() {
        if (this.classList.contains("disabled")) {
            return;
        }
        g = y();
        s.showBatchPanel(c, {
            title: "批量删除",
            action: "batch.removeAction",
            text: _(1)
        });
    }
    function C() {
        report("batchDelete");
        s.showBatchPanel(c, {
            title: "批量删除",
            hideAll: true,
            text: _(2)
        });
        f.exit();
        r.removeBatch(g, function(e) {
            s.showBatchPanel(c, {
                title: "批量删除",
                action: "batch.removeAction",
                hideOk: true,
                closeText: "关闭",
                text: _(3, e)
            });
            k();
        });
    }
    function S() {
        if (this.classList.contains("disabled")) {
            return;
        }
        report("batchMove");
        g = y();
        n.showMove();
        return;
    }
    function M() {
        report("batchSaveAs");
        var e = function t() {
            y();
            var e = G.selectRows;
            f.exit();
            var t = [];
            for (var a = e.length - 1; a >= 0; a--) {
                var n = e[a];
                t.push({
                    filepath: n.filepath,
                    filename: n.fnameEsc,
                    domid: n.domid,
                    fname: n.fname,
                    filetype: n.filetype,
                    filesize: n.size
                });
            }
            o.saveBatch(t);
        };
        if (G.info.version < u) {
            w(e);
        } else {
            e();
        }
    }
    e.exports = {
        remove: T,
        removeAction: C,
        download: x,
        downloadAction: F,
        move: S,
        save: M
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(59);
    var l = a(35);
    var s = a(41);
    var f = $(G.handler);
    function c(e) {
        if (this.classList.contains("disable")) {
            return;
        }
        var t = e || G.selectRow;
        report("clkSaveAs", G.module());
        if (t && t.orcType === 1) {
            if (t.inDown) {} else {
                var a = t.filepath;
                var n = t.fnameEsc;
                var i = t.size;
                var r = {
                    bs: t.t,
                    fp: t.fp
                };
                var l = $("#" + t.domid);
                var s = l.attr("idx");
                var c = {
                    ver1: G.module(),
                    ver2: 0,
                    ver3: encodeURIComponent(t.name),
                    ver4: encodeURIComponent(t.filetype),
                    ver5: 3,
                    ver6: G.module() + "_" + s,
                    ver7: G.info.role
                };
                reportNew("fileDownload", c);
                var d = o.addDownloadTask(a, n, i);
                f.trigger("menu.hide");
            }
        }
    }
    function d(e) {
        var t = {
            files: e,
            save2default: 0
        };
        var a = $("#" + e[0].domid);
        var n = a.attr("idx");
        var r = {
            ver1: G.module(),
            ver2: 0,
            ver3: encodeURIComponent(e[0].fname),
            ver4: encodeURIComponent(e[0].filetype),
            ver5: 5,
            ver6: G.module() + "_" + n,
            ver7: G.info.role
        };
        reportNew("fileDownload", r);
        o.addMultiDownloadTasks((0, i.default)(t));
    }
    e.exports = {
        save: c,
        saveBatch: d
    };
}, function(e, t, a) {
    "use strict";
    var n = a(8);
    var i = {};
    i.byUin = function() {
        var e = $(this).data("uin");
        var t = this.innerHTML;
        var a = function i() {
            G.module(2);
            $("#navTopFolder").addClass("selected");
            $("#createFolder").hide();
            $("#fileNum").addClass("hide").attr("data-action", "menu.filenum");
            $("#headerLine").text(">");
            $("#box").addClass("one");
            $("#folderName").html('<div style="display: -webkit-box;"><div class="uploader-name">' + t + "</div><div>上传的文件</div></div>").removeClass("hide");
            $("#normalNav").removeClass("hide");
            if (G.mac) {
                $(".mac-file-top").addClass("user-module");
            }
        };
        G.module(2);
        n.getList({
            paramsFilter: {
                filterUin: e,
                filterCode: 3
            },
            succ: a,
            renderParams: {
                getByUinHide: true,
                uploaderHide: true
            }
        })();
    };
    e.exports = i;
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = a(41);
    var r = a(121);
    var o = $(G.handler);
    var l = {
        "1": "没有登陆或登陆态失效",
        "2": "系统内部错误",
        "7": "没有群权限",
        "21": "不是上传者或群主不能转永久",
        "22": "不能跨群转永久文件",
        "23": "登录态校验失败",
        "24": "群成员关系校验失败",
        "25": "容量满，可以升级",
        "26": "容量满，不能再升级",
        "27": "要转存的文件不存在",
        "28": "永久空间容量超限"
    };
    function s() {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkForever");
        var e = G.selectRow.path;
        var t = n.getFile(e);
        if (t && t.remoteType === 2) {
            var a = t.filepath;
            var l = {
                fp: a
            };
            i.setPermanent(l).done(function(e) {
                if (e.ec === 0) {
                    var a = "/102" + e.fp;
                    t.newFilePath = a;
                    t.remoteType = 1;
                    t.fp = e.fp;
                    t.temp = false;
                    n.updateFile(t, "permanent");
                    o.trigger("file.dataUpdate", t);
                    o.trigger("toast.show", {
                        type: "suc",
                        text: "转存成功"
                    });
                }
            }).fail(function(e) {
                console.log(e);
                r.showError(e.ec);
            });
        } else {
            console.log("文件不存在或者不是临时文件");
        }
        o.trigger("menu.hide");
    }
    e.exports = s;
}, function(e, t, a) {
    "use strict";
    var n = a(25);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(41);
    var l = a(98);
    var s = a(35);
    var f = a(10);
    G.renderOtherGroupResultFuncSingtons = {};
    var c = void 0;
    function d() {
        var e = true;
        return function(e, t) {
            var a = G.getDomPanel();
            if (!e) {
                return;
            }
            var n = [ t ];
            var i = e.file[0];
            var r = i.domid;
            if ($("#" + r).length === 0) {
                i.name = f.heightLight(i.name, [ t ]);
                i.suf = f.heightLight(i.suf, [ t ]);
                var o = l({
                    list: e.file
                });
                a.prepend(o);
            }
            $("#" + r).addClass("height-light");
        };
    }
    function u(e, t) {
        e = e || {};
        var a = e.busId;
        var n = e.fileId;
        o.getFileAttr({
            bus_id: a,
            file_id: n
        }).done(function(e) {
            var a = [];
            if ((0, i.default)(e.file_info) === "object") {
                e.file_info.upload_size = e.file_info.size;
            } else {
                return;
            }
            var r = e.file_info;
            r.proId = r.id;
            r.id = n;
            a.push(r);
            a = s.setFileList(a);
            d()(a, t);
        }).fail(function(e) {
            console.log("fail", e);
        });
    }
    window.getFileAttr = u;
    e.exports = u;
}, function(e, t, a) {
    "use strict";
    var n = a(25);
    var i = l(n);
    var r = a(26);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = a(41);
    var f = a(35);
    var c = {};
    e.exports = c;
    function d(e) {
        f.setAllNum(e);
        f.setRole(e);
        return f.setFileList(e.list);
    }
    c.getList = function(e) {
        e = e || {};
        var t = e.folderId || "/";
        var a = e.filterUin || undefined;
        var n = 0;
        var r = 25;
        var l = e.filterCode || 0;
        var f = false;
        var c = undefined;
        var u = false;
        var p = false;
        return function(e, v, m) {
            if (p) {
                return;
            }
            p = true;
            if (f) {
                v({
                    ec: 1e3,
                    em: "no more items"
                });
                return;
            }
            var h = {
                folder_id: t,
                start_index: n,
                cnt: r,
                filter_code: l,
                filter_uin: a
            };
            var g = (0, o.default)(h) === c;
            c = (0, o.default)(h);
            if (u && g) {
                console.log("same params will be ignored");
                return;
            }
            m && m();
            var w = function b(a) {
                p = false;
                u = true;
                var i = {
                    list: a.file_list,
                    total: a.total_cnt,
                    totalSpace: a.total_space,
                    usedSpace: a.used_space,
                    userRole: a.user_role,
                    openFlag: a.open_flag
                };
                G.nowFolder = t;
                if (a.file_list && a.file_list.length) {
                    n = n + a.file_list.length;
                }
                if (a.next_index === 0) {
                    f = true;
                }
                e(d(i));
            };
            if ((typeof nodeData === "undefined" ? "undefined" : (0, i.default)(nodeData)) === "object") {
                w(nodeData);
                nodeData = false;
            } else {
                s.getFileList(h).done(function(e) {
                    w(e);
                }).fail(function(e) {
                    report("getListError");
                    p = false;
                    u = false;
                    v(e);
                });
            }
        };
    };
    c.getFileList = function(e) {
        s.getFileList(e).done(function(e) {
            if (e.total_cnt === 0 && folderId === "/") {
                suc(false);
                return;
            }
            console.log(e);
            var t = {
                list: e.file_list,
                total: e.total_cnt,
                totalSpace: e.total_space,
                usedSpace: e.used_space,
                userRole: e.user_role,
                openFlag: e.open_flag
            };
            G.nowFolder = folderId;
            if (e.file_list && e.file_list.length) {
                startIndex = startIndex + e.file_list.length;
            }
            if (e.next_index === 0) {
                isEnd = true;
            }
            suc(d(t));
        }).fail(function(e) {
            console.log(e);
            if (e.fc && e.fc === 1) {
                return;
            }
        });
    };
    c.setAllSpace = function(e, t) {
        s.getSpace().done(function(t) {
            var a = {
                totalSpace: t.total_space,
                usedSpace: t.used_space
            };
            f.setAllSpace(a);
            e(t);
        }).fail(function(e) {
            console.log(e);
        });
    };
}, function(e, t, a) {
    "use strict";
    var n = $(G.handler);
    var i = $("#fileNum");
    var r = $("#fileNumMenu");
    var o = $(".file-more");
    var l = $("#fileMoreMenu");
    var s = a(166);
    var f = a(35);
    var c = null;
    var d = void 0;
    var u = $("#fileFoward");
    var p = $("#fileFowardTo");
    var v = $("#fileOpenFolder");
    var m = $("#filePreview");
    var h = $("#renameFile");
    var g = $("#foreverFile");
    var w = $("#fileDelete");
    var b = $("#fileMove");
    var _ = $("#fileJubao");
    function k(e, t) {
        report("clkFiles");
        var a = $(".hover-border.file-num-toggle");
        if (r.is(":hidden")) {
            r.show();
            a.addClass("active");
        } else {
            r.hide();
            a.removeClass("active");
        }
    }
    function y() {
        var e = G.selectRow.path;
        var t = f.getData(e);
        m.removeClass("disable");
        u.removeClass("disable");
        p.removeClass("disable");
        v.removeClass("disable");
        h.removeClass("disable");
        g.removeClass("disable");
        b.removeClass("disable");
        w.removeClass("disable");
        _.removeClass("disable");
        if (t.icon === "pic" && t.preview) {
            m.removeClass("disable");
        } else {
            m.addClass("disable");
        }
        if (!t.isDown) {
            v.attr("title", "另存为").attr("data-action", "file.saveAs");
            v.find(".menu-item-label").text("另存为");
        } else {
            v.attr("title", "在文件夹中显示").attr("data-action", "file.openFolderInBox");
            v.find(".menu-item-label").text("在文件夹中显示");
        }
        if (t.temp && t.admin) {
            g.removeClass("disable");
        } else {
            g.addClass("disable");
        }
        if (t.admin) {
            h.removeClass("disable");
            w.removeClass("disable");
            report("showFolderMove");
        } else {
            h.addClass("disable");
            w.addClass("disable");
        }
        if (G.info.isAdmin) {
            b.removeClass("disable");
        } else {
            b.addClass("disable");
        }
        if (G.module() !== 3) {
            b.show();
        } else {
            b.hide();
        }
        if (t.safeType) {
            m.addClass("disable");
            u.addClass("disable");
            p.addClass("disable");
            v.addClass("disable");
            h.addClass("disable");
            g.addClass("disable");
            b.addClass("disable");
        }
    }
    function x() {
        var e = G.selectRow.path;
        var t = f.getData(e);
        if (t) {
            if (t.succ) {
                l.find(".open-in-folder").removeClass("disable");
                l.find(".download-item").removeClass("disable");
            } else {
                l.find(".open-in-folder").addClass("disable");
                if (t.filenum === 0) {
                    l.find(".download-item").addClass("disable").removeAttr("data-action");
                } else {
                    l.find(".download-item").removeClass("disable").attr("data-action", "folder.download");
                    report("showDownloadBtn", G.module());
                }
            }
        }
        if (G.oldVersion) {
            l.find(".download-item").addClass("disable").removeAttr("data-action");
        }
    }
    function F(e) {
        $(".list-item").removeClass("active");
        e.addClass("active");
    }
    function T() {
        var e = this;
        var t = $(this).parents(".list-item");
        var a = t.data("path");
        var n = void 0;
        var i = void 0;
        F(t);
        report("clkShowBtn", G.module());
        i = f.getData(a);
        if (i.orcType === 2) {
            n = "fold";
            report("clkFolderMore", G.info.isAdmin ? 0 : 1);
        } else if (i.orcType == 1) {
            n = "file";
            if (i.succ) {
                report("clkUnMore");
            } else {
                report("clkMore");
            }
        }
        G.selectRow = i || {};
        G.selectRow.path = a;
        G.selectRow.type = n;
        G.selectRows = [ G.selectRow ];
        if (n === "fold") {
            if (d !== n) {
                s.renderFolder();
            }
            x();
        } else if (n === "file") {
            if (d === n) {
                y();
            } else {
                s.renderFile();
                u = $("#fileFoward");
                p = $("#fileFowardTo");
                v = $("#fileOpenFolder");
                m = $("#filePreview");
                h = $("#renameFile");
                g = $("#foreverFile");
                w = $("#fileDelete");
                b = $("#fileMove");
                var r = $("#menuPreview");
                y();
            }
        }
        d = n;
        if (e == c && l[0].style.display === "block") {
            l.css("display", "none");
        } else {
            var o = e.getBoundingClientRect();
            var _ = $(e).parents(".scroll-dom")[0];
            var k = _.getBoundingClientRect();
            var T = k.right - o.right;
            var C = document.querySelector(".scroll-dom");
            var S = C.scrollTop;
            var M = C.scrollHeight;
            var j = o.bottom + S - 52;
            l.css("display", "block");
            var R = l.get(0).offsetHeight;
            if (j + R > S + window.innerHeight) {
                j = j - R - 28;
            }
            l.css({
                right: T + "px",
                top: j + "px"
            });
            c = e;
        }
    }
    function C(e) {
        return $(e).closest("#fileNumMenu").length == 0;
    }
    function S(e) {
        return $(e).closest("#fileMoreMenu").length == 0 && $(e).closest(".file-more").length == 0;
    }
    function M(e) {
        if (C(e)) {
            r.hide();
            var t = $(".hover-border.file-num-toggle");
            t.removeClass("active");
        }
        if (S(e)) {
            l.hide();
        }
    }
    function j() {
        report("clkRefresh");
    }
    function R() {
        M();
        report("clkFeed");
    }
    n.bind("menu.hide", M);
    e.exports = {
        "menu.filenum": k,
        "menu.filemore": T,
        "menu.foldmore": T,
        "menu.hide": M,
        "menu.refresh": j,
        "menu.feedback": R
    };
}, function(e, t, a) {
    "use strict";
    var n = a(25);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(168).fileEvent;
    var l = a(118).groupEvent;
    var s = a(169).uploadEvent;
    var f = a(169).dropEvent;
    var c = a(167);
    var d = top;
    var u = top.external;
    window.addEventListener("message", v);
    d["PostMessage"] = d["onClientEvent"] = p;
    function p(e) {
        var t = void 0;
        if (!e) {
            console.error("[Client] msg is not exist!");
            return;
        }
        if (typeof e === "string") {
            try {
                t = JSON.parse(e);
            } catch (a) {
                console.error("[Client|init()]msg is string, but parse to object catch e!");
            }
        }
        if ((typeof t === "undefined" ? "undefined" : (0, i.default)(t)) !== "object") {
            console.error("[Client|init()]after parse, got no object!");
            return;
        }
        v(t);
    }
    function v(e) {
        var t = e;
        if (t && (typeof t === "undefined" ? "undefined" : (0, i.default)(t)) === "object") {
            if (t.from === "Client") {
                var a = t.data;
                if (typeof a === "string") {
                    a = JSON.parse(t.data) || {};
                }
                var n = a.cmd || "";
                switch (n) {
                  case "OnFiletransporterEvent":
                    o(a.param);
                    break;

                  case "OnGroupShareTabChangedEvent":
                    l(a.param);
                    break;

                  case "OnGroupUploadFileListsEvent":
                    s(param);
                    break;

                  case "OnGroupDropInGroupFolderUpload":
                    s(param);
                    break;

                  default:
                    console.warn("warn:预期外的message.cmd:" + n);
                    break;
                }
            } else if (t.cmd && t.cmd === "OnGroupUploadFileListsEvent") {
                s(t.param);
            } else if (t.cmd && t.cmd === "OnGroupDropInGroupFolderUpload") {
                f(t.param);
            } else {
                var r = t.data;
                if (!r) {
                    return;
                }
                if (typeof r === "string") {
                    r = JSON.parse(r);
                }
                var d = r.cmd || "";
                switch (d) {
                  case "jubao_close":
                    c.hide();
                    break;

                  default:
                    console.warn("warn:预期外的message.cmd:" + d);
                    break;
                }
            }
        }
    }
    window.onClientEvent = p;
    e.exports = {};
}, function(e, t, a) {
    "use strict";
    var n = {
        folderTreePanel: a(227)
    };
    var i = a(164);
    var r = $(G.handler);
    function o(e, t) {
        r.trigger("menu.hide");
        e.find(".panel-title span").text(t.title);
        e.find(".rename-hint").text(t.tips);
        e.find(".btn-ok").attr("data-action", t.action);
        var a = e.find(".new-name");
        if (t.showValue) {
            a.val(t.showValue);
        }
        e.find(".error-message").removeClass("show");
        e.addClass("open").focus();
        if (t.showValue) {
            a[0].inputStart = true;
            a[0].focus();
            a[0].select();
            setTimeout(function() {
                a[0].inputStart = false;
            }, 200);
        }
    }
    function l(e) {
        e.removeClass("open");
    }
    function s(e) {
        r.trigger("menu.hide");
        var t = $("#containerFolderTreePanel");
        t.html(n.folderTreePanel(e));
        i.render(t.find(".folder-tree-box"));
        t.find("#folderTreePanel").addClass("open");
    }
    function f(e, t) {
        r.trigger("menu.hide");
        e.addClass("open").focus();
        if (t) {
            if (t.hideAll) {
                e.find(".panel-footer").addClass("hide");
            } else {
                e.find(".panel-footer").removeClass("hide");
            }
            if (t.hideOk) {
                e.find(".btn-ok").addClass("hide");
            } else {
                e.find(".btn-ok").removeClass("hide");
            }
            if (t.closeText) {
                e.find(".btn-no").text("确定").val("确定");
            } else {
                e.find(".btn-no").text("取消").val("取消");
            }
            e.find(".panel-title span").text(t.title);
            e.find(".panel-content").html(t.text);
            e.find(".btn-ok").attr("data-action", t.action);
        }
    }
    function c() {
        $(".panel-overlay").removeClass("open");
    }
    r.bind("panel.hideAll", c);
    e.exports = {
        show: o,
        hide: l,
        hideAll: c,
        showFolderTreePanel: s,
        showBatchPanel: f
    };
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = a(59);
    var r = a(8);
    var o = a(34);
    var l = a(4);
    var s = $(G.handler);
    function f(e) {
        delete e.status;
        e.isDown = false;
        e.isDowning = false;
        e.succ = false;
        r.updateRow(e);
        o.removeOpenFolder(e);
        l.remove(e);
    }
    function c(e) {
        s.trigger("menu.hide");
        if (window.external && window.external.isFileExist) {
            var t = window.external.isFileExist(e);
            if (t == "false" || t === false) {
                i.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                var a = n.getFile(e);
                f(a);
                return false;
            }
        } else {}
        if (window.external && window.external.openFile) {
            var r = window.external.openFile(e);
            if (r == "success") {
                return true;
            } else if (r !== "file cannot open") {
                return false;
            }
        }
        if (window.external && window.external.openFolder) {
            var o = window.external.openFolder(e);
            if (o == "success") {} else {
                i.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                return false;
            }
        } else {}
    }
    function d() {
        if (this.classList.contains("disable")) {
            return;
        }
        var e = G.selectRow;
        var t = e.localpath;
        s.trigger("menu.hide");
        if (typeof t === "string" && t.indexOf("OSRoot") < 0) {
            t = "OSRoot:\\" + t;
        }
        report("clkOpenFile", G.module());
        if (window.external && window.external.isFileExist) {
            var a = window.external.isFileExist(t);
            if (a == "false" || a === false) {
                i.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                f(e);
                return false;
            }
        } else {}
        if (window.external && window.external.openFolder) {
            var n = window.external.openFolder(t);
            if (n == "success") {} else {
                i.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                return false;
            }
        } else {}
    }
    function u() {
        var e = $(this).parents(".file");
        var t = e.data("path");
        var a = n.getData(t);
        var r = a.localpath;
        s.trigger("menu.hide");
        if (a.safeType) {
            var o = G.getReportInfo(a);
            o.ver3 = o.ver4;
            o.ver4 = o.ver5;
            o.ver5 = a.isDown ? 2 : 1;
            reportNew("blackTips", o);
            i.alert(2, "提示", "该文件存在安全风险，无法正常使用");
            return;
        }
        if (typeof r === "string" && r.indexOf("OSRoot") < 0) {
            r = "OSRoot:\\" + r;
        }
        report("clkOpenFile", G.module());
        if (window.external && window.external.isFileExist) {
            var l = window.external.isFileExist(r);
            if (l == "false" || l === false) {
                i.alert(2, "提示", "此文件不存在，可能已被删除或被移动到其他位置");
                f(a);
                return false;
            }
        } else {}
        if (window.external && window.external.openFile) {
            var c = window.external.openFile(r);
            if (c == "success") {
                return true;
            } else if (c !== "file cannot open") {
                return false;
            }
        }
        if (window.external && window.external.openFolder) {
            var d = window.external.openFolder(r);
            if (d == "success") {} else {
                i.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                f(a);
                return false;
            }
        } else {}
    }
    function p() {
        var e = this;
        s.trigger("menu.hide");
        report("clkShowInFolder", G.module());
        while (!e.classList.contains("complete")) {
            e = e.parentNode;
        }
        var t = $(e);
        var a = t.data("path");
        var i = n.getData(a);
        var r = i._localpath || i.localpath || i.localname;
        if (r && r.indexOf("OSRoot:\\") != 0) {
            r = "OSRoot:\\" + r;
        }
        var o = c(r);
        if (o == false) {}
    }
    function v() {
        var e = this;
        s.trigger("menu.hide");
        while (!e.classList.contains("complete")) {
            e = e.parentNode;
        }
        var t = $(e);
        var a = t.data("path");
        var r = n.getData(a);
        $("#boxTitle a").focus();
        if (r) {
            var o = r._localpath || r.localpath || r.localname;
            if (o) {
                if (typeof o === "string" && o.indexOf("OSRoot:\\") != 0) {
                    o = "OSRoot:\\" + o;
                }
                var l = false;
                if (window.external && window.external.openFolder) {
                    var c = window.external.openFolder(o);
                    if (c == "success") {
                        l = true;
                    } else {
                        i.alert(2, "提示", "此文件夹不存在，可能被删除或被移动到其他位置");
                    }
                } else {}
                if (l == false) {
                    f(r);
                }
            } else {
                f(r);
            }
        }
    }
    function m() {
        if (this.classList.contains("disable")) {
            return;
        }
        var e = G.selectRow.path;
        var t = n.getFile(e);
        s.trigger("menu.hide");
        if (t) {
            report("clkShowInFolder", G.module());
            var a = t.localpath;
            if (a) {
                if (typeof a === "string" && a.indexOf("OSRoot:\\") != 0) {
                    a = "OSRoot:\\" + a;
                }
                var r = false;
                if (window.external && window.external.openFolder) {
                    var o = window.external.openFolder(a);
                    console.log(o);
                    if (o == "success") {
                        r = true;
                    } else {
                        i.alert(2, "提示", "此文件夹不存在，可能被删除或被移动到其他位置");
                    }
                } else {}
                if (r == false) {
                    f(t);
                }
            } else {
                f(t);
            }
        }
    }
    e.exports = {
        openByFolder: d,
        openByPath: u,
        openByBox: p,
        openByMenu: m,
        openFolderByBoxIco: v
    };
}, , , , , , , , , , , function(e, t, a) {
    "use strict";
    var n = {};
    var i = $("#groupSize");
    var r = $("#groupSizeBar");
    n.renderSpace = function o() {
        if (G.nowFolder !== "/") {
            return;
        }
        i.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        r.css("width", e + "%");
        $("#fileNum").removeClass("hide");
        $(".nav").addClass("hide");
        $("#normalNav").removeClass("hide");
    };
    e.exports = n;
}, function(e, t, a) {
    var n = a(101), i = n.JSON || (n.JSON = {
        stringify: JSON.stringify
    });
    e.exports = function r(e) {
        return i.stringify.apply(i, arguments);
    };
}, , function(e, t, a) {
    a(107);
    a(108);
    e.exports = a(102).f("iterator");
}, function(e, t, a) {
    a(103);
    a(104);
    a(105);
    a(106);
    e.exports = a(101).Symbol;
}, function(e, t, a) {
    a(109);
    e.exports = a(101).Object.keys;
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '	<div class="toast-overlay" id="toastDom" aria-describedby="toastText" tabindex="-1">\r\n		<div class="toast" id="toastInfo">\r\n			<div class="icons-<%-locals.cls%> toast-icon"></div>\r\n			<div class="toast-message" id="toastText"><%-locals.text%></div>\r\n		</div>\r\n	</div>',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('	<div class="toast-overlay" id="toastDom" aria-describedby="toastText" tabindex="-1">\n		<div class="toast" id="toastInfo">\n			<div class="icons-', (__stack.lineno = 3, 
                    locals.cls), ' toast-icon"></div>\n			<div class="toast-message" id="toastText">', (__stack.lineno = 4, 
                    locals.text), "</div>\n		</div>\n	</div>");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<%\n	for(var i = 0,l=locals.list.length;i<l;i++){\n		var item = locals.list[i];\n		if(item.orcType === 2){\n%>\n\n	<div class="fold list-item <%if(item.succ){%>succ<%}%>" data-path="<%=item.id%>" id="<%=item.domid%>" data-action="folder.open">\n		<div class="file-select">\n\n		</div>\n		<div class="file-icons">\n			<div class="files-folder" data-action="folder.open"  data-path="<%=item.id%>" data-viewcntr="folder<%=item.domid%>"></div>\n			<i class="icons-check"></i>\n		</div>\n		<dl class="file-info">\n			<dt>\n				<div class="name" data-action="folder.open"  data-path="<%=item.id%>" data-viewcntr="folder<%=item.domid%>"><%- item.fname %></div>\n			</dt>\n\n			<dd>\n				<span class="file-size" title="<%- item.filenum %>个文件"><%- item.filenum %>个文件</span>\n				<span class="file-dot">.</span>\n				<span class="uploadtime" title="更新时间:<%= item.mtStr %>"><%= item.mtStr %> 更新</span>\n			</dd>\n		</dl>\n		<%if(locals.renderParams&&locals.renderParams.actionHide===true){}else{%>\n		<div class="file-action">\n			<div class="btn-group">\n				<a href="javascript:void(0)" class="btn-left download open open-folder-link" title="打开文件夹" tabindex="3" aria-label="打开文件夹<%- item.fname %>"  data-action="folder.open" data-path="<%=item.id%>"  data-viewcntr="folder<%=item.domid%>" tabindex="3">\n					<i class="open mac-folder"></i><%if(!G.mac){%>打开<%}%>\n				</a>\n				<a class="file-more icons-btn-right-down folder-icon-down-link" data-action="menu.foldmore" menu="file-menu" title="更多"></a>\n				<div class="aria-hide">\n					<a href="javascript:void(0)" data-focus="file.aria" aria-label="下载文件夹<%=item.fname%>" data-action="folder.download" tabindex="3">下载</a>\n					<a href="javascript:void(0)" data-focus="file.aria" aria-label="重命名文件夹<%=item.fname%>" data-action="folder.showRenameFolder" data-blur="aria.fmg" tabindex="3">重命名</a>\n					<a href="javascript:void(0)" data-focus="file.aria" aria-label="查看文件夹属性<%=item.fname%>" data-action="folder.property" data-blur="aria.fmg" tabindex="3">文件夹属性</a>\n					<%if(G.info.isAdmin){%>\n					<a href="javascript:void(0)"  data-focus="file.aria" aria-label="删除文件夹<%=item.fname%>" data-action="folder.showDeleteFolder" tabindex="3">删除</a>\n					<%}else{%>\n					<a href="javascript:void(0)"  data-focus="file.aria" aria-label="举报<%=item.fname%>" data-action="file.jubao" tabindex="3">举报</a>\n					<%}%>\n				</div>\n			</div>\n		</div>\n		<%}%>\n		<div class="line"></div>\n	</div>\n<%\n}else{\n%>\n	<div class="file list-item <%=item.icon%> <%if(item.remoteType===2){%>temp<%}%> <%if(item.succ){%>succ<%}%> <%if(item.safeType){%>illegal<%}%>" id="<%=item.domid%>" data-path="<%=item.filepath%>" <%if(!locals.renderParams){%>id="<%=item.domid%>"<%}%> <%if(item.otherGroupName){%> data-action="openGroupFile" data-uin="<%- item.gc %>"<%}%> <%if(item.preview){%>data-action="file.preview"<%}%> <%if(item.safeType){%>title="该文件存在安全风险，无法正常使用"<%}%>>\n		<div class="file-select">\n		<%if(locals.batchMode===undefined?true:locals.batchMode){%>\n			<input type="checkbox" class="cbox" data-action="file.check" aria-label="文件类型:<%=item.filetype%>,名称<%=item.fname%>,大小:<%=item.sizeStr%>,下载次数:<%=item.down%>次,上传人:<%=item.nick%>,上传时间:<%=item.ctStr%>" tabindex="3" value="<%=item.filepath%>">\n		<%}%>\n		</div>\n		<div class="file-icons" data-path="<%=item.filepath%>" <%if(item.preview){%>data-action="file.preview"<%}%>>\n			<div class="files-<%=item.icon%> <%if(item.previewObj){%>thumb<%}%>" <%if(item.previewObj){%>style="background-image:url(<%=item.previewObj.url%>);"<%}%>></div>\n			<i class="icons-check"></i>\n		</div>\n		<dl class="file-info">\n			<dt>\n				<div class="name"><%- item.name %></div>\n				<div class="suffix"><%- item.suf %></div>\n				<div class="icons-temp-icon" <%if(!item.safeType){%>title="临时文件"<%}%>></div>\n				<div class="security"></div>\n			</dt>\n\n			<dd>\n				<span class="file-size" <%if(!item.safeType){%>title="文件大小:<%= item.sizeStr%>"<%}%>><%= item.sizeStr%></span>\n				<span class="file-dot">.</span>\n				<span <%if(!item.safeType){%>title="下载次数:<%=item.down%>次"<%}%>><span class="downloadtime"><%=item.down%>次下载</span></span>\n\n				<%if(locals.renderParams&&locals.renderParams.uploaderHide===true){}else{%>\n					<span class="uploader" <%if(!item.safeType){%>title="上传者:<%=item.nick%> (<%=item.uin%>)"<%}%>><i class="uploader-name" <%if(locals.renderParams&&locals.renderParams.getByUinHide===true){%>data-action=""<%}else{%>data-action="file.getByUin"<%}%> data-uin="<%=item.uin%>"><%- item.nick%></i></span>\n				<%}%>\n\n				<span class="uploadtime" <%if(!item.safeType){%>title="上传时间:<%=item.ctStr%>"<%}%>><%= item.ctStr %></span>\n\n				<%if(item.folderName){%>\n					<span  class="uploader" <%if(!item.safeType){%>title="来自：<%=item.folderName%>"<%}%> data-action="folder.open" data-path="<%- item.parentId %>">来自：<a class="from-folder-name"><%=item.folderName%></a></span>\n				<%}%>\n\n				<%if(item.otherGroupName){%>\n					<span class="from-group">来自群：</span>\n					<span class="other-group-name" data-action="openGroupInfoCard" <%if(!item.safeType){%>title="来自群：<%=item.otherGroupName%>"<%}%> data-uin="<%- item.gc %>"><%- item.otherGroupName %></span>\n				<%}%>\n			</dd>\n		</dl>\n		<%if(locals.renderParams&&locals.renderParams.actionHide===true){}else{%>\n			<div class="file-action">\n				<div class="btn-group">\n					<%if(item.isDown){%>\n					<a href="javascript:void(0)" class="btn-left download open open-file-link" data-action="file.openFolder" title="打开" tabindex="3" aria-label="打开文件<%=item.name%>">\n						<i class="open"></i><%if(!G.mac){%>打开<%}%>\n					</a>\n					<%}else{%>\n					<a href="javascript:void(0)" class="btn-left download download-file-link" data-action="file.download" title="下载" tabindex="3" aria-label="下载文件<%=item.name%>">\n						<i class="down"></i><%if(!G.mac){%>下载<%}%>\n					</a>\n					<%}%>\n					<a class="file-more icons-btn-right-down file-icons-down-link" data-action="menu.filemore" menu="file-menu" title="更多"></a>\n				</div>\n			</div>\n		<%}%>\n		<div class="aria-hide">\n			<%if(item.admin || G.info.isAdmin){%>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="转发文件<%=item.fname%>" data-action="file.forward" tabindex="3">转发</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="转发文件到手机<%=item.fname%>" data-action="file.forwardMobile" tabindex="3">转发文件到手机</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="在文件夹中显示<%=item.fname%>" data-action="file.openFolderInBox" tabindex="3">在文件夹中显示</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="重命名文件<%=item.fname%>" data-action="file.showRename" data-blur="aria.fmg" tabindex="3">重命名</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="转存为永久文件<%=item.fname%>" data-action="file.permanent" tabindex="3">转存为永久文件</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="移动文件<%=item.fname%>" data-action="file.showMove" data-blur="aria.fmg" tabindex="3">移动文件</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="删除文件<%=item.fname%>" data-action="file.delete" tabindex="3">删除</a>\n			<%}%>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="举报文件<%=item.fname%>" data-action="file.jubao" tabindex="3">举报文件</a>\n		</div>\n		<div class="line"></div>\n	</div>\n<%}}%>\n',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push("");
                    __stack.lineno = 1;
                    for (var e = 0, t = locals.list.length; e < t; e++) {
                        var a = locals.list[e];
                        if (a.orcType === 2) {
                            buf.push('\n\n	<div class="fold list-item ');
                            __stack.lineno = 7;
                            if (a.succ) {
                                buf.push("succ");
                                __stack.lineno = 7;
                            }
                            buf.push('" data-path="', escape((__stack.lineno = 7, a.id)), '" id="', escape((__stack.lineno = 7, 
                            a.domid)), '" data-action="folder.open">\n		<div class="file-select">\n\n		</div>\n		<div class="file-icons">\n			<div class="files-folder" data-action="folder.open"  data-path="', escape((__stack.lineno = 12, 
                            a.id)), '" data-viewcntr="folder', escape((__stack.lineno = 12, a.domid)), '"></div>\n			<i class="icons-check"></i>\n		</div>\n		<dl class="file-info">\n			<dt>\n				<div class="name" data-action="folder.open"  data-path="', escape((__stack.lineno = 17, 
                            a.id)), '" data-viewcntr="folder', escape((__stack.lineno = 17, a.domid)), '">', (__stack.lineno = 17, 
                            a.fname), '</div>\n			</dt>\n\n			<dd>\n				<span class="file-size" title="', (__stack.lineno = 21, 
                            a.filenum), '个文件">', (__stack.lineno = 21, a.filenum), '个文件</span>\n				<span class="file-dot">.</span>\n				<span class="uploadtime" title="更新时间:', escape((__stack.lineno = 23, 
                            a.mtStr)), '">', escape((__stack.lineno = 23, a.mtStr)), " 更新</span>\n			</dd>\n		</dl>\n		");
                            __stack.lineno = 26;
                            if (locals.renderParams && locals.renderParams.actionHide === true) {} else {
                                buf.push('\n		<div class="file-action">\n			<div class="btn-group">\n				<a href="javascript:void(0)" class="btn-left download open open-folder-link" title="打开文件夹" tabindex="3" aria-label="打开文件夹', (__stack.lineno = 29, 
                                a.fname), '"  data-action="folder.open" data-path="', escape((__stack.lineno = 29, 
                                a.id)), '"  data-viewcntr="folder', escape((__stack.lineno = 29, a.domid)), '" tabindex="3">\n					<i class="open mac-folder"></i>');
                                __stack.lineno = 30;
                                if (!G.mac) {
                                    buf.push("打开");
                                    __stack.lineno = 30;
                                }
                                buf.push('\n				</a>\n				<a class="file-more icons-btn-right-down folder-icon-down-link" data-action="menu.foldmore" menu="file-menu" title="更多"></a>\n				<div class="aria-hide">\n					<a href="javascript:void(0)" data-focus="file.aria" aria-label="下载文件夹', escape((__stack.lineno = 34, 
                                a.fname)), '" data-action="folder.download" tabindex="3">下载</a>\n					<a href="javascript:void(0)" data-focus="file.aria" aria-label="重命名文件夹', escape((__stack.lineno = 35, 
                                a.fname)), '" data-action="folder.showRenameFolder" data-blur="aria.fmg" tabindex="3">重命名</a>\n					<a href="javascript:void(0)" data-focus="file.aria" aria-label="查看文件夹属性', escape((__stack.lineno = 36, 
                                a.fname)), '" data-action="folder.property" data-blur="aria.fmg" tabindex="3">文件夹属性</a>\n					');
                                __stack.lineno = 37;
                                if (G.info.isAdmin) {
                                    buf.push('\n					<a href="javascript:void(0)"  data-focus="file.aria" aria-label="删除文件夹', escape((__stack.lineno = 38, 
                                    a.fname)), '" data-action="folder.showDeleteFolder" tabindex="3">删除</a>\n					');
                                    __stack.lineno = 39;
                                } else {
                                    buf.push('\n					<a href="javascript:void(0)"  data-focus="file.aria" aria-label="举报', escape((__stack.lineno = 40, 
                                    a.fname)), '" data-action="file.jubao" tabindex="3">举报</a>\n					');
                                    __stack.lineno = 41;
                                }
                                buf.push("\n				</div>\n			</div>\n		</div>\n		");
                                __stack.lineno = 45;
                            }
                            buf.push('\n		<div class="line"></div>\n	</div>\n');
                            __stack.lineno = 48;
                        } else {
                            buf.push('\n	<div class="file list-item ', escape((__stack.lineno = 51, a.icon)), " ");
                            __stack.lineno = 51;
                            if (a.remoteType === 2) {
                                buf.push("temp");
                                __stack.lineno = 51;
                            }
                            buf.push(" ");
                            __stack.lineno = 51;
                            if (a.succ) {
                                buf.push("succ");
                                __stack.lineno = 51;
                            }
                            buf.push(" ");
                            __stack.lineno = 51;
                            if (a.safeType) {
                                buf.push("illegal");
                                __stack.lineno = 51;
                            }
                            buf.push('" id="', escape((__stack.lineno = 51, a.domid)), '" data-path="', escape((__stack.lineno = 51, 
                            a.filepath)), '" ');
                            __stack.lineno = 51;
                            if (!locals.renderParams) {
                                buf.push('id="', escape((__stack.lineno = 51, a.domid)), '"');
                                __stack.lineno = 51;
                            }
                            buf.push(" ");
                            __stack.lineno = 51;
                            if (a.otherGroupName) {
                                buf.push(' data-action="openGroupFile" data-uin="', (__stack.lineno = 51, a.gc), '"');
                                __stack.lineno = 51;
                            }
                            buf.push(" ");
                            __stack.lineno = 51;
                            if (a.preview) {
                                buf.push('data-action="file.preview"');
                                __stack.lineno = 51;
                            }
                            buf.push(" ");
                            __stack.lineno = 51;
                            if (a.safeType) {
                                buf.push('title="该文件存在安全风险，无法正常使用"');
                                __stack.lineno = 51;
                            }
                            buf.push('>\n		<div class="file-select">\n		');
                            __stack.lineno = 53;
                            if (locals.batchMode === undefined ? true : locals.batchMode) {
                                buf.push('\n			<input type="checkbox" class="cbox" data-action="file.check" aria-label="文件类型:', escape((__stack.lineno = 54, 
                                a.filetype)), ",名称", escape((__stack.lineno = 54, a.fname)), ",大小:", escape((__stack.lineno = 54, 
                                a.sizeStr)), ",下载次数:", escape((__stack.lineno = 54, a.down)), "次,上传人:", escape((__stack.lineno = 54, 
                                a.nick)), ",上传时间:", escape((__stack.lineno = 54, a.ctStr)), '" tabindex="3" value="', escape((__stack.lineno = 54, 
                                a.filepath)), '">\n		');
                                __stack.lineno = 55;
                            }
                            buf.push('\n		</div>\n		<div class="file-icons" data-path="', escape((__stack.lineno = 57, 
                            a.filepath)), '" ');
                            __stack.lineno = 57;
                            if (a.preview) {
                                buf.push('data-action="file.preview"');
                                __stack.lineno = 57;
                            }
                            buf.push('>\n			<div class="files-', escape((__stack.lineno = 58, a.icon)), " ");
                            __stack.lineno = 58;
                            if (a.previewObj) {
                                buf.push("thumb");
                                __stack.lineno = 58;
                            }
                            buf.push('" ');
                            __stack.lineno = 58;
                            if (a.previewObj) {
                                buf.push('style="background-image:url(', escape((__stack.lineno = 58, a.previewObj.url)), ');"');
                                __stack.lineno = 58;
                            }
                            buf.push('></div>\n			<i class="icons-check"></i>\n		</div>\n		<dl class="file-info">\n			<dt>\n				<div class="name">', (__stack.lineno = 63, 
                            a.name), '</div>\n				<div class="suffix">', (__stack.lineno = 64, a.suf), '</div>\n				<div class="icons-temp-icon" ');
                            __stack.lineno = 65;
                            if (!a.safeType) {
                                buf.push('title="临时文件"');
                                __stack.lineno = 65;
                            }
                            buf.push('></div>\n				<div class="security"></div>\n			</dt>\n\n			<dd>\n				<span class="file-size" ');
                            __stack.lineno = 70;
                            if (!a.safeType) {
                                buf.push('title="文件大小:', escape((__stack.lineno = 70, a.sizeStr)), '"');
                                __stack.lineno = 70;
                            }
                            buf.push(">", escape((__stack.lineno = 70, a.sizeStr)), '</span>\n				<span class="file-dot">.</span>\n				<span ');
                            __stack.lineno = 72;
                            if (!a.safeType) {
                                buf.push('title="下载次数:', escape((__stack.lineno = 72, a.down)), '次"');
                                __stack.lineno = 72;
                            }
                            buf.push('><span class="downloadtime">', escape((__stack.lineno = 72, a.down)), "次下载</span></span>\n\n				");
                            __stack.lineno = 74;
                            if (locals.renderParams && locals.renderParams.uploaderHide === true) {} else {
                                buf.push('\n					<span class="uploader" ');
                                __stack.lineno = 75;
                                if (!a.safeType) {
                                    buf.push('title="上传者:', escape((__stack.lineno = 75, a.nick)), " (", escape((__stack.lineno = 75, 
                                    a.uin)), ')"');
                                    __stack.lineno = 75;
                                }
                                buf.push('><i class="uploader-name" ');
                                __stack.lineno = 75;
                                if (locals.renderParams && locals.renderParams.getByUinHide === true) {
                                    buf.push('data-action=""');
                                    __stack.lineno = 75;
                                } else {
                                    buf.push('data-action="file.getByUin"');
                                    __stack.lineno = 75;
                                }
                                buf.push(' data-uin="', escape((__stack.lineno = 75, a.uin)), '">', (__stack.lineno = 75, 
                                a.nick), "</i></span>\n				");
                                __stack.lineno = 76;
                            }
                            buf.push('\n\n				<span class="uploadtime" ');
                            __stack.lineno = 78;
                            if (!a.safeType) {
                                buf.push('title="上传时间:', escape((__stack.lineno = 78, a.ctStr)), '"');
                                __stack.lineno = 78;
                            }
                            buf.push(">", escape((__stack.lineno = 78, a.ctStr)), "</span>\n\n				");
                            __stack.lineno = 80;
                            if (a.folderName) {
                                buf.push('\n					<span  class="uploader" ');
                                __stack.lineno = 81;
                                if (!a.safeType) {
                                    buf.push('title="来自：', escape((__stack.lineno = 81, a.folderName)), '"');
                                    __stack.lineno = 81;
                                }
                                buf.push(' data-action="folder.open" data-path="', (__stack.lineno = 81, a.parentId), '">来自：<a class="from-folder-name">', escape((__stack.lineno = 81, 
                                a.folderName)), "</a></span>\n				");
                                __stack.lineno = 82;
                            }
                            buf.push("\n\n				");
                            __stack.lineno = 84;
                            if (a.otherGroupName) {
                                buf.push('\n					<span class="from-group">来自群：</span>\n					<span class="other-group-name" data-action="openGroupInfoCard" ');
                                __stack.lineno = 86;
                                if (!a.safeType) {
                                    buf.push('title="来自群：', escape((__stack.lineno = 86, a.otherGroupName)), '"');
                                    __stack.lineno = 86;
                                }
                                buf.push(' data-uin="', (__stack.lineno = 86, a.gc), '">', (__stack.lineno = 86, 
                                a.otherGroupName), "</span>\n				");
                                __stack.lineno = 87;
                            }
                            buf.push("\n			</dd>\n		</dl>\n		");
                            __stack.lineno = 90;
                            if (locals.renderParams && locals.renderParams.actionHide === true) {} else {
                                buf.push('\n			<div class="file-action">\n				<div class="btn-group">\n					');
                                __stack.lineno = 93;
                                if (a.isDown) {
                                    buf.push('\n					<a href="javascript:void(0)" class="btn-left download open open-file-link" data-action="file.openFolder" title="打开" tabindex="3" aria-label="打开文件', escape((__stack.lineno = 94, 
                                    a.name)), '">\n						<i class="open"></i>');
                                    __stack.lineno = 95;
                                    if (!G.mac) {
                                        buf.push("打开");
                                        __stack.lineno = 95;
                                    }
                                    buf.push("\n					</a>\n					");
                                    __stack.lineno = 97;
                                } else {
                                    buf.push('\n					<a href="javascript:void(0)" class="btn-left download download-file-link" data-action="file.download" title="下载" tabindex="3" aria-label="下载文件', escape((__stack.lineno = 98, 
                                    a.name)), '">\n						<i class="down"></i>');
                                    __stack.lineno = 99;
                                    if (!G.mac) {
                                        buf.push("下载");
                                        __stack.lineno = 99;
                                    }
                                    buf.push("\n					</a>\n					");
                                    __stack.lineno = 101;
                                }
                                buf.push('\n					<a class="file-more icons-btn-right-down file-icons-down-link" data-action="menu.filemore" menu="file-menu" title="更多"></a>\n				</div>\n			</div>\n		');
                                __stack.lineno = 105;
                            }
                            buf.push('\n		<div class="aria-hide">\n			');
                            __stack.lineno = 107;
                            if (a.admin || G.info.isAdmin) {
                                buf.push('\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="转发文件', escape((__stack.lineno = 108, 
                                a.fname)), '" data-action="file.forward" tabindex="3">转发</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="转发文件到手机', escape((__stack.lineno = 109, 
                                a.fname)), '" data-action="file.forwardMobile" tabindex="3">转发文件到手机</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="在文件夹中显示', escape((__stack.lineno = 110, 
                                a.fname)), '" data-action="file.openFolderInBox" tabindex="3">在文件夹中显示</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="重命名文件', escape((__stack.lineno = 111, 
                                a.fname)), '" data-action="file.showRename" data-blur="aria.fmg" tabindex="3">重命名</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="转存为永久文件', escape((__stack.lineno = 112, 
                                a.fname)), '" data-action="file.permanent" tabindex="3">转存为永久文件</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="移动文件', escape((__stack.lineno = 113, 
                                a.fname)), '" data-action="file.showMove" data-blur="aria.fmg" tabindex="3">移动文件</a>\n				<a href="javascript:void(0)" data-focus="file.aria" aria-label="删除文件', escape((__stack.lineno = 114, 
                                a.fname)), '" data-action="file.delete" tabindex="3">删除</a>\n			');
                                __stack.lineno = 115;
                            }
                            buf.push('\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="举报文件', escape((__stack.lineno = 116, 
                            a.fname)), '" data-action="file.jubao" tabindex="3">举报文件</a>\n		</div>\n		<div class="line"></div>\n	</div>\n');
                            __stack.lineno = 120;
                        }
                    }
                    buf.push("\n");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<div class="files-empty"><div><div class="icons-empty"></div><div class="empty-desc">在这里，你可以把各种有趣的东西分享给大家</div></div></div>\n',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('<div class="files-empty"><div><div class="icons-empty"></div><div class="empty-desc">在这里，你可以把各种有趣的东西分享给大家</div></div></div>\n');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, , function(e, t, a) {
    var n = e.exports = {
        version: "2.4.0"
    };
    if (typeof __e == "number") __e = n;
}, function(e, t, a) {
    t.f = a(193);
}, function(e, t, a) {
    "use strict";
    var n = a(194), i = a(195), r = a(196), o = a(197), l = a(198), s = a(199).KEY, f = a(200), c = a(201), d = a(202), u = a(203), p = a(193), v = a(102), m = a(204), h = a(205), g = a(206), w = a(207), b = a(208), _ = a(209), k = a(225), y = a(210), G = a(211), x = a(212), F = a(213), T = a(214), C = a(215), S = F.f, $ = T.f, M = x.f, j = n.Symbol, R = n.JSON, D = R && R.stringify, O = "prototype", P = p("_hidden"), L = p("toPrimitive"), I = {}.propertyIsEnumerable, N = c("symbol-registry"), E = c("symbols"), A = c("op-symbols"), q = Object[O], z = typeof j == "function", B = n.QObject;
    var U = !B || !B[O] || !B[O].findChild;
    var Q = r && f(function() {
        return G($({}, "a", {
            get: function() {
                return $(this, "a", {
                    value: 7
                }).a;
            }
        })).a != 7;
    }) ? function(e, t, a) {
        var n = S(q, t);
        if (n) delete q[t];
        $(e, t, a);
        if (n && e !== q) $(q, t, n);
    } : $;
    var V = function(e) {
        var t = E[e] = G(j[O]);
        t._k = e;
        return t;
    };
    var H = z && typeof j.iterator == "symbol" ? function(e) {
        return typeof e == "symbol";
    } : function(e) {
        return e instanceof j;
    };
    var J = function nt(e, t, a) {
        if (e === q) J(A, t, a);
        b(e);
        t = k(t, true);
        b(a);
        if (i(E, t)) {
            if (!a.enumerable) {
                if (!i(e, P)) $(e, P, y(1, {}));
                e[P][t] = true;
            } else {
                if (i(e, P) && e[P][t]) e[P][t] = false;
                a = G(a, {
                    enumerable: y(0, false)
                });
            }
            return Q(e, t, a);
        }
        return $(e, t, a);
    };
    var Y = function it(e, t) {
        b(e);
        var a = g(t = _(t)), n = 0, i = a.length, r;
        while (i > n) J(e, r = a[n++], t[r]);
        return e;
    };
    var W = function rt(e, t) {
        return t === undefined ? G(e) : Y(G(e), t);
    };
    var K = function ot(e) {
        var t = I.call(this, e = k(e, true));
        if (this === q && i(E, e) && !i(A, e)) return false;
        return t || !i(this, e) || !i(E, e) || i(this, P) && this[P][e] ? t : true;
    };
    var X = function lt(e, t) {
        e = _(e);
        t = k(t, true);
        if (e === q && i(E, t) && !i(A, t)) return;
        var a = S(e, t);
        if (a && i(E, t) && !(i(e, P) && e[P][t])) a.enumerable = true;
        return a;
    };
    var Z = function st(e) {
        var t = M(_(e)), a = [], n = 0, r;
        while (t.length > n) {
            if (!i(E, r = t[n++]) && r != P && r != s) a.push(r);
        }
        return a;
    };
    var et = function ft(e) {
        var t = e === q, a = M(t ? A : _(e)), n = [], r = 0, o;
        while (a.length > r) {
            if (i(E, o = a[r++]) && (t ? i(q, o) : true)) n.push(E[o]);
        }
        return n;
    };
    if (!z) {
        j = function ct() {
            if (this instanceof j) throw TypeError("Symbol is not a constructor!");
            var e = u(arguments.length > 0 ? arguments[0] : undefined);
            var t = function(a) {
                if (this === q) t.call(A, a);
                if (i(this, P) && i(this[P], e)) this[P][e] = false;
                Q(this, e, y(1, a));
            };
            if (r && U) Q(q, e, {
                configurable: true,
                set: t
            });
            return V(e);
        };
        l(j[O], "toString", function dt() {
            return this._k;
        });
        F.f = X;
        T.f = J;
        a(216).f = x.f = Z;
        a(217).f = K;
        a(218).f = et;
        if (r && !a(219)) {
            l(q, "propertyIsEnumerable", K, true);
        }
        v.f = function(e) {
            return V(p(e));
        };
    }
    o(o.G + o.W + o.F * !z, {
        Symbol: j
    });
    for (var tt = "hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables".split(","), at = 0; tt.length > at; ) p(tt[at++]);
    for (var tt = C(p.store), at = 0; tt.length > at; ) m(tt[at++]);
    o(o.S + o.F * !z, "Symbol", {
        "for": function(e) {
            return i(N, e += "") ? N[e] : N[e] = j(e);
        },
        keyFor: function ut(e) {
            if (H(e)) return h(N, e);
            throw TypeError(e + " is not a symbol!");
        },
        useSetter: function() {
            U = true;
        },
        useSimple: function() {
            U = false;
        }
    });
    o(o.S + o.F * !z, "Object", {
        create: W,
        defineProperty: J,
        defineProperties: Y,
        getOwnPropertyDescriptor: X,
        getOwnPropertyNames: Z,
        getOwnPropertySymbols: et
    });
    R && o(o.S + o.F * (!z || f(function() {
        var e = j();
        return D([ e ]) != "[null]" || D({
            a: e
        }) != "{}" || D(Object(e)) != "{}";
    })), "JSON", {
        stringify: function pt(e) {
            if (e === undefined || H(e)) return;
            var t = [ e ], a = 1, n, i;
            while (arguments.length > a) t.push(arguments[a++]);
            n = t[1];
            if (typeof n == "function") i = n;
            if (i || !w(n)) n = function(e, t) {
                if (i) t = i.call(this, e, t);
                if (!H(t)) return t;
            };
            t[1] = n;
            return D.apply(R, t);
        }
    });
    j[O][L] || a(220)(j[O], L, j[O].valueOf);
    d(j, "Symbol");
    d(Math, "Math", true);
    d(n.JSON, "JSON", true);
}, function(e, t, a) {}, function(e, t, a) {
    a(204)("asyncIterator");
}, function(e, t, a) {
    a(204)("observable");
}, function(e, t, a) {
    "use strict";
    var n = a(221)(true);
    a(222)(String, "String", function(e) {
        this._t = String(e);
        this._i = 0;
    }, function() {
        var e = this._t, t = this._i, a;
        if (t >= e.length) return {
            value: undefined,
            done: true
        };
        a = n(e, t);
        this._i += a.length;
        return {
            value: a,
            done: false
        };
    });
}, function(e, t, a) {
    a(223);
    var n = a(194), i = a(220), r = a(224), o = a(193)("toStringTag");
    for (var l = [ "NodeList", "DOMTokenList", "MediaList", "StyleSheetList", "CSSRuleList" ], s = 0; s < 5; s++) {
        var f = l[s], c = n[f], d = c && c.prototype;
        if (d && !d[o]) i(d, o, f);
        r[f] = r.Array;
    }
}, function(e, t, a) {
    var n = a(190), i = a(215);
    a(192)("keys", function() {
        return function e(t) {
            return i(n(t));
        };
    });
}, function(e, t, a) {
    "use strict";
    function n(e) {
        if (!G.cMap) {
            G.cMap = {};
        }
        var t = G.cMap[e.id];
        if (!t) {
            t = G.cMap[e.filepath];
            if (t) {
                if (t && t.type.indexOf("upload") >= 0 && e.type.indexOf("upload") >= 0 && t.status != e.status) {
                    if (e.id) {
                        plistMap[e.id] = t;
                    }
                    console.warn("new task 发现续传 id[" + t.id + "] status[" + t.status + "]");
                } else if (e.type == "download") {
                    console.log(e);
                } else {}
            }
        }
        if (!t) {
            if (e.id) {
                G.cMap[e.id] = e;
            }
            if (e.filepath) {
                G.cMap[e.filepath] = e;
            }
            return e;
        } else {}
    }
    function i(e) {
        console.log("验证任务:", G.cMap, e, e.id, e.filepath, G.cMap[e.id] || G.cMap[e.filepath]);
        if (G.cMap[e.id] || G.cMap[e.filepath]) {
            console.log("已经存在数据!");
            return true;
        } else {
            return false;
        }
    }
    function r(e) {
        if (G.cMap[e.id]) {
            delete G.cMap[e.id];
        }
        if (G.cMap[e.filepath]) {
            delete G.cMap[e.filepath];
        }
    }
    function o(e) {}
    function l() {
        for (var e in G.cMap) {
            var t = G.cMap[e];
            if (t && t.status === "uploadcomplete") {
                delete G.cMap[t.id];
                delete G.cMap[t.filepath];
            }
        }
    }
    e.exports = {
        check: i,
        add: n,
        del: r,
        update: o,
        clearComplete: l
    };
}, function(e, t, a) {
    "use strict";
    var n = a(112);
    function i(e) {
        var t = n.errorCfgPrefix[e.type] + "-" + e.status;
        if (t in n.errorCfg && n.errorCfg) {
            return true;
        }
        return false;
    }
    function r(e) {
        if (!e || !e.type || !e.status) {
            return "";
        }
        var t = n.errorCfgPrefix[e.type] + "-" + e.status;
        if (t in n.errorCfg) {
            if (t === "upload-uploadsecurityfail" && n.securityattriMap[e.securityattri]) {
                return n.securityattriMap[e.securityattri];
            }
            return n.errorCfg[t];
        }
        return;
    }
    function o(e, t) {
        return n.wordingMap[e][t];
    }
    function l(e, t) {
        return n.styleMap[e][t];
    }
    function s(e) {
        return n.typeMap[e];
    }
    function f(e, t) {
        if (!e) {
            return false;
        }
        if (!n.wordingMap[e]) {
            console.warn("设置wording 未知任务类型=[" + e + "]");
        }
        if (!n.wordingMap[e][t]) {
            console.warn("设置wording 未知任务状态=[" + t + "]");
        }
        if (!n.styleMap[e][t]) {
            console.warn("设置样式 未知任务状态=[" + t + "]");
        }
    }
    e.exports = {
        check: f,
        getType: s,
        getWord: o,
        getClass: l,
        ifError: i,
        getErrorWord: r
    };
}, function(e, t, a) {
    "use strict";
    var n = {
        upload: "upload",
        continueupload: "continueupload",
        download: "download"
    };
    var i = {};
    i.upload = {
        scanning: "扫描中...&nbsp;&nbsp;",
        scanfail: "扫描失败&nbsp;&nbsp;",
        scanend: "扫描完成...&nbsp;&nbsp;",
        uploadgeturl: "准备上传...&nbsp;&nbsp;",
        uploadgeturlend: "上传中...&nbsp;&nbsp;",
        uploadadminonlyfail: "无法上传，已限制成员上传文件",
        uploadgeturlfail: "申请上传地址失败",
        uploadlimit: "文件个数达到上限，无法上传",
        uploadsecurityfail: "安全扫描失败",
        cancel: "空间不足,已取消上传",
        uploadprogress: "上传中:&nbsp;&nbsp;",
        uploadfail: "上传失败",
        uploadcomplete: "上传完成&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        pause: "暂停&nbsp;&nbsp;",
        "continue": "待续传&nbsp;&nbsp;"
    };
    i.download = {
        wait: "等待下载...&nbsp;&nbsp;",
        downloadready: "准备下载...&nbsp;&nbsp;",
        downloadgeturl: "准备下载...&nbsp;&nbsp;",
        downloadgeturlfail: "获取下载地址失败",
        cancel: "已取消下载&nbsp;&nbsp;",
        downloadgeturlend: "下载中...",
        downloadprogress: "下载中:&nbsp;&nbsp;",
        downloadfail: "下载失败&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        downloadcomplete: "下载完成&nbsp;&nbsp;",
        pause: "暂停&nbsp;&nbsp;"
    };
    i.continueupload = {
        scanning: "扫描中...&nbsp;&nbsp;",
        scanfail: "扫描失败&nbsp;&nbsp;",
        scanend: "扫描完成...&nbsp;&nbsp;",
        uploadgeturl: "准备续传...&nbsp;&nbsp;",
        uploadgeturlend: "续传中...&nbsp;&nbsp;",
        uploadgeturlfail: "申请续传地址失败",
        uploadlimit: "文件个数达到上限，无法上传",
        uploadsecurityfail: "安全扫描失败",
        cancel: "空间不足,已取消续传",
        uploadprogress: "续传中:&nbsp;&nbsp;",
        uploadfail: "续传失败",
        uploadcomplete: "续传完成&nbsp;&nbsp;",
        pause: "暂停&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        "continue": "待续传&nbsp;&nbsp;"
    };
    var r = {};
    r.upload = {
        scanning: "scan",
        scanfail: "err",
        scanend: "scan",
        uploadgeturl: "pre",
        uploadgeturlend: "pre",
        uploadgeturlfail: "err",
        uploadsecurityfail: "err",
        cancel: "err",
        uploadprogress: "progress",
        uploadfail: "err",
        uploadcomplete: "complete",
        pause: "pause",
        filenotexsit: "err",
        "continue": "continue",
        remove: ""
    };
    r.download = {
        wait: "pre",
        downloadready: "pre",
        downloadgeturl: "pre",
        downloadgeturlfail: "err",
        cancel: "err",
        downloadgeturlend: "pre",
        downloadprogress: "progress",
        downloadfail: "err",
        filenotexsit: "err",
        downloadcomplete: "complete",
        pause: "pause"
    };
    r.continueupload = {
        scanning: "scan",
        scanfail: "err",
        scanend: "scan",
        uploadgeturl: "pre",
        uploadgeturlend: "pre",
        uploadgeturlfail: "err",
        uploadsecurityfail: "err",
        cancel: "err",
        uploadprogress: "progress",
        uploadfail: "err",
        uploadcomplete: "complete",
        pause: "pause",
        filenotexsit: "err",
        "continue": "continue",
        remove: ""
    };
    var o = {
        upload: "upload",
        download: "download",
        continueupload: "upload"
    };
    var l = [ "安全", "扫描到病毒，已取消上传", "扫描到未知风险", "扫描到安全风险", "扫描到安全风险", "扫描到安全风险", "文件包含敏感词" ];
    var s = {
        "download-downloadgeturlfail": "下载失败,请稍候再试",
        "download-cancel": "",
        "download-downloadfail": "下载失败",
        "upload-scanfail": "扫描失败,请稍候再试",
        "upload-uploadgeturlfail": "上传失败",
        "upload-uploadsecurityfail": "上传安全扫描失败",
        "upload-cancel": "空间不足,已取消上传",
        "upload-uploadfail": "上传失败,请稍候再试",
        folderLimit: "文件夹个数以达上限"
    };
    var f = 300;
    e.exports = {
        errorCfg: s,
        errorCfgPrefix: o,
        securityattriMap: l,
        styleMap: r,
        wordingMap: i,
        typeMap: n,
        refreshTime: f
    };
}, function(e, t, a) {
    "use strict";
    function n(e) {
        var t = {
            fLen: 3
        };
        if (typeof e != "number") return "";
        var a;
        var n = e;
        var i = [ "B", "KB", "MB", "GB", "TB", "PB" ];
        while (n > 1024) {
            n = n / 1024;
            i.shift();
        }
        if (n >= 1e3) {
            n = n / 1024;
            i.shift();
        }
        var r = ("" + n).length;
        var o = 2;
        var l = 100;
        if (t && t.len) o = t.len;
        if (o < 0) o = 0;
        l = Math.pow(10, o);
        n = Math.floor(n * l) / l;
        if (t && t.fLen) {
            var s = n.toString().indexOf(".");
            if (n.toString().length <= t.fLen) {
                var f = parseInt(n, 10).toString().length;
                n = n.toFixed(t.fLen - f);
            } else if (t.fLen < n.toString().length) {
                n = n.toString();
                if (s > 0 && s < 3) n = n.substr(0, 4); else n = n.substr(0, 3);
            }
        }
        a = n.toString().replace(/\.0+$/, "");
        a = a + i[0];
        if (n === 0) a = 0;
        return a;
    }
    function i(e) {
        var t = {
            fLen: 3
        };
        if (typeof e != "number") return "";
        var a;
        var n = e;
        var i = [ "B", "KB", "MB", "GB", "TB", "PB" ];
        while (n > 1024) {
            n = n / 1024;
            i.shift();
        }
        if (n >= 1e3) {
            n = 1;
            i.shift();
        }
        var r = ("" + n).length;
        var o = 2;
        var l = 100;
        if (t && t.len) o = t.len;
        if (o < 0) o = 0;
        l = Math.pow(10, o);
        var s = Math.round(n * l) / l;
        if (s >= 1e3) n = Math.floor(n * l) / l; else n = s;
        if (t && t.fLen) {
            var f = n.toString().indexOf(".");
            if (n.toString().length <= t.fLen) {
                var c = parseInt(n, 10).toString().length;
                n = n.toFixed(t.fLen - c);
            } else if (t.fLen < n.toString().length) {
                n = n.toString();
                if (f > 0 && f < 3) n = n.substr(0, 4); else n = n.substr(0, 3);
            }
        }
        a = n.toString().replace(/\.0+$/, "");
        a = a + i[0];
        if (n === 0) a = 0;
        return a;
    }
    function r(e) {
        var t = "unknow";
        var a = {
            excel: /xls|xlsx/i,
            pdf: /pdf/i,
            ppt: /ppt|pptx/i,
            word: /doc|docx|wps/i,
            text: /txt/i,
            pic: /jpg|jpeg|jpgx|gif|bmp|png|ico|webp|raw|tiff/i,
            music: /mp3|wma|midi|aac|ape|flac|wav|mid|ogg|aac/i,
            video: /mp4|rm|rmvb|mpeg|mov|avi|3gp|amv|dmv|flv|wmv|qsed|asf|mkv/i,
            zip: /rar|zip|tar|cab|uue|jar|iso|7z|ace|lzh|arj|gzip|bz2/i,
            code: /ink|torrent|url|vbs|tif|w3g|vbe|ssf|dll|mht|rcd|bat|sav|dat|cmd|ttf|xml|vob|sgs|mhw|js|html|htm|css/i,
            exe: /exe|msi/i,
            ipa: /ipa/i,
            dmg: /dmg/i,
            apk: /apk/i
        };
        for (var n in a) {
            var i = a[n];
            if (i.test(e)) {
                t = n;
                break;
            }
        }
        return t;
    }
    function o(e) {
        var t = "其他";
        var a = {
            "文档": /doc|docx|ppt|pptx|xsl|xslx|xls|xlsx|pdf|txt|wps/i,
            "图片": /jpg|jpeg|jpgx|gif|bmp|png/i,
            "音乐": /mp3|wma|midi|aac/i,
            "视频": /mp4|rm|rmvb|mpeg|mov|avi|3gp|amv|dmv|flv|wmv|qsed/i,
            "压缩包": /rar|zip|tar|cab|uue|jar|iso|7z|ace|lzh|arj|gzip|bz2/i,
            "应用": /dmg/i
        };
        for (var n in a) {
            var i = a[n];
            if (i.test(e)) {
                t = n;
                break;
            }
        }
        return t;
    }
    function l(e) {
        var t = e.lastIndexOf("."), a = {};
        if (t >= 0) {
            a.filename_name = e.substr(0, t);
            a.filename_suf = e.substr(t);
        } else {
            a.filename_name = e;
            a.filename_suf = "";
        }
        return a;
    }
    function s(e) {
        var t = e.lastIndexOf("\\"), a = e.substr(t + 1);
        return a;
    }
    e.exports = {
        getSize: n,
        getIcon: r,
        getType: o,
        getFileName: l,
        getFolderName: s
    };
}, function(e, t, a) {
    "use strict";
    var n = a(246);
    var i = a(247);
    var r = a(248);
    var o = a(249);
    var l = a(250);
    var s = a(251);
    var f = a(252);
    var c = a(80);
    var d = a(253);
    var u = a(254);
    e.exports = {
        "box.toggle": n.toggle,
        "task.continue": i.continueUpload,
        "task.pause": o.pause,
        "task.remove": l.remove,
        "task.resume": s.resume,
        "task.clear": r.clear,
        "task.openFolder": c.openByBox,
        "task.openFolderIco": c.openFolderByBoxIco,
        "tips.close": u.closeTips,
        "tips.refesh": u.refeshVip,
        "tips.con": u.conVip,
        "tips.vipOk": u.vipTipsOk,
        "tips.vipCancel": u.vipTipsCancel,
        "tips.open": u.openVip,
        "task.clearHistory": r.clear,
        "task.openfail": d.toggle
    };
}, function(e, t, a) {
    "use strict";
    function n() {}
    e.exports = {
        "input.edit": n
    };
}, function(e, t, a) {
    "use strict";
    var n = a(79);
    var i = function r() {
        n.hideAll();
        if (G.activeElement) {
            G.activeElement.focus();
        }
    };
    e.exports = {
        "panel.close": i
    };
}, function(e, t, a) {
    "use strict";
    var n = {
        folderTree: a(164),
        list: a(8)
    };
    var i = {
        folder: a(273)
    };
    var r = a(50);
    var o = a(255);
    var l = a(41);
    var s = a(35);
    var f = a(164);
    var c = a(10);
    var d = false;
    var u = false;
    function p() {
        if ($('[data-keyup="folderTree.create"]').length) {
            console.log("can not try to create more than one folder at the same time");
            return;
        }
        report("createFolderInTree");
        n.folderTree.newFolder();
        n.folderTree.select("new");
        $("#inputFolderNameInFolderTree").val(c.getFolderNameDefault());
        $("#inputFolderNameInFolderTree")[0].focus();
        $("#inputFolderNameInFolderTree")[0].select();
    }
    function v(e) {
        e.keyCode = 13;
        m.call(this, e);
    }
    function m(e, t) {
        if (e && e.keyCode !== 13 && $("#inputFolderNameInFolderTree").length) {
            r["input.keyup"].call(this, e);
            return;
        }
        var a = $('[data-keyup="folderTree.create"]');
        if (!a.length) {
            t && t();
            return;
        }
        if (t) {
            u = t;
        }
        if (d) {
            return;
        }
        var o = $.trim(a.val());
        var c = r.folderName(o);
        if (!c) {
            return;
        }
        var p = {
            parent_id: "/",
            name: o
        };
        var v = this;
        d = true;
        l.createFolder(p).done(function(e) {
            var t = s.filterFolder(e.folder_info);
            s.addData(t);
            n.list.appendFold(t);
            var a = $(".folder-tree-box").find('[data-id="new"].folder-list-item');
            a.html(i.folder({
                item: t
            })).attr("data-id", t.id);
            if (G.folderTree.selected.id === "new") {
                f.select(t.id);
            }
            report("createFolderInTreeSuc");
            d = false;
            u && u();
            u = false;
        }).fail(function(e) {
            console.log("fail", e);
            d = false;
            var t = {
                134: "文件夹名称包含违禁词",
                313: "文件夹名已经存在",
                314: "创建文件夹失败",
                405: "文件夹个数已达上限",
                "default": "创建失败"
            };
            var a = Math.abs(e.ec);
            var n = $(".folder-tree-box").find(".bubble");
            n.html('<span class="bot"></span><span class="top"></span>' + (t[a] || t["default"])).show();
            setTimeout(function() {
                n.hide();
            }, 3e3);
        });
    }
    e.exports = {
        "folderTree.select": f.select,
        "folderTree.new": p,
        "folderTree.create": m,
        createInputBlur: v
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(59);
    function l(e) {
        if (e.action === "offline") {} else if (e.action === "online") {}
    }
    var s = function c() {
        var e = parseInt($(this).data("uin"));
        o.openGroupInfoCard(e);
    };
    var f = function d() {
        var e = parseInt($(this).data("uin"));
        var t = G.fileMap()[$(this).data("path")] || {};
        var a = {
            action: "search",
            params: {
                keyword: G.searchKeyword,
                files: [ {
                    fileId: t.fp,
                    busId: t.busid
                } ]
            }
        };
        localStorage.setItem("notifyOtherGroup", encodeURIComponent((0, i.default)({
            gc: e,
            webParams: (0, i.default)(a),
            random: Math.random()
        })));
        o.openGroupFile(e, encodeURIComponent((0, i.default)(a)));
    };
    e.exports = {
        groupEvent: l,
        openGroupFile: f,
        openGroupInfoCard: s
    };
}, function(e, t, a) {
    "use strict";
    var n = a(15);
    var i = a(14);
    var r = a(35);
    var o = function _() {
        G.activeElement = this;
    };
    var l = [ 65, 68, 0, 72, 74, 76, 77, 78, 79, 80, 82, 85, 89 ];
    var s = function k() {
        var e = $(document.activeElement).parents(".list-item");
        if (e.length === 0) {
            return false;
        }
        var t = e.data("path");
        var a = void 0;
        var n = r.getData(t);
        if (n.orcType === 2) {
            a = "fold";
        } else if (n.orcType == 1) {
            a = "file";
        }
        G.selectRow = n || {};
        G.selectRow.path = t;
        G.selectRow.type = a;
        G.selectRows = [ G.selectRow ];
        return true;
    };
    var f = function y() {
        if (s()) {
            if (G.selectRow.type === "fold") {
                i["folder.openfolder"]();
            }
        }
    };
    var c = function x() {
        if (s()) {
            if (G.selectRow.type === "file") {
                n["file.showRename"]();
            } else if (G.selectRow.type === "fold") {
                i["folder.showRenameFolder"]();
            }
        }
    };
    var d = function F() {
        if (s()) {
            if (G.selectRow.type === "file") {
                n["file.download"]();
            } else if (G.selectRow.type === "fold") {
                i["folder.download"]();
            }
        }
    };
    var u = function T() {
        if (s()) {
            if (G.selectRow.type === "fold") {
                i["folder.property"]();
            }
        }
    };
    var p = function C() {
        if (s()) {
            if (G.selectRow.type === "file") {
                n["file.showRename"]();
            } else if (G.selectRow.type === "fold") {
                i["folder.showRenameFolder"]();
            }
        }
    };
    var v = function S() {
        if (s()) {
            if (G.selectRow.type === "file") {
                n["file.preview"]();
            }
        }
    };
    var m = function M() {
        if (s()) {
            if (G.selectRow.type === "file") {
                n["file.showMove"]();
            }
        }
    };
    var h = function j() {
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
        if (s()) {
            if (G.selectRow.type === "file") {
                if (e) {
                    n["file.forwardMobile"]();
                } else {
                    n["file.forward"]();
                }
            }
        }
    };
    var g = function R() {
        if (s()) {
            if (G.selectRow.type === "file") {
                n["file.jubao"]();
            }
        }
    };
    var w = function D(e) {
        switch (e) {
          case 65:
            $("#selectAllFile").click();
            break;

          case 66:
            $("#openBoxBtn").click();
            break;

          case 68:
            c();
            break;

          case 70:
            h();
            break;

          case 72:
            h(true);
            break;

          case 74:
            g();
            break;

          case 76:
            doDownLoad();
            break;

          case 77:
            m();
            break;

          case 78:
            $("#createFolder button").click();
            break;

          case 79:
            f();
            break;

          case 80:
            u();
            break;

          case 82:
            p();
            break;

          case 85:
            $(".icons-upload-1").click();
            break;

          case 88:
            $(G.handler).trigger("panel.hideAll");
            break;

          case 89:
            v();
            break;
        }
    };
    var b = function O(e) {
        if (e.altKey && e.shiftKey) {
            w.call(this, e.keyCode);
        }
    };
    e.exports = {
        "aria.fmg": o,
        "aria.quick": b
    };
}, function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(10);
    var l = window.performance;
    var s = {};
    e.exports = s;
    var f = o.getParameter("gc");
    function c() {
        u = o.getCookie("skey");
        var e = 5381;
        for (var t = 0, a = u.length; t < a; ++t) {
            e += (e << 5) + u.charCodeAt(t);
        }
        var n = e & 2147483647;
        return n;
    }
    function d() {
        var e = o.getCookie("uin");
        if (!e) {
            return 0;
        }
        e += "";
        return e.replace(/^[\D0]+/g, "");
    }
    var u = o.getCookie("skey");
    var p = d();
    var v = o.getParameter("groupuin");
    var m = c();
    function h(e) {
        return false;
    }
    var g = [ "http://pan.qun.qq.com/cgi-bin/checkAuditFlag" ];
    var w = [];
    var b = [];
    function _(e, t) {
        if (!l) {
            return;
        }
        var a = e.substr(0, e.indexOf("?"));
        if ($.inArray(e, b) < 0) {
            if (!l.getEntriesByName) {
                return;
            }
            var n = l.getEntriesByName(e)[0];
            if (!n) {
                return;
            }
            b.push(e);
            var r = {
                1: n.redirectEnd - n.redirectStart,
                2: n.domainLookupStart - n.fetchStart,
                3: n.domainLookupEnd - n.domainLookupStart,
                4: n.connectEnd - n.connectStart,
                5: n.responseStart - n.requestStart,
                6: n.responseEnd - n.responseStart,
                7: n.responseEnd - n.startTime,
                8: n.fetchStart,
                9: n.domainLookupStart
            };
            if ($.inArray(a, g) >= 0) {
                var o = 3;
                if (e === g[1]) {
                    o = 4;
                }
                QReport.huatuo({
                    appid: 10016,
                    flag1: 1772,
                    flag2: 1,
                    flag3: o,
                    speedTime: r
                });
            }
            r.url = e;
            if (r[2] > 5e3) {
                badjsReport.info((0, i.default)({
                    "重定向": r[1],
                    appcache: r[2],
                    dns: r[3],
                    tcp: r[4],
                    "接收": r[5],
                    "完成": r[6],
                    "总时间": r[7],
                    fetchStart: n.fetchStart,
                    dnsstart: n.domainLookupStart,
                    header: t.getAllResponseHeaders && t.getAllResponseHeaders() || false,
                    status: t.status,
                    t: "0427",
                    url: e,
                    "离线包": localVersion === "isLocal" ? "离线包请求" : "非离线包请求"
                }));
            }
        }
    }
    function k(e, t) {
        var a = Date.now();
        t = t || e.responseURL;
        e.done(function(n) {
            QReport.retcode({
                url: t,
                type: 1,
                code: n.ec,
                time: Date.now() - a,
                rate: 1
            });
            setTimeout(function() {
                _(t, e);
            }, 100);
            if (n.ec == 1) console.log("1", "缺少登录态");
        }).fail(function(e, n) {
            _(t);
            var i = {
                status: e.status,
                statusText: e.statusText
            };
            if (n == "timeout") {
                i.status = 999;
                i.statusText = "timeout";
            }
            var r = i.status;
            if (r === 0) {
                r === 9999;
            }
            QReport.retcode({
                url: t,
                type: r === 9999 ? 3 : 2,
                code: r,
                time: Date.now() - a,
                rate: 1
            });
        });
    }
    s.ajax = function(e) {
        var t = {
            type: "GET",
            dataType: "json",
            data: {
                src: "qpan",
                gc: e && e.data && e.data.gc || o.getParameter("groupuin")
            },
            xhrFields: {
                withCredentials: true
            },
            success: function i(e, t, a) {}
        };
        m && (t.data.bkn = c());
        $.extend(true, t, e);
        t.headers = {
            "Cache-Control": "no-cache,no-store"
        };
        if (t.type === "GET") {
            if (t.url.indexOf("?") < 0) {
                t.url += "?" + $.param(t.data);
            } else {
                t.url += "&" + $.param(t.data);
            }
            t.url += "&_ti=" + new Date().getTime();
            delete t.data;
        }
        var a = $.ajax(t);
        k(a, t.url);
        var n = {
            done: function r(e) {
                var n = 0;
                (function i(e, a) {
                    e.done(function(e) {
                        if (e.ec == 0) a(e);
                    });
                    e.fail(function() {
                        if (n >= 1 || h(t.url)) return;
                        n++;
                        e = $.ajax(t);
                        k(e, t.url);
                        i(e, a);
                    });
                })(a, e);
                return this;
            },
            fail: function l(e) {
                var n = 0;
                (function i(e, a) {
                    e.done(function(e) {
                        if (e.ec != 0) a(e);
                    });
                    e.fail(function(r, o) {
                        if (n >= 0) {
                            if (o == "timeout") {
                                report("cgiTimeout");
                                return a({
                                    ec: 504,
                                    msg: o
                                });
                            }
                            return a({
                                ec: r.status
                            });
                        }
                        n++;
                        e = $.ajax(t);
                        k(e, t.url);
                        i(e, a);
                    });
                })(a, e);
                return this;
            },
            timeout: function s(e) {
                a.fail(function(t, a) {
                    if (a == "timeout") e({
                        ec: 504,
                        msg: a
                    });
                });
                return this;
            },
            always: function f(e) {
                a.always(e);
                return this;
            },
            then: function d() {
                a.then.apply(a, arguments);
                return this;
            }
        };
        return n;
    };
    s.bkn = m;
}, function(e, t, a) {
    "use strict";
    var n = {
        102: "非群成员",
        103: "该文件不存在或已失效",
        106: "登录态校验失败",
        116: "没有权限",
        117: "没有权限",
        118: "没有权限",
        119: "没有权限",
        120: "没有权限",
        121: "没有权限",
        122: "没有权限",
        123: "没有权限",
        124: "没有权限",
        125: "没有权限",
        126: "没有权限",
        127: "没有权限",
        128: "没有权限",
        129: "没有权限",
        130: "没有权限",
        131: "没有权限",
        132: "文件存在安全风险",
        133: "文件安全性未知",
        134: "名称包含特殊/敏感字符，请重新输入。",
        313: "已存在同名文件夹，请重新命名",
        314: "创建文件夹失败",
        315: "删除文件夹失败",
        402: "文件数量已经超过限制",
        403: "可用空间不够",
        405: "创建失败，文件夹个数已达上限",
        25: "操作失败，空间不足."
    };
    var i = {
        deleteSuc: "删除成功",
        moveSuc: "转存成功",
        folderSuc: "新建文件夹成功",
        deleteFolderSuc: "删除文件夹成功"
    };
    var r = $(G.handler), o = a(79);
    var l = [ 134, 313, 405 ];
    function s(e, t) {
        e = Math.abs(e);
        if (n[e] && $.inArray(e, l) >= 0) {
            t.find(".error-message").text(n[e]).addClass("show");
        } else {
            var a = n[e] || "操作失败";
            r.trigger("toast.show", {
                type: "alert",
                text: a
            });
            o.hideAll();
        }
    }
    function f() {
        r.trigger("toast.show", {
            type: "alert",
            text: msg
        });
    }
    function c() {
        r.trigger("toast.show", {
            type: "alert",
            text: msg
        });
    }
    e.exports = {
        showError: s,
        showWait: f,
        showSuc: c
    };
}, function(e, t, a) {
    "use strict";
    var n = new Date();
    var i = n.getFullYear();
    function r(e) {
        var t = Math.ceil(e / 86400);
        return t;
    }
    function o(e) {
        e = k(e);
        if (e.getFullYear() != n.getFullYear()) return false;
        if (e.getMonth() != n.getMonth()) return false;
        if (e.getDate() != n.getDate()) return false;
        return true;
    }
    function l(e) {
        e = k(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var i = new Date(n.getFullYear(), n.getMonth(), n.getDate()) - e;
            a = i > 0 && i < 864e5;
        }
        return a;
    }
    function s(e) {
        e = k(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var i = new Date(n.getFullYear(), n.getMonth(), n.getDate()) - e;
            a = i > 0 && i < 864e5 * 2;
        }
        return a;
    }
    function f(e) {
        e = k(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var i = new Date(n.getFullYear(), n.getMonth(), n.getDate()) - e;
            a = i >= 0 && i <= 864e5;
        }
        if (a) return "昨天"; else return "前天";
    }
    function c(e) {
        e = k(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var i = new Date(n.getFullYear(), n.getMonth(), n.getDate()) - e;
            a = i > 0 && i < 864e5 * 2;
        }
        return a;
    }
    function d(e) {
        e = k(e);
        var t = m(n);
        if (e > t) return true;
        return false;
    }
    function u(e) {
        e = k(e);
        if (e.getYear() != n.getYear()) return false;
        return true;
    }
    function p(e) {
        if (!e) e = n.getFullYear();
        var t = new Date(e, 0, 1);
        var a = void 0;
        var i = t.getDay();
        if (i === 0) i = 7;
        var r = [ null, "一", "二", "三", "四", "五", "六", "日" ];
        var o = "周" + r[i];
        if (i != 1) t.setDate(1 + 8 - i);
        return t;
    }
    function v(e) {
        var t = new Date(e);
        var a = p(t.getFullYear());
        var n = 0;
        var i = void 0;
        if (a.getDate() > 1) n = 1;
        if (t < a) i = 1; else {
            i = Math.floor((t - a) / 7 / 864e5) + n;
        }
        return i;
    }
    function m(e) {
        var t = k(e);
        var a = t.getDay();
        if (a === 0) a = 7;
        var n = a - 1;
        var i = void 0;
        i = new Date(t.getTime() - n * 864e5);
        return i;
    }
    function h(e) {
        var t = k(e);
        var a = t.getDay();
        if (a === 0) a = 7;
        return a;
    }
    function g() {}
    function w(e) {
        if (!e) {
            return;
        }
        var t = k(e);
        var a = t.getFullYear();
        var n = t.getMonth() + 1;
        var i = t.getDate();
        var r = t.getHours();
        var o = t.getMinutes();
        if (o < 10) {
            o = "0" + o;
        }
        return a + "-" + n + "-" + i + " " + r + ":" + o;
    }
    function b(e) {
        if (!e) {
            return;
        }
        var t = k(e);
        var a = t.getFullYear();
        var n = t.getMonth() + 1;
        var i = t.getDate();
        var r = t.getHours();
        var o = t.getMinutes();
        if (o < 10) {
            o = "0" + o;
        }
        return a + "-" + n + "-" + i;
    }
    function _(e) {
        var t = k(e);
        var a = new Date();
        var n = a.getTime() - t.getTime();
        var i = parseInt(n / 36e5, 10);
        if (i < 1) i = "刚刚"; else i = i + "小时前";
        return i;
    }
    function k(e) {
        var t = e;
        if (typeof e === "string") t = new Date(e);
        if (typeof e === "number") t = new Date(e * 1e3);
        return t;
    }
    function y(e) {
        if (!e) {
            return;
        }
        var t = 60, a = 3600, n = 86400, i = "";
        if (e >= n) {
            i = Math.ceil(e / n) + "天";
        } else if (e >= a) {
            i = Math.ceil(e / a) + "小时";
        } else if (e >= t) {
            i = Math.ceil(e / t) + "分钟";
        } else if (e > 0) {
            i = e + "秒";
        } else {
            i = "已过期";
        }
        return i;
    }
    function G(e) {
        var t = void 0;
        var a = void 0;
        if (typeof e == "number") {
            t = new Date(e * 1e3);
        } else if (e instanceof Date) {
            t = e;
        }
        if (o(t)) {
            a = "今天";
        } else if (s(t)) {
            a = f(t);
        } else {
            a = b(t);
        }
        return a;
    }
    function x(e) {
        var t = e.createtime;
        e.day_str = G(t);
        e.createtime_str = w(t);
        if (e.day_str === "今天") {
            e.createtime_str = _(t);
        }
        if (e.day_str === "最近三天") {
            e.createtime_str = f(t);
        }
    }
    e.exports = {
        dayStr: G,
        genTimeStr: x,
        getValidity: y,
        toDate: k,
        getHourStr: _,
        getExpriesDayNum: r,
        isToday: o,
        isYesterday: l,
        strYesterdayOrPre: f,
        isLast3days: c,
        isThisWeek: d,
        isThisYear: u,
        getMonOY: p,
        getWOY: v,
        getMOW: m,
        getDayOfWeek: h,
        getDayOfYear: g,
        getDateStr: w
    };
}, function(e, t, a) {
    "use strict";
    var n = a(256), i = a(257);
    function r(e, t) {
        var a = n(t);
        e.html(a);
    }
    function o(e) {
        var t = G.getDomPanel().find(".fold");
        var a = t.length ? t : G.getDomPanel();
        a.after(i({
            id: e
        }));
    }
    function l(e) {
        if (e) {
            $("#navTopFolder").addClass("selected");
            $("#createFolder").hide();
            $("#fileNum").addClass("hide").attr("data-action", "menu.filenum");
            $("#headerLine").text(">");
            $("#box").addClass("one");
            $("#folderName").text(e.fnameEsc).removeClass("hide");
        } else {
            $("#navTopFolder").removeClass("selected");
            if (G.info.isAdmin) {
                $("#createFolder").show();
            }
            $("#headerLine").text("|");
            $("#fileNum").removeClass("hide").attr("data-action", "menu.filenum");
            $("#folderName").text("").addClass("hide");
            $("#box").removeClass("one");
        }
        $("#normalNav").removeClass("hide");
    }
    e.exports = {
        render: r,
        updataFolderHeader: l
    };
}, , function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<%\r\n	for(var i = 0,l = locals.list.length;i<l;i++){\r\n		var item = locals.list[i];\r\n%>\r\n<div class="file2 file2-2 <%-item.styles%>" data-path="<%-item.filepath%>" data-id="<%-item.id%>" data-folder="<%-item.folderpath%>" <%if(item.styleStatus === \'complete\'){%>data-action="task.openFolder"<%}%>>\r\n	<div class="file-icon">\r\n		<div class="files-<%-item.icon%>"></div>\r\n		<i></i>\r\n	</div>\r\n	<div class="file-info">\r\n		<div class="filename">\r\n			<div class="name"><%=item.name%></div>\r\n			<%if(item.orcType === 1){%>\r\n				<div class="suffix"><%-item.suf%></div>\r\n			<%}%>\r\n		</div>\r\n		<div class="loading">\r\n			<div class="bar" style="width:<%-item.cPercent%>%;"></div>\r\n		</div>\r\n		<%if(item.failedFileList && item.failedFileList.length > 0){%>\r\n			<div class="wording"  data-action="task.openfail">\r\n				<i class=\'warn\'></i>有<%-item.failedFileList.length%>个文件下载失败<i class="arrow"></i>\r\n					<ul class="fail-list">\r\n						<%for(var j = 0,m = item.failedFileList.length;j<m;j++){%>\r\n							<li><%=item.failedFileList[j].filename%></li>\r\n						<%}%>\r\n					</ul>\r\n			</div>\r\n		<%}else{%>\r\n			<div class="wording"><%-item.wording%></div>		\r\n		<%}%>\r\n	</div>\r\n	<div class="aris-hide">\r\n		<a tabindex="-1"><%=item.name%> 进度<%-item.cPercent%>%</a>\r\n	</div>\r\n	<div class="file-action">\r\n		<a href="javascript:void(0)" tabindex="-1" class="seat"></a>\r\n		<a href="javascript:void(0)" tabindex="-1" class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 <%=item.name%>" tabindex="3"></a>\r\n		<a href="javascript:void(0)" tabindex="-1" class="resume" data-action="task.resume" title="启动" aria-label="启动任务 <%=item.name%>" tabindex="3"></a>\r\n		<a href="javascript:void(0)" tabindex="-1" class="continue" data-action="task.continue" title="续传" aria-label="续传任务 <%=item.name%>" tabindex="3"></a>\r\n		<a href="javascript:void(0)" tabindex="-1" class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 <%=item.name%>" tabindex="3"></a>\r\n		<a href="javascript:void(0)" tabindex="-1" class="ok-upload"></a>\r\n		<a href="javascript:void(0)" tabindex="-1" class="ok-download"></a>\r\n		<a href="javascript:void(0)" tabindex="-1" class="go-folder" data-action="task.openFolderIco" title="打开该文件所在的文件夹" arir-label="打开<%=item.name%>所在的文件夹" tabindex="3"></a>\r\n	</div>\r\n	<div></div>\r\n</div>\r\n<%}%>',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push("");
                    __stack.lineno = 1;
                    for (var e = 0, t = locals.list.length; e < t; e++) {
                        var a = locals.list[e];
                        buf.push('\n<div class="file2 file2-2 ', (__stack.lineno = 5, a.styles), '" data-path="', (__stack.lineno = 5, 
                        a.filepath), '" data-id="', (__stack.lineno = 5, a.id), '" data-folder="', (__stack.lineno = 5, 
                        a.folderpath), '" ');
                        __stack.lineno = 5;
                        if (a.styleStatus === "complete") {
                            buf.push('data-action="task.openFolder"');
                            __stack.lineno = 5;
                        }
                        buf.push('>\n	<div class="file-icon">\n		<div class="files-', (__stack.lineno = 7, 
                        a.icon), '"></div>\n		<i></i>\n	</div>\n	<div class="file-info">\n		<div class="filename">\n			<div class="name">', escape((__stack.lineno = 12, 
                        a.name)), "</div>\n			");
                        __stack.lineno = 13;
                        if (a.orcType === 1) {
                            buf.push('\n				<div class="suffix">', (__stack.lineno = 14, a.suf), "</div>\n			");
                            __stack.lineno = 15;
                        }
                        buf.push('\n		</div>\n		<div class="loading">\n			<div class="bar" style="width:', (__stack.lineno = 18, 
                        a.cPercent), '%;"></div>\n		</div>\n		');
                        __stack.lineno = 20;
                        if (a.failedFileList && a.failedFileList.length > 0) {
                            buf.push('\n			<div class="wording"  data-action="task.openfail">\n				<i class=\'warn\'></i>有', (__stack.lineno = 22, 
                            a.failedFileList.length), '个文件下载失败<i class="arrow"></i>\n					<ul class="fail-list">\n						');
                            __stack.lineno = 24;
                            for (var n = 0, i = a.failedFileList.length; n < i; n++) {
                                buf.push("\n							<li>", escape((__stack.lineno = 25, a.failedFileList[n].filename)), "</li>\n						");
                                __stack.lineno = 26;
                            }
                            buf.push("\n					</ul>\n			</div>\n		");
                            __stack.lineno = 29;
                        } else {
                            buf.push('\n			<div class="wording">', (__stack.lineno = 30, a.wording), "</div>		\n		");
                            __stack.lineno = 31;
                        }
                        buf.push('\n	</div>\n	<div class="aris-hide">\n		<a tabindex="-1">', escape((__stack.lineno = 34, 
                        a.name)), " 进度", (__stack.lineno = 34, a.cPercent), '%</a>\n	</div>\n	<div class="file-action">\n		<a href="javascript:void(0)" tabindex="-1" class="seat"></a>\n		<a href="javascript:void(0)" tabindex="-1" class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 ', escape((__stack.lineno = 38, 
                        a.name)), '" tabindex="3"></a>\n		<a href="javascript:void(0)" tabindex="-1" class="resume" data-action="task.resume" title="启动" aria-label="启动任务 ', escape((__stack.lineno = 39, 
                        a.name)), '" tabindex="3"></a>\n		<a href="javascript:void(0)" tabindex="-1" class="continue" data-action="task.continue" title="续传" aria-label="续传任务 ', escape((__stack.lineno = 40, 
                        a.name)), '" tabindex="3"></a>\n		<a href="javascript:void(0)" tabindex="-1" class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 ', escape((__stack.lineno = 41, 
                        a.name)), '" tabindex="3"></a>\n		<a href="javascript:void(0)" tabindex="-1" class="ok-upload"></a>\n		<a href="javascript:void(0)" tabindex="-1" class="ok-download"></a>\n		<a href="javascript:void(0)" tabindex="-1" class="go-folder" data-action="task.openFolderIco" title="打开该文件所在的文件夹" arir-label="打开', escape((__stack.lineno = 44, 
                        a.name)), '所在的文件夹" tabindex="3"></a>\n	</div>\n	<div></div>\n</div>\n');
                        __stack.lineno = 48;
                    }
                    buf.push("");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(e, t, a) {
    "use strict";
    var n = a(37);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = {
        folderTree: a(274),
        newFloder: a(275)
    };
    var l = $("#containerFolderTreePanel");
    var s = a(10);
    function f(e, t) {
        G.folderTree = G.folderTree || {};
        var a = G.nowFolder === "/" ? {
            fname: "群文件",
            id: "/"
        } : G.folderMap()[G.nowFolder];
        if (G.folderTree && G.folderTree.selected) {
            G.folderTree.selected = a;
        }
        G.folderTree.container = $(e);
        var n = [];
        var r = (0, i.default)(G.folderMap());
        for (var l = r.length - 1; l >= 0; l--) {
            n.push(G.folderMap()[r[l]]);
        }
        n = s.quickSortByObjectAttr(n, "mt");
        $(e).html(o.folderTree({
            topFolder: G.topFolder,
            items: n
        }));
        c(a.id);
    }
    function c(e) {
        console.log(this);
        e = e || $(this).data("id");
        if (!e) {
            return;
        }
        if (!G.folderTree) {
            G.folderTree = {};
        }
        l.find(".active").removeClass("active");
        var t = {};
        if (e === "/") {
            t = G.folderTree.selected = G.topFolder;
        } else if (e !== "new") {
            t = G.folderTree.selected = G.folderMap()[e];
        } else {
            t = {
                id: e
            };
            G.folderTree.selected = t;
        }
        $('.folder-list-item[data-id="' + t.id + '"]').addClass("active");
        t.fname !== undefined && l.find('[data-role="dest"]').html(t.fname);
    }
    function d() {
        var e = G.folderTree.container.find(".secondary-folder-list li");
        if (e.length) {
            e.first().before(o.newFloder());
        } else {
            G.folderTree.container.find(".secondary-folder-list").append(o.newFloder());
        }
    }
    e.exports = {
        render: f,
        newFolder: d,
        select: c
    };
}, function(e, t, a) {
    "use strict";
    var n = a(41), i = {}, r = $(G.handler);
    e.exports = i;
    var o = 10, l = 3 * 60 * 1e3;
    function s(e) {
        var t = e.filepath;
        var a = e.remoteType;
        var n = e.fname;
        var i = e.fp;
        if (!i) {
            i = t.substr(4);
        }
        var r = a == 1 ? 0 : 1;
        var i = r + "<" + i + "<" + escape(n);
        return i;
    }
    function f(e) {
        var t = "";
        for (var a = 0; a < e.length; a++) {
            if (a > 0) {
                t += ":";
            }
            t += s(e[a]);
        }
        return t;
    }
    i.getThumb = function(e, t) {
        if (!G.flagThumb) {
            return;
        }
        var a = f(e);
        var i = {
            id: Math.floor(new Date().getTime() / 1e3),
            fp_list: a
        };
        n.getPreview(i).done(function(t) {
            if (t.ec === 0) {
                if (!t.address_list) {
                    t.address_list = [];
                }
                for (var a = 0, n = e.length; a < n; a++) {
                    var i = e[a], o = t.address_list[a];
                    o.t = new Date().getTime();
                    if (i) {
                        i.usedTime = 0;
                        G.previewCache[i.filepath] = o;
                        i.previewObj = o;
                        r.trigger("file.thumbUpdate", i);
                    }
                }
            }
        }).fail(function(e) {});
    };
    i.getOneThumb = function(e, t) {
        var a = new Date().getTime();
        try {
            if (a - e.previewObj.t < l && e.usedTime <= 3) {
                t(e);
                return;
            }
        } catch (i) {
            console.log(i);
        }
        var r = {
            id: Math.floor(new Date().getTime() / 1e3),
            fp_list: s(e)
        };
        n.getPreview(r).done(function(a) {
            if (a.ec === 0) {
                if (!a.address_list) {
                    a.address_list = [];
                }
                var n = a.address_list[0];
                n.t = new Date().getTime();
                e.usedTime = 0;
                e.previewObj = n;
                t(e);
            }
        }).fail(function(e) {});
    };
}, function(e, t, a) {
    "use strict";
    var n = a(264), i = a(265);
    var r = $("#fileMoreMenu");
    function o() {
        var e = i(G.info);
        r.html(e);
    }
    function l() {
        var e = n({
            mac: G.mac
        });
        r.html(e);
    }
    e.exports = {
        renderFolder: o,
        renderFile: l
    };
}, function(e, t, a) {
    "use strict";
    var n = a(266);
    var i = void 0;
    var r = void 0;
    function o(e) {
        if (!i) {
            var t = n();
            $("body").append(t);
            i = $("#jubaoDom");
            r = $("#jubaoIframe");
        }
        if (e) {
            i.addClass("open");
            r.attr("src", e).addClass("open");
        }
    }
    function l() {
        if (i) {
            i.removeClass("open");
            r.removeClass("open");
        }
    }
    e.exports = {
        show: o,
        hide: l
    };
}, function(e, t, a) {
    "use strict";
    var n = a(25);
    var i = r(n);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(36);
    var l = {
        newtask: a(267),
        taskcomplete: a(268),
        taskpause: a(269),
        taskresume: a(270),
        taskprogress: a(271),
        taskabort: a(272)
    };
    function s(e) {
        if ((typeof e === "undefined" ? "undefined" : (0, i.default)(e)) !== "object") {
            console.error("onFiletransporterEvent param parse error");
            return;
        }
        var t = e.event;
        var a = e.task;
        var n = {
            newtask: "newtask",
            taskcomplete: "taskcomplete",
            taskpause: "taskpause",
            taskresume: "taskresume",
            startprogress: "taskprogress",
            taskabort: "taskabort"
        };
        if (typeof n[t] !== "undefined" && typeof l[n[t]] !== "undefined") {
            console.log("收到任务:", a, e);
            a = o.get(a);
            l[n[t]](a);
            console.log("-------------");
            $(G.handler).trigger("task.startRefresh");
        }
    }
    e.exports = {
        fileEvent: s
    };
}, function(e, t, a) {
    "use strict";
    var n = a(62);
    function i(e) {
        n.showUpload(e);
    }
    function r(e) {
        var t = e.fileList;
        var a = [];
        for (var i = 0, r = t.length; i < r; i++) {
            var o = t[i];
            a.push(o.filepath);
        }
        n.batchuploadInFolder(G.nowFolder, a);
    }
    e.exports = {
        uploadEvent: i,
        dropEvent: r
    };
}, function(e, t, a) {
    "use strict";
    var n = function() {
        var e = /"|&|'|<|>|[\x00-\x20]|[\x7F-\xFF]|[\u0100-\u2700]/g;
        var t = /&\w+;|&#(\d+);/g;
        var a = /(^\s*)|(\s*$)/g;
        var n = {
            "&lt;": "<",
            "&gt;": ">",
            "&amp;": "&",
            "&nbsp;": " ",
            "&quot;": '"',
            "&copy;": ""
        };
        var i = function o(t) {
            t = t != undefined ? t : "";
            return typeof t != "string" ? t : t.replace(e, function(e) {
                var t = e.charCodeAt(0), a = [ "&#" ];
                t = t == 32 ? 160 : t;
                a.push(t);
                a.push(";");
                return a.join("");
            });
        };
        var r = function l(e) {
            e = e != undefined ? e : "";
            var a = typeof e != "string" ? e : e.replace(t, function(e, t) {
                var a = n[e];
                if (a == undefined) {
                    if (!isNaN(t)) {
                        a = String.fromCharCode(t == 160 ? 32 : t);
                    } else {
                        a = e;
                    }
                }
                return a;
            });
            a = a.replace(/&#x2028;/g, "\u2028");
            a = a.replace(/&#x2029;/g, "\u2029");
            return a;
        };
        return {
            encodeHtml: i,
            decodeHtml: r
        };
    }();
    e.exports = {
        encode: n.encodeHtml,
        decode: n.decodeHtml
    };
}, , , , , , , , , , , function(e, t, a) {
    "use strict";
    var n = a(26);
    var i = l(n);
    var r = a(25);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = function(e) {
        if (e.BJ_REPORT) return e.BJ_REPORT;
        var t = [];
        var a = e.onerror;
        e.onerror = function(t, n, i, o, l) {
            var s = t;
            if (l && l.stack) {
                s = f(l);
            }
            if (r(s, "Event")) {
                s += s.type ? "--" + s.type + "--" + (s.target ? s.target.tagName + "--" + s.target.src : "") : "";
            }
            h.push({
                msg: s,
                target: n,
                rowNum: i,
                colNum: o
            });
            m();
            a && a.apply(e, arguments);
        };
        var n = {
            id: 0,
            uin: 0,
            url: "",
            combo: 1,
            ext: {},
            level: 4,
            ignore: [],
            random: 1,
            delay: 1e3,
            submit: null
        };
        var r = function g(e, t) {
            return Object.prototype.toString.call(e) === "[object " + (t || "Object") + "]";
        };
        var l = function w(e) {
            var t = typeof e === "undefined" ? "undefined" : (0, o.default)(e);
            return t === "object" && !!e;
        };
        var s = function b(e) {
            try {
                if (e.stack) {
                    var t = e.stack.match("//[^\n]+");
                    t = t ? t[0] : "";
                    var a = t.match(":([0-9]+):([0-9]+)");
                    if (!a) {
                        a = [ 0, 0, 0 ];
                    }
                    var n = f(e);
                    return {
                        msg: n,
                        rowNum: a[1],
                        colNum: a[2],
                        target: t.replace(a[0], "")
                    };
                } else {
                    return e;
                }
            } catch (i) {
                return e;
            }
        };
        var f = function _(e) {
            var t = e.stack.replace(/\n/gi, "").split(/\bat\b/).slice(0, 5).join("@").replace(/\?[^:]+/gi, "");
            var a = e.toString();
            if (t.indexOf(a) < 0) {
                t = a + "@" + t;
            }
            return t;
        };
        var c = function k(e, t) {
            var a = [];
            var r = [];
            var o = [];
            if (l(e)) {
                e.level = e.level || n.level;
                for (var s in e) {
                    var f = e[s] || "";
                    if (f) {
                        if (l(f)) {
                            try {
                                f = (0, i.default)(f);
                            } catch (c) {
                                f = "[BJ_REPORT detect value stringify error] " + c.toString();
                            }
                        }
                        o.push(s + ":" + f);
                        a.push(s + "=" + encodeURIComponent(f));
                        r.push(s + "[" + t + "]=" + encodeURIComponent(f));
                    }
                }
            }
            return [ r.join("&"), o.join(","), a.join("&") ];
        };
        var d = [];
        var u = function y(e) {
            if (n.submit) {
                n.submit(e);
            } else {
                var t = new Image();
                d.push(t);
                t.src = e;
            }
        };
        var p = [];
        var v = 0;
        var m = function G(e) {
            if (!n.report) return;
            while (t.length) {
                var a = false;
                var i = t.shift();
                var o = c(i, p.length);
                for (var l = 0, s = n.ignore.length; l < s; l++) {
                    var f = n.ignore[l];
                    if (r(f, "RegExp") && f.test(o[1]) || r(f, "Function") && f(i, o[1])) {
                        a = true;
                        break;
                    }
                }
                if (!a) {
                    if (n.combo) {
                        p.push(o[0]);
                    } else {
                        u(n.report + o[2] + "&_t=" + +new Date());
                    }
                    n.onReport && n.onReport(n.id, i);
                }
            }
            var d = p.length;
            if (d) {
                var m = function h() {
                    clearTimeout(v);
                    u(n.report + p.join("&") + "&count=" + d + "&_t=" + +new Date());
                    v = 0;
                    p = [];
                };
                if (e) {
                    m();
                } else if (!v) {
                    v = setTimeout(m, n.delay);
                }
            }
        };
        var h = {
            push: function x(e) {
                if (Math.random() >= n.random) {
                    return h;
                }
                t.push(l(e) ? s(e) : {
                    msg: e
                });
                m();
                return h;
            },
            report: function F(e) {
                e && h.push(e);
                m(true);
                return h;
            },
            info: function T(e) {
                if (!e) {
                    return h;
                }
                if (l(e)) {
                    e.level = 2;
                } else {
                    e = {
                        msg: e,
                        level: 2
                    };
                }
                h.push(e);
                return h;
            },
            debug: function C(e) {
                if (!e) {
                    return h;
                }
                if (l(e)) {
                    e.level = 1;
                } else {
                    e = {
                        msg: e,
                        level: 1
                    };
                }
                h.push(e);
                return h;
            },
            init: function S(e) {
                if (l(e)) {
                    for (var t in e) {
                        n[t] = e[t];
                    }
                }
                var a = parseInt(n.id, 10);
                if (a) {
                    n.report = (n.url || "//badjs2.qq.com/badjs") + "?id=" + a + "&uin=" + parseInt(n.uin || (document.cookie.match(/\buin=\D+(\d+)/) || [])[1], 10) + "&from=" + encodeURIComponent(location.href) + "&ext=" + (0, 
                    i.default)(n.ext) + "&";
                }
                return h;
            },
            __onerror__: e.onerror
        };
        return h;
    }(window);
    t.createReport = function(e) {
        e = e || {};
        var t = e.id;
        if (!t) throw new Error("id is required");
        s.init({
            id: t
        });
        return s;
    };
}, , , , , , , , , function(e, t, a) {
    var n = a(229);
    e.exports = function(e) {
        return Object(n(e));
    };
}, function(e, t, a) {
    var n = a(195), i = a(190), r = a(228)("IE_PROTO"), o = Object.prototype;
    e.exports = Object.getPrototypeOf || function(e) {
        e = i(e);
        if (n(e, r)) return e[r];
        if (typeof e.constructor == "function" && e instanceof e.constructor) {
            return e.constructor.prototype;
        }
        return e instanceof Object ? o : null;
    };
}, function(e, t, a) {
    var n = a(197), i = a(101), r = a(200);
    e.exports = function(e, t) {
        var a = (i.Object || {})[e] || Object[e], o = {};
        o[e] = t(a);
        n(n.S + n.F * r(function() {
            a(1);
        }), "Object", o);
    };
}, function(e, t, a) {
    var n = a(201)("wks"), i = a(203), r = a(194).Symbol, o = typeof r == "function";
    var l = e.exports = function(e) {
        return n[e] || (n[e] = o && r[e] || (o ? r : i)("Symbol." + e));
    };
    l.store = n;
}, function(e, t, a) {
    var n = e.exports = typeof window != "undefined" && window.Math == Math ? window : typeof self != "undefined" && self.Math == Math ? self : Function("return this")();
    if (typeof __g == "number") __g = n;
}, function(e, t, a) {
    var n = {}.hasOwnProperty;
    e.exports = function(e, t) {
        return n.call(e, t);
    };
}, function(e, t, a) {
    e.exports = !a(200)(function() {
        return Object.defineProperty({}, "a", {
            get: function() {
                return 7;
            }
        }).a != 7;
    });
}, function(e, t, a) {
    var n = a(194), i = a(101), r = a(230), o = a(220), l = "prototype";
    var s = function(e, t, a) {
        var f = e & s.F, c = e & s.G, d = e & s.S, u = e & s.P, p = e & s.B, v = e & s.W, m = c ? i : i[t] || (i[t] = {}), h = m[l], g = c ? n : d ? n[t] : (n[t] || {})[l], w, b, _;
        if (c) a = t;
        for (w in a) {
            b = !f && g && g[w] !== undefined;
            if (b && w in m) continue;
            _ = b ? g[w] : a[w];
            m[w] = c && typeof g[w] != "function" ? a[w] : p && b ? r(_, n) : v && g[w] == _ ? function(e) {
                var t = function(t, a, n) {
                    if (this instanceof e) {
                        switch (arguments.length) {
                          case 0:
                            return new e();

                          case 1:
                            return new e(t);

                          case 2:
                            return new e(t, a);
                        }
                        return new e(t, a, n);
                    }
                    return e.apply(this, arguments);
                };
                t[l] = e[l];
                return t;
            }(_) : u && typeof _ == "function" ? r(Function.call, _) : _;
            if (u) {
                (m.virtual || (m.virtual = {}))[w] = _;
                if (e & s.R && h && !h[w]) o(h, w, _);
            }
        }
    };
    s.F = 1;
    s.G = 2;
    s.S = 4;
    s.P = 8;
    s.B = 16;
    s.W = 32;
    s.U = 64;
    s.R = 128;
    e.exports = s;
}, function(e, t, a) {
    e.exports = a(220);
}, function(e, t, a) {
    var n = a(203)("meta"), i = a(231), r = a(195), o = a(214).f, l = 0;
    var s = Object.isExtensible || function() {
        return true;
    };
    var f = !a(200)(function() {
        return s(Object.preventExtensions({}));
    });
    var c = function(e) {
        o(e, n, {
            value: {
                i: "O" + ++l,
                w: {}
            }
        });
    };
    var d = function(e, t) {
        if (!i(e)) return typeof e == "symbol" ? e : (typeof e == "string" ? "S" : "P") + e;
        if (!r(e, n)) {
            if (!s(e)) return "F";
            if (!t) return "E";
            c(e);
        }
        return e[n].i;
    };
    var u = function(e, t) {
        if (!r(e, n)) {
            if (!s(e)) return true;
            if (!t) return false;
            c(e);
        }
        return e[n].w;
    };
    var p = function(e) {
        if (f && v.NEED && s(e) && !r(e, n)) c(e);
        return e;
    };
    var v = e.exports = {
        KEY: n,
        NEED: false,
        fastKey: d,
        getWeak: u,
        onFreeze: p
    };
}, function(e, t, a) {
    e.exports = function(e) {
        try {
            return !!e();
        } catch (t) {
            return true;
        }
    };
}, function(e, t, a) {
    var n = a(194), i = "__core-js_shared__", r = n[i] || (n[i] = {});
    e.exports = function(e) {
        return r[e] || (r[e] = {});
    };
}, function(e, t, a) {
    var n = a(214).f, i = a(195), r = a(193)("toStringTag");
    e.exports = function(e, t, a) {
        if (e && !i(e = a ? e : e.prototype, r)) n(e, r, {
            configurable: true,
            value: t
        });
    };
}, function(e, t, a) {
    var n = 0, i = Math.random();
    e.exports = function(e) {
        return "Symbol(".concat(e === undefined ? "" : e, ")_", (++n + i).toString(36));
    };
}, function(e, t, a) {
    var n = a(194), i = a(101), r = a(219), o = a(102), l = a(214).f;
    e.exports = function(e) {
        var t = i.Symbol || (i.Symbol = r ? {} : n.Symbol || {});
        if (e.charAt(0) != "_" && !(e in t)) l(t, e, {
            value: o.f(e)
        });
    };
}, function(e, t, a) {
    var n = a(215), i = a(209);
    e.exports = function(e, t) {
        var a = i(e), r = n(a), o = r.length, l = 0, s;
        while (o > l) if (a[s = r[l++]] === t) return s;
    };
}, function(e, t, a) {
    var n = a(215), i = a(218), r = a(217);
    e.exports = function(e) {
        var t = n(e), a = i.f;
        if (a) {
            var o = a(e), l = r.f, s = 0, f;
            while (o.length > s) if (l.call(e, f = o[s++])) t.push(f);
        }
        return t;
    };
}, function(e, t, a) {
    var n = a(232);
    e.exports = Array.isArray || function i(e) {
        return n(e) == "Array";
    };
}, function(e, t, a) {
    var n = a(231);
    e.exports = function(e) {
        if (!n(e)) throw TypeError(e + " is not an object!");
        return e;
    };
}, function(e, t, a) {
    var n = a(233), i = a(229);
    e.exports = function(e) {
        return n(i(e));
    };
}, function(e, t, a) {
    e.exports = function(e, t) {
        return {
            enumerable: !(e & 1),
            configurable: !(e & 2),
            writable: !(e & 4),
            value: t
        };
    };
}, function(e, t, a) {
    var n = a(208), i = a(234), r = a(235), o = a(228)("IE_PROTO"), l = function() {}, s = "prototype";
    var f = function() {
        var e = a(236)("iframe"), t = r.length, n = "<", i = ">", o;
        e.style.display = "none";
        a(237).appendChild(e);
        e.src = "javascript:";
        o = e.contentWindow.document;
        o.open();
        o.write(n + "script" + i + "document.F=Object" + n + "/script" + i);
        o.close();
        f = o.F;
        while (t--) delete f[s][r[t]];
        return f();
    };
    e.exports = Object.create || function c(e, t) {
        var a;
        if (e !== null) {
            l[s] = n(e);
            a = new l();
            l[s] = null;
            a[o] = e;
        } else a = f();
        return t === undefined ? a : i(a, t);
    };
}, function(e, t, a) {
    var n = a(209), i = a(216).f, r = {}.toString;
    var o = typeof window == "object" && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [];
    var l = function(e) {
        try {
            return i(e);
        } catch (t) {
            return o.slice();
        }
    };
    e.exports.f = function s(e) {
        return o && r.call(e) == "[object Window]" ? l(e) : i(n(e));
    };
}, function(e, t, a) {
    var n = a(217), i = a(210), r = a(209), o = a(225), l = a(195), s = a(238), f = Object.getOwnPropertyDescriptor;
    t.f = a(196) ? f : function c(e, t) {
        e = r(e);
        t = o(t, true);
        if (s) try {
            return f(e, t);
        } catch (a) {}
        if (l(e, t)) return i(!n.f.call(e, t), e[t]);
    };
}, function(e, t, a) {
    var n = a(208), i = a(238), r = a(225), o = Object.defineProperty;
    t.f = a(196) ? Object.defineProperty : function l(e, t, a) {
        n(e);
        t = r(t, true);
        n(a);
        if (i) try {
            return o(e, t, a);
        } catch (l) {}
        if ("get" in a || "set" in a) throw TypeError("Accessors not supported!");
        if ("value" in a) e[t] = a.value;
        return e;
    };
}, function(e, t, a) {
    var n = a(239), i = a(235);
    e.exports = Object.keys || function r(e) {
        return n(e, i);
    };
}, function(e, t, a) {
    var n = a(239), i = a(235).concat("length", "prototype");
    t.f = Object.getOwnPropertyNames || function r(e) {
        return n(e, i);
    };
}, function(e, t, a) {
    t.f = {}.propertyIsEnumerable;
}, function(e, t, a) {
    t.f = Object.getOwnPropertySymbols;
}, function(e, t, a) {
    e.exports = true;
}, function(e, t, a) {
    var n = a(214), i = a(210);
    e.exports = a(196) ? function(e, t, a) {
        return n.f(e, t, i(1, a));
    } : function(e, t, a) {
        e[t] = a;
        return e;
    };
}, function(e, t, a) {
    var n = a(241), i = a(229);
    e.exports = function(e) {
        return function(t, a) {
            var r = String(i(t)), o = n(a), l = r.length, s, f;
            if (o < 0 || o >= l) return e ? "" : undefined;
            s = r.charCodeAt(o);
            return s < 55296 || s > 56319 || o + 1 === l || (f = r.charCodeAt(o + 1)) < 56320 || f > 57343 ? e ? r.charAt(o) : s : e ? r.slice(o, o + 2) : (s - 55296 << 10) + (f - 56320) + 65536;
        };
    };
}, function(e, t, a) {
    "use strict";
    var n = a(219), i = a(197), r = a(198), o = a(220), l = a(195), s = a(224), f = a(240), c = a(202), d = a(191), u = a(193)("iterator"), p = !([].keys && "next" in [].keys()), v = "@@iterator", m = "keys", h = "values";
    var g = function() {
        return this;
    };
    e.exports = function(e, t, a, w, b, _, k) {
        f(a, t, w);
        var y = function(e) {
            if (!p && e in T) return T[e];
            switch (e) {
              case m:
                return function t() {
                    return new a(this, e);
                };

              case h:
                return function n() {
                    return new a(this, e);
                };
            }
            return function i() {
                return new a(this, e);
            };
        };
        var G = t + " Iterator", x = b == h, F = false, T = e.prototype, C = T[u] || T[v] || b && T[b], S = C || y(b), $ = b ? !x ? S : y("entries") : undefined, M = t == "Array" ? T.entries || C : C, j, R, D;
        if (M) {
            D = d(M.call(new e()));
            if (D !== Object.prototype) {
                c(D, G, true);
                if (!n && !l(D, u)) o(D, u, g);
            }
        }
        if (x && C && C.name !== h) {
            F = true;
            S = function O() {
                return C.call(this);
            };
        }
        if ((!n || k) && (p || F || !T[u])) {
            o(T, u, S);
        }
        s[t] = S;
        s[G] = g;
        if (b) {
            j = {
                values: x ? S : y(h),
                keys: _ ? S : y(m),
                entries: $
            };
            if (k) for (R in j) {
                if (!(R in T)) r(T, R, j[R]);
            } else i(i.P + i.F * (p || F), t, j);
        }
        return j;
    };
}, function(e, t, a) {
    "use strict";
    var n = a(242), i = a(243), r = a(224), o = a(209);
    e.exports = a(222)(Array, "Array", function(e, t) {
        this._t = o(e);
        this._i = 0;
        this._k = t;
    }, function() {
        var e = this._t, t = this._k, a = this._i++;
        if (!e || a >= e.length) {
            this._t = undefined;
            return i(1);
        }
        if (t == "keys") return i(0, a);
        if (t == "values") return i(0, e[a]);
        return i(0, [ a, e[a] ]);
    }, "values");
    r.Arguments = r.Array;
    n("keys");
    n("values");
    n("entries");
}, function(e, t, a) {
    e.exports = {};
}, function(e, t, a) {
    var n = a(231);
    e.exports = function(e, t) {
        if (!n(e)) return e;
        var a, i;
        if (t && typeof (a = e.toString) == "function" && !n(i = a.call(e))) return i;
        if (typeof (a = e.valueOf) == "function" && !n(i = a.call(e))) return i;
        if (!t && typeof (a = e.toString) == "function" && !n(i = a.call(e))) return i;
        throw TypeError("Can't convert object to primitive value");
    };
}, function(e, t, a) {
    e.exports = function(e) {
        if (!e.webpackPolyfill) {
            e.deprecate = function() {};
            e.paths = [];
            e.children = [];
            e.webpackPolyfill = 1;
        }
        return e;
    };
}, function(e, t, a) {
    var n = a(293);
    e.exports = function i(e) {
        var t = [];
        var a = {};
        var i;
        var r = e || {};
        (function(e, a, r, o, l, s, f, c) {
            t.push('<!-- 移动文件/上传文件 公用模态框--><div id="folderTreePanel" role="panel" class="panel-overlay folder-tree-panel"><div class="panel"><div class="panel-title"><i class="icons-qq"></i><span>' + n.escape((i = e) == null ? "" : i) + '</span><div data-action="panel.close" data-dismiss="panel" aria-label="取消" class="close"></div></div><div class="panel-body"><div class="panel-content"><div class="selected-files"><span class="file-name">' + (null == (i = a) ? "" : i) + "</span>");
            if (r > 1) {
                t.push('						等 <span class="file-number">' + (null == (i = r) ? "" : i) + "</span> 个文件");
            }
            t.push('</div><div class="translateTo"><span class="translateTo-label">' + n.escape((i = o) == null ? "" : i) + '</span><span class="little-folder-icon"></span><div data-role="dest" class="selected-folder-name">' + (null == (i = l) ? "" : i) + '</div><div id="targetFolderName" aria-live="assertive" aria-atomic="true" aria-relevant="all" class="aria-hide"><span>已选中文件夹</span><span class="folder-name">' + (null == (i = l) ? "" : i) + '</span></div></div><div class="folder-tree-box"></div></div></div><div class="panel-footer">');
            if (s = f.info.isAdmin) {
                t.push('<input type="submit" value="新建文件夹" data-action="folderTree.new" tabindex="1" class="btn-create btn-common"/>');
            }
            t.push('<input type="submit" value="取消" data-action="panel.close" data-dismiss="panel" aris-label="取消移动文件" tabindex="1" class="btn-no btn-common btn-right"/><input type="submit" value="确定"' + n.attr("data-action", "" + c + "", true, false) + ' aria-label="确定移动文件" tabindex="1" class="btn-ok btn-common btn-right"/></div></div></div>');
        }).call(this, "title" in r ? r.title : typeof title !== "undefined" ? title : undefined, "firstFileName" in r ? r.firstFileName : typeof firstFileName !== "undefined" ? firstFileName : undefined, "fileNum" in r ? r.fileNum : typeof fileNum !== "undefined" ? fileNum : undefined, "action" in r ? r.action : typeof action !== "undefined" ? action : undefined, "destFolder" in r ? r.destFolder : typeof destFolder !== "undefined" ? destFolder : undefined, "canCreatFolder" in r ? r.canCreatFolder : typeof canCreatFolder !== "undefined" ? canCreatFolder : undefined, "G" in r ? r.G : typeof G !== "undefined" ? G : undefined, "okAction" in r ? r.okAction : typeof okAction !== "undefined" ? okAction : undefined);
        return t.join("");
    };
}, function(e, t, a) {
    var n = a(201)("keys"), i = a(203);
    e.exports = function(e) {
        return n[e] || (n[e] = i(e));
    };
}, function(e, t, a) {
    e.exports = function(e) {
        if (e == undefined) throw TypeError("Can't call method on  " + e);
        return e;
    };
}, function(e, t, a) {
    var n = a(244);
    e.exports = function(e, t, a) {
        n(e);
        if (t === undefined) return e;
        switch (a) {
          case 1:
            return function(a) {
                return e.call(t, a);
            };

          case 2:
            return function(a, n) {
                return e.call(t, a, n);
            };

          case 3:
            return function(a, n, i) {
                return e.call(t, a, n, i);
            };
        }
        return function() {
            return e.apply(t, arguments);
        };
    };
}, function(e, t, a) {
    e.exports = function(e) {
        return typeof e === "object" ? e !== null : typeof e === "function";
    };
}, function(e, t, a) {
    var n = {}.toString;
    e.exports = function(e) {
        return n.call(e).slice(8, -1);
    };
}, function(e, t, a) {
    var n = a(232);
    e.exports = Object("z").propertyIsEnumerable(0) ? Object : function(e) {
        return n(e) == "String" ? e.split("") : Object(e);
    };
}, function(e, t, a) {
    var n = a(214), i = a(208), r = a(215);
    e.exports = a(196) ? Object.defineProperties : function o(e, t) {
        i(e);
        var a = r(t), o = a.length, l = 0, s;
        while (o > l) n.f(e, s = a[l++], t[s]);
        return e;
    };
}, function(e, t, a) {
    e.exports = "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",");
}, function(e, t, a) {
    var n = a(231), i = a(194).document, r = n(i) && n(i.createElement);
    e.exports = function(e) {
        return r ? i.createElement(e) : {};
    };
}, function(e, t, a) {
    e.exports = a(194).document && document.documentElement;
}, function(e, t, a) {
    e.exports = !a(196) && !a(200)(function() {
        return Object.defineProperty(a(236)("div"), "a", {
            get: function() {
                return 7;
            }
        }).a != 7;
    });
}, function(e, t, a) {
    var n = a(195), i = a(209), r = a(245)(false), o = a(228)("IE_PROTO");
    e.exports = function(e, t) {
        var a = i(e), l = 0, s = [], f;
        for (f in a) if (f != o) n(a, f) && s.push(f);
        while (t.length > l) if (n(a, f = t[l++])) {
            ~r(s, f) || s.push(f);
        }
        return s;
    };
}, function(e, t, a) {
    "use strict";
    var n = a(211), i = a(210), r = a(202), o = {};
    a(220)(o, a(193)("iterator"), function() {
        return this;
    });
    e.exports = function(e, t, a) {
        e.prototype = n(o, {
            next: i(1, a)
        });
        r(e, t + " Iterator");
    };
}, function(e, t, a) {
    var n = Math.ceil, i = Math.floor;
    e.exports = function(e) {
        return isNaN(e = +e) ? 0 : (e > 0 ? i : n)(e);
    };
}, function(e, t, a) {
    e.exports = function() {};
}, function(e, t, a) {
    e.exports = function(e, t) {
        return {
            value: t,
            done: !!e
        };
    };
}, function(e, t, a) {
    e.exports = function(e) {
        if (typeof e != "function") throw TypeError(e + " is not a function!");
        return e;
    };
}, function(e, t, a) {
    var n = a(209), i = a(294), r = a(295);
    e.exports = function(e) {
        return function(t, a, o) {
            var l = n(t), s = i(l.length), f = r(o, s), c;
            if (e && a != a) while (s > f) {
                c = l[f++];
                if (c != c) return true;
            } else for (;s > f; f++) if (e || f in l) {
                if (l[f] === a) return e || f || 0;
            }
            return !e && -1;
        };
    };
}, function(e, t, a) {
    "use strict";
    var n = a(34);
    var i = 299;
    var r = $("#box");
    var o = $(G.handler);
    var l = false;
    var s = false;
    function f() {
        report("clkTask");
        if (l) {
            d();
        } else {
            c();
            n.removePoint();
        }
    }
    function c() {
        report("showTask");
        if (!s) {
            n.firstRender();
        }
        s = true;
        l = true;
        r.addClass("open");
        $("#boxTitle a").focus();
    }
    function d() {
        l = false;
        r.removeClass("open");
        if (G.activeElement) {
            G.activeElement.focus();
        }
    }
    o.bind("box.hide", d);
    e.exports = {
        toggle: f
    };
}, function(e, t, a) {
    "use strict";
    var n = a(59);
    var i = a(35);
    function r(e) {
        var t = $(this.parentNode.parentNode);
        var a = t.data("path");
        var r = i.getTask(a);
        a = r.filepath;
        var o = r.remoteType;
        var l = r.localpath;
        var s = r.fnameEsc || r.fname;
        console.log("调用续传接口:", r, a);
        var f = n.addContinueUploadTask(a, l, s, o);
        $("#boxTitle a").focus();
        console.log("continueUpload ret:", f);
    }
    e.exports = {
        continueUpload: r
    };
}, function(e, t, a) {
    "use strict";
    var n = a(59);
    var i = a(34);
    var r = a(35);
    var o = a(4);
    function l() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("path");
        var a = r.getFile(t);
        r.clearComplete();
        i.clearComplete();
        n.clearClist();
        o.clearClist();
    }
    e.exports = {
        clear: l
    };
}, function(e, t, a) {
    "use strict";
    var n = a(59);
    var i = a(35);
    function r() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("path");
        var a = e.data("id");
        var r = i.getTask(a, t);
        console.log(">>", "task pause");
        var o = n.pauseTask(a);
        $("#boxTitle a").focus();
        report("clkTaskPause", typeof r.downloadtasktype === "undefined" ? 0 : 1);
    }
    e.exports = {
        pause: r
    };
}, function(e, t, a) {
    "use strict";
    var n = a(59);
    var i = a(10);
    var r = a(41);
    var o = a(35);
    var l = a(34);
    var s = a(8);
    var f = $(G.handler);
    function c() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("id");
        var a = e.data("path");
        var i = o.getTask(t);
        if (!i) {
            i = o.getTask(a);
        }
        var l = i.type;
        var c = true;
        var d = i.filepath;
        report("clkTaskDelete");
        $("#boxTitle a").focus();
        console.log(">>", "task remove", i);
        if (i.id) {
            var u = n.removeTask(i.id);
            c = true;
        }
        if (c) {
            if (l && l.indexOf("upload") >= 0) {
                if (d) {
                    var p = d.substr(4);
                    var v = d.substr(1, 3);
                    var m = {
                        app_id: G.appid,
                        bus_id: parseInt(v),
                        file_id: p,
                        parent_folder_id: G.nowFolder
                    };
                    console.log("删除任务:", m, i);
                    r.deleteFile(m).done(function(e) {
                        console.log("删除任务结果:", e);
                        o.remove(i);
                    }).fail(function(e) {
                        if (e.fc && e.fc === 1) {
                            return;
                        }
                    });
                }
            } else if (l === "download") {
                n.removeTask(i.id);
                n.removeCompleteTask(i.id);
            }
            if (i.id) {
                o.remove(i.id);
            }
            if (i.type !== "download") {
                o.remove(i.filepath);
            }
            i.status = "remove";
            f.trigger("client.updateTask", i);
            n.clearClist();
            var h = o.getData(d);
            if (h) {
                h.isDowning = false;
            }
            s.updateRow(h);
        }
    }
    f.bind("task.removeOne", function(e, t) {
        var a = n.removeTask(t);
        console.log(a, t);
    });
    e.exports = {
        remove: c
    };
}, function(e, t, a) {
    "use strict";
    var n = a(59);
    var i = a(35);
    function r() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("path");
        var a = i.getTask(t);
        var r = a.id;
        var o = n.resumeTask(r);
        report("clkTaskPause");
        $("#boxTitle a").focus();
    }
    e.exports = {
        resume: r
    };
}, function(e, t, a) {
    "use strict";
    var n = a(59);
    var i = a(112).refreshTime;
    var r = a(36);
    var o = $(G.handler);
    var l = 0;
    function s() {
        if (!l) {
            return;
        }
        clearTimeout(l);
        l = 0;
    }
    function f() {
        if (l) {
            return;
        }
        c();
    }
    function c() {
        var e = n.getTaskListAdv();
        var t = false;
        if (e.empty && e.status === "ok") {
            s();
        } else {
            var a = /progress|ready|scan|geturl/gi;
            var f = r.cleanMap(e.map);
            for (var d = 0, u = f.length; d < u; d++) {
                var p = f[d];
                o.trigger("client.updateTask", p);
                if (a.test(p.status)) {
                    t = true;
                }
            }
        }
        if (t) {
            l = setTimeout(c, i);
        } else {
            console.log("do stop refresh!");
            s();
        }
    }
    $(G.handler).bind("task.startRefresh", f);
    $(G.handler).bind("task.stopRefresh", s);
}, function(e, t, a) {
    "use strict";
    function n() {
        if (this.classList.contains("open")) {
            this.classList.remove("open");
        } else {
            report("clkTaskExp");
            this.classList.add("open");
        }
    }
    e.exports = {
        toggle: n
    };
}, function(e, t, a) {
    "use strict";
    var n = a(41), i = a(59), r = a(35), o = {};
    e.exports = o;
    o.closeTips = function() {};
    o.refeshVip = function() {
        n.checkVip().done(function(e) {
            console.log(e);
        }).fail(function(e) {});
    };
    o.conVip = function() {
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    o.vipTipsOk = function() {
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    o.vipTipsCancel = function() {};
    o.openVip = function() {};
}, function(e, t, a) {
    "use strict";
    var n = a(41), i = a(35), r = {};
    e.exports = r;
    r.createFolder = function(e, t) {
        n.createFolder(e).done(function(e) {
            t(e);
        }).fail(function(e) {});
    };
    r.renameFolder = function(e, t) {};
    r.deleteFolder = function(e, t) {};
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '		<div class="panel">\n			<div class="panel-title">\n				<i class="icons-qq"></i>\n				<span>文件夹属性</span>\n				<div class="close" data-action="panel.close"></div>\n			</div>\n			<div class="panel-body">\n				<div class="panel-content">\n					<div class="folder-property-top">\n						<div class="files-folder filesmall-folder"></div>\n						<div class="folder-title">\n							<div class="folder-name"><%-locals.fname%></div>\n							<div class="folder-size">共<%=locals.filenum%>个文件</div>\n						</div>\n					</div>\n					<div class="folder-property-bottom">\n						<div class="created-at">\n							<span class="folder-property-label">创建时间:</span>\n							<span class="folder-property-content"><%=locals.ctStr%></span>\n						</div>\n						<div class="creator">\n							<span class="folder-property-label">创&nbsp;&nbsp;建&nbsp;&nbsp;人:</span>\n							<span class="folder-property-content"><%-locals.nick%></span>\n						</div>\n						<div class="updated-at">\n							<span class="folder-property-label">最后更新时间:</span>\n							<span class="folder-property-content"><%=locals.mtStr%></span>\n						</div>\n						<div class="updater">\n							<span class="folder-property-label">最&nbsp;后&nbsp;更&nbsp;新&nbsp;人:</span>\n							<span class="folder-property-content"><%-locals.mnick%></span>\n						</div>\n					</div>\n				</div>\n			</div>\n			<a href="javascript:void(0);" class="aria-hide" tabindex="3" aria-label="文件夹<%-locals.fname%>共<%=locals.filenum%>个文件 创建时间:<%=locals.ctStr%> 创建人:<%-locals.nick%> 最后更新人:<%-locals.mnick%>"></a>\n			<a href="javascript:void(0);" class="aria-hide" data-action="panel.close" tabindex="3" aria-label="关闭文件夹属性窗口"></a>\n			<%if(G.mac){%>\n				<div class="panel-footer">\n					<input aria-label="确定" type="submit" value="确定" class="btn-ok btn-common btn-right" data-action="panel.close" tabindex="2">\n				</div>\n			<%}%>\n		</div>\n\n',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('		<div class="panel">\n			<div class="panel-title">\n				<i class="icons-qq"></i>\n				<span>文件夹属性</span>\n				<div class="close" data-action="panel.close"></div>\n			</div>\n			<div class="panel-body">\n				<div class="panel-content">\n					<div class="folder-property-top">\n						<div class="files-folder filesmall-folder"></div>\n						<div class="folder-title">\n							<div class="folder-name">', (__stack.lineno = 12, 
                    locals.fname), '</div>\n							<div class="folder-size">共', escape((__stack.lineno = 13, 
                    locals.filenum)), '个文件</div>\n						</div>\n					</div>\n					<div class="folder-property-bottom">\n						<div class="created-at">\n							<span class="folder-property-label">创建时间:</span>\n							<span class="folder-property-content">', escape((__stack.lineno = 19, 
                    locals.ctStr)), '</span>\n						</div>\n						<div class="creator">\n							<span class="folder-property-label">创&nbsp;&nbsp;建&nbsp;&nbsp;人:</span>\n							<span class="folder-property-content">', (__stack.lineno = 23, 
                    locals.nick), '</span>\n						</div>\n						<div class="updated-at">\n							<span class="folder-property-label">最后更新时间:</span>\n							<span class="folder-property-content">', escape((__stack.lineno = 27, 
                    locals.mtStr)), '</span>\n						</div>\n						<div class="updater">\n							<span class="folder-property-label">最&nbsp;后&nbsp;更&nbsp;新&nbsp;人:</span>\n							<span class="folder-property-content">', (__stack.lineno = 31, 
                    locals.mnick), '</span>\n						</div>\n					</div>\n				</div>\n			</div>\n			<a href="javascript:void(0);" class="aria-hide" tabindex="3" aria-label="文件夹', (__stack.lineno = 36, 
                    locals.fname), "共", escape((__stack.lineno = 36, locals.filenum)), "个文件 创建时间:", escape((__stack.lineno = 36, 
                    locals.ctStr)), " 创建人:", (__stack.lineno = 36, locals.nick), " 最后更新人:", (__stack.lineno = 36, 
                    locals.mnick), '"></a>\n			<a href="javascript:void(0);" class="aria-hide" data-action="panel.close" tabindex="3" aria-label="关闭文件夹属性窗口"></a>\n			');
                    __stack.lineno = 38;
                    if (G.mac) {
                        buf.push('\n				<div class="panel-footer">\n					<input aria-label="确定" type="submit" value="确定" class="btn-ok btn-common btn-right" data-action="panel.close" tabindex="2">\n				</div>\n			');
                        __stack.lineno = 42;
                    }
                    buf.push("\n		</div>\n\n");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<section class="file-list" id="<%-locals.id%>"></section>',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('<section class="file-list" id="', (__stack.lineno = 1, locals.id), '"></section>');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, , , , , , , function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '		<li class="item with-icon-item disable" id="filePreview" data-action="file.menupreview" aria-label="预览"><span class="icons-preview"></span><span class="menu-item-label">预览</span></li>\n		<%if(!G.mac){%>\n			<li class="item" id="fileFoward" data-action="file.forward" aria-label="转发">转发</li>\n			<li class="item" id="fileFowardTo" data-action="file.forwardMobile" aria-label="转发到手机" tabindex="1">转发到手机</li>\n		<%}%>\n		<li class="item save-as open-folder with-icon-item" id="fileOpenFolder" data-action="file.openFolderInBox" aria-label="在文件夹中显示" tabindex="1"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item rename" id="renameFile" data-action="file.showRename" aria-label="重命名" tabindex="1">重命名</li>\n		<li class="item forever disable" id="foreverFile" data-action="file.permanent" aria-label="转存为永久文件" tabindex="-1">转存为永久文件</li>\n		<%if(G.info.isAdmin){%>\n		<li class="item " id="fileMove" data-action="file.showMove" aria-label="移动" tabindex="-1">移动</li>\n		<%}%>\n		<li class="item jubao" id="fileJubao" data-action="file.jubao" aria-label="举报" tabindex="1">举报</li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item delete with-icon-item" data-action="file.delete" id="fileDelete" aria-label="删除" tabindex="1"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('		<li class="item with-icon-item disable" id="filePreview" data-action="file.menupreview" aria-label="预览"><span class="icons-preview"></span><span class="menu-item-label">预览</span></li>\n		');
                    __stack.lineno = 2;
                    if (!G.mac) {
                        buf.push('\n			<li class="item" id="fileFoward" data-action="file.forward" aria-label="转发">转发</li>\n			<li class="item" id="fileFowardTo" data-action="file.forwardMobile" aria-label="转发到手机" tabindex="1">转发到手机</li>\n		');
                        __stack.lineno = 5;
                    }
                    buf.push('\n		<li class="item save-as open-folder with-icon-item" id="fileOpenFolder" data-action="file.openFolderInBox" aria-label="在文件夹中显示" tabindex="1"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item rename" id="renameFile" data-action="file.showRename" aria-label="重命名" tabindex="1">重命名</li>\n		<li class="item forever disable" id="foreverFile" data-action="file.permanent" aria-label="转存为永久文件" tabindex="-1">转存为永久文件</li>\n		');
                    __stack.lineno = 10;
                    if (G.info.isAdmin) {
                        buf.push('\n		<li class="item " id="fileMove" data-action="file.showMove" aria-label="移动" tabindex="-1">移动</li>\n		');
                        __stack.lineno = 12;
                    }
                    buf.push('\n		<li class="item jubao" id="fileJubao" data-action="file.jubao" aria-label="举报" tabindex="1">举报</li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item delete with-icon-item" data-action="file.delete" id="fileDelete" aria-label="删除" tabindex="1"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '		<li class="download-item with-icon-item download-folder" id="folderDownloadLink" data-action="folder.download"><span class="icons-download"></span><span class="menu-item-label">下载</span></li>\n		<li class="with-icon-item open-in-folder disable" id="showInFolderLink" data-action="folder.openfolder"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<%if(locals.isAdmin){%>\n		<li class="rename-item" id="folderRenameLink" data-action="folder.showRenameFolder">重命名</li>\n		<%}%>\n		<li class="property-item" id="folderPropLink" data-action="folder.property">文件夹属性</li>\n		<li class="gap"></li>\n		<%if(locals.isAdmin){%>\n		<li class="delete-item with-icon-item" id="folderDeleteLink" data-action="folder.showDeleteFolder"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n		<%}else{%>\n		<li class="item jubao" data-action="file.jubao" id="folderJubaoLink" aria-label="举报" tabindex="1">举报</li>\n		<%}%>\n',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('		<li class="download-item with-icon-item download-folder" id="folderDownloadLink" data-action="folder.download"><span class="icons-download"></span><span class="menu-item-label">下载</span></li>\n		<li class="with-icon-item open-in-folder disable" id="showInFolderLink" data-action="folder.openfolder"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		');
                    __stack.lineno = 3;
                    if (locals.isAdmin) {
                        buf.push('\n		<li class="rename-item" id="folderRenameLink" data-action="folder.showRenameFolder">重命名</li>\n		');
                        __stack.lineno = 5;
                    }
                    buf.push('\n		<li class="property-item" id="folderPropLink" data-action="folder.property">文件夹属性</li>\n		<li class="gap"></li>\n		');
                    __stack.lineno = 8;
                    if (locals.isAdmin) {
                        buf.push('\n		<li class="delete-item with-icon-item" id="folderDeleteLink" data-action="folder.showDeleteFolder"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n		');
                        __stack.lineno = 10;
                    } else {
                        buf.push('\n		<li class="item jubao" data-action="file.jubao" id="folderJubaoLink" aria-label="举报" tabindex="1">举报</li>\n		');
                        __stack.lineno = 12;
                    }
                    buf.push("\n");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '  <div class="panel-con jubao-panel" id="jubaoDom">\r\n    <iframe class="frame-jubao" id="jubaoIframe" frameborder="0" scrolling="no"></iframe>\r\n  </div>',
            filename: undefined
        };
        function rethrow(e, t, a, n) {
            var i = t.split("\n"), r = Math.max(n - 3, 0), o = Math.min(i.length, n + 3);
            var l = i.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == n ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + n + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('  <div class="panel-con jubao-panel" id="jubaoDom">\n    <iframe class="frame-jubao" id="jubaoIframe" frameborder="0" scrolling="no"></iframe>\n  </div>');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(e, t, a) {
    "use strict";
    var n = {
        upload: 2186487,
        continueupload: 2186489,
        download: 2186490
    };
    var i = a(36);
    function r(e) {
        console.warn("------新任务---------");
        e.taskStarttime = parseInt(new Date().getTime() / 1e3, 10);
        if (!(e.type === "download" && e.downloadtasktype === 2)) {
            $(G.handler).trigger("client.addTask", e);
        } else {
            var t = e.foldertaskid;
            var a = i.getOneTask(t);
            if (a) {
                if (!a.fileTaskList) {
                    a.fileTaskList = [];
                }
                a.fileTaskList.push(e.id);
            }
        }
        QReport.monitor(n[e.type]);
    }
    e.exports = r;
}, function(e, t, a) {
    "use strict";
    var n = a(35);
    var i = a(8);
    var r = a(4);
    var o = $(G.handler);
    var l = a(122);
    var s = a(113);
    var f = a(9);
    function c(e) {
        var t = n.task2file(e);
        if (!G.file) {
            G.file = {};
        }
        if (G.file && typeof G.file.cu === "undefined") {
            G.file.cu = 0;
        }
        if (e.status === "downloadcomplete") {
            if (e.downloadtasktype !== 2) {
                i.updateRow(t);
            }
            if (t.parentId && t.parentId !== "/") {
                var a = n.getData(t.parentId);
                if (a) {
                    a.downNum++;
                    if (a.downNum === a.filenum) {
                        a.isDown = true;
                        a.succ = true;
                        i.updateRow(a);
                    }
                }
            }
        } else {
            G.file.cu += t.size;
            G.file.capacityused = s.getSize(G.file.cu);
            i.renderSpace();
            if (t.folderpath === G.nowFolder || !t.folderpath) {
                i.appendFile(t);
            } else {
                var f = n.getData(e.folderpath);
                f.filenum++;
                var c = parseInt(new Date().getTime() / 1e3, 10);
                f.mt = c;
                f.mtStr = l.dayStr(c);
                f.toFirst = true;
                i.updateRow(f);
            }
            n.updateAllNum({
                files: [ t ],
                action: "add"
            });
        }
        r.set(t);
        report("showTaskShow");
        console.log("task complete", t);
        o.trigger("client.updateTask", e);
    }
    e.exports = c;
}, function(e, t, a) {
    "use strict";
    var n = $(G.handler);
    function i(e) {
        n.trigger("client.updateTask", e);
    }
    e.exports = i;
}, function(e, t, a) {
    "use strict";
    var n = $(G.handler);
    function i(e) {
        n.trigger("client.updateTask", e);
    }
    e.exports = i;
}, function(e, t, a) {
    "use strict";
    var n = $(G.handler);
    function i(e) {
        e.createtime = parseInt(new Date().getTime() / 1e3, 10);
        if (e.status === "uploadprogress") {
            setTimeout(function() {
                $(G.handler).trigger("box.show", e);
            }, 20);
        }
        if (e.remotetype === 1) {}
        if (e.type === "download") {}
        n.trigger("client.updateTask", e);
    }
    e.exports = i;
}, function(e, t, a) {
    "use strict";
    var n = a(59);
    var i = $(G.handler);
    var r = {
        upload: {
            cancel: 2186633,
            remove: 2186634,
            scanfail: 2186635,
            uploadsecurityfail: 2186636,
            uploadgeturlfail: 2186637,
            uploadfail: 2186491,
            _default: 2186638
        },
        continueupload: {
            cancel: 2186639,
            remove: 2186640,
            scanfail: 2186641,
            uploadsecurityfail: 2186642,
            uploadgeturlfail: 2186643,
            uploadfail: 2186491,
            _default: 2186644
        },
        download: {
            cancel: 2186645,
            remove: 2186646,
            downloadgeturlfail: 2186647,
            downloadfail: 386331,
            _default: 2186648
        }
    };
    function o(e) {
        var t = e.filepath;
        var a = e.localpath;
        var i = e.filename_esc || e.filename;
        var r = e.remotetype;
        n.addContinueUploadTask(t, a, i, r);
    }
    function l(e) {
        i.trigger("client.updateTask", e);
        var t = r[e.type];
        var a = t[e.status];
        if (a) {
            QReport.monitor(a);
        }
        if (e.errorcode || e.securityattri) {
            var n = e.errorcode;
            if (n === 32221991) {
                o(e);
                return;
            } else if (n === 12029) {}
        }
    }
    e.exports = l;
}, function(e, t, a) {
    var n = a(293);
    e.exports = function i(e) {
        var t = [];
        var a = {};
        var n;
        var i = e || {};
        (function(e) {
            t.push('<!--文件夹模板--><div class="whole-row"></div><div class="folder-info"><span class="little-folder-icon"></span><span class="folder-name">' + (null == (n = e.fname) ? "" : n) + "</span></div>");
        }).call(this, "item" in i ? i.item : typeof item !== "undefined" ? item : undefined);
        return t.join("");
    };
}, function(e, t, a) {
    var n = a(293);
    e.exports = function i(e) {
        var t = [];
        var a = {};
        var i;
        var r = e || {};
        (function(e, a) {
            t.push('<!--文件夹树模板--><ul data-action="file_active" role="tree" class="primary-folder-list"><li' + n.attr("data-id", "" + e.id + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"> </div><div class="folder-info"><span class="little-folder-icon"></span><span class="folder-name">' + (null == (i = e.fname) ? "" : i) + '</span><a href="javascript:void(0)"' + n.attr("data-id", "" + e.id + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + n.attr("aria-label", "选择文件夹:" + e.fname + "", true, false) + ' class="aria-hide"></a></div><ul class="secondary-folder-list">');
            (function() {
                var e = a;
                if ("number" == typeof e.length) {
                    for (var r = 0, o = e.length; r < o; r++) {
                        var l = e[r];
                        t.push("<li" + n.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><div class="little-folder-icon"></div><div class="folder-name">' + (null == (i = l && l.fname) ? "" : i) + '</div><a href="javascript:void(0)"' + n.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + n.attr("aria-label", "选择文件夹:" + (l && l.fname) + "", true, false) + ' class="aria-hide"></a></div></li>');
                    }
                } else {
                    var o = 0;
                    for (var r in e) {
                        o++;
                        var l = e[r];
                        t.push("<li" + n.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><div class="little-folder-icon"></div><div class="folder-name">' + (null == (i = l && l.fname) ? "" : i) + '</div><a href="javascript:void(0)"' + n.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + n.attr("aria-label", "选择文件夹:" + (l && l.fname) + "", true, false) + ' class="aria-hide"></a></div></li>');
                    }
                }
            }).call(this);
            t.push("</ul></li></ul>");
        }).call(this, "topFolder" in r ? r.topFolder : typeof topFolder !== "undefined" ? topFolder : undefined, "items" in r ? r.items : typeof items !== "undefined" ? items : undefined);
        return t.join("");
    };
}, function(e, t, a) {
    var n = a(293);
    e.exports = function i(e) {
        var t = [];
        var a = {};
        var n;
        t.push('<li data-id="new" data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><span class="little-folder-icon"></span><input id="inputFolderNameInFolderTree" value="新建文件夹" data-blur="createInputBlur" data-keyup="folderTree.create" autofocus="true" class="folder-name"/><div class="bubble"><span class="bot"></span><span class="top"></span>文件夹名称中含有违禁词</div></div></li>');
        return t.join("");
    };
}, , , , , , , , , , , , , , , , , , function(e, t, a) {
    "use strict";
    t.merge = function r(e, t) {
        if (arguments.length === 1) {
            var a = e[0];
            for (var i = 1; i < e.length; i++) {
                a = r(a, e[i]);
            }
            return a;
        }
        var o = e["class"];
        var l = t["class"];
        if (o || l) {
            o = o || [];
            l = l || [];
            if (!Array.isArray(o)) o = [ o ];
            if (!Array.isArray(l)) l = [ l ];
            e["class"] = o.concat(l).filter(n);
        }
        for (var s in t) {
            if (s != "class") {
                e[s] = t[s];
            }
        }
        return e;
    };
    function n(e) {
        return e != null && e !== "";
    }
    t.joinClasses = i;
    function i(e) {
        return Array.isArray(e) ? e.map(i).filter(n).join(" ") : e;
    }
    t.cls = function o(e, a) {
        var n = [];
        for (var r = 0; r < e.length; r++) {
            if (a && a[r]) {
                n.push(t.escape(i([ e[r] ])));
            } else {
                n.push(i(e[r]));
            }
        }
        var o = i(n);
        if (o.length) {
            return ' class="' + o + '"';
        } else {
            return "";
        }
    };
    t.attr = function l(e, a, n, i) {
        if ("boolean" == typeof a || null == a) {
            if (a) {
                return " " + (i ? e : e + '="' + e + '"');
            } else {
                return "";
            }
        } else if (0 == e.indexOf("data") && "string" != typeof a) {
            return " " + e + "='" + JSON.stringify(a).replace(/'/g, "&apos;") + "'";
        } else if (n) {
            return " " + e + '="' + t.escape(a) + '"';
        } else {
            return " " + e + '="' + a + '"';
        }
    };
    t.attrs = function s(e, a) {
        var n = [];
        var r = Object.keys(e);
        if (r.length) {
            for (var o = 0; o < r.length; ++o) {
                var l = r[o], s = e[l];
                if ("class" == l) {
                    if (s = i(s)) {
                        n.push(" " + l + '="' + s + '"');
                    }
                } else {
                    n.push(t.attr(l, s, false, a));
                }
            }
        }
        return n.join("");
    };
    t.escape = function f(e) {
        var t = String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        if (t === "" + e) return e; else return t;
    };
    t.rethrow = function c(e, t, n, i) {
        if (!(e instanceof Error)) throw e;
        if ((typeof window != "undefined" || !t) && !i) {
            e.message += " on line " + n;
            throw e;
        }
        try {
            i = i || a(!function d() {
                var e = new Error('Cannot find module "fs"');
                e.code = "MODULE_NOT_FOUND";
                throw e;
            }()).readFileSync(t, "utf8");
        } catch (r) {
            c(e, null, n);
        }
        var o = 3, l = i.split("\n"), s = Math.max(n - o, 0), f = Math.min(l.length, n + o);
        var o = l.slice(s, f).map(function(e, t) {
            var a = t + s + 1;
            return (a == n ? "  > " : "    ") + a + "| " + e;
        }).join("\n");
        e.path = t;
        e.message = (t || "Jade") + ":" + n + "\n" + o + "\n\n" + e.message;
        throw e;
    };
}, function(e, t, a) {
    var n = a(241), i = Math.min;
    e.exports = function(e) {
        return e > 0 ? i(n(e), 9007199254740991) : 0;
    };
}, function(e, t, a) {
    var n = a(241), i = Math.max, r = Math.min;
    e.exports = function(e, t) {
        e = n(e);
        return e < 0 ? i(e + t, 0) : r(e, t);
    };
} ]);