(function(e) {
    var t = {};
    function a(i) {
        if (t[i]) return t[i].exports;
        var n = t[i] = {
            exports: {},
            id: i,
            loaded: false
        };
        e[i].call(n.exports, n, n.exports, a);
        n.loaded = true;
        return n.exports;
    }
    a.m = e;
    a.c = t;
    a.p = "//s1.url.cn/qqun/pan/clt_filetab/js/";
    return a(0);
})([ function(e, t, a) {
    "use strict";
    var i = a(25);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    savePoint("start");
    window.G = {};
    G.flagThumb = true;
    G.flagUploadTemp = false;
    G.flagHeightChrome = /chrome\/([2|3]\d)/gi.test(window.navigator.userAgent);
    G.canOpenFolder = window.external && window.external.openFolder;
    G.ifFileExist = window.external && window.external.isFileExist;
    G.flagIsVip = false;
    G.handler = {};
    G.cMap = {};
    G.pList = [];
    G.cList = [];
    G.continueUploadMap = {
        init: false
    };
    G.compList = [];
    G.selectRow = {};
    G.previewCache = {};
    G.activeElement;
    G.oldVersion = false;
    G.filesClass = {};
    G.folderVersion = 5461;
    G.nowFolder = "/";
    G.folderNum = 0;
    G.appid = 4;
    G.canCreateFolder = true;
    G.mac = false;
    G.secondMove = {};
    G.tab = {};
    var o = a(17);
    var l = a(16);
    var s = a(18);
    var f = o.getParameter("debug");
    var d = decodeURIComponent(o.getParameter("webParams"));
    var c = window.external && window.external.CallHummerApi && window.external.CallHummerApi("IM.GetVersion");
    if (c) {
        try {
            c = JSON.parse(c);
            if (c.errorCode === 0) {
                c = c.version;
            }
        } catch (u) {
            c = false;
        }
    }
    G.version = c;
    G.webParams = d;
    G.downFast = window.external && window.external.downloadByXF;
    G.fileMap = function(e) {
        var t = [];
        G.fileMaps = t;
        return function(e) {
            var a = e || G.module();
            t[a] = t[a] || {};
            return t[a];
        };
    }();
    G.folderMap = function() {
        var e = [];
        return function() {
            var t = G.module();
            if (t === 1 || t === 2 || t === 3) {
                t = 0;
            }
            e[t] = e[t] || {};
            return e[t];
        };
    }();
    G.module = function() {
        var e = 0;
        var t = {
            0: "首页",
            1: "文件夹内",
            2: "成员文件列表",
            3: "搜索结果页"
        };
        return function(a) {
            if (a === undefined) {
                return e;
            } else if (t[a]) {
                if (a !== 3) {
                    $("#inputSearch").val("");
                }
                return e = a;
            } else {
                console.log("illegal module");
            }
        };
    }();
    G.checkHttps = function() {
        var e = location.href;
        return e.indexOf("https://") >= 0 ? true : false;
    };
    G.scrollHandler = function() {
        var e = [];
        return function(t) {
            var a = G.module();
            if (t) {
                return e[a] = t;
            } else {
                e[a] = e[a] || function() {};
                e[a]();
            }
        };
    }();
    function p() {
        var e = location.href;
        if (e.indexOf("groupShareClientV2.html") > 0) {
            G.newUi = true;
        }
        if (navigator.userAgent.indexOf("Mac OS X") >= 0) {
            G.mac = true;
            $("#inputSearch").attr("placeholder", "");
            $("#navTopFolder").attr("data-action", "menu.filenum");
            $(".refresh-icon").attr("data-action", "menu.refresh").click(function() {
                window.location.reload();
            });
        } else {
            $("#inputSearch").attr("placeholder", "搜索");
        }
    }
    function v() {
        var e = new Date("2016-3-23");
        var t = new Date("2019-3-23");
        var a = new Date().getTime();
        if (a > e && a < t) {
            return true;
        } else {
            return false;
        }
    }
    function m() {
        var e = a(21);
        var t = a(22);
        var i = a(19);
        var n = a(23);
        var r = a(24);
        var o = a(1);
        var l = a(20);
        p();
        G.info = e.getInfo();
        l.init();
        t.init();
        n.init();
        i.init();
        r.init();
        o.action(d);
        if (localVersion === "isLocal") {
            report("offlinePage");
        }
        var s = __getParameter("timeout");
        if (s === "0") {
            report("httpssuc");
        } else if (s === "1") {
            report("httpsfail");
            if (!v()) {
                report("httptimeerr");
            }
        } else if (s === "") {
            report("oldJump");
        }
        report("httpsall");
        report("expnew");
    }
    function h() {
        if (typeof $ === "function" && (typeof QReport === "undefined" ? "undefined" : (0, 
        n.default)(QReport)) === "object") {
            if (__getParameter("fromiframe") === "1") {
                var e = new Date().getTime();
                window.localStorage.setItem("iframetime", e - startTime);
                try {
                    console.debug(top);
                    top.postMessage("load suc", "http://pan.qun.qq.com/");
                } catch (t) {}
            } else {
                m();
            }
        } else {
            requestAnimationFrame(h);
        }
    }
    h();
}, function(e, t, a) {
    "use strict";
    var i = a(25);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(57);
    var l = a(58);
    var s = a(30);
    var f = a(31);
    G.initInFolder = false;
    var d = function u(e) {
        try {
            G.setHistory({
                action: "fileList",
                params: {
                    fid: "/",
                    fname: false
                }
            });
        } catch (t) {}
        if (e === "") {
            f.init();
        } else {
            try {
                e = JSON.parse(e);
            } catch (t) {
                f.init();
                return;
            }
        }
        if (e.params && e.params.fid) {
            var a = e.params;
            a = (typeof a === "undefined" ? "undefined" : (0, n.default)(a)) === "object" ? a : {};
            var i = a.fid;
            G.initInFolder = i;
            f.init(true);
            f.getList({
                folderId: i,
                fname: a.fname
            });
        } else if (e.action === "search") {
            var r = e.params;
            r = (typeof r === "undefined" ? "undefined" : (0, n.default)(r)) === "object" ? r : {};
            var o = r.keyword;
            $("#inputSearch").val(o);
            var d = r.files[0];
            s.search(undefined, function(e) {
                var t = true;
                var a = false;
                return function() {
                    if (t) {
                        l["file.getAttr"](e, o);
                        t = false;
                    }
                    if (!a) {
                        var i = "#" + ("/" + e["busId"] + e["fileId"]).replace(/\//gi, "-");
                        a = true;
                    }
                };
            }(d));
        } else {
            f.init();
        }
    };
    var c = function p() {
        window.addEventListener("storage", function(e) {
            if (e.key !== "notifyOtherGroup") {
                return;
            }
            var t = {};
            try {
                t = JSON.parse(e.newValue);
            } catch (e) {
                console.log("decode JSON fail");
                return;
            }
            if (t.gc !== G.info.gc) {
                return;
            }
            var a = t.webParams;
            d(a);
        });
    }();
    e.exports = {
        action: d
    };
}, , , , , , , , , , , , , , , function(e, t, a) {
    "use strict";
    a(81);
}, function(e, t, a) {
    "use strict";
    var i = a(37);
    var n = l(i);
    var r = a(25);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    e.exports = function() {
        function e(e) {
            var t = function i(e) {
                if (!e) return e;
                for (;e != unescape(e); ) {
                    e = unescape(e);
                }
                for (var t = [ "<", ">", "'", '"', "%3c", "%3e", "%27", "%22", "%253c", "%253e", "%2527", "%2522" ], a = [ "&#x3c;", "&#x3e;", "&#x27;", "&#x22;", "%26%23x3c%3B", "%26%23x3e%3B", "%26%23x27%3B", "%26%23x22%3B", "%2526%2523x3c%253B", "%2526%2523x3e%253B", "%2526%2523x27%253B", "%2526%2523x22%253B" ], i = 0; i < t.length; i++) {
                    e = e.replace(new RegExp(t[i], "gi"), a[i]);
                }
                return e;
            };
            var a;
            return t((a = document.cookie.match(RegExp("(^|;\\s*)" + e + "=([^;]*)(;|$)"))) ? unescape(a[2]) : null);
        }
        var t = function y() {
            var t = e("uin");
            if (!t) {
                return 0;
            }
            t += "";
            return t.replace(/^[\D0]+/g, "");
        };
        var a = function x(e, t) {
            t = t || location.href;
            var a = new RegExp("(\\?|#|&)" + e + "=([^&^#]*)(&|#|$)"), i = t.match(a);
            return decodeURIComponent(!i ? "" : i[2]);
        };
        var i = function F(e) {
            e += "";
            return e.replace(/^[ 　]*/gi, "");
        };
        var r = function T(e, t) {
            var a = t || 3;
            e += "";
            e = i(e);
            var n = e.match(/[^\x00-\xff]/g) || [];
            var r = e.replace(/[^\x00-\xff]/g, "");
            return parseInt(n.length * a + r.length);
        };
        function l(e, t) {
            var a = 0;
            for (var i = 0; i < e.length; i++) {
                var n = e.charAt(i);
                encodeURI(n).length > 2 ? a += 1 : a += .5;
                if (a >= t) {
                    var r = a == t ? i + 1 : i;
                    return e.substr(0, r);
                    break;
                }
            }
            return e;
        }
        function s(e) {
            var t = 0;
            for (var a = 0; a < e.length; a++) {
                var i = e.charAt(a);
                encodeURI(i).length > 2 ? t += 1 : t += .5;
            }
            return t;
        }
        var f = function $(e, t, a) {
            var i = r(e, 3);
            if (i < t || i > a) {
                return false;
            }
            return true;
        };
        var d = function C(e, t) {
            var t = t || 10;
            var a = r(e);
            var i = t - a;
            return i >= 0 ? i : 0;
        };
        var c = function S(e, t) {};
        window.onerror = function(e, t, a) {};
        function u(e) {
            if (e && e.length > 0) {
                e.addClass("remove-ease");
                setTimeout(function() {
                    e.remove();
                }, 300);
            }
        }
        var p = function M(e, t) {
            return function(a) {
                var i = arguments.length;
                if (t) a = Object(a);
                if (i < 2 || a == null) return a;
                for (var n = 1; n < i; n++) {
                    var r = arguments[n], o = e(r), l = o.length;
                    for (var s = 0; s < l; s++) {
                        var f = o[s];
                        if (!t || a[f] === void 0) a[f] = r[f];
                    }
                }
                return a;
            };
        };
        var v = function D(e) {
            var t = typeof e === "undefined" ? "undefined" : (0, o.default)(e);
            return t === "function" || t === "object" && !!e;
        };
        var m = function R(e) {
            if (!v(e)) return [];
            var t = [];
            for (var a in e) {
                t.push(a);
            }
            return t;
        };
        var h = p(m);
        function g() {
            var e = {};
            var t = (0, n.default)(G.folderMap());
            for (var a = t.length - 1; a >= 0; a--) {
                var i = G.folderMap()[t[a]];
                if (i) {
                    e[i.fnameEsc] = i;
                }
            }
            var r = "新建文件夹";
            var o = 1;
            while (e[r] !== undefined) {
                r = "新建文件夹(" + o + ")";
                o++;
            }
            return r;
        }
        var w = function I(e, t) {
            if (e.length <= 1) {
                return e;
            }
            var a = Math.floor(e.length / 2);
            var i = e.splice(a, 1)[0];
            var n = [];
            var r = [];
            for (var o = 0; o < e.length; o++) {
                if (e[o]) {
                    if (e[o][t] > i[t]) {
                        n.push(e[o]);
                    } else {
                        r.push(e[o]);
                    }
                }
            }
            return I(n, t).concat([ i ], I(r, t));
        };
        function b(e, t) {
            var a = t.map(function(e) {
                return e.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1");
            });
            var i = "(" + a.join("|") + ")";
            var n = e.split(new RegExp(i, "i"));
            return n;
        }
        function _(e, t) {
            for (var a = t.length - 1; a >= 0; a--) {
                t[a] = ("" + t[a]).toUpperCase();
            }
            var i = [];
            for (var n = e.length - 1; n >= 0; n--) {
                if (t.indexOf(e[n].toUpperCase()) !== -1) {
                    i[n] = '<span class="match-word">' + e[n] + "</span>";
                } else {
                    i[n] = e[n];
                }
            }
            return i.join("");
        }
        function k(e, t) {
            var a = b(e, t);
            return _(a, t);
        }
        return {
            getCookie: e,
            getUin: t,
            getParameter: a,
            getLen: r,
            changeLen: d,
            checkLength: f,
            checkLen: c,
            extend: h,
            removeEase: u,
            subString: l,
            quickSortByObjectAttr: w,
            getFolderNameDefault: g,
            heightLight: k
        };
    }();
}, function(e, t, a) {
    "use strict";
    var i = a(97), n = a(17), r = $(G.handler), o;
    var l = a(82);
    var s = {
        fail: "fail",
        wait: "wait",
        suc: "suc",
        alert: "new-alert"
    }, f, d;
    function c(e, t) {
        var a = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
        if (G.mac) {
            if (e === "fail") {
                l.alert(2, "提示", t);
            }
        } else {
            if (!o) {
                var n = {
                    cls: s[e],
                    text: t
                };
                var r = i(n);
                $("body").append(r);
                o = $("#toastDom");
                f = o.find(".toast-icon");
                d = o.find(".toast-message");
            } else {
                f.attr("class", "icons-" + s[e] + " toast-icon");
                d.text(t);
            }
            o.addClass("open");
            o.focus();
            if (a) {
                setTimeout(function() {
                    u();
                }, 2500);
            }
        }
    }
    function u() {
        if (o) {
            o.removeClass("open");
        }
    }
    r.bind("toast.show", function(e, t) {
        if (t && t.type && t.text) {
            c(t.type, t.text, t.autoHide);
        }
    });
    r.bind("toast.hide", function(e, t) {
        u();
    });
    e.exports = {
        show: c,
        hide: u
    };
}, function(e, t, a) {
    "use strict";
    var i = a(51);
    var n = a(52);
    var r = a(53);
    var o = a(54);
    var l = a(22);
    var s = a(55);
    var f = a(82);
    var d = $(G.handler);
    window.client = f;
    function c() {
        for (var e in r) {
            if (r.hasOwnProperty(e)) {
                d.bind("box." + e, r[e]);
            }
        }
    }
    function u() {
        var e = f.getMapLocationPathToRemotePath();
        var t = f.getTaskListAdv();
        var a = l.getClist();
        if (e.status === "ok") {
            for (var i in e.map) {
                var n = e.map[i];
                var r = {
                    filepath: i,
                    localpath: n
                };
                l.set(r);
            }
        }
        G.pList = s.cleanMap(t.map);
        G.compList = a;
        if (G.pList) {
            for (var d = 0, u = G.pList.length; d < u; d++) {
                var p = G.pList[d];
                var v = o.getData(p.filepath);
                if (!v) {
                    p.id = p.filepath;
                    o.addData(p);
                }
            }
        }
        if (G.compList) {
            for (var m = 0, h = G.compList.length; m < h; m++) {
                var g = G.compList[m];
                var w = o.getData(g.filepath);
                if (!w) {
                    g.id = g.filepath;
                    o.addData(g);
                }
            }
        }
        c();
    }
    e.exports = {
        init: u
    };
}, function(e, t, a) {
    "use strict";
    var i = a(56);
    var n = $(G.handler);
    var r = function l(e, t) {
        i.getFileCount(function(a) {
            if (G.file.isFull) {
                $(".icons-upload-1").addClass("disabled");
                $(".icons-new-folder-1").addClass("icons-new-folder-2");
                o();
                try {
                    if (t === "delete") {
                        reportNew("changeHand");
                    } else if (t !== "downloadcomplete") {
                        reportNew("limitOver");
                    }
                } catch (i) {}
            } else {
                $(".icons-upload-1").removeClass("disabled");
                $(".icons-new-folder-1").removeClass("icons-new-folder-2");
                o();
            }
            if (e) {
                location.reload();
            }
        });
    };
    var o = function s(e) {
        try {
            if (G.file.isTooMany) {
                var t = void 0;
                try {
                    if (G.info.isMaster) {
                        t = 2;
                    } else if (G.info.isAdmin) {
                        t = 1;
                    } else {
                        t = 0;
                    }
                    reportNew("showLimit", {
                        ver1: t
                    });
                } catch (e) {}
                $("#alertTips").addClass("not-opacity");
                if (typeof G.info.isMaster === "undefined") {
                    $("#alertTips").html('<div class="more-file-info" aria-label="文件数已超出上限(1500)，无法显示文件夹，请提醒群主或管理员清理。" tabindex="1"><i class="icons-alert"></i>文件数已超出上限(1500)，无法显示文件夹，请提醒群主或管理员清理。</div>');
                } else if (G.info.isMaster) {
                    $("#alertTips").html('<div class="more-file-info" aria-label="文件数已超出上限(1500)，无法显示文件夹。" tabindex="1"><i class="icons-alert"></i>文件数已超出上限(1500)，无法显示文件夹。</div><div class="more-file-tips">请自行清理或<button class="auto-delete-file" data-blur="aria.fmg" data-action="file.autoClear" tabindex="1">自动删除旧文件</button></div>');
                } else if (G.info.isAdmin) {
                    $("#alertTips").html('<div class="more-file-info" aria-label="文件数已超出上限(1500)，无法显示文件夹，请尽快清理。" tabindex="1"><i class="icons-alert"></i>文件数已超出上限(1500)，无法显示文件夹，请尽快清理。</div>');
                }
            } else {
                $("#alertTips").html('<a href="http://kf.qq.com/faq/120511jiYzIJ140828eimiAR.html" target="_blank" data-action="tips.close">【网络正能量倡议书】腾讯呼吁网友共建绿色QQ群 抵制色情、反动等违法信息。</a><div class="close" data-action="tips.close"></div>').removeClass("not-opacity");
            }
        } catch (e) {}
    };
    n.bind("filecount.getrole", o);
    e.exports = {
        init: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(17), n = a(82);
    function r() {
        var e = i.getUin();
        var t = i.getParameter("gid") || i.getParameter("groupid");
        var a = function() {
            var a = "refresh_" + e + "_" + t;
            if (i.getCookie(a) * 1) {
                i.getCookie(a);
                return true;
            }
            return false;
        }();
        if (!/^\d+$/.test(t)) {
            t = parseInt(t, 10);
            if (isNaN(t)) {
                t = "0";
            }
        }
        var r = i.getParameter("visitor");
        var o = r === "1";
        var l = n.getVersion().version;
        var s = {
            uin: parseInt(e),
            gc: parseInt(t),
            isVisitor: o,
            nickName: n.getNickName(e),
            fromRefresh: a,
            version: l
        };
        return s;
    }
    e.exports = {
        getInfo: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = void 0;
    var l = void 0;
    var s = void 0;
    var f = [];
    var d = window.localStorage;
    var c = {};
    function u() {
        if (!o) {
            o = "lp" + G.info.gc + "-" + G.info.uin;
        }
        if (!s) {
            s = "tips" + G.info.gc + "-" + G.info.uin;
        }
        if (!l) {
            l = "clist" + G.info.gc + "-" + G.info.uin;
        }
        return o;
    }
    function p(e) {
        try {
            d.setItem(s, e);
        } catch (t) {
            d.clear();
            d.setItem(s, e);
        }
    }
    function v() {
        return d.getItem(s);
    }
    function m(e) {
        c[e.filepath] = e.localpath;
        f.push(e);
        try {
            d.setItem(o, (0, n.default)(c));
            d.setItem(l, (0, n.default)(f));
        } catch (t) {
            d.clear();
            d.setItem(o, (0, n.default)(c));
            d.setItem(l, (0, n.default)(f));
        }
    }
    function h(e) {
        if (e.orcType === 1) {
            delete c[e.filepath];
        } else {
            delete c[e.id];
        }
        try {
            d.setItem(o, (0, n.default)(c));
        } catch (t) {
            d.clear();
            d.setItem(o, (0, n.default)(c));
        }
    }
    function g(e) {
        return c[e] || false;
    }
    function w(e) {
        var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "push";
        if (t === "push") {
            f.push(e);
        } else if (t === "delete") {
            f = f.filter(function(t) {
                return e.localpath !== t.localpath;
            });
        }
        try {
            d.setItem(l, (0, n.default)(f));
        } catch (a) {
            d.clear();
            d.setItem(l, (0, n.default)(f));
        }
    }
    function b() {
        var e = d.getItem(l);
        if (e === null) {
            return [];
        }
        try {
            return JSON.parse(e);
        } catch (t) {
            return [];
        }
    }
    function _() {
        d.removeItem(l);
    }
    function k() {
        o = u();
        f = b();
        var e = d.getItem(o);
        if (e) {
            c = JSON.parse(e);
        }
    }
    e.exports = {
        set: m,
        remove: h,
        check: g,
        init: k,
        setTips: p,
        getTips: v,
        clearClist: _,
        getClist: b,
        setClist: w
    };
}, function(e, t, a) {
    "use strict";
    var i = a(86);
    var n = l(i);
    var r = a(87);
    var o = l(r);
    function l(e) {
        if (e && e.__esModule) {
            return e;
        } else {
            var t = {};
            if (e != null) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) t[a] = e[a];
                }
            }
            t.default = e;
            return t;
        }
    }
    var s = a(83).getHandlerTasks();
    var f = a(88);
    var d = a(89);
    var c = a(90);
    var u = $(G.handler);
    G.tab = d;
    function p(e) {
        var t = $(this).data("keyup");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function v(e) {
        var t = $(this).data("keydown");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function m(e) {
        var t = $(this).data("blur");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function h(e) {
        var t = $(this).data("hover");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function g() {
        this.inputStart = true;
    }
    function w() {
        var e = this;
        setTimeout(function() {
            e.inputStart = false;
        }, 200);
    }
    function b(e) {
        var t = $(e.target);
        if (t.parents("#box").length === 0 && t.data("action") !== "box.toggle") {
            u.trigger("box.hide");
        }
        $(".error-message").hide();
    }
    function _(e) {
        var t = $(this).data("focus");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this);
            }
        }
    }
    function k(e) {
        var t = $(this).data("action");
        console.log(t);
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this);
            }
            if (t === "openGroupInfoCard") {
                e.stopPropagation();
            }
        } else {
            u.trigger("box.hide");
        }
    }
    function y(e) {
        var t = $(this).data("dbaction");
        if (e.target.nodeName === "INPUT") {
            return;
        }
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this);
            }
        } else {
            u.trigger("box.hide");
        }
    }
    function x() {
        o.init();
        $(document).on("click", "[data-action]", k);
        $(document).on("dblclick", "[data-dbaction]", y);
        $("body").on("click", b);
        $(document).on("keyup", "[data-keyup]", p);
        $(document).on("keydown", "[data-keydown]", v);
        $(document).on("focus", "[data-focus]", _);
        $(document).on("blur", "[data-blur]", m);
        $(document).on("mouseenter", "[data-hover]", h);
        $(document).on("compositionstart", "[data-cstart]", g);
        $(document).on("compositionend", "[data-cend]", w);
        $("body").on("click", function(e) {
            f["menu.hide"](e.target);
            if (G.module() !== 3) {
                s["search:hide"]();
            }
        });
        $(window).on("load", function() {
            $(".scroll-dom").scroll(function() {
                var e = document.querySelector(".scroll-dom").scrollHeight;
                var t = $(".scroll-dom").scrollTop();
                var a = $(".scroll-dom").height();
                var i = 30;
                if (e - (t + a) <= i) {
                    G.scrollHandler && G.scrollHandler.getData();
                }
            });
        });
    }
    e.exports = {
        init: x
    };
}, function(e, t, a) {
    "use strict";
    var i = a(84);
    var n = a(85);
    var r = $(G.handler);
    var o = function f() {
        i.checkVip().done(function(e) {
            if (e && e.vinfo && e.vinfo.supervip) {
                G.flagIsVip = true;
            } else {
                G.flagIsVip = false;
            }
            n.showQQVip();
        }).fail(function(e) {
            n.showQQVip();
        });
    };
    var l = function d() {
        n.show();
        r.trigger("menu.hide");
    };
    var s = function c() {
        report("openVip");
        if (G.activeElement) {
            G.activeElement.focus();
        }
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    e.exports = {
        init: o,
        "vip.show": l,
        "vip.open": s
    };
}, function(e, t, a) {
    "use strict";
    t.__esModule = true;
    var i = a(29);
    var n = s(i);
    var r = a(28);
    var o = s(r);
    var l = typeof o.default === "function" && typeof n.default === "symbol" ? function(e) {
        return typeof e;
    } : function(e) {
        return e && typeof o.default === "function" && e.constructor === o.default && e !== o.default.prototype ? "symbol" : typeof e;
    };
    function s(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    t.default = typeof o.default === "function" && l(n.default) === "symbol" ? function(e) {
        return typeof e === "undefined" ? "undefined" : l(e);
    } : function(e) {
        return e && typeof o.default === "function" && e.constructor === o.default && e !== o.default.prototype ? "symbol" : typeof e === "undefined" ? "undefined" : l(e);
    };
}, function(e, t, a) {
    e.exports = {
        "default": a(92),
        __esModule: true
    };
}, , function(e, t, a) {
    e.exports = {
        "default": a(95),
        __esModule: true
    };
}, function(e, t, a) {
    e.exports = {
        "default": a(94),
        __esModule: true
    };
}, function(e, t, a) {
    "use strict";
    var i = a(31);
    function n(e) {
        if (this.nodeName === "INPUT" && e.keyCode !== 13) {
            return;
        }
        var t = G.searchKeyword = $("#inputSearch").val() || "";
        i.getList({
            keyword: t,
            skey: "searchResult"
        });
    }
    function r() {
        this.classList.add("hover");
    }
    function o() {
        $(".search-action").removeClass("hover");
    }
    e.exports = {
        search: n,
        "search:hover": r,
        "search:hide": o
    };
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = c(i);
    var r = a(157);
    var o = c(r);
    var l = a(158);
    var s = c(l);
    var f = a(88);
    var d = c(f);
    function c(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var u = a(159);
    var p = a(160);
    var v = a(99);
    var m = a(161);
    var h = a(54);
    var g = a(132);
    var w = a(17);
    var b = a(53);
    var _ = a(162);
    var k = $("#fileListDom");
    var y = $("#fileNumText");
    var x = $("#groupSize");
    var F = $("#groupSizeBar");
    var T = a(182);
    var C = $(G.handler);
    var S = location.href;
    var M = void 0;
    M = a(163);
    var D = true;
    var R = void 0;
    G.renderListFuncSingtons = {};
    G.getListFuncSingtons = {};
    G.searchFuncSingtons = {};
    C.bind("file.thumbUpdate", function(e, t) {
        var a = $("#" + t.domid);
        if (a.length && t.previewObj && t.previewObj.url) {
            var i = t.previewObj.url + "&pictype=scaled&size=50*50";
            if (G.checkHttps()) {
                i = i.replace("http://", "");
                i = "https://proxy.qun.qq.com/tx_tls_gate=" + i;
            }
            var n = new Image();
            n.onload = function() {
                a.find(".filev3-pic").css("background-image", 'url("' + i + '")').addClass("thumb");
            };
            n.onerror = function() {
                console.log("缩略图加载失败!", i);
            };
            n.src = i;
            report("imgurl");
        }
    });
    C.bind("file.dataUpdate", function(e, t) {
        var a = $("#" + t.domid);
        if (t.remoteType === 1) {
            a.removeClass("temp");
            a.find(".item-tags").hide();
            a.find(".tmp").remove();
        }
        if (t.newFilePath) {
            a.attr("data-path", t.newFilePath);
        }
        a.find(".file-info .name").text(t.fnameEsc);
    });
    var I = function lt() {
        var e = G.module();
        var t = function r(e) {
            return '<section class="file-list" id="' + e + '"></section>';
        };
        var a = function o() {
            var e = h.getData(G.nowFolder);
            var a = e.domid;
            if (!e && G.nowFolder) {
                a = G.nowFolder.replace(/\//g, "-");
            }
            if (a === "-") {
                a = false;
            }
            if (a) {
                var i = $("#list" + a);
                if (i.length > 0) {
                    return i;
                } else {
                    k.after(t("list" + a));
                    i = $("#list" + a);
                    return i;
                }
            } else {
                return $("#fileListDom");
            }
        };
        var i = function l() {
            var e = $("#searchResult");
            if (e.length > 0) {
                return e;
            } else {
                k.after(t("searchResult"));
                e = $("#searchResult");
                return e;
            }
        };
        var n = function s() {
            var e = $("#userFileDom");
            if (e.length > 0) {
                return e;
            } else {
                k.after(t("userFileDom"));
                e = $("#userFileDom");
                return e;
            }
        };
        $(".file-list").hide();
        switch (e) {
          case 0:
            if (e === 0) {
                k.show();
            }
            return k;
            break;

          case 1:
            return a().show();
            break;

          case 3:
            return i().show();
            break;

          case 2:
            return n().show();
            break;
        }
    };
    var j = function st() {
        var e = G.module();
        var t = function r(e) {
            return '<section class="file-list" id="' + e + '"></section>';
        };
        var a = function o() {
            var e = h.getData(G.nowFolder);
            var a = e.domid;
            if (!e && G.nowFolder) {
                a = G.nowFolder.replace(/\//g, "-");
            }
            if (a === "-") {
                a = false;
            }
            if (a) {
                var i = $("#list" + a);
                if (i.length > 0) {
                    return i;
                } else {
                    k.after(t("list" + a));
                    i = $("#list" + a);
                    return i;
                }
            } else {
                return $("#fileListDom");
            }
        };
        var i = function l() {
            var e = $("#searchResult");
            if (e.length > 0) {
                return e;
            } else {
                k.after(t("searchResult"));
                e = $("#searchResult");
                return e;
            }
        };
        var n = function s() {
            var e = $("#userFileDom");
            if (e.length > 0) {
                return e;
            } else {
                k.after(t("userFileDom"));
                e = $("#userFileDom");
                return e;
            }
        };
        switch (e) {
          case 0:
            return k;
            break;

          case 1:
            return a();
            break;

          case 3:
            return i();
            break;

          case 2:
            return n();
            break;
        }
    };
    G.onlyGetDom = j;
    G.getDomPanel = I;
    function L() {
        Q();
        y.text(G.file.allnum).attr("aria-label", "共" + G.file.allnum + "个文件");
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        F.css("width", e + "%");
        if (G.file.capacityused) {
            x.text(G.file.capacityused + "/" + G.file.capacitytotal);
        } else {
            x.text("未知/未知");
        }
        if (G.nowFolder === "/") {
            $("#fileNum").removeClass("hide");
        }
        if (G.info.isAdmin) {
            $("#createFolder").show();
        }
    }
    var O = 0;
    function P() {
        var e = G.getDomPanel();
        if (!e.find(".list-item").length) {
            var t = v();
            e.html(t);
        }
    }
    function N(e) {
        if (G.nowFolder !== "/") {
            return;
        }
        var t = M({
            list: [ e ]
        });
        if (k.find(".icons-empty").length === 0) {
            k.prepend(t);
        } else {
            k.html(t);
        }
    }
    function E(e) {
        if (e) {
            if (e.domid) {
                var t = e.domid;
                $("#" + t).remove();
            } else if (e.id) {
                var a = e.id;
                $("[data-path=" + a + "]").remove();
            }
        }
        setTimeout(P, 500);
    }
    function A(e) {
        var t = G.getDomPanel();
        if (G.module() === 3 || G.module() === 2) {
            t = $("#fileListDom");
        }
        if (e.folderpath !== "/" && t.attr("id") === "fileListDom") {
            console.debug("----------------------", h.getData(e.folderpath), e.folderpath);
            Y({});
            return;
        }
        console.debug("appendFile:", e);
        var a = t.find(".fold").last();
        var i = M({
            list: [ e ]
        });
        console.debug("file : ", e);
        if (G.info.version < G.folderVersion) {
            if (e.parentId === "/" && G.nowFolder === "/") {
                if (a.length) {
                    a.after(i);
                } else {
                    t.prepend(i);
                }
            }
        } else {
            if (a.length) {
                a.after(i);
            } else if (G.folder !== "/" && t.find(".icons-empty").length === 0) {
                t.prepend(i);
            } else {
                t.html(i);
            }
        }
        T.renderSpace();
    }
    function B(e) {
        var t = e.parentId;
        if (t === "/") {
            var a = "#fileListDom";
            var i = $(a);
            var n = M({
                list: [ e ]
            });
            $("#" + e.domid).remove();
            if (i.find(".fold").length > 0) {
                i.find(".fold").last().after(n);
            } else {
                i.prepend(n);
            }
        }
    }
    function U(e) {
        console.debug("remove:", e);
        if (e) {
            var t = e.domid;
            $("#" + t).remove();
            $("#search" + t).remove();
            w.removeEase($("#" + t));
        }
    }
    function z(e) {
        if (e.orcType === 2) {
            E(e);
        } else {
            U(e);
        }
        var t = G.getDomPanel();
        if (t.find(".list-item").length === 0) {
            P();
        }
    }
    var q = 0;
    var H = 0;
    var Q = function ft() {
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : -1;
        q++;
        if (e !== -1) {
            H = e;
        }
        if (q < 2) {
            return;
        }
        if (!G.info.isAdmin && !H) {
            G.info.canCreateFolder = false;
            $("#createFolder").hide();
        } else {
            G.info.canCreateFolder = true;
        }
    };
    function V(e, t) {
        u.setAllSpace(function(t) {
            W();
            Q(t.all_upload);
            e && e(t);
        }, t);
    }
    function W() {
        if (G.nowFolder !== "/") {
            return;
        }
        x.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        if (G.file.capacitytotal) {
            $("#ariaSpace").attr("aril-label", "已用容量" + G.file.capacityused + "共" + G.file.capacitytotal);
        } else {
            $("#ariaSpace").attr("aril-label", "已用容量未知G,共未知G");
        }
        var e = parseInt(G.file.cu / G.file.ct * 100);
        F.css("width", e + "%");
        $("#fileNum").removeClass("hide");
    }
    function J(e) {
        var t = e || {};
        var a = t.container || "#folderOrSearchResult";
        var i = t.succ;
        var r = t.searchParams || {};
        var o = (0, n.default)(r);
        if (G.searchFuncSingtons[o] == undefined) {
            G.searchFuncSingtons[o] = m.search(r);
        }
        G.searchFuncSingtons[o](function(e) {
            if (G.renderListFuncSingtons[folderId] == undefined) {
                G.renderListFuncSingtons[folderId] = renderList(a);
            }
            G.renderListFuncSingtons[folderId](e);
            i && i(e);
        }, function() {});
    }
    function Y(e) {
        var t = void 0;
        if (e) {
            t = e.folderId || e.ukey || e.skey;
        }
        console.log(G.nowFolder, G.nowUin, e);
        if (!t) {
            return;
        }
        d.default["menu.closeBatch"]();
        if (G.nowFolder !== "/") {
            $("body").addClass("folder-module");
        } else {
            $("body").removeClass("folder-module");
        }
        if (!G.filesClass[t]) {
            if (e.skey) {
                G.filesClass[t] = new s.default(e);
            } else {
                G.filesClass[t] = new o.default(e);
            }
            var a = G.filesClass[t];
            a.getData(true);
            if (t === "/") {
                X();
            }
            if (G.continueUploadMap.init) {
                if (a.appendContinueUpload) {
                    a.appendContinueUpload();
                }
            }
        } else {
            var i = G.filesClass[t];
            if (e.uin) {
                if (e.uin === i.filterUin) {
                    i.setshow();
                } else {
                    i.changeStatus(e);
                }
            } else if (e.skey) {
                i.changeStatus(e);
            } else {
                if (e.sort_by) {
                    i.changeStatus(e);
                } else {
                    i.setshow();
                }
            }
        }
    }
    var X = function dt() {
        var e = {
            filterUin: G.info.uin,
            filterCode: 4
        };
        var t = u.getList(e);
        t(function(e) {
            console.debug(e);
            for (var t in e.clist) {
                var a = e.clist[t];
                if (a.lp.indexOf("/") === 0) {
                    continue;
                }
                if (!G.continueUploadMap[a.parentId]) {
                    G.continueUploadMap[a.parentId] = {};
                }
                G.continueUploadMap[a.parentId][a.filepath] = a;
            }
            G.continueUploadMap.init = true;
            for (var i in G.filesClass) {
                if (G.filesClass[i]) {
                    G.filesClass[i].appendContinueUpload();
                }
            }
        }, function(e) {
            for (var t in G.filesClass) {
                if (G.filesClass[t]) {
                    G.filesClass[t].appendContinueUpload();
                }
            }
        });
    };
    var K = function ct() {
        var e = {};
        var t = {};
        var a = "#fileListDom";
        u.getList(t)();
    };
    function Z(e) {
        Y({
            folderId: "/",
            noShow: e
        });
        if (!G.file || !G.file.ct) {
            V();
        }
    }
    function et(e) {
        var t = function r(t) {
            if (t.length === 0) {
                return;
            }
            var a = t.find(".file-aria-btn");
            if (a.length > 0) {
                if (e.status === "downloadcomplete") {
                    a.attr("aria-label", "打开文件" + e.name + e.suf).attr("data-action", "file.openFolder");
                } else if (e.status === "downloadprogress") {
                    a.attr("aria-label", "文件" + e.name + e.suf + "下载中").removeAttr("data-action");
                } else if (e.status === "downloadready") {
                    a.attr("aria-label", "准备下载文件" + e.name + e.suf).removeAttr("data-action");
                }
            }
            if (e.filepath !== "") {
                t.attr("data-path", e.filepath);
                t.attr("id", e.domid);
            }
            if (e.id) {
                t.attr("data-id", e.taskId);
            }
            t.find(".file-status-action").attr("class", "file-status-action " + e.styles);
            var i = "上传";
            if (e.type != "upload") {
                i = "下载";
            }
            var n = function o() {
                if (e.failedFileList && e.failedFileList.length > 0) {
                    var t = [];
                    for (var a = 0, i = e.failedFileList.length; a < i; a++) {
                        t.push("<p>" + e.failedFileList[a].filename + "</p>");
                    }
                    var n = '<div class="error-message">有' + e.failedFileList.length + "个文件下载失败<br /> " + t.join("") + "</div>";
                    return n;
                } else {
                    return '<div class="error-message">' + e.wording + "</div>";
                }
            };
            if (e.status === "remove" && e.type === "upload") {
                t.remove();
            } else if (e.succ === false && e.isDowning === false) {
                t.removeClass("succ").find(".item-action button").attr("class", "v3-down").attr("data-action", "file.downloadByBtn").attr("aria-label", "下载文件" + e.fname);
            } else if (t.find(".file-status").length > 0) {
                if (e.status === "uploadcomplete" || e.status === "downloadcomplete") {
                    t.addClass("succ");
                    if (e.orcType === 1) {
                        t.find(".file-status").hide();
                        t.find(".item-time .drag-dom").show();
                        t.find(".item-size").attr("title", e.sizeStr);
                        t.find(".item-size span").text(e.sizeStr);
                        t.find(".item-action button").attr("class", "v3-open").attr("title", "在文件夹中打开").attr("data-action", "file.openFolder").attr("aria-label", "在文件夹中打开");
                    } else if (e.orcType === 2) {
                        console.debug("文件夹下载完成!");
                        t.find(".width").css("width", "100%");
                        if (e.failedFileList && e.failedFileList.length > 0) {
                            console.debug("文件夹下载失败!!!");
                            t.find(".file-task-txt").html('下载失败 <span class="show-error" data-action="error:show">详情</span>' + n());
                        } else {
                            t.find(".file-status").hide();
                            t.find(".item-time .drag-dom").show();
                        }
                    }
                } else {
                    t.find(".file-status").attr("class", "file-download file-status " + e.styles);
                    t.find(".width").css("width", e.cPercent + "%");
                    if (e.styles.indexOf("err") > 0) {
                        t.find(".file-task-txt").html(i + '失败 <span class="show-error" data-action="error:show">详情</span>' + n());
                    } else {
                        t.find(".file-task-txt").html("" + e.wording);
                    }
                    if (e.cPercent >= 100 || e.status === "remove") {
                        t.find(".item-time .drag-dom").show();
                        t.find(".item-time .file-status").hide();
                    } else {
                        t.find(".item-time .drag-dom").hide();
                        t.find(".item-time .file-status").show();
                    }
                }
            } else {
                var r = p(e);
                t.find(".item-time .drag-dom").hide();
                t.find(".item-time").append(r);
            }
        };
        var a = e.domid;
        var i = $("#" + a);
        if (i.length === 0) {
            a = "task" + e.taskId;
            i = $("#" + a);
        }
        t(i);
        if (e.orcType === 1) {
            var n = $("#search" + a);
            t(n);
        }
    }
    function tt(e, t) {
        console.debug("updateRow:", e);
        var a = void 0;
        if (e.orcType === 1) {
            a = $('.list-item[data-path="' + e.filepath + '"]');
            if (!a) {
                return;
            }
            if (t === "rename") {
                a.find(".item-name-wrap").attr("title", "" + e.nameEsc + e.suf + "\n创建时间：" + e.ctoStr);
                a.find(".item-name .name").text(e.nameEsc + e.suf);
            }
            if (e.mtoStr) {
                a.find(".item-time").attr("title", "更新时间：" + e.mtoStr);
            }
            a.find(".item-time span").text(e.mtStr);
            a.find(".item-download-times").text(e.down + "次");
        } else {
            a = $("#" + e.domid);
            if (!a) {
                return;
            }
            if (e.toFirst) {
                a.remove();
                N(e);
                return;
            } else {
                a = $("#" + e.domid);
                if (e.filenum) {
                    a.find(".file-size").text(e.filenum + "个文件").attr("title", e.filenum + "个文件");
                }
            }
            a.find(".item-name").attr("title", e.fnameEsc + "\n文件个数：" + e.filenum + "\n创建时间：" + e.ctoStr + "\n创建人：" + e.nick);
            if (e.mtoStr) {
                a.find(".item-time").attr("title", "更新时间：" + e.mtoStr);
            }
            a.find(".item-time span").text(e.mtStr);
        }
        if (e.status === "uploadcomplete" || e.status === "downloadcomplete") {
            a.addClass("succ");
            var i = "打开";
            if (G.mac) {
                i = "";
            }
            a.find(".file-status").attr("tabindex", "3").attr("aria-label", "打开文件" + e.nameEsc + e.suf).attr("data-actioin", "file.openFolder");
        } else if (!e.isDown && !e.isDowning) {
            if (e.orcType === 1) {
                var n = "下载";
                if (G.mac) {
                    n = "";
                }
                a.find(".file-status").attr("tabindex", "3").attr("aria-label", "下载文件" + e.nameEsc + e.suf).attr("data-action", "file.download");
            } else {}
            a.find(".item-time .drag-dom").show();
            a.find(".item-time .file-download").hide();
            a.removeClass("succ");
        } else if (e.isDowning) {
            a.find(".file-status").attr("tabindex", "3").attr("aria-label", "文件" + e.nameEsc + e.suf + "下载中").removeAttr("data-actioin");
        }
    }
    function at(e) {}
    function it(e, t) {
        var a = e.domid;
        if (!a) {
            a = h.getId(e.oldfilepath);
        }
        var i = $("#" + a);
        var n = void 0;
        i.find(".item-time .drag-dom").hide();
        n = '<div class="file-status">正在更新中</div>';
        i.find(".item-time").append(n);
        i.find(".file-icons").addClass("editing");
    }
    function nt(e) {
        var t = h.getData(e.oldfilepath);
        var a = $("#" + t.domid);
        if (a) {
            a.attr("id", e.domid);
            a.attr("data-path", e.filepath);
            a.find(".item-time .drag-dom").attr("title", "更新时间：" + e.mtoStr).show();
            a.find(".item-time .drag-dom span").text(e.mtStr);
            a.find(".file-icons").removeClass("editing");
            a.find(".item-time .file-status").hide();
            if (!e.preview) {
                a.attr("data-dbaction", "file.downloadByDom");
            }
        }
        delete G.editFileList[t.filepath];
        h.remove(e.oldfilepath);
    }
    function rt(e) {
        if (!R) {
            $("body").append('<div class="loader" id="loaderDom"><div class="loading"></div></div>');
            R = $("#loaderDom");
        }
        if (e) {
            R.removeClass("open");
        } else {
            R.addClass("open");
        }
    }
    function ot(e) {
        if (!e || e.status !== "downloadgeturl" && e.status !== "downloadprogress" && e.status !== "downloadcomplete") {
            return;
        }
        var t = h.getData(e.filepath);
        if (e.status === "downloadcomplete") {
            return t.hasCountDownloadTime = false;
        }
        if (!t.hasCountDownloadTime && (e.status === "downloadgeturl" || e.status === "downloadprogress")) {
            if (G.pList.some(function(e) {
                return e.filepath === t.filepath;
            })) {
                return;
            }
            t.hasCountDownloadTime = true;
            t.down++;
            var a = $('.list-item[data-path="' + t.filepath + '"]');
            a.find(".item-download-times").attr("title", "下载次数：" + t.down + "次");
            a.find(".item-download-times").text(t.down + "次");
        }
    }
    e.exports = {
        init: Z,
        appendFold: N,
        removeFold: E,
        appendFile: A,
        appendFileToFolder: B,
        updateRow: tt,
        search: J,
        renderSpace: W,
        removeRow: z,
        getList: Y,
        getRoot: K,
        showLoad: rt,
        updateDownloadRow: et,
        updateEditFileRow: nt,
        fileInEditRow: it,
        getDomPanel: I,
        updateDownloadTimes: ot,
        folderFileList: o.default
    };
}, , , , , , function(e, t, a) {
    e.exports = {
        "default": a(96),
        __esModule: true
    };
}, , , , , , , , , , , , , , function(e, t, a) {
    "use strict";
    var i = a(124), n = a(53), r = a(31);
    function o(e, t) {
        var a = t;
        if (!i.check(a)) {
            i.add(a);
        }
        if (a.type === "download" || a.type === "continueupload") {
            r.updateDownloadRow(a);
        } else {
            r.appendFile(a);
        }
    }
    $(G.handler).bind("client.addTask", o);
}, function(e, t, a) {
    "use strict";
    var i = a(124), n = a(53), r = a(31);
    function o(e, t) {
        var a = t;
        if (a.type === "download") {
            r.updateDownloadTimes(a);
        }
        r.updateDownloadRow(a);
    }
    $(G.handler).bind("client.updateTask", o);
}, function(e, t, a) {
    "use strict";
    var i = a(130);
    var n = a(131);
    var r = a(17);
    var o = $("#boxNum");
    var l = $("#boxListDom");
    var s = $(G.handler);
    var f = false;
    var d = 0;
    var c = true;
    var u = false;
    function p(e, t) {
        var a = void 0;
        if (t) {
            a = l.find('[data-path="' + e + '"]').filter('[data-name="' + t + '"]');
        } else {
            a = l.find('[data-path="' + e + '"]');
        }
        if (a.length > 0 && !a.hasClass("complete")) {
            return a;
        }
        return false;
    }
    function v(e) {
        var t = l.find('[data-id="' + e + '"]');
        if (t.length > 0 && !t.hasClass("complete")) {
            return t;
        }
        return false;
    }
    function m(e) {
        if (e.type === 1 || e.type === "upload") {
            return v(e.taskId);
        } else if (e.orcType === 2) {
            return v(e.taskId);
        } else {
            return p(e.filepath, e.filename);
        }
    }
    function h(e) {
        return;
        var t = m(e);
        if (e.status === "remove") {
            d--;
            r.removeEase(t);
            _();
            return;
        }
        if (t) {
            t.attr("class", "file2 file2-2 " + e.styles);
            if (e.cPercent) {
                t.find(".bar").css("width", e.cPercent + "%");
            }
            var a = t.find(".wording");
            if (e.failedFileList && e.failedFileList.length) {
                a.attr("data-action", "task.openfail");
                var i = n({
                    item: e
                });
                a.html(i);
            } else {
                if (e.wording === "文件过大，仅支持 2GB 以内文件") {
                    e.wording = "文件过大，仅支持2GB以内";
                }
                a.html(e.wording);
            }
            if (e.styleStatus === "complete") {
                t.attr("data-action", "task.openFolder");
            }
        }
        if (e.status === "uploadcomplete" || e.status === "downloadcomplete") {
            $("#boxTitle").attr("class", "box-title tri");
            d--;
            _();
        }
    }
    function g(e) {
        var t = m(e);
        u = true;
        if (t.length > 0) {
            return;
        }
        var a = i({
            list: [ e ]
        });
        f = true;
        d++;
        _();
        l.prepend(a);
        l.removeClass("empty");
    }
    function w(e) {}
    function b(e, t) {}
    function _() {
        return;
        if (d < 0) {
            d = 0;
        }
        if (d) {
            o.text(d).addClass("small");
        } else {
            o.text(d).removeClass("small");
        }
    }
    function k() {
        u = false;
    }
    function y(e, t) {
        var a = i(t);
        if (f) {
            l.append(a);
        } else {
            l.html(a);
        }
    }
    var x = function S(e) {
        var t = [];
        var a = [];
        for (var i = 0, n = e.length; i < n; i++) {
            if ($.inArray(e[i].id, t) < 0 && $.inArray(e[i].filepath, t) < 0) {
                if (e[i].id) {
                    t.push(e[i].id);
                }
                if (e[i].filepath) {
                    t.push(e[i].filepath);
                }
                a.push(e[i]);
            }
        }
        return a;
    };
    function F() {
        if (!c) {
            return;
        }
        c = false;
        var e = [];
        var t = G.pList;
        var a = G.compList;
        var i = x(t);
        var n = e.length;
        e = i;
        if (a) {
            e = i.concat(a);
        }
        e = x(e);
        y(null, {
            list: e
        });
        if (e.length > 0) {
            l.removeClass("empty");
        }
        if (a.length > 0) {
            $("#boxTitle").attr("class", "box-title tri");
        } else {}
    }
    function T() {
        r.removeEase(l.find(".complete"));
        if (G.mac) {
            var e = l.find(".err");
            var t = e.length;
            for (var a = 0; a < t; a++) {
                var i = e.eq(a);
                var n = i.data("id");
                s.trigger("task.removeOne", n);
                r.removeEase(i);
            }
        }
        setTimeout(function() {
            if (l.find(".file2").length === 0) {
                l.addClass("empty");
            }
        }, 500);
        $("#boxTitle").attr("class", "box-title empty");
    }
    function C(e) {
        var t = l.find('[data-path="' + e.filepath + '"]');
        t.find(".go-folder").addClass("disable");
    }
    e.exports = {
        updateBoxRow: h,
        addBoxRow: g,
        removeBoxRow: w,
        cleanBox: b,
        render: y,
        firstRender: F,
        updateBoxNum: _,
        clearComplete: T,
        removePoint: k,
        removeOpenFolder: C
    };
}, function(e, t, a) {
    "use strict";
    var i = a(25);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(126);
    var l = a(129);
    var s = a(171);
    var f = a(124);
    var d = a(172);
    var c = a(17);
    var u = a(55);
    var p = a(22);
    var v = $(G.handler);
    var m = {};
    var h = false;
    var g = $("#groupSize");
    var w = $("#groupSizeBar");
    function b(e) {
        if (e.orcType === 1) {
            var t = G.module() === 1 ? 1 : 0;
            var a = $("#" + e.domid);
            var i = a.attr("idx");
            var n = t;
            if (typeof i !== "undefined") {
                n += "_" + i;
            }
            var r = e.uin === G.info.uin ? 1 : 2;
            return {
                ver1: e.isDown ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: r,
                ver4: encodeURIComponent(e.fname),
                ver5: encodeURIComponent(e.filetype),
                ver6: n
            };
        } else if (e.orcType === 2) {
            var o = 0;
            var l = $("#" + e.domid);
            var s = l.attr("idx");
            var f = o;
            if (typeof s !== "undefined") {
                f += "_" + s;
            }
            var d = G.info.uin === e.uin ? 1 : 2;
            return {
                ver1: e.filenum === e.downNum ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: d,
                ver4: encodeURIComponent(e.name),
                ver5: f
            };
        }
        return false;
    }
    G.getReportInfo = b;
    function _() {
        if (G.nowFolder !== "/") {
            return;
        }
        g.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        w.css("width", e + "%");
        $("#fileNum").removeClass("hide");
    }
    e.exports = m;
    function k(e) {
        e += "";
        return e.replace(/\//gi, "-");
    }
    m.getId = k;
    m.updateFile = function(e, t) {
        if (t === "rename" && e) {
            e.mt = Math.ceil(new Date().getTime() / 1e3);
            e.mtStr = l.getDateStr(e.mt);
            e.mtoStr = l.getorcDateStr(e.mt);
        }
        if (t === "permanent" && e) {
            delete G.fileMap()[e.filepath];
            if (e.id) {
                delete G.fileMap()[e.id];
            }
            G.fileMap()[e.newFilePath] = e;
            e.filepath = e.newFilePath;
        }
    };
    m.updateFolder = function(e) {
        delete G.folderMap()[e.id];
        e.modify_time = Math.ceil(new Date().getTime() / 1e3);
        e.mt = e.modify_time;
        e.mtStr = l.getDateStr(e.modify_time);
        e.mtoStr = l.getorcDateStr(e.modify_time);
        G.folderMap()[e.id] = e;
        return e;
    };
    m.filterFolder = function(e) {
        var t = {
            fname: e.name,
            fnameEsc: s.decode(e.name),
            name: e.name,
            id: e.id,
            icon: "folder",
            ct: e.create_time,
            ctStr: l.getDateStr(e.create_time),
            ctoStr: l.getorcDateStr(e.create_time),
            mt: e.modify_time,
            mtStr: l.getDateStr(e.modify_time),
            mtoStr: l.getorcDateStr(e.modify_time),
            uin: e.owner_uin || G.info.uin,
            filenum: e.size,
            nick: e.owner_name || G.info.nickName,
            mnick: e.modify_name || G.info.nickName,
            muin: e.modify_uin || G.info.uin,
            orcType: e.type || 2,
            domid: k(e.id),
            downNum: 0
        };
        var a = p.check(t.id);
        if (a) {
            t.localpath = a;
            t.succ = true;
        }
        return t;
    };
    m.addData = function(e) {
        if (!e) {
            return;
        }
        if (e.orcType === 2) {
            G.folderMap()[e.id] = e;
        } else {
            G.fileMap()[e.filepath] = e;
        }
    };
    m.getData = function(e) {
        return G.folderMap()[e] || G.fileMap()[e] || false;
    };
    m.remove = function(e) {
        if (G.folderMap()[e]) {
            delete G.folderMap()[e];
        }
        var t = G.fileMap()[e];
        if (t) {
            t.isRemoved = true;
            delete G.fileMap()[e];
            delete G.fileMap()[t.filepath];
        }
    };
    m.getFile = function(e, t) {
        return G.fileMap()[e] || G.fileMap()[t] || false;
    };
    m.getTask = function(e) {
        return G.cMap[e] || false;
    };
    m.setAllNum = function(e) {
        var t = "total_cnt";
        if (!G.file) {
            G.file = {};
        }
        if (G.module() === 0) {
            G.file.allnum = e.total || 0;
        }
    };
    m.setFileCount = function(e) {
        if (!G.file) {
            G.file = {};
        }
        G.file.fileCount = e.file_count || 0;
        G.file.isTooMany = e.is_too_many;
        G.file.isFull = e.is_full;
    };
    m.setAllSpace = function R(e) {
        if (!G.file) {
            G.file = {};
        }
        G.file.capacitytotal = o.getSize(e.totalSpace);
        G.file.capacityused = o.getSize(e.usedSpace);
        G.file.ct = e.totalSpace;
        G.file.cu = e.usedSpace;
    };
    m.removeAllNum = function(e) {
        if (G.file.allnum) {
            G.file.allnum--;
        }
        if (e.remoteType === 1) {
            G.file.cu -= e.size;
            G.file.capacityused = o.getSize(G.file.cu);
        }
    };
    m.addAllNum = function(e) {};
    m.updateAllNum = function(e) {
        var t = {
            files: [],
            action: ""
        };
        e = c.extend(t, e);
        var a = e.action;
        var i = e.files;
        var n = 0;
        for (var r = i.length - 1; r >= 0; r--) {
            n += i[r].size;
        }
        if (a === "add") {
            G.file.allnum = G.file.allnum + i.length;
            G.file.cu += n;
        } else if (a === "remove") {
            G.file.allnum = G.file.allnum - i.length;
            G.file.cu -= n;
        } else {
            console.log("illegal action");
        }
        _();
    };
    m.setRole = function(e) {
        if (h) {
            return;
        }
        h = true;
        var t = e.userRole || 0;
        var a = e.openFlag || 0;
        var i = 0;
        var n = 0;
        var r = false;
        var o = e.userRole === 3 ? true : false;
        if (t >= 1 && t !== 4) {
            i = 1;
            t === 1 && (n = 1);
            r = true;
        } else if (t === 3 && a === 1) {
            o = true;
        }
        G.info.isAdmin = i;
        G.info.isMaster = n;
        G.info.isVisitor = o;
        G.info.isPublic = a;
        v.trigger("filecount.getrole");
        G.canCreateFolder = r;
        report("enter", a);
        report("showSearchBtn");
        $("body").addClass("auth" + G.info.isAdmin);
    };
    function y(e) {
        var t = {};
        for (var a in e) {
            t[a] = e[a];
        }
        return t;
    }
    m.task2file = function(e) {
        var t = e;
        var a = t.filepath.substr(1, 3);
        a = parseInt(a);
        var i = parseInt(new Date().getTime() / 1e3, 10);
        var n = o.getFileName(t.filename);
        if (t.status !== "downloadcomplete") {
            t.name = n.filename_name;
            t.fname = t.filename;
            t.fnameEsc = s.decode(t.filename);
            t.nameEsc = s.decode(n.filename_name);
            t.folderid = k(t.folderpath);
            t.down = 0;
            t.filepath = t.filepath;
            t.fp = t.filepath.substr(4);
            t.domid = k(t.filepath);
            t.busid = a;
            t.filetype = o.getType(n.filename_suf);
            t.uin = G.info.uin;
            t.nick = G.info.nickName;
            t.upsize = t.filesize;
            t.temp = a == 102 ? false : true;
            t.ttl = 86400;
            t.ct = i;
            t.ctStr = l.dayStr(i);
            t.ctoStr = l.getorcDateStr(i);
            t.mt = i;
            t.mtStr = l.getDateStr(i);
            t.mtoStr = l.getorcDateStr(i);
            t.type = 1;
            t.succ = true;
            t.admin = true;
            t.isDown = true;
            t.remove = true;
            t.rename = true;
            t.size = t.size;
            t.canEdit = o.canEdit(t.filetype, t.admin);
            t.remoteType = a === 102 ? 1 : 2;
            t.parentId = t.folderpath || "/";
        } else {
            var r = void 0;
            var f = t.id;
            if (t.downloadtasktype === 1) {
                r = y(G.folderMap()[t.filepath]);
            } else {
                r = y(G.fileMap()[t.filepath]);
            }
            t = $.extend(true, r, t);
            t.taskId = f;
            t.isDown = true;
            t.succ = true;
            t.domid = k(t.filepath);
        }
        if (G.cMap[t.id]) {
            delete G.cMap[t.id];
        }
        if (G.cMap[t.filepath]) {
            delete G.cMap[t.filepath];
        }
        if (t.orcType === 2) {
            t.id = t.filepath;
        }
        m.addData(t);
        return t;
    };
    m.setFileList = function(e, t, a) {
        console.log(e);
        var i;
        if (typeof a === "number") {
            i = a;
        }
        if (!G.cMap) {
            G.cMap = {};
        }
        var n = [];
        var r = [];
        var u = [];
        var h = [];
        t = c.extend({
            fn: "name",
            t: "bus_id",
            uin: "owner_uin",
            dt: "download_times",
            ut: "create_time",
            mt: "modify_time",
            lp: "local_path",
            ufs: "upload_size",
            fp: "id",
            fs: "size",
            owner_name: "owner_name"
        }, t);
        var g = t.fn;
        var w = t.t;
        var b = t.uin;
        var _ = t.dt;
        var y = t.ut;
        var F = t.mt;
        var T = t.lp;
        var C = t.ufs;
        var S = t.fp;
        var D = t.fs;
        var R = t.owner_name;
        e = e || [];
        for (var I = 0, j = e.length; I < j; I++) {
            var L = e[I];
            if (L.type === undefined) {
                L.type = 1;
            }
            if (L.type === 1) {
                var O = o.getFileName(L[g]);
                var P = {
                    t: L[w],
                    exp: L.exp || 0,
                    lp: L[T],
                    busid: L[w],
                    fname: L[g],
                    fnameEsc: s.decode(L[g]),
                    name: O.filename_name,
                    nameEsc: s.decode(O.filename_name),
                    suf: O.filename_suf,
                    icon: o.getIcon(O.filename_suf),
                    domid: k("/" + L[w] + L[S]),
                    filepath: "/" + L[w] + L[S],
                    fp: L[S],
                    admin: false,
                    filetype: o.getType(O.filename_suf),
                    uin: L[b],
                    nick: L[R],
                    size: L[D],
                    sizeStr: o.getSize(L[D]),
                    upsize: L[C],
                    temp: L[w] === 104 ? true : false,
                    down: L[_],
                    ct: L[y],
                    ctStr: l.dayStr(L[y]),
                    ctoStr: l.getorcDateStr(L[y]),
                    mt: L[F],
                    parentId: L["parent_id"],
                    mtStr: l.dayStr(L[F]),
                    mtoStr: l.getorcDateStr(L[F]),
                    orcType: L.type,
                    md5: L.md5,
                    safeType: L["safe_type"],
                    remove: false,
                    rename: false,
                    isDown: false
                };
                if (L.gc) {
                    P.gc = L.gc;
                }
                if (L.group_name) {
                    P.gname = L.group_name;
                }
                P.admin = x(L[b]);
                if (P.admin) {
                    P.remove = true;
                    P.rename = true;
                }
                P.canEdit = o.canEdit(P.filetype, P.admin);
                P = M(P);
                var N = p.check(P.filepath);
                if (N) {
                    P.isDown = true;
                    P.localpath = N;
                    P.succ = true;
                    report("showOpenFile", G.module(), 1);
                } else {
                    report("showDownloadBtn", G.module(), 1);
                }
                reportNew("newFileShow", {
                    ver1: P.isDown ? 1 : 2,
                    ver2: G.info.isAdmin ? 1 : 2
                });
                if (P.safeType) {
                    var E = G.getReportInfo(P);
                    E.ver3 = E.ver4;
                    E.ver4 = E.ver5;
                    E.ver5 = E.ver6;
                    delete E.ver6;
                    reportNew("blackExp", E);
                }
                if (P.result === 3 && !G.previewCache[P.filepath]) {
                    n.push(P);
                }
                if (G.previewCache[P.filepath]) {
                    P.previewObj = G.previewCache[P.filepath];
                }
                if (G.fileMap(i)[P.filepath]) {
                    P = $.extend(G.fileMap(i)[P.filepath], P);
                    G.fileMap(i)[P.filepath] = P;
                } else {
                    G.fileMap(i)[P.filepath] = P;
                }
                if (L[D] === L[C]) {
                    r.push(P);
                } else if (L[b] === G.info.uin) {
                    f.add(P);
                    u.push(P);
                }
            } else {
                var A = m.filterFolder(L);
                G.folderNum++;
                m.addData(A);
                h.push(A);
                reportNew("folderShow", {
                    ver1: A.downNum === A.fileNum ? 1 : 2,
                    ver2: G.info.isAdmin ? 1 : 2
                });
                report("showOpenFile", G.module(), 1);
            }
        }
        G.topFolder = {
            fname: "群文件",
            fnameEsc: "群文件",
            id: "/",
            icon: "folder",
            mt: 0,
            mtStr: 0,
            uin: 0,
            filenum: 0,
            nick: 0,
            type: 2
        };
        if (u.length > 0) {
            G.cList = u;
            v.trigger("box.renderNum");
        }
        if (n.length > 0) {
            d.getThumb(n);
        }
        if (h.length > 0) {
            report("folderNum", G.module(), h.length);
        }
        report("showSeeBtn", G.module());
        return {
            file: r,
            clist: u,
            folder: h
        };
    };
    function x(e) {
        if (G.info.isAdmin || e === G.info.uin) {
            return true;
        } else {
            return false;
        }
    }
    function F(e) {
        if (G.info.isAdmin || e === G.info.uin) {
            return true;
        } else {
            return false;
        }
    }
    function T() {
        return !G.info.isVisitor;
    }
    var C = 1;
    var S = 2;
    function M(e) {
        var t = 0;
        if (!e || typeof e.name === "undefined") {
            console.log(!e, !e.name);
            return;
        }
        if (e.filepath) {
            e.filepath = e.filepath.replace(/\\\//g, "/");
        }
        if (!e.remoteType) {
            switch (e.busid) {
              case 102:
                e.remoteType = C;
                break;

              case 104:
              case 105:
                e.remoteType = S;
                break;

              default:
                e.remoteType = C;
            }
        }
        if (e.lp) {
            if (G.mac) {
                e.localpath = s.decode(e.lp);
            } else {
                e.localpath = s.decode(e.lp).replace(/\\|\//g, "\\\\");
            }
        }
        if (e.upsize < e.size) {
            if (e.uin === G.info.uin) {
                e.type = "continueupload";
                e.status = "continue";
                e.canContinueUpload = true;
                e.taskStarttime = e.ct;
                e.styles = "upload pause";
                e.csize = e.upsize;
                e.csizeStr = o.getSize(e.upsize);
                e.cPercent = 0;
                if (e.upsize && e.size) {
                    e.cPercent = 100 * e.upsize / e.size;
                }
                e.notComplete = true;
                e.result = 1;
                u.parse(e);
            }
        } else {
            e.result = 2;
            if (e.auditflag > 0) {
                console.warn("auditFlag", e);
            }
            var a = e.name;
            var i = e.size;
            var n = e.ct;
            if (!e.down) {
                e.down = 0;
            }
            if (e.filetype === "图片") {
                e.result = 3;
                if (!G.info.isVisitor) {
                    e.preview = true;
                }
            }
            if (e.remoteType === S && e.isAdmin) {
                e.canForever = true;
            }
            var r = 0;
            if (i < 1024 * 100) {
                r = 5;
            } else if (i < 1024 * 1024) {
                r = 4;
            } else if (i < 1024 * 1024 * 10) {
                r = 3;
            } else if (i < 1024 * 1024 * 50) {
                r = 2;
            } else if (i < 1024 * 1024 * 100) {
                r = 1;
            }
            var l = [];
            if (e.isAdmin) {
                e.canDelete = true;
                e.canRename = true;
                l.push("can_delete=1 ");
                l.push("can_rename=1 ");
            }
            if (e.preview) {
                l.push("can_preview=1 ");
            }
            if (e.canForever) {
                l.push("can_forever=1 ");
            }
            e.canDo = l.join("");
            e.showMore = "";
            if (e.canDo === "") {
                e.showMore = "disable_more";
            }
            e.sizeType = r;
            if (!e.styleTemp) {
                e.styleTemp = "";
            }
            if (!e.styleIssucc) {
                e.styleIssucc = "";
            }
            e.expireStr = "";
            e.fileTitle = e.filename;
            if (e.remotetype === S) {
                e.styleTemp = "temp";
                e.expireStr = c.getExpriesDayNum(e.ttl) + "天后到期";
                e.fileTitle += " (临时文件：剩余" + data.getExpriesDayNum(e.ttl) + "天)";
            }
        }
        return e;
    }
    var D = function() {
        var e = window.external && window.external.getPreviewSuffixConfig && window.external.getPreviewSuffixConfig();
        if (e === null) {
            e = {
                content: []
            };
        }
        if (typeof e === "string") {
            try {
                e = JSON.parse(e);
            } catch (t) {}
        }
        if ((typeof e === "undefined" ? "undefined" : (0, n.default)(e)) !== "object") {
            e = {
                content: []
            };
        }
        var a = {};
        if (e = e.content) {
            var i = function l(t, i) {
                var n = e[t].suffix, r = e[t].maxsize;
                var o = n.split(".");
                o.forEach(function(e, t, i) {
                    if (e) {
                        a[e] = r;
                    }
                });
            };
            for (var r = 0, o = e.length; r < o; r++) {
                i(r, o);
            }
        }
        return function(e, t) {
            var i = void 0;
            if ((i = a[e]) && t <= i) {
                return true;
            }
        };
    }();
    m.clearComplete = function() {
        f.clearComplete();
    };
}, function(e, t, a) {
    "use strict";
    var i = a(126);
    var n = a(127);
    var r = a(128);
    var o = a(129);
    var l = {};
    var s = {};
    function f(e) {
        try {
            if (!e) {
                return;
            }
            if (!G.cMap) {
                G.cMap = {};
            }
            e.taskId = e.id;
            if (e.taskId) {
                G.cMap[e.taskId] = e;
            }
            if (e.filepath) {
                G.cMap[e.filepath] = e;
            }
            var t = n.getType(e.type);
            n.check(t, e.status);
            var a = "";
            var i = n.getClass(t, e.status);
            if (i.indexOf("err") >= 0) {
                a = n.getWord(t, e.status);
            }
            if (i === "scan") {
                if (e.cPercent) {
                    a += e.cPercent + "%";
                }
                e.cPercent = 0;
                i = "pre";
            } else if (i === "pre") {
                e.cPercent = 0;
            } else if (i === "pause" || i === "continue") {
                if (e.csizeStr) {
                    a += e.csizeStr;
                }
                if (e.sizeStr) {
                    a += "/" + e.sizeStr;
                }
            } else if (i === "err") {
                e.cPercent = 0;
                if (e.status.indexOf("securityfail") >= 0) {
                    a = getErrorWording(e);
                    if (e.securityattri >= 1 && e.securityattri <= 5) {}
                } else {
                    if (e.errorcode == -1e3) {
                        a = "该文件已被删除";
                    }
                }
            } else if (i === "progress") {
                if (e.speedStr) {
                    a += e.speedStr;
                }
                var r = void 0;
                if (e.speed) {
                    var l = Math.ceil((e.filesize - e.completesize) / e.speed);
                    var s = Math.floor(l / 3600);
                    var f = Math.floor(l % 3600 / 60);
                    l = Math.floor(l % 60);
                    if (s < 10) {
                        s = "0" + s;
                    }
                    if (f < 10) {
                        f = "0" + f;
                    }
                    if (l < 10) {
                        l = "0" + l;
                    }
                    r = "<span class='lefttime'>" + s + ":" + f + ":" + l + "</span>";
                } else {}
            } else if (i === "complete") {
                e.cPercent = 100;
                a += e.sizeStr;
            } else {
                e.c_percent = 0;
            }
            if (a === "") {
                a = "&nbsp;";
            }
            var d = parseInt(new Date().getTime() / 1e3, 10);
            if (t !== "download") {
                e.ctStr = o.dayStr(d);
            }
            if (typeof e.errorcode !== "undefined" && e.errorcode !== 0) {
                if (e.type === "download") {
                    a = e.clientwording;
                } else {
                    a = e.clientwording;
                }
            }
            if (typeof e.remoteresult === "number" && e.remoteresult !== 0) {
                i = "err";
            }
            e.wording = a;
            e.styleType = t;
            if (t === "continueupload") {
                e.styleType = "upload";
            }
            e.styleStatus = i;
            if (e.failedFileList && e.failedFileList.length > 0) {
                e.styles = e.styleType + " " + e.styleStatus + " err";
            } else {
                e.styles = e.styleType + " " + e.styleStatus;
            }
        } catch (c) {
            console.warn("parse", c, e);
        }
    }
    function d(e) {
        e.taskId = e.id;
        if (e.downloadtasktype === 1) {
            e.filepath = e.folderpath;
            e.orcType = 2;
            e.icon = "folder";
            if (G.mac) {
                e.name = e.filename;
            } else {
                e.name = i.getFolderName(e.localpath);
            }
            e.filename = e.name;
            e.filelist = [];
            if (!e.status) {
                e.status = "downloadprogress";
            }
            if (e.filepath) {
                e.domid = "" + e.filepath.replace(/\//gi, "-");
            } else {
                e.domid = "task" + e.id;
            }
            e.filesize = e.foldersize;
        } else {
            e.orcType = 1;
            if (e.filepath) {
                e.domid = "" + e.filepath.replace(/\//gi, "-");
            } else {
                e.domid = "task" + e.id;
            }
        }
        if (e.type === "upload") {
            e.down = 0;
            e.mtStr = "刚刚";
            e.nick = G.info.nickName;
        }
        e.speedStr = "";
        e.wording = "";
        e.csizeStr = "";
        e.updateFlag = true;
        var t = e.filename;
        var a = e.filesize;
        var n = e.createtime;
        e.speedStr = i.getSize(e.speed);
        if (e.speedStr === 0) {
            e.speedStr = "";
        } else {
            e.speedStr += "/S";
        }
        if (e.size === undefined) {
            e.size = e.completesize;
        }
        e.sizeStr = i.getSize(a);
        e.csizeStr = i.getSize(e.completesize);
        var r = 0;
        if (e.completesize > 0 && e.filesize > 0) {
            r = Math.round(e.completesize * 100 / e.filesize);
        }
        e.cPercent = r;
        var o = t.lastIndexOf(".");
        if (o >= 0) {
            e.name = t.substr(0, o);
            e.suf = t.substr(o);
        } else {
            e.name = t;
            e.suf = "";
        }
        if (!e.icon) {
            e.icon = i.getIcon(e.suf);
        }
        f(e);
        return e;
    }
    function c(e) {
        var t = [];
        for (var a in e) {
            var i = e[a];
            i = d(i);
            if (i.downloadtasktype !== 2) {
                t.push(i);
            } else {
                var n = p(i.fordertaskid);
                if (n) {
                    if (!n.fileTaskList) {
                        n.fileTaskList = [];
                    }
                    n.fileTaskList.push(i.id);
                }
            }
        }
        return t;
    }
    function u(e) {
        var t = [];
        for (var a in G.cMap) {
            var i = G.cMap[a];
            if (i.foldertaskid === e || i.folderpath === e) {
                t.push(i);
            }
        }
        return t;
    }
    function p(e) {
        return G.cMap[e] || false;
    }
    e.exports = {
        get: d,
        getFolderTask: u,
        getOneTask: p,
        parse: f,
        cleanMap: c
    };
}, function(e, t, a) {
    "use strict";
    var i = a(84);
    var n = a(54);
    var r = {};
    e.exports = r;
    r.getFileCount = function(e, t) {
        i.getFileCount().done(function(t) {
            n.setFileCount(t);
            e(t);
        }).fail(function(e) {
            console.log(e);
        });
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#folderPanel");
    var n = a(180);
    var r = a(149);
    var o = a(150);
    var l = a(151);
    var s = a(152);
    var f = a(153);
    var d = a(154);
    var c = a(155);
    var u = a(17);
    var p = a(178);
    var v = $(G.handler);
    var m = a(156);
    var h = a(18);
    function g() {}
    function w() {
        report("clkCreateFolder");
        if (G.file.isFull) {
            reportNew("limitTip", {
                ver1: 1
            });
            return h.show("alert", "文件数已达到上限");
        }
        if (this.nodeName === "LI") {
            reportNew("blankRightMenuClick", {
                ver1: G.customMenuLength ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: 2
            });
        }
        if (!G.canCreateFolder) {
            v.trigger("toast.show", {
                type: "new-alert",
                text: "文件夹个数已达上限"
            });
            return;
        }
        n.show(i, {
            title: "新建文件夹",
            tips: "请输入文件夹名称",
            showValue: u.getFolderNameDefault(),
            action: "folder.createFolder"
        });
        $(".new-name").focus();
    }
    function b(e) {
        report("renameFolder");
        if (G.selectRow) {
            var t = G.getReportInfo(G.selectRow);
            t.ver3 = 4;
            reportNew("folderRightMenuClick", t);
        }
        n.show(i, {
            title: "重命名",
            tips: "请输入文件夹的新名称",
            action: "folder.renameFolder",
            showValue: G.selectRow.fnameEsc
        });
    }
    function _() {
        n.hide(i);
        if (G.activeElement) {
            G.activeElement.focus();
        }
    }
    function k() {}
    function y() {}
    function y() {
        i.find(".btn-ok").attr("data-action", "folder.createOK");
    }
    function x() {
        if (event && event.keyCode !== 13) {
            m["input.keyup"].call(this, event);
            return;
        }
        var e = $('[data-keyup="folderTree.create"]');
        if (!e.length) {
            callback && callback();
            return;
        }
        var t = e.val();
        var a = m.folderName(t);
        if (!a) {
            return;
        }
        r.createFolder();
    }
    e.exports = {
        "folder.openfolder": p.openByFolder,
        "folder.property": f.show,
        "folder.create": w,
        "folder.panelhide": _,
        "folder.show": k,
        "folder.showmove": y,
        "folder.toDelete": y,
        "folder.createFolder": r.createFolder,
        "folder.deleteFolder": o.deleteFolder,
        "folder.renameFolder": l.renameFolder,
        "folder.showDeleteFolder": o.showDeleteFolder,
        "folder.showRenameFolder": b,
        "folder.open": d.renderFolder,
        "folder.openroot": d.renderRootFolder,
        "folder.download": s.download,
        "folder.downloadByBtn": s.downloadByBtn,
        "input.createFolder": x
    };
}, function(e, t, a) {
    "use strict";
    var i = a(133);
    var n = a(134);
    var r = l(n);
    var o = a(135);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = a(136);
    var f = a(178);
    var d = a(137);
    var c = a(138);
    var u = a(139);
    var p = a(140);
    var v = a(141);
    var m = a(142);
    var h = a(143);
    var g = a(132);
    var w = a(144);
    var b = a(145);
    var _ = a(146);
    var k = a(147);
    var y = a(148);
    var x = a(54);
    function F() {
        var e = $(this).parents(".list-item");
        var t = e.data("path");
        var a = void 0;
        var i = e.attr("idx");
        G.nowIdx = parseInt(i);
        var n = x.getData(t);
        if (n.orcType === 2) {
            a = "fold";
        } else if (n.orcType == 1) {
            a = "file";
        }
        G.selectRow = n || {};
        G.selectRow.path = t;
        G.selectRow.type = a;
        G.selectRows = [ G.selectRow ];
    }
    e.exports = {
        "file.batchDelete": w.remove,
        "batch.removeAction": w.removeAction,
        "file.batchMove": w.move,
        "file.batchDownload": w.down,
        "batch.downloadAction": w.downloadAction,
        "file.batchSaveAs": w.save,
        "file.selectAll": g.selectAll,
        "file.select": g.select,
        "file.check": g.check,
        "file.exitBatch": g.exit,
        "file.upload": s.upload,
        "file.batchUpload": s.bupload,
        "file.openFolder": f.openByPath,
        "file.openFolderInBox": f.openByMenu,
        "file.showRename": d.showFileRename,
        "file.renameFile": d.renameFile,
        "file.saveAs": b.save,
        "file.download": c.download,
        "file.downloadByDom": c.downloadByDom,
        "file.downloadByMenu": c.downloadByMenu,
        "file.downloadByBtn": c.downloadByBtn,
        "file.downloadBatch": c.downloadBatch,
        "file.preview": v.preview,
        "file.menupreview": v.menupreview,
        "file.jubao": h,
        "file.permanent": k,
        "file.delete": p.removeOne,
        "file.deleteBatch": p.removeBatch,
        "file.forward": u.forward,
        "file.forwardMobile": u.toMobile,
        "file.showUpload": s.showUpload,
        "file.showMove": m.showMove,
        "file.secondMove": m.secondMove,
        "file.move": m.move,
        "upload.noTips": s.noTips,
        "upload.cUpload": s.cupload,
        "file.getByUin": _.byUin,
        "file.getAttr": y,
        "qq.update": s.update,
        "file.aria": F,
        "file.sort": o.sortFile,
        "file.autoClear": i.clickClearFile,
        "file.doClearFile": i.doClearFile,
        "error:show": r.default
    };
}, , , , , , , , , , , , , , , , , , , , , , , function(e, t, a) {
    (function(e) {
        "use strict";
        var t = a(26);
        var i = n(t);
        function n(e) {
            return e && e.__esModule ? e : {
                "default": e
            };
        }
        var r = a(17);
        var o = a(185);
        var l = {
            enter: {
                monitor: 2057388,
                mac: 2162523,
                tdw: [ "home", "exp" ]
            },
            clkGroupFile: {
                monitor: 2057389,
                tdw: [ "home", "Clk_grpfiles" ]
            },
            clkFiles: {
                monitor: 2057390,
                tdw: [ "home", "Clk_files" ]
            },
            openVip: {
                monitor: 2057391,
                tdw: [ "home", "Clk_open" ]
            },
            clkFeed: {
                monitor: 2057392,
                tdw: [ "home", "Clk_feed" ]
            },
            clkRefresh: {
                monitor: 2057393,
                tdw: [ "home", "Clk_refresh" ]
            },
            forward: {
                monitor: 0,
                tdw: [ "home", "Clk_towards_mac" ]
            },
            back: {
                monitor: 0,
                tdw: [ "home", "Clk_back" ]
            },
            folder: {
                monitor: 2057394,
                tdw: [ "file", "exp" ]
            },
            propFolder: {
                monitor: 2057401,
                tdw: [ "file", "Clk_property" ]
            },
            folderBtnShow: {
                monitor: 2057396,
                tdw: [ "file", "exp_create" ]
            },
            clkCreateFolder: {
                monitor: 2057397,
                tdw: [ "file", "Clk_create" ]
            },
            createFolderSuc: {
                monitor: 2057398,
                tdw: [ "file", "create_suc" ]
            },
            renameFolder: {
                monitor: 2057400,
                tdw: [ "file", "Clk_rename" ]
            },
            clkFolderMore: {
                monitor: 2057399,
                tdw: [ "file", "Clk_more" ]
            },
            downloadFolder: {
                monitor: 2057399,
                tdw: [ "file", "Clk_down" ]
            },
            deleteFolder: {
                monitor: 2057402,
                tdw: [ "file", "Clk_delete" ]
            },
            returnHome: {
                monitor: 2057395,
                tdw: [ "file", "Clk_home" ]
            },
            folderTree: {
                monitor: 2057403,
                tdw: [ "file", "exp_select" ]
            },
            createFolderInTree: {
                monitor: 2057404,
                tdw: [ "file", "select_create" ]
            },
            createFolderInTreeSuc: {
                monitor: 2057405,
                tdw: [ "file", "select_suc" ]
            },
            memberFileShow: {
                monitor: 2057406,
                tdw: [ "mber_file", "exp" ]
            },
            memberClkFolder: {
                monitor: 2057407,
                tdw: [ "mber_file", "Clk_name" ]
            },
            memberReturnHome: {
                monitor: 2057408,
                tdw: [ "mber_file", "Clk_home" ]
            },
            uploadShow: {
                monitor: 2057409,
                tdw: [ "oper_file", "exp_button" ]
            },
            clkUpload: {
                monitor: 2057410,
                tdw: [ "oper_file", "Clk_button" ]
            },
            clkFolder: {
                monitor: 2057411,
                tdw: [ "oper_file", "Clk_category" ]
            },
            showOpenFile: {
                monitor: 2057412,
                tdw: [ "oper_file", "exp_open" ]
            },
            clkOpenFile: {
                monitor: 2057413,
                tdw: [ "oper_file", "Clk_open" ]
            },
            showDownloadBtn: {
                monitor: 2057414,
                tdw: [ "oper_file", "exp_download" ]
            },
            clkDownloadBtn: {
                monitor: 2057415,
                tdw: [ "oper_file", "Clk_download" ]
            },
            showSeeBtn: {
                monitor: 2057416,
                tdw: [ "oper_file", "exp_see" ]
            },
            clkShowBtn: {
                monitor: 2057417,
                tdw: [ "oper_file", "Clk_see" ]
            },
            clkMore: {
                monitor: 2057418,
                tdw: [ "oper_file", "Clk_more" ]
            },
            clkUnMore: {
                monitor: 2057419,
                tdw: [ "oper_file", "Clk_un_more" ]
            },
            clkSaveAs: {
                monitor: 2057420,
                tdw: [ "oper_file", "Clk_save" ]
            },
            clkRepost: {
                monitor: 2057421,
                tdw: [ "oper_file", "Clk_repost" ]
            },
            clkPhone: {
                monitor: 2057422,
                tdw: [ "oper_file", "Clk_phone" ]
            },
            clkRenameFile: {
                monitor: 2057423,
                tdw: [ "oper_file", "Clk_rename" ]
            },
            clkForever: {
                monitor: 2057424,
                tdw: [ "oper_file", "Clk_forever" ]
            },
            clkJubao: {
                monitor: 2057425,
                tdw: [ "oper_file", "Clk_report" ]
            },
            clkDeleteFile: {
                monitor: 2057426,
                tdw: [ "oper_file", "Clk_delete" ]
            },
            clkShowInFolder: {
                monitor: 2057427,
                tdw: [ "oper_file", "Clk_show" ]
            },
            showSelectAll: {
                monitor: 2057428,
                tdw: [ "all_oper", "exp_box" ]
            },
            clkSelectAll: {
                monitor: 2057429,
                tdw: [ "all_oper", "Clk_select" ]
            },
            showBatch: {
                monitor: 2057430,
                tdw: [ "all_oper", "exp_mode" ]
            },
            clkBatch: {
                monitor: 2057431,
                tdw: [ "all_oper", "Clk_all" ]
            },
            batchSaveAs: {
                monitor: 2057432,
                tdw: [ "all_oper", "Clk_save" ]
            },
            batchDownload: {
                monitor: 2057433,
                tdw: [ "all_oper", "Clk_download" ]
            },
            batchDelete: {
                monitor: 2057434,
                tdw: [ "all_oper", "Clk_delete" ]
            },
            batchDeleteSuc: {
                monitor: 2057435,
                tdw: [ "all_oper", "suc_delete" ]
            },
            batchMove: {
                monitor: 2057436,
                tdw: [ "all_oper", "Clk_move" ]
            },
            batchMoveSuc: {
                monitor: 2057437,
                tdw: [ "all_oper", "suc_move" ]
            },
            showTask: {
                monitor: 2057438,
                tdw: [ "task", "exp" ]
            },
            clkTask: {
                monitor: 2057439,
                tdw: [ "task", "Clk_task" ]
            },
            showOneTask: {
                monitor: 2057440,
                tdw: [ "task", "exp_category" ]
            },
            clkTaskName: {
                monitor: 2057441,
                tdw: [ "task", "Clk_name" ]
            },
            showTaskShow: {
                monitor: 2057442,
                tdw: [ "task", "exp_see" ]
            },
            clkTaskShow: {
                monitor: 2057443,
                tdw: [ "task", "Clk_see" ]
            },
            showTaskPause: {
                monitor: 2057444,
                tdw: [ "task", "exp_start" ]
            },
            clkTaskPause: {
                monitor: 2057445,
                tdw: [ "task", "Clk_stop" ]
            },
            showTaskDelete: {
                monitor: 2057446,
                tdw: [ "task", "exp_delete" ]
            },
            clkTaskDelete: {
                monitor: 2057447,
                tdw: [ "task", "Clk_delete" ]
            },
            taskExp: {
                monitor: 2057448,
                tdw: [ "task", "exp_tips" ]
            },
            clkTaskExp: {
                monitor: 2057449,
                tdw: [ "task", "Clk_tips" ]
            },
            showSearchBtn: {
                monitor: 2057450,
                tdw: [ "search", "exp_button" ]
            },
            clkSearchBtn: {
                monitor: 2057451,
                tdw: [ "search", "Clk_button" ]
            },
            doSearch: {
                monitor: 2057452,
                tdw: [ "search", "Clk_search" ]
            },
            showSearchRes: {
                monitor: 2057453,
                tdw: [ "search", "exp_result" ]
            },
            clkSearchRes: {
                monitor: 2057454,
                tdw: [ "search", "Clk_result" ]
            },
            clkSearchName: {
                monitor: 2057455,
                tdw: [ "search", "Clk_name" ]
            },
            showFolderMove: {
                monitor: 2057456,
                tdw: [ "oper_file", "exp_move" ]
            },
            clkFolderMove: {
                monitor: 2057457,
                tdw: [ "oper_file", "Clk_move" ]
            },
            moveFileSuc: {
                monitor: 2057458,
                tdw: [ "oper_file", "move_suc" ]
            },
            showOldVersion: {
                monitor: 2057459,
                tdw: [ "oper_file", "exp_upgradetips" ]
            },
            clkUpdateQQ: {
                monitor: 2057460,
                tdw: [ "oper_file", "Clk_upgrade" ]
            },
            clkNotRemind: {
                monitor: 2057461,
                tdw: [ "oper_file", "Clk_nomoreremind" ]
            },
            showMoveFail: {
                monitor: 2057462,
                tdw: [ "oper_file", "exp_movefail" ]
            },
            delFolderSuc: {
                monitor: 2057463,
                tdw: [ "oper_file", "delete_suc" ]
            },
            jsError: {
                monitor: 2069233
            },
            getListError: {
                monitor: 2069234
            },
            delFileError: {
                monitor: 2069235
            },
            moveFileError: {
                monitor: 2069236
            },
            renameFileError: {
                monitor: 2069237
            },
            newFolderError: {
                monitor: 2069238
            },
            renameFolderError: {
                monitor: 2069239
            },
            delFolderError: {
                monitor: 2069240
            },
            cgiTimeout: {
                monitor: 2069241
            },
            offlinePage: {
                monitor: 2069242
            },
            nodePage: {
                monitor: 2069243
            },
            folderNum: {
                tdw: [ "file", "exp_folder" ]
            },
            imgurl: {
                monitor: 2200307
            },
            expnew: {
                monitor: 2227445
            },
            newFileShow: {
                tdw: [ "file_single", "exp" ],
                monitor: 2227391
            },
            doubleClickFile: {
                tdw: [ "file_single", "Clk_open" ],
                monitor: 2227392
            },
            fileRightMenuShow: {
                tdw: [ "file_single", "exp_right" ],
                monitor: 2227393
            },
            fileRightMenuClick: {
                tdw: [ "file_single", "Clk_option" ],
                monitor: 2227394
            },
            folderShow: {
                tdw: [ "file_pack", "exp" ],
                monitor: 2227395
            },
            doubleClickFolder: {
                tdw: [ "file_pack", "Clk_open" ],
                monitor: 2227396
            },
            folderRightMenuShow: {
                tdw: [ "file_pack", "exp_right" ],
                monitor: 2227397
            },
            folderRightMenuClick: {
                tdw: [ "file_pack", "Clk_option" ],
                monitor: 2227398
            },
            blankRightMenuShow: {
                tdw: [ "blank", "exp_right" ],
                monitor: 2227399
            },
            blankRightMenuClick: {
                tdw: [ "blank", "Clk_option" ],
                monitor: 2227400
            },
            chooseRightMenuShow: {
                tdw: [ "choose", "exp_right" ],
                monitor: 2227401
            },
            chooseRightMenuClick: {
                tdw: [ "choose", "Clk_option" ],
                monitor: 2227402
            },
            chooseDrag: {
                tdw: [ "choose", "Clk_drag" ],
                monitor: 2227403
            },
            chooseDragSinge: {
                tdw: [ "drag", "Clk_drag" ],
                monitor: 2227404
            },
            wayNext: {
                tdw: [ "way", "next" ],
                monitor: 2227405
            },
            wayPrev: {
                tdw: [ "way", "previous" ],
                monitor: 2227406
            },
            wayRoot: {
                tdw: [ "way", "Clk_root" ],
                monitor: 2227407
            },
            fileDownload: {
                monitor: 2366515,
                tdw: [ "oper_file", "down_in" ]
            },
            blackExp: {
                monitor: 2370085,
                tdw: [ "black", "exp_foul" ]
            },
            blackTips: {
                monitor: 2370086,
                tdw: [ "black", "exp_tip" ]
            },
            blackDelete: {
                monitor: 2370087,
                tdw: [ "black", "delete" ]
            },
            adjustTab: {
                tdw: [ "home", "oper_title" ],
                monitor: 2374983
            },
            guideExp: {
                tdw: [ "new_guide", "exp" ],
                monitor: 2387418
            },
            guideRemove: {
                tdw: [ "new_guide", "remove" ],
                monitor: 2387419
            },
            limitOver: {
                tdw: [ "multi", "limit_over" ],
                monitor: 2404320
            },
            limitTip: {
                tdw: [ "multi", "limit_tip" ],
                monitor: 2404321
            },
            showLimit: {
                tdw: [ "multi", "show_limit" ],
                monitor: 2404322
            },
            cleanEntry: {
                tdw: [ "multi", "clean_entry" ],
                monitor: 2404323
            },
            clickClean: {
                tdw: [ "multi", "clear_but" ],
                monitor: 2404324
            },
            changeHand: {
                tdw: [ "multi", "grp_hand" ],
                monitor: 2404325
            },
            sortFile: {
                tdw: [ "home", "rank_title" ],
                monitor: 2404326
            },
            httpssuc: {
                monitor: 2442360
            },
            httpsfail: {
                monitor: 2442361
            },
            httpsall: {
                monitor: 2442382
            },
            httptimeerr: {
                monitor: 2447218
            },
            oldJump: {
                monitor: 2447219
            }
        };
        var s = "Grp_pcfiles";
        window.badjsReport = o.createReport({
            id: 1033
        });
        function f() {
            var e = window.webkitPerformance ? window.webkitPerformance : window.performance, t = [ "navigationStart", "unloadEventStart", "unloadEventEnd", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "requestStart", "responseStart", "responseEnd", "domLoading", "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart", "loadEventEnd" ], a, i, n;
            if (e && (a = e.timing)) {
                if (!a.domContentLoadedEventStart) {
                    t.splice(15, 2, "domContentLoadedStart", "domContentLoadedEnd");
                }
                var r = [];
                for (n = 0, i = t.length; n < i; n++) {
                    r[n] = a[t[n]];
                }
                QReport.huatuo({
                    appid: 10016,
                    flag1: 1772,
                    flag2: 1,
                    flag3: 1,
                    speedTime: r
                });
            }
        }
        function d() {
            var e = /\/\/(s[\d]*\.url\.cn|[\w\.\d]*\.qq.com|report\.url\.cn)/i;
            if (window.performance && window.performance.getEntries) {
                var t = window.performance.getEntries();
                var a = false;
                for (var n = 0, r = t.length; n < r; n++) {
                    var o = t[n].name;
                    if (!e.test(o)) {
                        a = true;
                        QReport.monitor(2154095);
                        badjsReport.info((0, i.default)({
                            "被劫持": o
                        }));
                    }
                }
                if (G.checkHttps() && a) {
                    QReport.monitor(2442389);
                } else if (a) {
                    if (localVersion === "isLocal") {
                        QReport.monitor(2442390);
                    } else {
                        QReport.monitor(2442388);
                    }
                }
            }
        }
        window.addEventListener("load", function() {
            f();
            d();
        });
        window.addEventListener("error", function() {
            report("jsError");
        });
        var c = r.getParameter("gid");
        window.speedReport = function(e) {
            var t = "//isdspeed.qq.com/cgi-bin/r.cgi?flag=7832&flag2=89&flag3=2";
            for (var a in e) {
                t += "&" + a + "=" + e[a];
            }
            var i = new Image().src = t;
            i = null;
        };
        window.reportNew = function(t) {
            var a = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            if (l[t]) {
                var i = l[t];
                if (i.monitor) {
                    QReport.monitor(i.monitor);
                }
                if (i.mac) {
                    QReport.monitor(i.mac);
                }
                if (G.module) {
                    e = G.module();
                }
                if (i.tdw) {
                    var n = {
                        obj1: c,
                        opername: s,
                        module: i.tdw[0],
                        action: i.tdw[1]
                    };
                    if (G.mac) {
                        n.action = i.tdw[1] + "_mac";
                    }
                    n = $.extend(n, a);
                    QReport.tdw(n);
                }
            }
        };
        window.report = function(t) {
            var a = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
            var i = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
            var n = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
            var r = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
            var o = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 0;
            var f = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : 0;
            var d = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : 0;
            if (l[t]) {
                var u = l[t];
                if (u.monitor) {
                    QReport.monitor(u.monitor);
                }
                if (u.mac) {
                    QReport.monitor(u.mac);
                }
                if (G.module) {
                    e = G.module();
                }
                if (u.tdw) {
                    var p = {
                        obj1: c,
                        opername: s,
                        module: u.tdw[0],
                        action: u.tdw[1]
                    };
                    if (G.mac) {
                        p.action = u.tdw[1] + "_mac";
                    }
                    if (a >= 0) {
                        p.ver1 = a;
                    }
                    if (i) {
                        p.ver2 = i;
                    }
                    QReport.tdw(p);
                }
            }
        };
    }).call(t, a(226)(e));
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = l(i);
    var r = a(25);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = window.external;
    function f() {
        var e = void 0;
        if (window.external && s.getTaskList) {
            e = s.getTaskList();
            if (typeof e !== "string") {
                e = "";
            }
        } else {}
        return e;
    }
    function d() {
        var e = {};
        if (window.external && s.getTaskList) {
            var t = s.getTaskList();
            if (typeof t !== "string") {
                t = "";
            }
            if (t === "") {
                e.map = {};
                e.status = "busy";
            } else if (t === "{}") {
                e.map = {};
                e.status = "ok";
                e.empty = true;
            } else {
                try {
                    e.map = JSON.parse(t);
                } catch (a) {
                    console.error("客户端接口getTaskList返回的数据有问题?parse出错[" + t + "]");
                }
                if ((0, o.default)(e.map) === "object" && e.map !== null) {
                    e.status = "ok";
                } else {
                    e.map = {};
                    e.status = "parseerror";
                }
            }
        } else {
            e = {
                map: {},
                status: "ok",
                empty: true
            };
        }
        return e;
    }
    function c() {
        var e = void 0;
        if (window.external && s.getCompleteTaskList) {
            e = s.getCompleteTaskList();
            if (e === null) {
                e = "";
            }
        } else {
            console.log("task相关接口不存在 getTaskList");
        }
        return e;
    }
    function u() {
        var e = {};
        if (window.external && s.getCompleteTaskList) {
            var t = s.getCompleteTaskList();
            if (typeof t !== "string") {
                t = "";
            }
            if (t === "") {
                e.map = {};
                e.status = "busy";
            } else if (t === "{}") {
                e.map = {};
                e.status = "ok";
                e.empty = true;
            } else {
                try {
                    e.map = JSON.parse(t);
                } catch (a) {
                    console.error("客户端接口getCompleteTaskList返回的数据有问题?parse出错[" + t + "]");
                }
                if ((0, o.default)(e.map) === "object" && e.map !== null) {
                    e.status = "ok";
                } else {
                    e.map = {};
                    e.status = "parseerror";
                }
            }
        } else {
            e = {
                map: {},
                status: "ok",
                empty: true
            };
        }
        return e;
    }
    function p(e) {
        if (window.external && s.getTaskInfo) {
            var t = s.getTaskInfo(e);
        } else {}
        return ret;
    }
    function v(e, t) {
        var a = void 0;
        if (!e) {
            e = 1;
        }
        if (window.g_flag_upload_temp) {
            e = 2;
        }
        if ("addUploadTask" in s) {
            a = s.addUploadTask(e, t);
        } else {}
        return a;
    }
    function m(e, t, a, i) {
        var n = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;
        var r = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : false;
        var o = void 0;
        if (window.external && s.addDownloadTask) {
            a = a + "";
            o = s.addDownloadTask(e, t, a, i, n || false, r);
        } else {
            o = -1;
        }
        return o;
    }
    function h(e) {
        var t = void 0;
        if (window.external && s.downloadFiles) {
            t = s.downloadFiles((0, n.default)(e));
        } else {
            t = -1;
        }
        return t;
    }
    function g(e, t, a) {
        var i = void 0;
        if (window.external && s.downloadByXF) {
            a = a + "";
            i = s.downloadByXF(e, t, a);
        } else {
            i = -1;
        }
        return i;
    }
    function w(e, t, a) {
        var i = void 0;
        if (window.external && s.forwardFile) {
            i = s.forwardFile(t, e, a);
        } else {
            i = -1;
        }
        return i;
    }
    function b(e, t, a) {
        var i = void 0;
        if (window.external && s.forwardFileToDataLine) {
            i = s.forwardFileToDataLine(t, e, a);
        } else {
            i = -1;
        }
        return i;
    }
    function _(e, t, a, i) {
        var n = void 0;
        if (window.external && s.addContinueUploadTask) {
            n = s.addContinueUploadTask(e, t, a, i);
        } else {
            n = -1;
        }
        return n;
    }
    function k(e) {
        var t = void 0;
        if (window.external && s.removeTask) {
            t = s.removeTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function y(e) {
        var t = void 0;
        if (window.external && s.removeCompleteTask) {
            t = s.removeCompleteTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function x(e) {
        var t = void 0;
        if (window.external && s.pauseTask) {
            t = s.pauseTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function F(e) {
        var t = void 0;
        if (window.external && s.resumeTask) {
            t = s.resumeTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function T() {
        var e = top.external && top.external.CallHummerApi;
        if (e) {
            var t = void 0;
            try {
                t = e.apply(this, arguments);
                t = JSON.parse(t);
                return t;
            } catch (a) {
                return false;
            }
        }
        return false;
    }
    function $() {
        if (G.mac) {
            try {
                var e = s.getVersion();
                return {
                    errorCode: 0,
                    version: e
                };
            } catch (t) {
                return {
                    errorCode: 1,
                    version: 0
                };
            }
        } else {
            return T("IM.GetVersion");
        }
    }
    function C() {
        if (window["G_DEBUG"]) {
            return true;
        }
        var e = T("Contact.IsOnline");
        if (e) {
            return T("Contact.IsOnline").online;
        } else {
            return false;
        }
    }
    function S(e, t) {
        t = t || 1;
        return T("Contact.OpenContactInfoCard", '{ "uin" : "' + e + '", "tabId" : ' + t + " }");
    }
    function M(e, t) {
        t = t || 1;
        return T("Group.OpenGroupInfoCard", '{ "groupId" : "' + e + '", "tabId" : ' + t + " }");
    }
    function D(e, t) {
        var a = (0, n.default)({
            gc: "" + e,
            webParams: t
        });
        return T("Group.OpenGroupFile", a);
    }
    var R = null;
    function I(e) {
        if (R) {
            return R;
        }
        var t = {
            uin: e + ""
        };
        t = (0, n.default)(t);
        var a = T("Contact.GetNickName", t);
        if (a && a.errorCode === 0 && a.nickName) {
            R = a.nickName;
        }
        if (G.mac) {
            try {
                R = s.getNickName(e);
            } catch (i) {
                R = e;
            }
        }
        if (!R) {
            return e;
        }
        return R;
    }
    function j() {
        return T("IM.GetClientKey");
    }
    function L(e) {
        e += "&pictype=scaled&size=1024*1024";
        var t = void 0;
        if (G.mac) {
            t = window.external && window.external.previewPicture(e);
        } else {
            t = T("Misc.OpenWebPic", '{"url":"' + e + '"}');
        }
        return t;
    }
    function O(e, t) {
        window.external && window.external.previewFile(e, t);
    }
    function P() {
        var e = u();
        if (e.map) {
            for (var t in e.map) {
                var a = e.map[t];
                if (a.id) {
                    var i = y(a.id);
                    if (i === -1) {
                        console.warn("移除完成任务失败！");
                    }
                }
            }
        }
    }
    function N(e, t, a) {
        if (G.mac) {
            return window.alert(a);
        } else {
            return T("Window.Alert", '{ "iconType" : ' + e + ', "title" : "' + t + '", "text" : "' + a + '" }');
        }
    }
    function E(e, t, a) {
        if (G.mac) {
            var i = window.confirm(a);
            return {
                errorCode: 0,
                ret: i
            };
        } else {
            return T("Window.Confirm", '{ "iconType" : ' + e + ', "title" : "' + t + '", "text" : "' + a + '" }');
        }
    }
    function A() {
        var e = void 0;
        if (window.external && s.getUploadFiles) {
            e = s.getUploadFiles();
        } else {
            e = -1;
        }
        return e;
    }
    function B(e, t, a) {
        if (!a) {
            a = 1;
        }
        var i = void 0;
        if (window.external && s.uploadFiles) {
            i = s.uploadFiles(e, t, a);
        } else {
            i = -1;
        }
        return i;
    }
    function U(e, t, a) {
        var i = void 0;
        if (!a) {
            a = 1;
        }
        if ("onlineEditFile" in s) {
            i = s.onlineEditFile(e, t, a);
        } else {}
        return i;
    }
    function z(e) {
        var t = void 0;
        if (!remotetype) {
            remotetype = 1;
        }
        if (window.external && s.setUploadFileRemotePath) {
            t = s.setUploadFileRemotePath(e);
        } else {
            t = -1;
        }
        return t;
    }
    function q(e) {
        var t = void 0;
        if (window.external && s.addMultiDownloadTasks) {
            t = s.addMultiDownloadTasks(e);
        } else {
            t = -1;
        }
        return t;
    }
    function H() {
        var e = {};
        if (window.external && s.getMapLocationPathToRemotePath) {
            var t = s.getMapLocationPathToRemotePath();
            if (typeof t !== "string") {
                t = "";
            }
            if (t === "") {
                e.map = {};
                e.status = "busy";
            } else if (t === "{}") {
                e.map = {};
                e.status = "ok";
                e.empty = true;
            } else {
                try {
                    e.map = JSON.parse(t);
                } catch (a) {
                    console.error("客户端接口getTaskList返回的数据有问题?parse出错[" + t + "]");
                }
                if ((0, o.default)(e.map) === "object" && e.map !== null) {
                    e.status = "ok";
                } else {
                    e.map = {};
                    e.status = "parseerror";
                }
            }
        } else {
            e = {
                map: {},
                status: "ok",
                empty: true
            };
        }
        return e;
    }
    e.exports = {
        getVersion: $,
        getBatchFiles: A,
        batchUpload: B,
        setUploadFileRemotePath: z,
        getTaskListAdv: d,
        getCompleteTaskListAdv: u,
        addUploadTask: v,
        addDownloadTask: m,
        addDownloadFast: g,
        addContinueUploadTask: _,
        removeTask: k,
        removeCompleteTask: y,
        pauseTask: x,
        resumeTask: F,
        getTaskInfo: p,
        forwardFile: w,
        forwardFileToDataLine: b,
        callHummerApi: T,
        getNickName: I,
        isOnline: C,
        getClientKey: j,
        preview: L,
        previewFile: O,
        clearClist: P,
        alert: N,
        confirm: E,
        openGroupInfoCard: M,
        openGroupFile: D,
        addMultiDownloadTasks: q,
        onlineEditFile: U,
        getMapLocationPathToRemotePath: H
    };
}, function(e, t, a) {
    "use strict";
    var i = a(186);
    var n = l(i);
    var r = a(87);
    var o = l(r);
    function l(e) {
        if (e && e.__esModule) {
            return e;
        } else {
            var t = {};
            if (e != null) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) t[a] = e[a];
                }
            }
            t.default = e;
            return t;
        }
    }
    var s = [ a(57), a(58), a(88), a(179), a(173), a(174), a(175), a(30), a(156), a(177), a(24), a(176) ];
    var f = {
        "history.next": n.next,
        "history.pref": n.pref
    };
    var d = {
        "list.select": o.listClick
    };
    s.push(f);
    s.push(d);
    function c() {
        var e = {};
        for (var t = 0; t < s.length; t++) {
            var a = s[t];
            var i = void 0;
            for (i in a) {
                if (a.hasOwnProperty(i)) {
                    e[i] = a[i];
                }
            }
        }
        e["tips.close"] = function() {
            $("#alertTips").remove();
        };
        return e;
    }
    e.exports = {
        getHandlerTasks: c
    };
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(183);
    var l = {};
    e.exports = l;
    var s = "//pan.qun.qq.com/cgi-bin/group_file/";
    var f = {
        checkVip: "//pan.qun.qq.com/cgi-bin/get_vip_id",
        checkOneFile: "//pan.qun.qq.com/cgi-bin/checkAuditFlag",
        rename: "//pan.qun.qq.com/cgi-bin/rename",
        list: "//pan.qun.qq.com/cgi-bin/filelist",
        path: "//pan.qun.qq.com/cgi-bin/thumbnail",
        del: "//pan.qun.qq.com/cgi-bin/del_bat",
        permanent: "//pan.qun.qq.com/cgi-bin/permanent"
    };
    var d = {
        getFileList: s + "get_file_list",
        renameFolder: s + "rename_folder",
        getFileInfo: s + "get_file_info",
        createFolder: s + "create_folder",
        deleteFolder: s + "delete_folder",
        renameFile: s + "rename_file",
        deleteFile: s + "delete_file",
        moveFile: s + "move_file",
        fileSearch: s + "search_file",
        getSpace: s + "get_group_space",
        getUserFlag: s + "get_user_flag",
        setUserFlag: s + "set_user_flag",
        previewFile: "//pan.qun.qq.com/cgi-bin/thumbnail",
        permanent: s + "permanent",
        checkOneFile: "//pan.qun.qq.com/cgi-bin/checkAuditFlag",
        getFileAttr: s + "get_file_attr",
        checkVip: "//pan.qun.qq.com/cgi-bin/get_vip_info",
        checkWhite: s + "white_list",
        getFileCount: s + "get_file_count",
        cleanFile: s + "clean_file"
    };
    l.getEditFlag = function() {
        var e = {
            bus_id: 3
        };
        return o.ajax({
            url: d.checkWhite,
            type: "GET",
            data: e
        });
    };
    l.setPermanent = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.permanent,
            type: "POST",
            data: e
        });
    };
    l.getFileList = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.getFileList,
            type: "GET",
            data: e
        });
    };
    l.deleteFile = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        if (e.bus_id) {
            e.file_list = (0, n.default)({
                file_list: [ {
                    gc: G.info.gc,
                    app_id: G.appid,
                    bus_id: e.bus_id,
                    file_id: e.file_id,
                    parent_folder_id: e.parent_folder_id
                } ]
            });
        }
        return o.ajax({
            url: d.deleteFile,
            type: "POST",
            data: e
        });
    };
    l.renameFile = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.renameFile,
            type: "POST",
            data: e
        });
    };
    l.moveFile = function(e) {
        var t = {};
        t.file_list = (0, n.default)({
            file_list: e
        });
        if (!t.gc) {
            t.gc = G.info.gc;
        }
        return o.ajax({
            url: d.moveFile,
            type: "POST",
            data: t
        });
    };
    l.createFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.createFolder,
            type: "POST",
            data: e
        });
    };
    l.deleteFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.createFolder,
            type: "POST",
            data: e
        });
    };
    l.renameFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.renameFolder,
            type: "POST",
            data: e
        });
    };
    l.deleteFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.deleteFolder,
            type: "POST",
            data: e
        });
    };
    l.getPreview = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.previewFile,
            type: "POST",
            data: e
        });
    };
    l.checkOneFile = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.checkOneFile + "?_=" + new Date().getTime(),
            type: "POST",
            data: e
        });
    };
    l.search = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.fileSearch,
            type: "GET",
            data: e
        });
    };
    l.getSpace = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.getSpace,
            type: "GET",
            data: e
        });
    };
    l.getFileAttr = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.getFileAttr,
            type: "GET",
            data: e
        });
    };
    l.checkVip = function() {
        var e = {
            gc: G.info.gc
        };
        return o.ajax({
            type: "GET",
            data: e,
            url: d.checkVip + "?_=" + new Date().getTime()
        });
    };
    l.getUserFlag = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.getUserFlag,
            type: "GET",
            data: e
        });
    };
    l.setUserFlag = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.setUserFlag,
            type: "POST",
            data: e
        });
    };
    l.getFileCount = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        if (!e.bus_id) {
            e.bus_id = 0;
        }
        return o.ajax({
            url: d.getFileCount,
            type: "GET",
            data: e
        });
    };
    l.cleanFile = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return o.ajax({
            url: d.cleanFile,
            type: "POST",
            data: e
        });
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#qqVip");
    var n = $("#openVip");
    function r() {
        if (G.flagIsVip) {
            i.html('<i class="icons-vip"></i>极速下载特权</a>').addClass("is-vip");
        }
    }
    function o() {
        if (G.flagIsVip) {
            n.find(".tips-msg").text("尊贵的QQ超级会员，您已获得群文件极速下载特权，快去下载文件体验吧！");
            n.find(".btn-ok").remove();
        }
        n.addClass("open");
        n.find(".btn-ok").focus();
    }
    e.exports = {
        showQQVip: r,
        show: o
    };
}, function(e, t, a) {
    "use strict";
    var i = a(17);
    var n = a(84);
    var r = window.localStorage;
    var o = "newbie" + i.getUin();
    var l = function u() {
        var e = $("#fileListDom");
        var t = e.find(".file").eq(0);
        console.log("getfileidx", G.nowFolder);
        if (t.length > 0 && G.nowFolder === "/") {
            var a = t[0].offsetTop;
            var i = $(".scroll-dom").height();
            var n = t.height();
            if (a < i) {
                var r = (Number(t.attr("idx")) || 0) + 1;
                if (a + 76 > i) {
                    return {
                        t: a - 76,
                        u: 0,
                        idx: r
                    };
                } else {
                    return {
                        t: a + n,
                        u: 1,
                        idx: r
                    };
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    };
    var s = function p() {
        try {
            r.setItem(o, 1);
        } catch (e) {
            r.clear();
            r.setItem(o, 1);
        }
        n.setUserFlag({
            position: 0
        }).done(function(e) {}).fail(function(e) {});
    };
    var f = function v() {
        $("#newBie").bind("click", function() {
            $("#newBie").hide();
            s();
            reportNew("guideRemove");
        });
    };
    var d = function m() {
        if (G.nowFolder === "/") {
            var e = l();
            if (e) {
                $("#newBie").show();
                $("#newBieTips").css("top", e.t + 78 + "px");
                if (!e.u) {
                    $("#newBieTips").addClass("bottom");
                }
                f();
                reportNew("guideExp", {
                    ver1: e.idx
                });
            } else {
                $("#newBie").hide();
            }
        } else {
            $("#newBie").hide();
        }
    };
    var c = function h() {
        $("#newBie").remove();
    };
    $("body").bind("newbie", function(e) {
        var t = void 0;
        try {
            t = r.getItem(o);
        } catch (e) {
            console.info(e);
        }
        n.getUserFlag({
            position: 0
        }).done(function(e) {
            if (e.ec !== 0) {
                if (t) {
                    c();
                } else {
                    d();
                }
                return;
            }
            if (e.flag === 1) {
                c();
            }
            if (e.flag === 0 && t) {
                c();
                s();
            }
            if (e.flag === 0 && !t) {
                d();
            }
        }).fail(function(e) {
            if (t) {
                c();
                s();
            } else {
                d();
            }
        });
    });
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.init = nt;
    t.listClick = rt;
    var i = a(132);
    var n = a(54);
    var r = a(184);
    var o = a(142);
    var l = $("#customMenu");
    var s = $(".scroll-dom");
    var f = $("header").height() + $(".list-thead").height();
    var d = 500;
    var c = {};
    var u = 0;
    var p = 40;
    var v = "dragDiv";
    var m = "w";
    var h = 0;
    var g = 0;
    var w = 0, b = 0;
    var _ = 0;
    var k = false;
    var y = false;
    var x = false;
    var F = 0;
    var T = 0;
    var C = "0px", S = "0px", M = "0px", D = "0px";
    var R = false;
    var I = void 0;
    var j = void 0;
    var L = void 0;
    var O = void 0;
    var P = 0;
    var N = 0;
    var E = 0;
    var A = 0;
    var B = document.body.clientWidth;
    var U = document.body.clientHeight;
    var z = function ot() {
        var e = G.onlyGetDom().find(".selected");
        var t = e.length;
        var a = [];
        var i = false;
        G.selectRows = [];
        for (var r = 0; r < t; r++) {
            var o = e[r];
            if (o.classList.contains("fold")) {
                i = o;
            } else {
                var l = o.getAttribute("data-path");
                var s = n.getData(l);
                if (s) {
                    G.selectRows.push(s);
                    a.push(s);
                }
            }
        }
        return {
            list: a,
            fold: i
        };
    };
    var q = function lt() {
        l.addClass("hide");
    };
    var H = function st(e) {
        k = false;
        if ($(".selected").length === 0) {
            return;
        }
        y = true;
    };
    var Q = function ft(e) {
        y = false;
        var t = function d() {
            $(".hover").removeClass("hover");
            $(".selected").removeClass("selected");
            Y();
        };
        if ($("#dragItem .status").hasClass("disable")) {
            t();
            return;
        }
        var a = e.clientY;
        var i = z();
        var r = i.list;
        var l = $(e.target);
        if (!l.hasClass("fold")) {
            l = l.parents(".fold");
        }
        var s = l.data("path");
        var f = n.getData(s);
        if (f) {
            o.movelist(r, s, true);
        }
        x = false;
        t();
    };
    var V = t.customMenu = function dt(e) {
        var t = $(e.target);
        var a = e.clientX;
        var o = e.clientY;
        if (!t.hasClass("list-item")) {
            t = t.parents(".list-item");
        }
        var s = z();
        var f = s.list;
        var d = {};
        var c = void 0;
        var u = function g(e) {
            var a = false;
            if (t.hasClass("file") || t.hasClass("fold")) {
                a = true;
                return a;
            }
            var i = t.data("path");
            if (!e) {
                a = false;
            } else if (e && e.filepath === i) {
                a = true;
            } else {
                a = false;
            }
            return a;
        };
        if (f.length > 1 && t.hasClass("selected")) {
            r.renderCustomMenu(l, f);
            c = "chooseMenuShow";
            d.ver1 = t.length > 0 ? 1 : 2;
            d.ver2 = G.info.isAdmin ? 1 : 2;
            d.ver3 = G.module() === 1 ? 0 : 1;
        } else {
            $(".selected").removeClass("selected");
            y = false;
            if (u(f[0])) {
                t.addClass("selected");
                var p = t.data("path");
                var v = n.getData(p);
                G.selectRow = v;
                G.selectRows = [ v ];
                d = G.getReportInfo(v);
                if (v.orcType === 2) {
                    c = "folderRightMenuShow";
                } else {
                    c = "fileRightMenuShow";
                }
                if ($(e.target).parents(".group1111").length > 0) {
                    v.othergroup = true;
                }
                if (at()) {
                    v.issearch = true;
                }
                r.renderCustomMenu(l, v);
            } else {
                c = "blankRightMenuShow";
                d.ver1 = t.length > 0 ? 1 : 2;
                d.ver2 = G.info.isAdmin ? 1 : 2;
                d.ver3 = G.module() === 1 ? 0 : 1;
                r.renderCustomMenu(l);
                i.changeDownLoadBtn(false);
            }
        }
        reportNew(c, d);
        l.removeClass("hide");
        var m = l.width();
        var h = l.height();
        if (o + h > U) {
            o += U - (o + h) - 10;
        }
        if (a + m > B) {
            a += B - (a + m) - 10;
        }
        l.css({
            top: o + "px",
            left: a + "px"
        });
    };
    var W = function ct(e) {
        if (!c.x) {
            c.x = e.clientX;
            c.y = e.clientY;
        }
        if (Math.abs(e.clientX - c.x) < 10 && Math.abs(e.clientY - c.y) < 10) {
            return false;
        } else {
            c.x = e.clientX;
            c.y = e.clientY;
        }
        var t = +new Date();
        var a = t - u < d;
        u = t;
        if (a) {
            y = false;
            k = false;
        }
        return a;
    };
    var J = function ut(e) {
        try {
            var t = e.clientY - f + _;
            var a = Math.ceil(t / p) - 1;
            return G.onlyGetDom().find(".list-item").eq(a);
        } catch (i) {
            return $("body");
        }
    };
    var Y = function pt() {
        $("#dragItem").remove();
    };
    var X = function vt(e) {
        var t = e.clientX;
        var a = e.clientY;
        if (t > 10 && a > 88 && t < B - 10 && a < U - 10) {
            return true;
        }
        k = false;
        y = false;
        return false;
    };
    var K = function mt() {
        if ($("#dragDiv").length) {
            $("#dragDiv").remove();
        }
    };
    var Z = function ht(e) {
        K();
        if (y) {
            Q(e);
        }
        if (k) {
            H(e);
        }
        R = false;
        x = false;
    };
    var et = function gt(e) {
        if (!x || at()) {
            return;
        }
        if (!X(e) || e.button === 2) {
            Y();
            return;
        }
        var t = e.clientX;
        var a = e.clientY;
        var i = t - L.x - 32;
        var r = a - L.y - 50;
        var o = $("#dragItem");
        if (Math.abs(i) > 5 || Math.abs(a - L.y) > 5) {
            o.show();
        }
        o.css({
            top: L.y + r + "px",
            left: L.x + i + "px"
        });
        var l = J(e);
        if (l.hasClass("fold")) {
            var s = l.data("path");
            var f = n.getData(s);
            $(".fold").removeClass("selected");
            l.addClass("selected");
            if ($("#folderNameWidth").length === 0) {
                $("body").append('<div id="folderNameWidth" style="opacity:0;display:inline-block;">' + f.fnameEsc + "</div>");
            } else {
                $("#folderNameWidth").text(f.fnameEsc);
            }
            var d = $("#folderNameWidth").width();
            o.addClass("can");
            o.find(".move-folder-name").text(f.fnameEsc);
            o.find(".move-info").css("width", d + 66 + "px");
        } else {
            $(".fold").removeClass("selected");
            o.removeClass("can");
        }
    };
    var tt = function wt(e) {
        Y();
        if (!X(e) || at()) {
            return;
        }
        y = true;
        x = true;
        var t = e.clientX - 32;
        var a = e.clientY - 50;
        var i = $(".selected").find(".file-icons").eq(0).html();
        var r = $(".selected").eq(0).data("path");
        var o = 0;
        $(".selected").each(function() {
            if ($(this).hasClass("file")) {
                o++;
            }
        });
        var l = n.getFile(r);
        var s = $('<div class="drag-item" id="dragItem"><div class="item"><div class="filesbig-' + l.icon + '_big"></div><span class="file-num">' + o + '</span></div><div class="status icon-cannot"></div><div class="bgs"></div><div class="move-info"> 移动到 <span class="move-folder-name"></span></div></div>');
        s.css({
            top: a + "px",
            left: t + "px"
        });
        s.hide();
        L = {
            x: t,
            y: e.clientY
        };
        $("body").append(s);
        if (l.previewObj) {
            var f = l.previewObj.url + "&pictype=scaled&size=50*50";
            var d = new Image();
            d.onload = function() {
                s.find(".filesmall-pic").css("background-image", "url(" + f + ")").addClass("thumb");
            };
            d.onerror = function() {
                console.log("缩略图加载失败!", f);
            };
            d.src = f;
        }
    };
    var at = function bt() {
        return G.module() === 3;
    };
    var it = function _t() {
        if (G.module() === 3) {
            F = 58;
            T = 58;
        } else {
            F = 0;
            T = 0;
        }
    };
    function nt() {
        var e = function r(e) {
            if (typeof I.x !== "undefined" && R) {
                var t = e - I.x;
                var a = Math.abs(t);
                R.width(a);
                if (t < 0) {
                    R.css("margin-left", t + "px");
                } else {
                    R.css("margin-left", 0);
                }
            }
        };
        var t = function o(e) {
            if (typeof I.y !== "undefined" && R) {
                var t = e - I.y;
                var a = Math.abs(t);
                R.height(a);
                if (t < 0) {
                    R.css("margin-top", t + "px");
                } else {
                    R.css("margin-top", 0);
                }
            }
        };
        var a = function d(e) {
            if (!X(e)) {
                Z(e);
                return;
            }
            $(".selected").removeClass("selected");
            var t = I.y - F;
            var a = j.y - F;
            if ($(e.target).parents(".group1111").length > 0) {
                a -= T;
            }
            var n = Math.floor(t / p);
            var r = Math.floor(a / p);
            n < 0 ? n = 0 : n;
            var o = G.onlyGetDom().find(".list-item");
            var l = void 0;
            if (n < r) {
                l = o.slice(n, r + 1);
            } else if (n === r) {
                l = [ o.eq(r) ];
            } else {
                l = o.slice(r, n + 1);
            }
            if (l.length > 1) {
                $("body").addClass("drag-module");
            }
            var s = false;
            l.each(function() {
                if (this.classList.contains("file")) {
                    this.classList.add("selected");
                    s = true;
                }
            });
            i.changeDownLoadBtn(s);
        };
        $(document).on("mousedown", ".scroll-dom", function(e) {
            if (G.batchMode || G.inBatchMode) {
                return;
            }
            it();
            K();
            var t = W(e);
            if (t) {
                e.stopPropagation();
                return;
            }
            var a = function l() {
                if (at()) {
                    return;
                }
                $(".selected").removeClass("selected");
                var e = i.clientX;
                var t = i.clientY + _ - f;
                R = $('<div id="' + v + '" class="drag-div"></div>');
                R.css({
                    top: t + "px",
                    left: e + "px"
                });
                I = {
                    x: e,
                    y: t
                };
                s.append(R);
                k = true;
                y = false;
            };
            var i = window.event || e;
            var n = i.button;
            try {
                if (n === 0) {
                    if (at()) {
                        return;
                    }
                    q(e);
                    var r = $(e.target);
                    var o = r.hasClass("drag-dom");
                    if (r.parents(".fold").length > 0) {
                        y = false;
                        o = false;
                    }
                    if (!r.hasClass("selected")) {
                        r = r.parents(".selected");
                    }
                    if (y || r.hasClass("selected")) {
                        if (r.hasClass("selected") && r.hasClass("file") || o) {
                            $(e.target).parents(".file").addClass("selected");
                            tt.call(this, e);
                        } else {
                            a();
                        }
                    } else {
                        a();
                    }
                } else if (n === 2) {
                    V.call(this, i);
                }
            } catch (e) {
                console.log(e);
            }
        });
        $(document).on("mousemove", ".scroll-dom", function(i) {
            try {
                var n = window.event || i;
                var r = n.button;
                if (r === 0) {
                    var o = n.clientY + _ - f;
                    if (y) {
                        et(i);
                    } else if (k) {
                        e(n.clientX);
                        t(o);
                        j = {
                            x: n.clientX,
                            y: o
                        };
                        a(i);
                    }
                } else {
                    k = false;
                }
            } catch (i) {}
        });
        $(document).on("mouseup", ".scroll-dom", function(e) {
            Z(e);
            if ($(".scroll-dom .selected").length === 0) {
                $("body").removeClass("drag-module");
            }
        });
        $(document).on("click", function() {
            l.addClass("hide");
        });
        $(document).bind("contextmenu", function(e) {
            return false;
        });
        s.on("scroll", function() {
            _ = this.scrollTop;
        });
        var n = function c() {
            if (B <= 800) {
                $("body").removeClass("mid-width");
                $("body").removeClass("max-width");
                $("body").addClass("min-width");
            } else if (B <= 1200) {
                $("body").removeClass("mid-width");
                $("body").removeClass("min-width");
                $("body").addClass("mid-width");
            } else {
                $("body").removeClass("min-width");
                $("body").removeClass("mid-width");
                $("body").addClass("max-width");
            }
        };
        $(window).on("resize", function() {
            B = document.body.clientWidth;
            U = document.body.clientHeight;
            $(".scroll-dom").height(U - f);
            n();
        });
        U = document.body.clientHeight;
        $(".scroll-dom").height(U - f);
        n();
    }
    function rt(e) {
        $(".list-item").removeClass("selected");
        this.classList.add("selected");
        i.changeDownLoadBtn(this.classList.contains("file"));
    }
}, function(e, t, a) {
    "use strict";
    var i = $(G.handler);
    var n = $("#fileNum");
    var r = $("#fileNumMenu");
    var o = $(".file-more");
    var l = $("#fileMoreMenu");
    var s = a(184);
    var f = a(54);
    var d = null;
    var c = void 0;
    function u() {
        window.location.reload();
        reportNew("blankRightMenuClick", {
            ver1: G.customMenuLength ? 1 : 2,
            ver2: G.info.isAdmin ? 1 : 2,
            ver3: 3
        });
        report("clkRefresh");
    }
    function p() {
        $("#moreMenu").addClass("show");
    }
    function v() {
        $("#moreMenu").removeClass("show");
    }
    var m = $("header").height() + $(".list-thead").height();
    var h = 40;
    function g() {
        if (G.module() === 3) {
            return;
        }
        $(".batch-block").addClass("show");
        $("body").addClass("batch-mode");
        $("#alertTips").hide();
        $("#selectFileNum").text(0);
        $(".list-item").removeClass("selected");
        G.batchMode = true;
        G.inBatchMode = true;
        b(false);
    }
    function w() {
        $("body").removeClass("batch-mode");
        $(".batch-block").removeClass("show");
        $("#batchSaveAs").addClass("disabled");
        $("#batchDel").addClass("disabled");
        $("#batchMove").addClass("disabled");
        $("#batchDown").addClass("disabled");
        $(".cbox").prop("checked", false);
        G.batchMode = false;
        G.inBatchMode = false;
        b(true);
    }
    function b(e) {
        var t = document.body.clientHeight;
        if (e) {
            $(".more-menu").attr("data-action", "menu.showBatch").attr("aria-label", "进入批量模式");
            $(".scroll-dom").height(t - m);
        } else {
            $(".more-menu").attr("data-action", "menu.closeBatch").attr("aria-label", "退出批量模式");
            $(".scroll-dom").height(t - m - h);
        }
    }
    i.bind("menu.hide", v);
    e.exports = {
        "menu.refresh": u,
        "menu.show": p,
        "menu.hide": v,
        "menu.showBatch": g,
        "menu.closeBatch": w
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        name: {
            initWidth: "auto",
            minWidth: 135,
            fileRow: ".item-name-adjust"
        },
        update: {
            initWidth: 120,
            minWidth: 96,
            fileRow: ".item-time",
            related: "name"
        },
        size: {
            initWidth: 70,
            minWidth: 68,
            fileRow: ".item-size",
            related: "update"
        },
        "upload-user": {
            initWidth: 92,
            minWidth: 92,
            fileRow: ".item-user",
            related: "size"
        },
        "download-times": {
            initWidth: 96,
            minWidth: 82,
            fileRow: ".item-download-times",
            related: "upload-user"
        },
        source: {
            initWidth: 100,
            minWidth: 68,
            fileRow: ".item-source",
            related: "upload-user"
        }
    };
    var n = false;
    var r = {};
    var o = $("body"), l = $(".file-name-wrap"), s = $(".item-name-adjust");
    var f = $("<style></style>"), d = "", c = $("<style></style>"), u = "";
    $("head").append(f);
    $("head").append(c);
    function p(e, t) {
        if (!~d.indexOf(e)) {
            d += ".file-list .list-item " + e + " {" + t + "}";
            return f[0].innerHTML = d;
        }
        d = d.replace(new RegExp(e + "\\s{.*}", "g"), e + " {" + t + "}");
        f[0].innerHTML = d;
    }
    function v(e, t) {
        if (!~u.indexOf(e)) {
            u += ".file-list .list-item " + e + " {width: " + t + "px;}";
            return c[0].innerHTML = u;
        }
        u = u.replace(new RegExp(e + "\\s{width:\\s\\d*px;}", "g"), e + " {width: " + t + "px;}");
        c[0].innerHTML = u;
    }
    function m(e) {
        var t = $(this), a = t.data("resize-aim"), s = $("[data-resize-id=" + a + "]"), f = i[a].related, c = $("[data-resize-id=" + f + "]"), u = [];
        var m = e.clientX, h = e.clientY;
        var g = i[a].minWidth, w = i[f].minWidth;
        d = "";
        for (var b in i) {
            if (b === a || b === f || b === "name") {
                continue;
            }
            var _ = $("[data-resize-id=" + b + "]"), k = _.width();
            v(i[b].fileRow, k);
            p(i[b].fileRow, "max-width:none; min-width: " + k + "px;");
            _.width(k).css({
                "max-width": k,
                "min-width": k
            });
            u.push({
                $tab: _,
                aim: b
            });
        }
        var y = l.width();
        l.width(y).css("flex", "initial");
        v(".item-name-adjust", y);
        o.addClass("ondrag");
        r = {
            x: m,
            y: h,
            aim: a,
            aimWidth: s.width(),
            related: f,
            relatedWidth: c.width(),
            aimMinWidth: g,
            relatedMinWidth: w,
            $drag: t,
            $aim: s,
            $related: c,
            aimRow: i[a].fileRow,
            $aimRow: $(i[a].fileRow),
            relatedRow: i[f].fileRow,
            $relatedRow: $(i[f].fileRow),
            dontMoveTabs: u,
            isDragToMin: s.width() <= g,
            isDragToRelatedMin: c.width() <= w
        };
        n = true;
    }
    function h(e) {
        if (!n || e.button !== 0) {
            return;
        }
        if (!e.clientX) {
            return;
        }
        if (r.isDragToMin && e.clientX > r.$drag.offset().left + 5) {
            return;
        } else if (r.isDragToMin) {
            r.isDragToMin = false;
        }
        if (r.isDragToRelatedMin && e.clientX < r.$drag.offset().left - 5) {
            return;
        } else if (r.isDragToRelatedMin) {
            r.isDragToRelatedMin = false;
        }
        var t = r.x - e.clientX, a = t + r.aimWidth, i = r.relatedWidth - t, o = t <= 0, l = void 0, s = void 0;
        if (o) {
            l = Math.max(a, r.aimMinWidth);
            s = i;
            if (l <= r.aimMinWidth) {
                s = i - (r.aimMinWidth - a);
            }
        } else {
            l = a;
            s = Math.max(i, r.relatedMinWidth);
            if (s <= r.relatedMinWidth) {
                l = a - (r.relatedMinWidth - i);
            }
        }
        r.aimWidth = l;
        r.relatedWidth = s;
        r.x = e.clientX;
        r.$aim.width(l);
        r.$related.width(s);
        v(r.aimRow, l);
        v(r.relatedRow, s);
        if (l <= r.aimMinWidth) {
            r.isDragToMin = true;
            r.x = r.$drag.offset().left + 5;
        }
        if (s <= r.relatedMinWidth) {
            r.isDragToRelatedMin = true;
            r.x = r.$drag.offset().left + 5;
        }
    }
    function g(e) {
        if (!n) {
            return;
        }
        n = false;
        l.css("flex", 1);
        p(".item-name-adjust", "flex: 1;");
        o.removeClass("ondrag");
        r.dontMoveTabs.forEach(function(e) {
            var t = i[e.aim].minWidth;
            e.$tab.css({
                "max-width": "none",
                "min-width": t
            });
            p("" + i[e.aim].fileRow, "max-width: none; min-width: " + t + "px;");
        });
        reportNew("adjustTab", {
            ver1: G.info.isAdmin ? G.info.isMaster ? 1 : 2 : 3
        });
    }
    function w() {
        console.log("reset Tab");
        for (var e in i) {
            var t = $("[data-resize-id=" + e + "]");
            t.css({
                width: i[e].initWidth,
                "max-width": "none",
                "min-width": "none"
            });
        }
        d = "";
        u = "";
        f[0].innerHTML = d;
        c[0].innerHTML = u;
    }
    $(document).on("mousedown", ".tab-resize", m);
    $(document).on("mousemove", h);
    $(document).on("mouseup.adjustTab", g);
    $(window).on("resize", g);
    e.exports = {
        resetTab: w
    };
}, function(e, t, a) {
    "use strict";
    var i = a(25);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(187).fileEvent;
    var l = a(177).groupEvent;
    var s = a(189).uploadEvent;
    var f = a(189).dropEvent;
    var d = a(188);
    var c = top;
    var u = top.external;
    window.addEventListener("message", v);
    c["PostMessage"] = c["onClientEvent"] = p;
    function p(e) {
        var t = void 0;
        console.debug(e);
        if (!e) {
            console.error("[Client] msg is not exist!");
            return;
        }
        if (typeof e === "string") {
            try {
                t = JSON.parse(e);
            } catch (a) {
                console.error("[Client|init()]msg is string, but parse to object catch e!");
            }
        }
        if ((typeof t === "undefined" ? "undefined" : (0, n.default)(t)) !== "object") {
            console.error("[Client|init()]after parse, got no object!");
            return;
        }
        v(t);
    }
    function v(e) {
        var t = e;
        if (t && (typeof t === "undefined" ? "undefined" : (0, n.default)(t)) === "object") {
            if (t.from === "Client") {
                var a = t.data;
                if (typeof a === "string") {
                    a = JSON.parse(t.data) || {};
                }
                var i = a.cmd || "";
                switch (i) {
                  case "OnFiletransporterEvent":
                    o(a.param);
                    break;

                  case "OnGroupShareTabChangedEvent":
                    l(a.param);
                    break;

                  case "OnGroupUploadFileListsEvent":
                    s(param);
                    break;

                  case "OnGroupDropInGroupFolderUpload":
                    s(param);
                    break;

                  default:
                    console.warn("warn:预期外的message.cmd:" + i);
                    break;
                }
            } else if (t.cmd && t.cmd === "OnGroupUploadFileListsEvent") {
                s(t.param);
            } else if (t.cmd && t.cmd === "OnGroupDropInGroupFolderUpload") {
                f(t.param);
            } else {
                var r = t.data;
                if (!r) {
                    return;
                }
                if (typeof r === "string") {
                    r = JSON.parse(r);
                }
                var c = r.cmd || "";
                switch (c) {
                  case "jubao_close":
                    d.hide();
                    break;

                  default:
                    console.warn("warn:预期外的message.cmd:" + c);
                    break;
                }
            }
        }
    }
    window.onClientEvent = p;
    e.exports = {};
}, , function(e, t, a) {
    var i = a(101), n = i.JSON || (i.JSON = {
        stringify: JSON.stringify
    });
    e.exports = function r(e) {
        return n.stringify.apply(n, arguments);
    };
}, , function(e, t, a) {
    a(107);
    a(108);
    e.exports = a(102).f("iterator");
}, function(e, t, a) {
    a(103);
    a(104);
    a(105);
    a(106);
    e.exports = a(101).Symbol;
}, function(e, t, a) {
    a(109);
    e.exports = a(101).Object.keys;
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '	<div class="toast-overlay" id="toastDom" aria-describedby="toastText" tabindex="-1">\r\n		<div class="toast" id="toastInfo">\r\n			<div class="icons-<%-locals.cls%> toast-icon"></div>\r\n			<div class="toast-message" id="toastText"><%-locals.text%></div>\r\n		</div>\r\n	</div>',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('	<div class="toast-overlay" id="toastDom" aria-describedby="toastText" tabindex="-1">\n		<div class="toast" id="toastInfo">\n			<div class="icons-', (__stack.lineno = 3, 
                    locals.cls), ' toast-icon"></div>\n			<div class="toast-message" id="toastText">', (__stack.lineno = 4, 
                    locals.text), "</div>\n		</div>\n	</div>");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, , function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<div class="files-empty"><div><div class="icons-empty"></div><div class="empty-desc">在这里，你可以把各种有趣的东西分享给大家</div></div></div>\n',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('<div class="files-empty"><div><div class="icons-empty"></div><div class="empty-desc">在这里，你可以把各种有趣的东西分享给大家</div></div></div>\n');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, , function(e, t, a) {
    var i = e.exports = {
        version: "2.4.0"
    };
    if (typeof __e == "number") __e = i;
}, function(e, t, a) {
    t.f = a(193);
}, function(e, t, a) {
    "use strict";
    var i = a(194), n = a(195), r = a(196), o = a(197), l = a(198), s = a(199).KEY, f = a(200), d = a(201), c = a(202), u = a(203), p = a(193), v = a(102), m = a(204), h = a(205), g = a(206), w = a(207), b = a(208), _ = a(209), k = a(225), y = a(210), x = a(211), G = a(212), F = a(213), T = a(214), $ = a(215), C = F.f, S = T.f, M = G.f, D = i.Symbol, R = i.JSON, I = R && R.stringify, j = "prototype", L = p("_hidden"), O = p("toPrimitive"), P = {}.propertyIsEnumerable, N = d("symbol-registry"), E = d("symbols"), A = d("op-symbols"), B = Object[j], U = typeof D == "function", z = i.QObject;
    var q = !z || !z[j] || !z[j].findChild;
    var H = r && f(function() {
        return x(S({}, "a", {
            get: function() {
                return S(this, "a", {
                    value: 7
                }).a;
            }
        })).a != 7;
    }) ? function(e, t, a) {
        var i = C(B, t);
        if (i) delete B[t];
        S(e, t, a);
        if (i && e !== B) S(B, t, i);
    } : S;
    var Q = function(e) {
        var t = E[e] = x(D[j]);
        t._k = e;
        return t;
    };
    var V = U && typeof D.iterator == "symbol" ? function(e) {
        return typeof e == "symbol";
    } : function(e) {
        return e instanceof D;
    };
    var W = function it(e, t, a) {
        if (e === B) W(A, t, a);
        b(e);
        t = k(t, true);
        b(a);
        if (n(E, t)) {
            if (!a.enumerable) {
                if (!n(e, L)) S(e, L, y(1, {}));
                e[L][t] = true;
            } else {
                if (n(e, L) && e[L][t]) e[L][t] = false;
                a = x(a, {
                    enumerable: y(0, false)
                });
            }
            return H(e, t, a);
        }
        return S(e, t, a);
    };
    var J = function nt(e, t) {
        b(e);
        var a = g(t = _(t)), i = 0, n = a.length, r;
        while (n > i) W(e, r = a[i++], t[r]);
        return e;
    };
    var Y = function rt(e, t) {
        return t === undefined ? x(e) : J(x(e), t);
    };
    var X = function ot(e) {
        var t = P.call(this, e = k(e, true));
        if (this === B && n(E, e) && !n(A, e)) return false;
        return t || !n(this, e) || !n(E, e) || n(this, L) && this[L][e] ? t : true;
    };
    var K = function lt(e, t) {
        e = _(e);
        t = k(t, true);
        if (e === B && n(E, t) && !n(A, t)) return;
        var a = C(e, t);
        if (a && n(E, t) && !(n(e, L) && e[L][t])) a.enumerable = true;
        return a;
    };
    var Z = function st(e) {
        var t = M(_(e)), a = [], i = 0, r;
        while (t.length > i) {
            if (!n(E, r = t[i++]) && r != L && r != s) a.push(r);
        }
        return a;
    };
    var et = function ft(e) {
        var t = e === B, a = M(t ? A : _(e)), i = [], r = 0, o;
        while (a.length > r) {
            if (n(E, o = a[r++]) && (t ? n(B, o) : true)) i.push(E[o]);
        }
        return i;
    };
    if (!U) {
        D = function dt() {
            if (this instanceof D) throw TypeError("Symbol is not a constructor!");
            var e = u(arguments.length > 0 ? arguments[0] : undefined);
            var t = function(a) {
                if (this === B) t.call(A, a);
                if (n(this, L) && n(this[L], e)) this[L][e] = false;
                H(this, e, y(1, a));
            };
            if (r && q) H(B, e, {
                configurable: true,
                set: t
            });
            return Q(e);
        };
        l(D[j], "toString", function ct() {
            return this._k;
        });
        F.f = K;
        T.f = W;
        a(216).f = G.f = Z;
        a(217).f = X;
        a(218).f = et;
        if (r && !a(219)) {
            l(B, "propertyIsEnumerable", X, true);
        }
        v.f = function(e) {
            return Q(p(e));
        };
    }
    o(o.G + o.W + o.F * !U, {
        Symbol: D
    });
    for (var tt = "hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables".split(","), at = 0; tt.length > at; ) p(tt[at++]);
    for (var tt = $(p.store), at = 0; tt.length > at; ) m(tt[at++]);
    o(o.S + o.F * !U, "Symbol", {
        "for": function(e) {
            return n(N, e += "") ? N[e] : N[e] = D(e);
        },
        keyFor: function ut(e) {
            if (V(e)) return h(N, e);
            throw TypeError(e + " is not a symbol!");
        },
        useSetter: function() {
            q = true;
        },
        useSimple: function() {
            q = false;
        }
    });
    o(o.S + o.F * !U, "Object", {
        create: Y,
        defineProperty: W,
        defineProperties: J,
        getOwnPropertyDescriptor: K,
        getOwnPropertyNames: Z,
        getOwnPropertySymbols: et
    });
    R && o(o.S + o.F * (!U || f(function() {
        var e = D();
        return I([ e ]) != "[null]" || I({
            a: e
        }) != "{}" || I(Object(e)) != "{}";
    })), "JSON", {
        stringify: function pt(e) {
            if (e === undefined || V(e)) return;
            var t = [ e ], a = 1, i, n;
            while (arguments.length > a) t.push(arguments[a++]);
            i = t[1];
            if (typeof i == "function") n = i;
            if (n || !w(i)) i = function(e, t) {
                if (n) t = n.call(this, e, t);
                if (!V(t)) return t;
            };
            t[1] = i;
            return I.apply(R, t);
        }
    });
    D[j][O] || a(220)(D[j], O, D[j].valueOf);
    c(D, "Symbol");
    c(Math, "Math", true);
    c(i.JSON, "JSON", true);
}, function(e, t, a) {}, function(e, t, a) {
    a(204)("asyncIterator");
}, function(e, t, a) {
    a(204)("observable");
}, function(e, t, a) {
    "use strict";
    var i = a(221)(true);
    a(222)(String, "String", function(e) {
        this._t = String(e);
        this._i = 0;
    }, function() {
        var e = this._t, t = this._i, a;
        if (t >= e.length) return {
            value: undefined,
            done: true
        };
        a = i(e, t);
        this._i += a.length;
        return {
            value: a,
            done: false
        };
    });
}, function(e, t, a) {
    a(223);
    var i = a(194), n = a(220), r = a(224), o = a(193)("toStringTag");
    for (var l = [ "NodeList", "DOMTokenList", "MediaList", "StyleSheetList", "CSSRuleList" ], s = 0; s < 5; s++) {
        var f = l[s], d = i[f], c = d && d.prototype;
        if (c && !c[o]) n(c, o, f);
        r[f] = r.Array;
    }
}, function(e, t, a) {
    var i = a(190), n = a(215);
    a(192)("keys", function() {
        return function e(t) {
            return n(i(t));
        };
    });
}, , , , , , , , , , , , , , , function(e, t, a) {
    "use strict";
    function i(e) {
        if (!G.cMap) {
            G.cMap = {};
        }
        var t = G.cMap[e.id];
        if (!t) {
            t = G.cMap[e.filepath];
            if (t) {
                if (t && t.type.indexOf("upload") >= 0 && e.type.indexOf("upload") >= 0 && t.status != e.status) {
                    if (e.id) {
                        plistMap[e.id] = t;
                    }
                    console.warn("new task 发现续传 id[" + t.id + "] status[" + t.status + "]");
                } else if (e.type == "download") {
                    console.log(e);
                } else {}
            }
        }
        if (!t) {
            if (e.id) {
                G.cMap[e.id] = e;
            }
            if (e.filepath) {
                G.cMap[e.filepath] = e;
            }
            return e;
        } else {}
    }
    function n(e) {
        if (G.cMap[e.id] || G.cMap[e.filepath]) {
            return true;
        } else {
            return false;
        }
    }
    function r(e) {
        if (G.cMap[e.id]) {
            delete G.cMap[e.id];
        }
        if (G.cMap[e.filepath]) {
            delete G.cMap[e.filepath];
        }
    }
    function o(e) {}
    function l() {
        for (var e in G.cMap) {
            var t = G.cMap[e];
            if (t && t.status === "uploadcomplete") {
                delete G.cMap[t.id];
                delete G.cMap[t.filepath];
            }
        }
    }
    e.exports = {
        check: n,
        add: i,
        del: r,
        update: o,
        clearComplete: l
    };
}, , function(e, t, a) {
    "use strict";
    function i(e) {
        var t = {
            fLen: 3
        };
        if (typeof e != "number") return "";
        var a;
        var i = e;
        var n = [ "B", "KB", "MB", "GB", "TB", "PB" ];
        while (i > 1024) {
            i = i / 1024;
            n.shift();
        }
        if (i >= 1e3) {
            i = i / 1024;
            n.shift();
        }
        var r = ("" + i).length;
        var o = 2;
        var l = 100;
        if (t && t.len) o = t.len;
        if (o < 0) o = 0;
        l = Math.pow(10, o);
        i = Math.floor(i * l) / l;
        if (t && t.fLen) {
            var s = i.toString().indexOf(".");
            if (i.toString().length <= t.fLen) {
                var f = parseInt(i, 10).toString().length;
                i = i.toFixed(t.fLen - f);
            } else if (t.fLen < i.toString().length) {
                i = i.toString();
                if (s > 0 && s < 3) i = i.substr(0, 4); else i = i.substr(0, 3);
            }
        }
        a = i.toString().replace(/\.0+$/, "");
        a = a + n[0];
        if (i === 0) a = 0;
        return a;
    }
    function n(e) {
        var t = {
            fLen: 3
        };
        if (typeof e != "number") return "";
        var a;
        var i = e;
        var n = [ "B", "KB", "MB", "GB", "TB", "PB" ];
        while (i > 1024) {
            i = i / 1024;
            n.shift();
        }
        if (i >= 1e3) {
            i = 1;
            n.shift();
        }
        var r = ("" + i).length;
        var o = 2;
        var l = 100;
        if (t && t.len) o = t.len;
        if (o < 0) o = 0;
        l = Math.pow(10, o);
        var s = Math.round(i * l) / l;
        if (s >= 1e3) i = Math.floor(i * l) / l; else i = s;
        if (t && t.fLen) {
            var f = i.toString().indexOf(".");
            if (i.toString().length <= t.fLen) {
                var d = parseInt(i, 10).toString().length;
                i = i.toFixed(t.fLen - d);
            } else if (t.fLen < i.toString().length) {
                i = i.toString();
                if (f > 0 && f < 3) i = i.substr(0, 4); else i = i.substr(0, 3);
            }
        }
        a = i.toString().replace(/\.0+$/, "");
        a = a + n[0];
        if (i === 0) a = 0;
        return a;
    }
    function r(e) {
        var t = "unknow";
        var a = {
            excel: /xls|xlsx/i,
            pdf: /pdf/i,
            ppt: /ppt|pptx/i,
            word: /doc|docx|wps/i,
            text: /txt/i,
            pic: /jpg|jpeg|jpgx|gif|bmp|png|ico|webp|raw|tiff/i,
            music: /mp3|wma|midi|aac|ape|flac|wav|mid|ogg|aac/i,
            video: /mp4|rm|rmvb|mpeg|mov|avi|3gp|amv|dmv|flv|wmv|qsed|asf|mkv/i,
            zip: /rar|zip|tar|cab|uue|jar|iso|7z|ace|lzh|arj|gzip|bz2/i,
            code: /ink|torrent|url|vbs|tif|w3g|vbe|ssf|dll|mht|rcd|bat|sav|dat|cmd|ttf|xml|vob|sgs|mhw|js|html|htm|css/i,
            exe: /exe|msi/i,
            ipa: /ipa/i,
            dmg: /dmg/i,
            apk: /apk/i
        };
        for (var i in a) {
            var n = a[i];
            if (n.test(e)) {
                t = i;
                break;
            }
        }
        return t;
    }
    function o(e) {
        var t = "其他";
        var a = {
            "文档": /doc|docx|ppt|pptx|xsl|xslx|xls|xlsx|pdf|txt|wps/i,
            "图片": /jpg|jpeg|jpgx|gif|bmp|png/i,
            "音乐": /mp3|wma|midi|aac/i,
            "视频": /mp4|rm|rmvb|mpeg|mov|avi|3gp|amv|dmv|flv|wmv|qsed/i,
            "压缩包": /rar|zip|tar|cab|uue|jar|iso|7z|ace|lzh|arj|gzip|bz2/i,
            "应用": /dmg/i
        };
        for (var i in a) {
            var n = a[i];
            if (n.test(e)) {
                t = i;
                break;
            }
        }
        return t;
    }
    var l = 5485;
    function s(e, t) {
        return false;
    }
    function f(e) {
        var t = e.lastIndexOf("."), a = {};
        if (t >= 0) {
            a.filename_name = e.substr(0, t);
            a.filename_suf = e.substr(t);
        } else {
            a.filename_name = e;
            a.filename_suf = "";
        }
        return a;
    }
    function d(e) {
        var t = e.lastIndexOf("\\"), a = e.substr(t + 1);
        return a;
    }
    e.exports = {
        getSize: i,
        getIcon: r,
        getType: o,
        canEdit: s,
        getFileName: f,
        getFolderName: d
    };
}, function(e, t, a) {
    "use strict";
    var i = a(128);
    function n(e) {
        var t = i.errorCfgPrefix[e.type] + "-" + e.status;
        if (t in i.errorCfg && i.errorCfg) {
            return true;
        }
        return false;
    }
    function r(e) {
        if (!e || !e.type || !e.status) {
            return "";
        }
        var t = i.errorCfgPrefix[e.type] + "-" + e.status;
        if (t in i.errorCfg) {
            if (t === "upload-uploadsecurityfail" && i.securityattriMap[e.securityattri]) {
                return i.securityattriMap[e.securityattri];
            }
            return i.errorCfg[t];
        }
        return;
    }
    function o(e, t) {
        return i.wordingMap[e][t];
    }
    function l(e, t) {
        return i.styleMap[e][t];
    }
    function s(e) {
        return i.typeMap[e];
    }
    function f(e, t) {
        if (!e) {
            return false;
        }
        if (!i.wordingMap[e]) {
            console.warn("设置wording 未知任务类型=[" + e + "]");
        }
        if (!i.wordingMap[e][t]) {
            console.warn("设置wording 未知任务状态=[" + t + "]");
        }
        if (!i.styleMap[e][t]) {
            console.warn("设置样式 未知任务状态=[" + t + "]");
        }
    }
    e.exports = {
        check: f,
        getType: s,
        getWord: o,
        getClass: l,
        ifError: n,
        getErrorWord: r
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        upload: "upload",
        continueupload: "continueupload",
        download: "download"
    };
    var n = {};
    n.upload = {
        scanning: "扫描中...&nbsp;&nbsp;",
        scanfail: "扫描失败&nbsp;&nbsp;",
        scanend: "扫描完成...&nbsp;&nbsp;",
        uploadgeturl: "准备上传...&nbsp;&nbsp;",
        uploadgeturlend: "上传中...&nbsp;&nbsp;",
        uploadadminonlyfail: "无法上传，已限制成员上传文件",
        uploadgeturlfail: "申请上传地址失败",
        uploadlimit: "文件个数达到上限，无法上传",
        uploadsecurityfail: "安全扫描失败",
        cancel: "空间不足,已取消上传",
        uploadprogress: "上传中:&nbsp;&nbsp;",
        uploadfail: "上传失败",
        uploadcomplete: "上传完成&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        pause: "暂停&nbsp;&nbsp;",
        "continue": "待续传&nbsp;&nbsp;"
    };
    n.download = {
        wait: "等待下载...&nbsp;&nbsp;",
        downloadready: "准备下载...&nbsp;&nbsp;",
        downloadgeturl: "准备下载...&nbsp;&nbsp;",
        downloadgeturlfail: "获取下载地址失败",
        cancel: "已取消下载&nbsp;&nbsp;",
        downloadgeturlend: "下载中...",
        downloadprogress: "下载中:&nbsp;&nbsp;",
        downloadfail: "下载失败&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        downloadcomplete: "下载完成&nbsp;&nbsp;",
        pause: "暂停&nbsp;&nbsp;"
    };
    n.continueupload = {
        scanning: "扫描中...&nbsp;&nbsp;",
        scanfail: "扫描失败&nbsp;&nbsp;",
        scanend: "扫描完成...&nbsp;&nbsp;",
        uploadgeturl: "准备续传...&nbsp;&nbsp;",
        uploadgeturlend: "续传中...&nbsp;&nbsp;",
        uploadgeturlfail: "申请续传地址失败",
        uploadlimit: "文件个数达到上限，无法上传",
        uploadsecurityfail: "安全扫描失败",
        cancel: "空间不足,已取消续传",
        uploadprogress: "续传中:&nbsp;&nbsp;",
        uploadfail: "续传失败",
        uploadcomplete: "续传完成&nbsp;&nbsp;",
        pause: "暂停&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        "continue": "待续传&nbsp;&nbsp;"
    };
    var r = {};
    r.upload = {
        scanning: "scan",
        scanfail: "err",
        scanend: "scan",
        uploadgeturl: "pre",
        uploadgeturlend: "pre",
        uploadgeturlfail: "err",
        uploadsecurityfail: "err",
        cancel: "err",
        uploadprogress: "progress",
        uploadfail: "err",
        uploadcomplete: "complete",
        pause: "pause",
        filenotexsit: "err",
        "continue": "continue",
        remove: ""
    };
    r.download = {
        wait: "pre",
        downloadready: "pre",
        downloadgeturl: "pre",
        downloadgeturlfail: "err",
        cancel: "err",
        downloadgeturlend: "pre",
        downloadprogress: "progress",
        downloadfail: "err",
        filenotexsit: "err",
        downloadcomplete: "complete",
        pause: "pause"
    };
    r.continueupload = {
        scanning: "scan",
        scanfail: "err",
        scanend: "scan",
        uploadgeturl: "pre",
        uploadgeturlend: "pre",
        uploadgeturlfail: "err",
        uploadsecurityfail: "err",
        cancel: "err",
        uploadprogress: "progress",
        uploadfail: "err",
        uploadcomplete: "complete",
        pause: "pause",
        filenotexsit: "err",
        "continue": "continue",
        remove: ""
    };
    var o = {
        upload: "upload",
        download: "download",
        continueupload: "upload"
    };
    var l = [ "安全", "扫描到病毒，已取消上传", "扫描到未知风险", "扫描到安全风险", "扫描到安全风险", "扫描到安全风险", "文件包含敏感词" ];
    var s = {
        "download-downloadgeturlfail": "下载失败,请稍候再试",
        "download-cancel": "",
        "download-downloadfail": "下载失败",
        "upload-scanfail": "扫描失败,请稍候再试",
        "upload-uploadgeturlfail": "上传失败",
        "upload-uploadsecurityfail": "上传安全扫描失败",
        "upload-cancel": "空间不足,已取消上传",
        "upload-uploadfail": "上传失败,请稍候再试",
        folderLimit: "文件夹个数以达上限"
    };
    var f = 300;
    e.exports = {
        errorCfg: s,
        errorCfgPrefix: o,
        securityattriMap: l,
        styleMap: r,
        wordingMap: n,
        typeMap: i,
        refreshTime: f
    };
}, function(e, t, a) {
    "use strict";
    var i = new Date();
    var n = i.getFullYear();
    function r(e) {
        var t = Math.ceil(e / 86400);
        return t;
    }
    function o(e) {
        e = k(e);
        if (e.getFullYear() != i.getFullYear()) return false;
        if (e.getMonth() != i.getMonth()) return false;
        if (e.getDate() != i.getDate()) return false;
        return true;
    }
    function l(e) {
        e = k(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var n = new Date(i.getFullYear(), i.getMonth(), i.getDate()) - e;
            a = n > 0 && n < 864e5;
        }
        return a;
    }
    function s(e) {
        e = k(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var n = new Date(i.getFullYear(), i.getMonth(), i.getDate()) - e;
            a = n > 0 && n < 864e5 * 2;
        }
        return a;
    }
    function f(e) {
        e = k(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var n = new Date(i.getFullYear(), i.getMonth(), i.getDate()) - e;
            a = n >= 0 && n <= 864e5;
        }
        if (a) return "昨天"; else return "前天";
    }
    function d(e) {
        e = k(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var n = new Date(i.getFullYear(), i.getMonth(), i.getDate()) - e;
            a = n > 0 && n < 864e5 * 2;
        }
        return a;
    }
    function c(e) {
        e = k(e);
        var t = m(i);
        if (e > t) return true;
        return false;
    }
    function u(e) {
        e = k(e);
        if (e.getYear() != i.getYear()) return false;
        return true;
    }
    function p(e) {
        if (!e) e = i.getFullYear();
        var t = new Date(e, 0, 1);
        var a = void 0;
        var n = t.getDay();
        if (n === 0) n = 7;
        var r = [ null, "一", "二", "三", "四", "五", "六", "日" ];
        var o = "周" + r[n];
        if (n != 1) t.setDate(1 + 8 - n);
        return t;
    }
    function v(e) {
        var t = new Date(e);
        var a = p(t.getFullYear());
        var i = 0;
        var n = void 0;
        if (a.getDate() > 1) i = 1;
        if (t < a) n = 1; else {
            n = Math.floor((t - a) / 7 / 864e5) + i;
        }
        return n;
    }
    function m(e) {
        var t = k(e);
        var a = t.getDay();
        if (a === 0) a = 7;
        var i = a - 1;
        var n = void 0;
        n = new Date(t.getTime() - i * 864e5);
        return n;
    }
    function h(e) {
        var t = k(e);
        var a = t.getDay();
        if (a === 0) a = 7;
        return a;
    }
    function g() {}
    function w(e) {
        if (!e) {
            return;
        }
        var t = k(e);
        var a = t.getFullYear();
        var i = t.getMonth() + 1;
        var n = t.getDate();
        var r = t.getHours();
        var o = t.getMinutes();
        if (i < 10) i = "0" + i;
        if (n < 10) n = "0" + n;
        if (o < 10) {
            o = "0" + o;
        }
        return a + "-" + i + "-" + n + " " + r + ":" + o;
    }
    function b(e) {
        if (!e) {
            return;
        }
        var t = k(e);
        var a = t.getFullYear();
        var i = t.getMonth() + 1;
        var n = t.getDate();
        var r = t.getHours();
        var o = t.getMinutes();
        if (i < 10) i = "0" + i;
        if (n < 10) n = "0" + n;
        if (o < 10) {
            o = "0" + o;
        }
        return a + "-" + i + "-" + n + " " + r + ":" + o;
    }
    function _(e) {
        var t = k(e);
        var a = new Date();
        var i = a.getTime() - t.getTime();
        var n = parseInt(i / 36e5, 10);
        if (n < 1) n = "刚刚"; else n = n + "小时前";
        return n;
    }
    function k(e) {
        var t = e;
        if (typeof e === "string") t = new Date(e);
        if (typeof e === "number") t = new Date(e * 1e3);
        return t;
    }
    function y(e) {
        if (!e) {
            return;
        }
        var t = 60, a = 3600, i = 86400, n = "";
        if (e >= i) {
            n = Math.ceil(e / i) + "天";
        } else if (e >= a) {
            n = Math.ceil(e / a) + "小时";
        } else if (e >= t) {
            n = Math.ceil(e / t) + "分钟";
        } else if (e > 0) {
            n = e + "秒";
        } else {
            n = "已过期";
        }
        return n;
    }
    function x(e) {
        var t = void 0;
        var a = void 0;
        if (typeof e == "number") {
            t = new Date(e * 1e3);
        } else if (e instanceof Date) {
            t = e;
        }
        if (o(t)) {
            a = _(t);
        } else if (s(t)) {
            a = f(t);
        } else {
            a = w(t);
        }
        return a;
    }
    function G(e) {
        var t = e.createtime;
        e.day_str = x(t);
        e.createtime_str = w(t);
        if (e.day_str === "今天") {
            e.createtime_str = _(t);
        }
        if (e.day_str === "最近三天") {
            e.createtime_str = f(t);
        }
    }
    e.exports = {
        dayStr: x,
        genTimeStr: G,
        getValidity: y,
        toDate: k,
        getHourStr: _,
        getExpriesDayNum: r,
        isToday: o,
        isYesterday: l,
        strYesterdayOrPre: f,
        isLast3days: d,
        isThisWeek: c,
        isThisYear: u,
        getMonOY: p,
        getWOY: v,
        getMOW: m,
        getDayOfWeek: h,
        getDayOfYear: g,
        getDateStr: x,
        getorcDateStr: w
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<%\r\n	for(var i = 0,l = locals.list.length;i<l;i++){\r\n		var item = locals.list[i];\r\n%>\r\n<div class="file2 file2-2 <%-item.styles%>" data-path="<%-item.filepath%>" data-id="<%-item.id%>" data-folder="<%-item.folderpath%>" data-name="<%-item.filename||item.fname%>" <%if(item.styleStatus === \'complete\'){%>data-action="task.openFolder"<%}%>>\r\n	<div class="file-icon">\r\n		<div class="filesmall-<%-item.icon%>"></div>\r\n		<i></i>\r\n	</div>\r\n	<div class="file-info">\r\n		<div class="filename">\r\n			<div class="name"><%-item.name%></div>\r\n			<%if(item.orcType === 1){%>\r\n				<div class="suffix"><%-item.suf%></div>\r\n			<%}%>\r\n		</div>\r\n		<div class="loading">\r\n			<div class="bar" style="width:<%-item.cPercent%>%;"></div>\r\n		</div>\r\n		<%if(item.failedFileList && item.failedFileList.length > 0){%>\r\n			<div class="wording"  data-action="task.openfail">\r\n				<i class=\'warn\'></i>有<%-item.failedFileList.length%>个文件下载失败<i class="arrow"></i>\r\n					<ul class="fail-list">\r\n						<%for(var j = 0,m = item.failedFileList.length;j<m;j++){%> \r\n							<li><%=item.failedFileList[j].filename%></li>\r\n						<%}%>\r\n					</ul>\r\n			</div>\r\n		<%}else{%>\r\n			<div class="wording"><%-item.wording%></div>		\r\n		<%}%>\r\n	</div>\r\n	<div class="file-action">\r\n		<div class="aria-hide">\r\n			<a class="aria-tips" tabindex="-1">\r\n				<%if(item.orcType === 1){%>\r\n					文件<%=item.name%><%-item.suf%>\r\n				<%}else{%>\r\n					文件夹<%=item.name%>\r\n				<%}%>\r\n				 状态:<%-item.wording%> 任务进度<%-item.cPercent%>% \r\n			</a>\r\n		</div>\r\n		<a href="javascript:void(0)" class="seat"  tabindex="-1"></a>\r\n		<a class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 <%=item.name%>" tabindex="-1"></a>\r\n		<a class="resume" data-action="task.resume" title="启动" aria-label="启动任务 <%=item.name%>" tabindex="-1"></a>\r\n		<a class="continue" data-action="task.continue" title="续传" aria-label="续传任务 <%=item.name%>" tabindex="-1"></a>\r\n		<a class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 <%=item.name%>" tabindex="-1"></a>\r\n		<a class="ok-upload"></a>\r\n		<a class="ok-download"></a>\r\n		<a class="go-folder" data-action="task.openFolderIco" title="打开该文件所在的文件夹" arir-label="打开<%=item.name%>所在的文件夹" tabindex="3"></a>\r\n	</div>\r\n	<div></div>\r\n</div>\r\n<%}%> ',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push("");
                    __stack.lineno = 1;
                    for (var e = 0, t = locals.list.length; e < t; e++) {
                        var a = locals.list[e];
                        buf.push('\n<div class="file2 file2-2 ', (__stack.lineno = 5, a.styles), '" data-path="', (__stack.lineno = 5, 
                        a.filepath), '" data-id="', (__stack.lineno = 5, a.id), '" data-folder="', (__stack.lineno = 5, 
                        a.folderpath), '" data-name="', (__stack.lineno = 5, a.filename || a.fname), '" ');
                        __stack.lineno = 5;
                        if (a.styleStatus === "complete") {
                            buf.push('data-action="task.openFolder"');
                            __stack.lineno = 5;
                        }
                        buf.push('>\n	<div class="file-icon">\n		<div class="filesmall-', (__stack.lineno = 7, 
                        a.icon), '"></div>\n		<i></i>\n	</div>\n	<div class="file-info">\n		<div class="filename">\n			<div class="name">', (__stack.lineno = 12, 
                        a.name), "</div>\n			");
                        __stack.lineno = 13;
                        if (a.orcType === 1) {
                            buf.push('\n				<div class="suffix">', (__stack.lineno = 14, a.suf), "</div>\n			");
                            __stack.lineno = 15;
                        }
                        buf.push('\n		</div>\n		<div class="loading">\n			<div class="bar" style="width:', (__stack.lineno = 18, 
                        a.cPercent), '%;"></div>\n		</div>\n		');
                        __stack.lineno = 20;
                        if (a.failedFileList && a.failedFileList.length > 0) {
                            buf.push('\n			<div class="wording"  data-action="task.openfail">\n				<i class=\'warn\'></i>有', (__stack.lineno = 22, 
                            a.failedFileList.length), '个文件下载失败<i class="arrow"></i>\n					<ul class="fail-list">\n						');
                            __stack.lineno = 24;
                            for (var i = 0, n = a.failedFileList.length; i < n; i++) {
                                buf.push(" \n							<li>", escape((__stack.lineno = 25, a.failedFileList[i].filename)), "</li>\n						");
                                __stack.lineno = 26;
                            }
                            buf.push("\n					</ul>\n			</div>\n		");
                            __stack.lineno = 29;
                        } else {
                            buf.push('\n			<div class="wording">', (__stack.lineno = 30, a.wording), "</div>		\n		");
                            __stack.lineno = 31;
                        }
                        buf.push('\n	</div>\n	<div class="file-action">\n		<div class="aria-hide">\n			<a class="aria-tips" tabindex="-1">\n				');
                        __stack.lineno = 36;
                        if (a.orcType === 1) {
                            buf.push("\n					文件", escape((__stack.lineno = 37, a.name)), "", (__stack.lineno = 37, 
                            a.suf), "\n				");
                            __stack.lineno = 38;
                        } else {
                            buf.push("\n					文件夹", escape((__stack.lineno = 39, a.name)), "\n				");
                            __stack.lineno = 40;
                        }
                        buf.push("\n				 状态:", (__stack.lineno = 41, a.wording), " 任务进度", (__stack.lineno = 41, 
                        a.cPercent), '% \n			</a>\n		</div>\n		<a href="javascript:void(0)" class="seat"  tabindex="-1"></a>\n		<a class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 ', escape((__stack.lineno = 45, 
                        a.name)), '" tabindex="-1"></a>\n		<a class="resume" data-action="task.resume" title="启动" aria-label="启动任务 ', escape((__stack.lineno = 46, 
                        a.name)), '" tabindex="-1"></a>\n		<a class="continue" data-action="task.continue" title="续传" aria-label="续传任务 ', escape((__stack.lineno = 47, 
                        a.name)), '" tabindex="-1"></a>\n		<a class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 ', escape((__stack.lineno = 48, 
                        a.name)), '" tabindex="-1"></a>\n		<a class="ok-upload"></a>\n		<a class="ok-download"></a>\n		<a class="go-folder" data-action="task.openFolderIco" title="打开该文件所在的文件夹" arir-label="打开', escape((__stack.lineno = 51, 
                        a.name)), '所在的文件夹" tabindex="3"></a>\n	</div>\n	<div></div>\n</div>\n');
                        __stack.lineno = 55;
                    }
                    buf.push(" ");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<%\r\n	var item = locals.item;\r\n%>				\r\n<i class=\'warn\'></i>有<%-item.failedFileList.length%>个文件下载失败<i class="arrow"></i>\r\n<ul class="fail-list">\r\n	<%for(var j = 0,m = item.failedFileList.length;j<m;j++){%> \r\n		<li><%=item.failedFileList[j].filename%></li>\r\n	<%}%>\r\n</ul>',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push("");
                    __stack.lineno = 1;
                    var e = locals.item;
                    buf.push("				\n<i class='warn'></i>有", (__stack.lineno = 4, e.failedFileList.length), '个文件下载失败<i class="arrow"></i>\n<ul class="fail-list">\n	');
                    __stack.lineno = 6;
                    for (var t = 0, a = e.failedFileList.length; t < a; t++) {
                        buf.push(" \n		<li>", escape((__stack.lineno = 7, e.failedFileList[t].filename)), "</li>\n	");
                        __stack.lineno = 8;
                    }
                    buf.push("\n</ul>");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(e, t, a) {
    "use strict";
    var i = a(88);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(54);
    var l = $("#selectFileNum");
    function s(e) {
        l.text(e);
    }
    function f(e) {
        var t = false;
        var a = false;
        for (var i = 0, n = e.length; i < n; i++) {
            var r = e[i];
            var l = r.value;
            var s = o.getData(l);
            if (s.admin) {
                t = true;
            }
            a = true;
        }
        if (e.length > 0) {
            $("#batchSaveAs").removeClass("disabled");
        } else {
            $("#batchSaveAs").addClass("disabled");
        }
        if (!t) {
            $("#batchDel").addClass("disabled");
            $("#batchMove").addClass("disabled");
        } else {
            $("#batchDel").removeClass("disabled");
            $("#batchMove").removeClass("disabled");
        }
        if (a) {
            $("#batchDown").removeClass("disabled");
        } else {
            $("#batchDown").addClass("disabled");
        }
    }
    function d() {
        return $(".scroll-dom .selected").length ? true : false;
    }
    function c() {
        if (G.mac || d()) {
            return;
        }
        var e = G.onlyGetDom()[0];
        var t = e.querySelectorAll(".cbox:checked");
        report("showSelectAll");
        report("showBatch");
        $(".nav").removeClass("hide");
        $("body").addClass("batch-mode");
        $(".file.list-item").attr("data-action", "file.select");
        f(t);
        s(t.length);
    }
    function u() {
        n.default["menu.closeBatch"]();
    }
    function p() {
        var e = G.getDomPanel()[0];
        report("clkSelectAll");
        report("clkBatch");
        G.getDomPanel().find(".cbox").prop("checked", true);
        var t = e.querySelectorAll(".cbox:checked");
        s(t.length);
    }
    function v() {
        var e = G.getDomPanel()[0];
        var t = $(this).find(".cbox");
        if (!t.prop("checked")) {
            t.prop("checked", true);
        } else {
            t.prop("checked", false);
        }
        var a = e.querySelectorAll(".cbox:checked");
        s(a.length);
    }
    var m = $("#downloadFile button");
    function h(e) {
        if (e) {
            m.attr("class", "icons-download-batch");
        } else {
            m.attr("class", "icons-download-batch-disabled disabled");
        }
    }
    function g() {
        var e = G.getDomPanel()[0];
        var t = e.querySelectorAll(".file");
        s(t.length);
    }
    e.exports = {
        allSelectNum: g,
        check: c,
        exit: u,
        selectAll: p,
        select: v,
        changeDownLoadBtn: h
    };
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.doClearFile = t.clickClearFile = undefined;
    var i = a(84);
    var n = l(i);
    var r = a(180);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = $("#cleanFile");
    var f = $("#cleanProg");
    var d = t.clickClearFile = function u() {
        if (!G.info.isMaster) {
            return;
        }
        reportNew("cleanEntry");
        o.default.showBatchPanel(s, {
            title: "提示",
            action: "file.doClearFile",
            text: '将为你保留最近的1500个文件和文件夹，并删除之前的所有文件<div class="warming">注意:本操作不可恢复，请自行备份</div>',
            okBtnText: "确定删除"
        });
    };
    var c = t.doClearFile = function p() {
        if (!G.info.isMaster) {
            return;
        }
        o.default.hide(s);
        o.default.show(f);
        n.default.cleanFile().done(function(e) {}).fail(function(e) {
            o.default.hide(f);
        });
        reportNew("clickClean", {
            ver1: 0
        });
        var e = 0;
        var t = function a() {
            n.default.getFileCount().done(function(t) {
                if (t.ec === 0 && !t.is_too_many) {
                    o.default.hide(f);
                    clearTimeout(e);
                    location.reload();
                } else {
                    e = setTimeout(a, 2e3);
                }
            }).fail(function(t) {
                e = setTimeout(a, 2e3);
            });
        };
        t();
    };
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.default = i;
    function i() {
        var e = this.parentNode;
        var t = e.querySelector(".error-message");
        if (t.style.display == "block") {
            t.style.display = "none";
        } else {
            t.style.display = "block";
        }
    }
}, function(e, t, a) {
    "use strict";
    "user strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.sortFile = v;
    var i = a(54);
    var n = c(i);
    var r = a(84);
    var o = c(r);
    var l = a(31);
    var s = c(l);
    var f = a(88);
    var d = c(f);
    function c(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var u = {
        time: 1,
        type: 2,
        user: 3,
        name: 4,
        size: 5,
        download: 6
    };
    var p = {
        time: 0,
        type: 0,
        user: 0,
        name: 0,
        size: 0,
        download: 0
    };
    function v(e) {
        if (G.module() == 3 || G.module() == 2) {
            return;
        }
        d.default["menu.closeBatch"]();
        var t = $(this).data("type");
        var a = $(this).data("sort");
        if (!a) {
            a = 1;
        } else {
            a = parseInt(a);
            if (a === 1) {
                a = 2;
            } else {
                a = 1;
            }
        }
        p[t] = a;
        $(".list-thead").find(".sort-up").removeClass("sort-up");
        $(".list-thead").find(".sort-down").removeClass("sort-down");
        $(this).attr("data-sort", a);
        if (a === 1) {
            this.parentNode.classList.add("sort-up");
        } else {
            this.parentNode.classList.add("sort-down");
        }
        var i = function r(e) {
            var i = "#list" + G.nowFolder.replace("/", "-");
            if (G.nowFolder === "/") {
                i = "#fileListDom";
            }
            $(i).attr("data-type", t).attr("data-sort", a);
        };
        var n = {
            paramsFilter: {
                folderId: G.nowFolder,
                sort_by: u[t],
                sort_order: a
            },
            renderParams: {
                sort_order: a
            },
            succ: i
        };
        reportNew("sortFile", {
            ver1: u[t],
            ver2: a
        });
        s.default.getList({
            folderId: G.nowFolder,
            sort_by: u[t],
            sort_order: a
        });
    }
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = l(i);
    var r = a(37);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = a(126);
    var f = a(82);
    var d = $("#upload-panel");
    var c = {
        folderTree: a(258),
        showFolderTreePanel: a(180).showFolderTreePanel,
        panel: a(180)
    };
    var u = a(22);
    var p = G.folderVersion;
    var v = a(175);
    var m = a(54);
    var h = a(18);
    var g = void 0;
    function w() {
        if (u.getTips()) {
            f.addUploadTask();
        } else {
            report("showOldVersion");
            $("#updateQQ").addClass("open");
            $("#updateQQTips").text("当前版本仅支持将文件上传至群文件首页，升级至QQ最新版本可上传文件至文件夹内。");
            $("#updateQQ").find("input.btn-notips").attr("data-action", "upload.cUpload");
        }
    }
    function b() {
        if (this.checked) {
            u.setTips(1);
            G.oldVersion = true;
            $("#headerBatch .store").addClass("disabled");
            report("clkNotRemind");
        } else {
            u.setTips(0);
        }
    }
    function _() {
        $("#updateQQ").removeClass("open");
        f.addUploadTask();
    }
    function k() {
        if (G.file.isFull) {
            reportNew("limitTip", {
                ver1: 0
            });
            return h.show("alert", "文件数已达到上限");
        }
        if (this.nodeName === "LI") {
            reportNew("blankRightMenuClick", {
                ver1: G.customMenuLength ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: 1
            });
        }
        if (G.info.version < p) {
            w();
        } else {
            if (G.folderMap() && (0, o.default)(G.folderMap()).length > 0 || G.nowFolder !== "/") {
                f.getBatchFiles();
            } else {
                report("clkUpload", G.module());
                f.addUploadTask();
            }
        }
    }
    function y(e) {
        if (!g) {
            return;
        }
        var t = void 0;
        if (typeof e === "string") {
            report("clkUpload", 1);
            t = e;
        } else {
            t = G.folderTree && G.folderTree.selected && G.folderTree.selected.id || "/";
        }
        if ($("#inputFolderNameInFolderTree").length > 0) {
            v["folderTree.create"](null, function() {
                t = G.folderTree.selected && G.folderTree.selected.id || "/";
                var e = f.batchUpload(t, (0, n.default)(g));
                g = null;
                c.panel.hideAll();
            });
        } else {
            var a = f.batchUpload(t, (0, n.default)(g));
            g = null;
            c.panel.hideAll();
        }
    }
    function x(e, t) {
        if (G.file.isFull) {
            reportNew("limitTip", {
                ver1: 0
            });
            return h.show("alert", "文件数已达到上限");
        }
        if (!t || t.length === 0) {
            return;
        }
        var a = void 0;
        a = e;
        var i = "上传到群文件？";
        if (a !== "/") {
            var r = m.getData(a);
            i = "上传到文件夹：" + r.fnameEsc + "？";
        }
        var o = f.confirm(1, "提示", i);
        if (o.errorCode === 0 && o.ret) {
            report("clkUpload", 1);
            var l = f.batchUpload(a, (0, n.default)(t));
            c.panel.hideAll();
        }
    }
    function F() {
        d.addClass("open");
    }
    function T(e) {
        var t = e[0];
        var a = e.length;
        var i = t.lastIndexOf("\\");
        var n = t.substr(i + 1);
        if (G.mac) {
            i = t.lastIndexOf("/");
            n = t.substr(i + 1);
        }
        console.log(t);
        var r = s.getFileName(n);
        if (a > 1) {
            return '<span class="name">' + r.filename_name + "</span><span>" + r.filename_suf + '</span>等<span class="blue">' + a + "</span>个文件";
        } else {
            return '<span class="name">' + r.filename_name + "</span><span>" + r.filename_suf + "</span>";
        }
    }
    function C(e) {
        g = e;
        if (G.nowFolder !== "/") {
            y(G.nowFolder);
            return;
        }
        var t = {
            title: "上传文件",
            firstFileName: T(e),
            action: "上传到：",
            destFolder: "群文件",
            okAction: "file.batchUpload"
        };
        c.showFolderTreePanel(t);
        var a = $("#containerFolderTreePanel");
        a.find("#folderTreePanel").addClass("open");
        report("folderTree", 0);
        return;
    }
    function S() {
        report("clkUpdateQQ");
    }
    e.exports = {
        batchuploadInFolder: x,
        upload: k,
        bupload: y,
        showUpload: C,
        noTips: b,
        cupload: _,
        update: S
    };
}, function(e, t, a) {
    "use strict";
    var i = a(180);
    var n = a(54);
    var r = a(31);
    var o = a(84);
    var l = a(171);
    var s = a(259);
    var f = a(82);
    var d = a(180);
    var c = $("#folderPanel");
    var u = $(G.handler);
    function p() {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkRenameFile", G.module());
        var e = G.selectRow;
        var t = G.getReportInfo(e);
        t.ver3 = 7;
        reportNew("fileRightMenuClick", t);
        i.show(c, {
            title: "重命名",
            tips: "请为文件输入新名称",
            action: "file.renameFile",
            showValue: G.selectRow.nameEsc
        });
    }
    function v() {
        var e = c.find(".new-name").val();
        var t = G.selectRow;
        var a = {
            file_id: t.fp,
            app_id: G.appid,
            new_file_name: e + t.suf,
            bus_id: t.busid,
            parent_folder_id: G.nowFolder
        };
        o.renameFile(a).done(function(a) {
            if (a.ec === 0) {
                t.name = e;
                t.nameEsc = l.decode(e);
                t.fname = e + t.suf;
                t.fnameEsc = l.decode(t.fname);
                n.updateFile(t, "rename");
                r.updateRow(t, "rename");
                u.trigger("file.thumbUpdate", t);
            }
            d.hideAll();
        }).fail(function(e) {
            s.showError(e.ec, c);
            report("renameFileError");
        });
    }
    e.exports = {
        showFileRename: p,
        renameFile: v
    };
}, function(e, t, a) {
    "use strict";
    var i = a(260);
    var n = r(i);
    function r(e) {
        if (e && e.__esModule) {
            return e;
        } else {
            var t = {};
            if (e != null) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) t[a] = e[a];
                }
            }
            t.default = e;
            return t;
        }
    }
    var o = a(54);
    var l = a(84);
    var s = a(31);
    var f = a(82);
    var d = $(G.handler);
    var c = 5485;
    function u(e) {
        var t = document.createElement("div");
        var a = this.getBoundingClientRect();
        var i = function r() {
            var e = document.height;
            var t = G.getDomPanel();
            var a = t[0].scrollHeight;
            if (a + 52 > e) {
                return true;
            }
            return false;
        };
        t.innerHTML = '<div class="img"></div>';
        t.className = "file-animate files-" + e.icon;
        var n = window.innerWidth - a.left - 3;
        if (G.info.isAdmin && G.nowFolder === "/") {
            n += 37;
        }
        if (!i()) {
            n += 10;
        }
        if (G.mac) {
            n = 177;
        }
        t.style.right = n + "px";
        t.style.top = a.top - 20 + "px";
        document.body.appendChild(t);
        setTimeout(function() {
            document.body.removeChild(t);
        }, 1500);
    }
    function p(e, t) {
        if (e) {
            var a = G.getReportInfo(e);
            if (t === 1) {
                a.ver7 = G.module() === 3 ? 2 : 1;
                reportNew("doubleClickFile", a);
            } else if (t === 2) {
                a.ver3 = 1;
                reportNew("fileRightMenuClick", a);
            }
            if (e.isDown && t !== 0) {
                n.edit(e);
                return;
            }
            var i = a;
            i.ver1 = G.module();
            i.ver2 = 1;
            i.ver3 = a.ver4;
            i.ver4 = a.ver5;
            i.ver5 = t;
            i.ver7 = G.info.role;
            reportNew("fileDownload", i);
            var r = e.filepath;
            var o = e.fnameEsc;
            var l = e.size;
            e.isDowning = true;
            var d = {
                bs: e.t,
                fp: e.fp
            };
            var c = this;
            s.updateRow(e);
            var u = f.addDownloadTask(r, o, l, true, false);
            console.debug("realdown", u);
        }
    }
    function v() {
        var e = G.selectRow;
        p(e, 2);
    }
    function m() {
        var e = $(this);
        var t = e.data("path");
        var a = o.getData(t);
        if (a.safeType) {
            var i = G.getReportInfo(a);
            i.ver3 = i.ver4;
            i.ver4 = i.ver5;
            i.ver5 = a.isDown ? 2 : 1;
            reportNew("blackTips", i);
            f.alert(2, "提示", "该文件存在安全风险，无法正常使用");
        } else {
            p(a, 1);
        }
    }
    function h() {
        var e = $(this).closest(".list-item");
        var t = e.data("path");
        var a = o.getData(t);
        G.saveasList[a.filepath] = 1;
        p(a, 0);
    }
    function g() {
        var e = G.selectRow;
        var t = this;
        report("clkDownloadBtn", G.module());
        if (e) {
            var a = e.filepath;
            var i = e.fnameEsc;
            var n = e.size;
            e.isDowning = true;
            var r = {
                bs: e.t,
                fp: e.fp
            };
            var o = this;
            u.call(o, e);
            s.updateRow(e);
            f.addDownloadTask(a, i, n, true);
        }
    }
    function w(e) {
        var t = function r(e) {
            var t = e.filepath;
            var a = e.fnameEsc;
            var i = e.size;
            var n = {
                bs: e.t,
                fp: e.fp
            };
            f.addDownloadTask(t, a, i, true);
        };
        for (var a = 0, i = e.length; a < i; a++) {
            var n = e[a];
            G.saveasList[n.filepath] = 1;
            t(n);
        }
    }
    e.exports = {
        download: g,
        downloadByDom: m,
        downloadByMenu: v,
        downloadByBtn: h,
        downloadBatch: w
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(82);
    var r = a(174);
    var o = $(G.handler);
    function l() {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkRepost", G.module());
        var e = G.selectRow;
        var t = G.getReportInfo(e);
        t.ver3 = 4;
        reportNew("fileRightMenuClick", t);
        if (e) {
            var a = e.filepath;
            var i = e.fnameEsc;
            var r = e.size;
            n.forwardFile(i, a, r);
            o.trigger("menu.hide");
        } else {}
    }
    function s(e) {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkPhone", G.module());
        var t = G.selectRow;
        var a = G.getReportInfo(t);
        a.ver3 = 5;
        reportNew("fileRightMenuClick", a);
        if (t) {
            var i = t.filepath;
            var r = t.fnameEsc;
            var l = t.size;
            var s = n.forwardFileToDataLine(r, i, l);
            console.log(s);
            o.trigger("menu.hide");
        } else {}
    }
    e.exports = {
        forward: l,
        toMobile: s
    };
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(54);
    var l = a(84);
    var s = a(82);
    var f = a(31);
    var d = a(126);
    var c = a(31);
    var u = a(174);
    var p = 2;
    var v = a(22);
    var m = a(20);
    var h = $(G.handler);
    function g() {
        h.trigger("menu.hide");
        report("clkDeleteFile", G.module());
        var e = G.selectRow;
        if (e) {
            var t = G.getReportInfo(e);
            t.ver3 = 8;
            reportNew("fileRightMenuClick", t);
            var a = s.confirm(2, "提示", "你确定要删除文件" + e.fnameEsc + "吗?");
            if (a.errorCode === 0 && a.ret) {
                var i = {
                    bus_id: parseInt(e.busid),
                    file_id: e.fp,
                    app_id: 4,
                    parent_folder_id: G.nowFolder || "/"
                };
                l.deleteFile(i).done(function(t) {
                    o.remove(e.filepath);
                    f.removeRow(e);
                    v.setClist(e, "delete");
                    o.updateAllNum({
                        files: [ e ],
                        action: "remove"
                    });
                    G.file.capacityused = d.getSize(G.file.cu);
                    c.renderSpace();
                    h.trigger("toast.show", {
                        type: "suc",
                        text: "删除成功"
                    });
                    m.init(G.file.isTooMany || G.file.isFull);
                    if (e.safeType) {
                        var a = G.getReportInfo(e);
                        a.ver6 = a.ver3;
                        a.ver3 = a.ver4;
                        a.ver4 = a.ver5;
                        a.ver5 = e.size;
                        reportNew("blackDelete", a);
                    }
                }).fail(function(e) {
                    s.alert(2, "提示", "删除失败");
                    report("delFileError");
                });
            }
        }
    }
    function w(e, t) {
        h.trigger("menu.hide");
        var a = [];
        var i = {};
        var r = 1;
        var u = 0;
        var g = 0;
        var w = function y() {
            u++;
            if (u === r) {
                G.scrollHandler && G.scrollHandler.getData();
            }
        };
        var b = function x() {
            var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
            if (e.length === 0) {
                return;
            }
            var a = {};
            var i = [];
            for (var p = 0, h = e.length; p < h; p++) {
                i[p] = {
                    gc: parseInt(G.info.gc),
                    app_id: G.appid,
                    bus_id: e[p].busid,
                    file_id: e[p].fp,
                    parent_folder_id: G.nowFolder || "/"
                };
            }
            a.file_list = (0, n.default)({
                file_list: i
            });
            l.deleteFile(a).done(function(a) {
                var i = [];
                if (a.fail) {
                    i = a.fail;
                    for (var n = e.length - 1; n >= 0; n--) {
                        if ($.inArray(e[n].fp, i)) {
                            e.splice(n, 1);
                        }
                    }
                }
                report("batchDeleteSuc");
                var l = e.length;
                g += l;
                e.forEach(function(e) {
                    f.removeRow(e);
                    o.remove(e.filepath);
                    v.setClist(e, "delete");
                    if (e.safeType) {
                        var t = G.getReportInfo(e);
                        t.ver6 = t.ver3;
                        t.ver3 = t.ver4;
                        t.ver4 = t.ver5;
                        t.ver5 = e.size;
                        reportNew("blackDelete", t);
                    }
                });
                o.updateAllNum({
                    files: e,
                    action: "remove"
                });
                G.file.capacityused = d.getSize(G.file.cu);
                c.renderSpace();
                w(g);
                console.debug("删除成功", u, r, a);
                if (u === r) {
                    t(g);
                }
                m.init(G.file.isTooMany || G.file.isFull, "delete");
            }).fail(function(e) {
                s.alert(2, "提示", "删除失败");
                $(G.handler).trigger("panel.hideAll");
                report("delFileError");
            });
        };
        e.forEach(function(e) {
            if (e.remove) {
                a.push(e);
                i[e.fp] = e;
            }
        });
        r = Math.ceil(a.length / p);
        if (r === 1) {
            b(a);
        } else {
            for (var _ = 0; _ < r; _++) {
                var k = a.slice(_ * p, (_ + 1) * p);
                b(k);
            }
        }
        return true;
    }
    e.exports = {
        removeOne: g,
        removeBatch: w
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(82);
    var r = a(172);
    var o = $(G.handler);
    var l = [ "图片" ];
    function s(e) {
        e.usedTime++;
        o.trigger("toast.hide");
        n.preview(e.previewObj.url);
    }
    function f() {
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
        var t = void 0;
        var a = $(this);
        var f = void 0;
        if (e) {
            t = e;
        } else {
            var d = a.data("path");
            t = i.getFile(d);
            if (!t) {
                var c = G.selectRow.path;
                t = i.getFile(c);
            }
            if (!t) {
                var u = G.selectRow.path;
                t = i.getFile(u);
            }
        }
        if (!t) {
            return;
        }
        if (t.safeType) {
            var p = G.getReportInfo(t);
            p.ver3 = p.ver4;
            p.ver4 = p.ver5;
            p.ver5 = t.isDown ? 2 : 1;
            reportNew("blackTips", p);
            n.alert(2, "提示", "该文件存在安全风险，无法正常使用");
            return;
        }
        var v = t.filepath;
        var m = t.remotetype;
        var h = t.fnameEsc || t.fname;
        var g = t.size;
        var w = t.filetype;
        if ($.inArray(w, l) >= 0) {
            if (g > 20 * 1024 * 1024) {
                n.alert(2, "提示", "图片太大不支持预览，请直接下载");
            } else {
                t.usedTime++;
                o.trigger("toast.show", {
                    type: "wait",
                    text: "正在加载预览图…"
                });
                r.getOneThumb(t, s);
            }
        } else {
            try {
                n.previewFile(v, h);
            } catch (b) {
                console.log(b);
            }
        }
    }
    function d() {
        if (this.classList && this.classList.contains("disable")) {
            return;
        }
        o.trigger("menu.hide");
        var e = G.selectRow;
        if (e) {
            f(e);
        }
    }
    e.exports = {
        preview: f,
        menupreview: d
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        folderTree: a(258),
        showFolderTreePanel: a(180).showFolderTreePanel
    };
    var n = a(84);
    var r = a(31);
    var o = a(259);
    var l = a(180);
    var s = a(174);
    var f = a(175);
    var d = a(132);
    var c = a(82);
    var u = $(G.handler);
    var p = a(54);
    var v = a(129);
    var m = a(18);
    var h = 10;
    var g = $("#batchPanel");
    function w(e) {
        console.debug("move file", e);
        if (e) {
            var t = +new Date();
            e.mt = Math.floor(t / 1e3);
            e.mtStr = v.getDateStr(e.mt);
            e.mtoStr = v.getorcDateStr(e.mt);
            r.removeFold(e);
            r.appendFold(e);
        }
        s["panel.close"]();
    }
    function b(e) {
        var t = [];
        var a = e.list;
        for (var i = a.length - 1; i >= 0; i--) {
            var n = a[i];
            if (G.info.isAdmin || G.info.uin === n.uin) {
                t.push(n);
            }
        }
        G.secondMove = {
            list: t,
            folderId: e.folderId,
            isDrag: e.flag
        };
        if (t.length !== a.length) {
            l.showBatchPanel(g, {
                title: "批量移动",
                action: "file.secondMove",
                text: '您选择了<span class="red">' + a.length + '</span>个文件,其中<span  class="red">' + t.length + '</span>个文件可以移动<br>您确定要移动这<span  class="red">' + t.length + "</span>个文件吗?"
            });
        } else if (e.flag) {
            y(t, e.folderId, e.flag);
        } else if (!e.flag) {
            k();
        }
    }
    function _(e, t, a) {
        if (G.file.isFull) {
            return m.show("alert", "文件数已达到上限");
        }
        if (this.classList && this.classList.contains("disable")) {
            return;
        }
        var i = e || G.selectRows;
        if (!i) {
            badjsReport.info("无选择目标");
            return;
        }
        b({
            list: i,
            flag: false
        });
    }
    function k() {
        var e = G.secondMove.list;
        var t = e[0];
        var a = G.getReportInfo(t);
        if (e.length > 1) {
            reportNew("chooseRightMenuClick", a);
        } else {
            a.ver3 = 5;
            reportNew("fileRightMenuClick", a);
        }
        var n = G.folderMap()[G.nowFolder];
        var r = {
            title: "移动文件",
            firstFileName: e[0].fname,
            fileNum: e.length,
            action: "移动到：",
            destFolder: G.nowFolder === "/" ? "群文件" : n.fname,
            okAction: "file.move"
        };
        i.showFolderTreePanel(r);
        var o = $("#containerFolderTreePanel");
        o.find(".active .aria-hide").eq(0).focus();
        report("folderTree", 1);
        report("clkFolderMove");
    }
    function y(e, t, a) {
        var i = [];
        var l = {};
        var f = [];
        if (e.length === 1) {
            var v = p.getData(e[0].filepath);
            if (v && v.safeType) {
                c.alert(2, "提示", "该文件存在安全风险，无法正常使用");
                return;
            }
        } else {
            for (var m = e.length; m--; ) {
                var g = p.getData(e[m].filepath);
                if (g && g.safeType) {
                    e.splice(m, 1);
                }
            }
        }
        for (var b = e.length - 1; b >= 0; b--) {
            var _ = e[b];
            if (G.info.isAdmin || G.info.uin === _.uin) {
                i.push({
                    file_id: _.fp,
                    bus_id: parseInt(_.busid),
                    parent_folder_id: _.parentId,
                    dest_folder_id: t,
                    app_id: G.appid,
                    gc: G.info.gc
                });
                f.push(_);
                l[e[b].fp] = e[b];
            }
        }
        d.exit();
        G.secondMove = {};
        var k = function M() {
            T++;
            if (T >= F) {
                u.trigger("toast.hide");
            }
        };
        var y = function D() {
            var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
            if (e.length === 0) {
                return;
            }
            n.moveFile(e).done(function(i) {
                k();
                var n = e;
                if (i.fail) {
                    var o = [];
                    try {
                        o = JSON.parse(i.fail).fail;
                    } catch (s) {}
                    for (var f = o.length - 1; f >= 0; f--) {
                        if (l[o[f]]) {
                            n.splice(f, 1);
                        }
                    }
                }
                if (e.length > 1) {
                    report("batchMoveSuc");
                    if (a) {
                        reportNew("chooseDrag", {
                            ver1: 1,
                            ver2: G.info.isAdmin ? 1 : 2,
                            ver5: 1
                        });
                    }
                } else {
                    report("moveFileSuc");
                    if (a) {
                        reportNew("chooseDragSinge", {
                            ver1: 1,
                            ver2: G.info.isAdmin ? 1 : 2,
                            ver5: 1
                        });
                    }
                }
                for (var d = n.length - 1; d >= 0; d--) {
                    var c = n[d];
                    var u = "/" + c.bus_id + c.file_id;
                    c = G.fileMap()[u];
                    c.parentId = t;
                    p.updateFile(c, "rename");
                    r.removeRow(c);
                    r.appendFileToFolder(c);
                }
                var v = void 0;
                if (v = G.folderMap()[t]) {
                    v.filenum += n.length;
                    $('[id="' + v.domid + '"]').find(".file-size").html(v.filenum + "个文件");
                }
                w(v);
                return;
            }).fail(function(t) {
                k();
                o.showError(t.ec);
                report("showMoveFail");
                report("moveFileError");
                if (a) {
                    if (e.length > 1) {
                        reportNew("chooseDrag", {
                            ver1: 1,
                            ver2: G.info.isAdmin ? 1 : 2,
                            ver5: 2
                        });
                    } else {
                        reportNew("chooseDragSinge", {
                            ver1: 1,
                            ver2: G.info.isAdmin ? 1 : 2,
                            ver5: 2
                        });
                    }
                }
                console.log("fail", t);
            });
        };
        var x = i.length;
        var F = Math.ceil(x / h);
        var T = 0;
        u.trigger("toast.show", {
            type: "wait",
            text: "正在移动文件",
            autoHide: false
        });
        if (F) {
            for (var C = 0; C < F; C++) {
                var S = i.slice(C * h, (C + 1) * h);
                y(S);
            }
        } else {
            k();
            s["panel.close"]();
        }
        return true;
    }
    function x() {
        f["folderTree.create"](null, function() {
            if (!G.selectRows) {
                return;
            }
            var e = G.folderTree.selected.id;
            if (e === G.nowFolder) {
                console.log("can not move to the same folder");
                u.trigger("toast.show", {
                    type: "alert",
                    text: "文件已在目标位置"
                });
                return;
            }
            y(G.selectRows, e);
        });
    }
    function F() {
        $("#batchPanel").removeClass("open");
        console.log("secondMove", G.secondMove);
        if (G.secondMove.isDrag) {
            y(G.secondMove.list, G.secondMove.folderId, G.secondMove.isDrag);
        } else {
            k();
        }
    }
    function T(e, t, a) {
        b({
            list: e,
            folderId: t,
            flag: true
        });
    }
    e.exports = {
        showMove: _,
        move: x,
        movelist: T,
        secondMove: F
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(188);
    var r = $(G.handler);
    function o() {
        var e = G.selectRow;
        report("clkJubao");
        if (e) {
            var t = G.getReportInfo(e);
            t.ver3 = 9;
            reportNew("fileRightMenuClick", t);
            var a = "http://jubao.qq.com/cn/jubao?appname=im&subapp=group_file&jubaotype=article";
            if (G.checkHttps()) {
                a = "https://proxy.qun.qq.com/tx_tls_gate=jubao.qq.com/cn/jubao?appname=im&subapp=group_file&jubaotype=article";
            }
            a += "&impeachuin=" + G.info.uin;
            a += "&uin=" + e.uin;
            a += "&fid=" + e.fp;
            a += "&fname=" + encodeURIComponent(e.fnameEsc);
            a += "&ut=" + e.ct;
            a += "&fs=" + e.size;
            a += "&dt=" + e.down;
            a += "&t=" + e.t;
            a += "&mt=" + e.mt;
            a += "&exp=" + e.exp;
            a += "&gid=" + G.info.gc;
            n.show(encodeURI(a));
        }
        r.trigger("menu.hide");
    }
    e.exports = o;
}, function(e, t, a) {
    "use strict";
    var i = a(142);
    var n = a(138);
    var r = a(140);
    var o = a(145);
    var l = a(54);
    var s = a(180);
    var f = a(132);
    var d = $("#batchPanel");
    var c = a(22);
    var u = G.folderVersion;
    var p = 0;
    var v = 0;
    var m = 0;
    var h = 0;
    var g = [];
    function w(e) {
        if (c.getTips()) {} else {
            report("showOldVersion");
            b();
        }
    }
    function b() {
        $("#updateQQ").addClass("open");
        $("#updateQQTips").text("当前版本不支持批量另存功能，请升级QQ至最新版本后体验");
        $("#updateQQ").find("input.btn-notips").attr("data-action", "panel.close");
    }
    function _(e, t) {
        switch (e) {
          case 1:
            if (p === m) {
                return "你确定要删除" + p + "个文件吗?";
            } else {
                return '您选择了<span class="red">' + p + '</span>个文件,其中<span class="red">' + m + '</span>个文件可以删除<br>您确定要删除这<span class="red">' + m + "</span>个文件吗?";
            }
            break;

          case 2:
            return "正在删除文件";
            break;

          case 3:
            return '已经成功删除<span class="red">' + t + "</span>个文件";
            break;
        }
    }
    function k() {
        p = 0;
        v = 0;
        m = 0;
        g = [];
    }
    function y() {
        k();
        var e = G.onlyGetDom().find("input:checked");
        var t = G.onlyGetDom().find(".selected");
        var a = [];
        var i = void 0;
        if (e.length > 0) {
            i = e;
        } else if (t.length > 0) {
            i = t;
        }
        p = i.length;
        i.each(function() {
            var e = this.value || $(this).data("path");
            var t = l.getData(e);
            if (t) {
                if (t.remove) {
                    m++;
                }
                h++;
                a.push(t);
            }
        });
        G.selectRows = a;
        G.inBatchMode = false;
        G.batchMode = false;
        return a;
    }
    function x() {
        if (this.classList.contains("disabled")) {
            return;
        }
        report("batchDownload");
        s.hide(d);
        n.downloadBatch(y());
        f.exit();
    }
    function F() {
        if (this.classList.contains("disabled")) {
            return;
        }
        g = y();
        var e = G.getReportInfo(g[0]);
        e.ver3 = 3;
        reportNew("chooseRightMenuClick", e);
        s.showBatchPanel(d, {
            title: "批量删除",
            action: "batch.removeAction",
            text: _(1)
        });
    }
    function T() {
        report("batchDelete");
        s.showBatchPanel(d, {
            title: "批量删除",
            hideAll: true,
            text: _(2)
        });
        f.exit();
        r.removeBatch(g, function(e) {
            s.showBatchPanel(d, {
                title: "批量删除",
                action: "batch.removeAction",
                hideOk: true,
                closeText: "关闭",
                text: _(3, e)
            });
            k();
        });
    }
    function C() {
        if (this.classList.contains("disabled")) {
            return;
        }
        report("batchMove");
        g = y();
        i.showMove();
        return;
    }
    function S() {
        report("batchSaveAs");
        var e = function t() {
            y();
            var e = G.selectRows;
            f.exit();
            var t = [];
            console.log(e, G.selectRows);
            for (var a = e.length - 1; a >= 0; a--) {
                var i = e[a];
                t.push({
                    filepath: i.filepath,
                    filename: i.fnameEsc,
                    fname: i.fname,
                    filetype: i.filetype,
                    filesize: i.size,
                    domid: i.domid,
                    orcType: i.orcType
                });
            }
            o.saveBatch(t);
        };
        if (G.info.version < u) {
            w(e);
        } else {
            e();
        }
    }
    e.exports = {
        remove: F,
        removeAction: T,
        downloadAction: x,
        move: C,
        save: S,
        getTipsText: _
    };
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(82);
    var l = a(54);
    var s = a(84);
    var f = $(G.handler);
    G.saveasList = {};
    function d(e) {
        var t = e || G.selectRow;
        report("clkSaveAs", G.module());
        try {
            var a = G.getReportInfo(t);
            var i = a;
            a.ver3 = 2;
            reportNew("fileRightMenuClick", a);
            i.ver1 = G.module();
            i.ver2 = 1;
            i.ver3 = a.ver4;
            i.ver4 = a.ver5;
            i.ver5 = 3;
            i.ver7 = G.info.role;
            reportNew("fileDownload", i);
        } catch (n) {
            console.info(n);
        }
        if (t && t.orcType === 1) {
            if (t.inDown) {} else {
                var r = t.filepath;
                var l = t.fnameEsc;
                var s = t.size;
                var d = {
                    bs: t.t || t.busid,
                    fp: t.fp
                };
                var c = o.addDownloadTask(r, l, s);
                G.saveasList[r] = 1;
                f.trigger("menu.hide");
            }
        }
    }
    function c(e) {
        var t = e[0];
        if (t) {
            var a = G.getReportInfo(t);
            a.ver3 = 1 + "";
            reportNew("chooseRightMenuClick", a);
            var i = a;
            i.ver1 = G.module();
            i.ver2 = 1;
            i.ver3 = a.ver4;
            i.ver4 = a.ver5;
            i.ver5 = 5;
            i.ver7 = G.info.role;
            console.log(t, a, i);
            reportNew("fileDownload", i);
        }
        for (var r in e) {
            var l = e[r];
            G.saveasList[l.filepath] = 1;
        }
        var s = {
            files: e,
            save2default: 0
        };
        o.addMultiDownloadTasks((0, n.default)(s));
    }
    e.exports = {
        save: d,
        saveBatch: c
    };
}, function(e, t, a) {
    "use strict";
    var i = a(31);
    var n = {};
    n.byUin = function() {
        var e = $(this).data("uin");
        var t = this.innerText;
        var a = function n() {
            G.module(2);
            $("#navTopFolder").addClass("selected");
            $("#createFolder").hide();
            $("#fileNum").addClass("hide").attr("data-action", "menu.filenum");
            $("#headerLine").text(">");
            $("#headerFolderName").html(" " + t + "上传的文件");
            $("#folderName").removeClass("hide");
            $("#normalNav").removeClass("hide");
            if (G.mac) {
                $(".mac-file-top").addClass("user-module");
            }
        };
        G.module(2);
        i.getList({
            ukey: "userFileDom",
            uin: e,
            name: t
        });
    };
    e.exports = n;
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(84);
    var r = a(259);
    var o = $(G.handler);
    var l = {
        "1": "没有登陆或登陆态失效",
        "2": "系统内部错误",
        "7": "没有群权限",
        "21": "不是上传者或群主不能转永久",
        "22": "不能跨群转永久文件",
        "23": "登录态校验失败",
        "24": "群成员关系校验失败",
        "25": "容量满，可以升级",
        "26": "容量满，不能再升级",
        "27": "要转存的文件不存在",
        "28": "永久空间容量超限"
    };
    function s() {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkForever");
        var e = G.selectRow;
        if (e && e.remoteType === 2) {
            var t = e.filepath;
            var a = {
                fp: t
            };
            n.setPermanent(a).done(function(t) {
                if (t.ec === 0) {
                    var a = "/102" + t.fp;
                    e.newFilePath = a;
                    e.remoteType = 1;
                    e.fp = t.fp;
                    e.temp = false;
                    i.updateFile(e, "permanent");
                    o.trigger("file.dataUpdate", e);
                    o.trigger("toast.show", {
                        type: "suc",
                        text: "转存成功"
                    });
                }
            }).fail(function(e) {
                console.log(e);
                r.showError(e.ec);
            });
        } else {
            console.log("文件不存在或者不是临时文件");
        }
        o.trigger("menu.hide");
    }
    e.exports = s;
}, function(e, t, a) {
    "use strict";
    var i = a(25);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(84);
    var l = a(163);
    var s = a(54);
    var f = a(17);
    G.renderOtherGroupResultFuncSingtons = {};
    var d = void 0;
    function c() {
        var e = true;
        return function(e, t) {
            var a = G.getDomPanel();
            if (!e) {
                return;
            }
            var i = [ t ];
            var n = e.file[0];
            var r = n.domid;
        };
    }
    function u(e, t) {
        e = e || {};
        var a = e.busId;
        var i = e.fileId;
        o.getFileAttr({
            bus_id: a,
            file_id: i
        }).done(function(e) {
            var a = [];
            if ((0, n.default)(e.file_info) === "object") {
                e.file_info.upload_size = e.file_info.size;
            } else {
                return;
            }
            var r = e.file_info;
            r.proId = r.id;
            r.id = i;
            a.push(r);
            a = s.setFileList(a);
            c()(a, t);
        }).fail(function(e) {
            console.log("fail", e);
        });
    }
    window.getFileAttr = u;
    e.exports = u;
}, function(e, t, a) {
    "use strict";
    var i = $("#folderPanel");
    var n = a(31);
    var r = a(259);
    var o = a(84);
    var l = a(180);
    var s = a(54);
    var f = a(20);
    var d = $(G.handler);
    function c() {
        var e = $.trim(i.find(".new-name").val());
        var t = {
            parent_id: "/",
            name: e
        };
        o.createFolder(t).done(function(e) {
            var t = s.filterFolder(e.folder_info);
            G.folderNum++;
            report("createFolderSuc");
            s.addData(t);
            n.appendFold(t);
            l.hideAll();
            d.trigger("toast.show", {
                type: "suc",
                text: "新建文件夹成功"
            });
            f.init();
        }).fail(function(e) {
            if (e.ec === 405) {
                G.canCreateFolder = false;
            }
            r.showError(e.ec, i);
            report("newFolderError");
        });
    }
    e.exports = {
        createFolder: c
    };
}, function(e, t, a) {
    "use strict";
    var i = a(31);
    var n = a(84);
    var r = a(54);
    var o = $(G.handler);
    var l = a(22);
    var s = a(20);
    function f(e) {
        if (e.errorCode === 0 && e.ret) {
            var t = {
                id: G.selectRow.id
            };
            n.deleteFolder(t).done(function(e) {
                if (e.ec) {
                    client.alert(2, "提示", "删除文件夹失败");
                    return;
                }
                G.canCreateFolder = true;
                var t = G.folderMap()[G.selectRow.id];
                G.folderNum--;
                if (G.folderNum < 0) {
                    G.folderNum = 0;
                }
                r.remove(t.id);
                i.removeRow(t);
                l.setClist(t, "delete");
                o.trigger("toast.show", {
                    type: "suc",
                    text: "删除文件夹成功"
                });
                s.init(G.file.isTooMany || G.file.isFull, "delete");
                report("delFolderSuc");
            }).fail(function(e) {
                client.alert(2, "提示", e && e.ec === -317 ? "该文件夹不可删除" : "删除文件夹失败");
                report("delFolderError");
            });
        }
    }
    function d() {
        o.trigger("menu.hide");
        if (!G.selectRow) {
            return;
        }
        var e = G.getReportInfo(G.selectRow);
        e.ver3 = 6;
        reportNew("folderRightMenuClick", e);
        report("deleteFolder", G.module());
        var t = client.confirm(2, "提示", "你确定要删除" + G.selectRow.fnameEsc + "以及文件夹内的所有文件吗？");
        if (t) {
            f(t);
        }
    }
    e.exports = {
        showDeleteFolder: d,
        deleteFolder: f
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#folderPanel");
    var n = a(31);
    var r = a(259);
    var o = a(84);
    var l = a(180);
    var s = a(54);
    var f = a(129);
    var d = $(G.handler);
    function c() {
        d.trigger("menu.hide");
        if (!G.selectRow) {
            return;
        }
        var e = $.trim(i.find(".new-name").val());
        var t = G.selectRow.id;
        var a = {
            folder_id: t,
            new_name: e
        };
        o.renameFolder(a).done(function(a) {
            var i = G.folderMap()[t];
            i.fname = e;
            i.fnameEsc = e;
            i.name = e;
            i.modify_time = Math.ceil(new Date().getTime() / 1e3);
            i = s.updateFolder(i);
            $("[data-path='" + t + "']").find(".name").html(e);
            d.trigger("toast.show", {
                type: "suc",
                text: "重命名文件夹成功"
            });
            n.updateRow(i);
            l.hideAll();
        }).fail(function(e) {
            var t = e.ec;
            if (t === -317) {
                t = 317.2;
            }
            r.showError(t, i);
            report("renameFolderError");
        });
        return true;
    }
    e.exports = {
        renameFolder: c
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(22);
    var r = $(G.handler);
    var o = G.folderVersion;
    function l() {
        if (n.getTips()) {} else {
            report("showOldVersion");
            s();
        }
    }
    function s() {
        $("#updateQQ").addClass("open");
        $("#updateQQTips").text("当前版本不支持文件夹下载功能，请升级QQ至最新版本后体验");
        $("#updateQQ").find("input.btn-notips").attr("data-action", "panel.close");
    }
    function f(e) {
        var t = document.createElement("div");
        var a = this.getBoundingClientRect();
        var i = function r() {
            var e = document.height;
            var t = G.getDomPanel();
            var a = t[0].scrollHeight;
            if (a + 52 > e) {
                return true;
            }
            return false;
        };
        t.innerHTML = '<div class="img"></div>';
        t.className = "file-animate files-" + e.icon;
        var n = window.innerWidth - a.left - 76;
        if (G.info.isAdmin) {
            n += 47;
        }
        if (i()) {
            n -= 20;
        }
        if (G.mac) {
            n = 177;
        }
        t.style.right = n + "px";
        t.style.top = a.top - 20 + "px";
        document.body.appendChild(t);
        setTimeout(function() {
            document.body.removeChild(t);
        }, 1500);
    }
    function d(e) {
        if (G.info.version < o) {
            l();
            return;
        }
        report("downloadFolder");
        if (e) {
            f.call(this, e);
            var t = e.id;
            var a = e.fnameEsc;
            console.log(e, t, a);
            client.addDownloadTask(t, a, 0, true, true);
        }
        r.trigger("menu.hide");
    }
    function c() {
        d.bind(this)(G.selectRow);
    }
    function u() {
        var e = $(this).closest(".list-item");
        var t = e.data("path");
        var a = i.getData(t);
        d.bind(this)(a);
    }
    e.exports = {
        download: c,
        downloadByBtn: u
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#folderPropertyPanel");
    var n = a(162);
    var r = $(G.handler);
    function o() {
        report("propFolder");
        n.render(i, G.selectRow);
        i.addClass("open");
        r.trigger("menu.hide");
        i.find(".aria-hide")[0].focus();
        var e = G.getReportInfo(G.selectRow);
        e.ver3 = 5;
        reportNew("folderRightMenuClick", e);
    }
    e.exports = {
        show: o
    };
}, function(e, t, a) {
    "use strict";
    var i = a(31);
    var n = a(54);
    var r = a(162);
    function o(e, t) {
        e = e || $(this).data("path");
        report("clkFolder", G.module());
        console.debug(e, t);
        if (G.mac) {
            $(".mac-file-top").removeClass("user-module");
        }
        if ((G.module() == 0 || G.module() == 1) && e === G.nowFolder) {
            console.debug("open folder return!!!!!", G.module(), G.nowFolder, e);
            return;
        }
        G.module(e === "/" ? 0 : 1);
        var a = undefined;
        if (e === "/") {
            $(".root-folder").removeClass("folder");
        } else {
            $(".root-folder").addClass("folder");
        }
        var r = n.getData(e);
        var o = G.getReportInfo(r);
        reportNew("doubleClickFolder", o);
        var l = true;
        var s = e.replace(/\//gi, "-");
        if (e === "/") {
            s = "#fileListDom";
        }
        var f = $(s);
        var d = void 0;
        var c = void 0;
        if (f.length > 0) {
            d = f.data("sort");
            c = f.data("order");
        }
        i.getList({
            folderId: e,
            fname: r.fnameEsc,
            sort_by: d,
            sort_order: c
        });
    }
    function l(e, t) {
        o.call(this, e, t);
        reportNew("wayRoot");
    }
    e.exports = {
        renderFolder: o,
        renderRootFolder: l
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#move-file-panel");
    function n() {
        i.addClass("open");
    }
    function r() {
        i.removeClass("open");
    }
    function o() {
        i.removeClass("open");
    }
    function l() {
        console.log("ok move file");
    }
    function s() {
        console.log("move file create folder");
    }
    function f(e, t) {
        var a = $(e.target).closest(".folder-list-item");
        $(".folder-list-item").removeClass("active");
        a.addClass("active");
    }
    e.exports = {
        oveFileOpen: n,
        moveFileClose: r,
        moveFileCancel: o,
        moveFileOk: l,
        moveFileCreateFolder: s,
        fileActive: f
    };
}, function(e, t, a) {
    "use strict";
    var i = a(17);
    var n = 48;
    var r = a(149);
    function o(e) {
        var t = false;
        var a = new RegExp('^[^/\\\\:?*"<>|]+$');
        t = a.test(e);
        console.log("reg", a.test(e));
        return t;
    }
    function l() {
        var e = $.trim(this.value);
        if (e.length > n && !input) {
            this.value = e.substr(0, n);
        }
        return;
    }
    function s(e) {
        var t = this.inputStart;
        var a = this.value;
        var r = $(this).parents(".panel-overlay");
        var l = $(this).parent().find(".bubble");
        var s = $("#folderPanel .btn-ok").data("action");
        if ($.trim(a) === "") {
            $(this).parent().find(".error-message").removeClass("show");
            r.find(".btn-ok").prop("disabled", true);
            l.hide();
            return;
        }
        if (!o(a)) {
            var f = '文件夹名称不能包含 \\ / : * ? " < > |';
            if (s === "file.renameFile") {
                f = '文件名称不能包含 \\ / : * ? " < > |';
            }
            $(this).parent().find(".error-message").text(f).addClass("show").show();
            l.html('<span class="bot"></span><span class="top"></span>' + f).show();
            r.find(".btn-ok").prop("disabled", true);
        } else {
            $(this).parent().find(".error-message").removeClass("show").hide();
            l.hide();
        }
        if (a.length === 0) {
            r.find(".btn-ok").prop("disabled", true);
        } else if (a.length !== 0 && o(a)) {
            r.find(".btn-ok").prop("disabled", false);
        }
        if (a.length > n && !t) {
            this.value = a.substr(0, n);
        }
        if ($("#folderPanel [data-action]").length) {
            if (e && e.keyCode == 13 && !t) {
                $("#folderPanel [data-action]").click();
            }
        }
        return;
        if (i.getLen(a) > n && !t) {
            this.value = i.subString(a, 16);
        }
    }
    function f() {
        $("#folderPanel .error-message").removeClass("show");
    }
    e.exports = {
        "input.keyup": s,
        "input.focus": f,
        "input.blur": l,
        folderName: o
    };
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    var i = a(26);
    var n = f(i);
    var r = a(261);
    var o = f(r);
    var l = a(262);
    var s = f(l);
    function f(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var d = a(159);
    var c = a(54);
    var u = a(55);
    var p = a(82);
    var v = a(17);
    var m = $("#fileNumText");
    var h = $("#groupSize");
    var g = $("#groupSizeBar");
    var w = a(163);
    var b = $(G.handler);
    var _ = true;
    function k() {
        for (var e in G.filesClass) {
            var t = G.filesClass[e];
            t.sethide();
        }
    }
    var y = function() {
        function e(t) {
            (0, o.default)(this, e);
            console.log(t);
            this.folderId = t.folderId;
            this.filterUin = t.uin;
            this.startIndex = 0;
            this.pageSize = 30;
            this.filterCode = t.filterCode || 0;
            this.isEnd = false;
            this.sort = t.sort_by || false;
            this.order = t.sort_order || false;
            this.isLoad = false;
            this.isRender = false;
            this.fname = t.fname;
            this.noShow = t.noShow || false;
            this.hasSetRole = false;
            this.role = 0;
            this.uploadingList = [];
            this.uploadingMap = [];
            this.cUploadFlag = false;
            this.module = 0;
            if (this.filterUin) {
                this.name = t.name;
                this.filterCode = 3;
                this.folderId = "/";
            }
            if (this.folderId !== "/") {
                this.module = 1;
            }
            if (this.filterUin) {
                this.module = 2;
            }
            this.getDom();
            this.getUploadingFile();
        }
        (0, s.default)(e, [ {
            key: "reset",
            value: function t() {
                this.startIndex = 0;
                this.isLoad = false;
                this.isRender = false;
                this.dom.html("");
            }
        }, {
            key: "getDom",
            value: function a() {
                var a = function i(e) {
                    return '<section class="file-list" id="' + e + '"></section>';
                };
                var e = $("#fileListDom");
                if (this.folderId === "/" && !this.filterUin) {
                    this.dom = e;
                } else if (this.filterUin) {
                    e.after(a("userFileDom"));
                    this.dom = $("#userFileDom");
                } else if (this.folderId !== "/") {
                    var t = "list" + this.folderId.replace(/\//i, "-");
                    e.after(a(t));
                    this.dom = $("#" + t);
                }
            }
        }, {
            key: "changeHash",
            value: function i() {
                if (this.folderId === "/" || this.filterUin) {
                    var e = location.hash;
                    var t = e.indexOf("&webParams=");
                    if (t > 0) {
                        location.hash = e.substr(0, e.indexOf("&webParams="));
                    }
                    return;
                }
                var a = location.hash;
                a = decodeURIComponent(a);
                var i = {
                    params: {
                        fid: this.folderId,
                        fname: this.fname
                    }
                };
                location.hash = a.replace(/&webParams={.+}/, "") + "&webParams=" + encodeURIComponent((0, 
                n.default)(i));
            }
        }, {
            key: "setshow",
            value: function r() {
                console.debug("setShow:", this.filterUin, G.module());
                if (this.noShow) {
                    this.noShow = false;
                    return;
                }
                k();
                this.isShow = true;
                this.fillTit();
                this.dom.show();
                this.changeHash();
                G.nowFolder = this.folderId;
                if (this.fname) {
                    $(".sub-folder").css("display", "flex");
                    $(".root-folder").hide();
                    $("#createNewFolder").hide();
                    $(".more-menu").show();
                } else if (this.filterUin) {
                    $(".sub-folder").css("display", "flex");
                    $(".root-folder").hide();
                    $("#createNewFolder").hide();
                    $(".more-menu").show();
                } else {
                    $(".more-menu").show();
                    $(".sub-folder").css("display", "none");
                    $(".root-folder").show();
                    if (G.info.isAdmin) {
                        $("#createNewFolder").show();
                    }
                }
                G.scrollHandler = this;
            }
        }, {
            key: "sethide",
            value: function l() {
                this.isShow = false;
                this.dom.hide();
            }
        }, {
            key: "getUploadingFile",
            value: function f() {
                var e = p.getTaskListAdv();
                this.uploadingList = [];
                this.uploadingMap = {};
                if (!(e.empty && e.status === "ok")) {
                    var t = u.cleanMap(e.map);
                    for (var a = 0, i = t.length; a < i; a++) {
                        var n = t[a];
                        if (n.type === "upload" && n.folderpath === this.folderId) {
                            this.uploadingMap[n.filepath] = n;
                        }
                    }
                }
            }
        }, {
            key: "changeStatus",
            value: function h(e) {
                if (e.uin) {
                    this.filterUin = e.uin;
                    this.name = e.name;
                    this.isRender = false;
                    this.startIndex = 0;
                    this.getData();
                } else if (e.sort_by) {
                    this.getUploadingFile();
                    if (e.sort_by === this.sort && e.sort_order === this.order) {
                        this.getData();
                    } else {
                        this.sort = e.sort_by;
                        this.order = e.sort_order;
                        this.reset();
                        this.getData();
                    }
                }
            }
        }, {
            key: "setRole",
            value: function g() {
                if (this.role === 0 || this.role === 3) {
                    $("#createNewFolder").remove();
                }
            }
        }, {
            key: "fillTit",
            value: function y(e) {
                if (this.fname) {
                    $(".sub-folder-name").text(this.fname);
                } else if (this.filterUin) {
                    $(".sub-folder-name").text(this.name + "上传的文件");
                } else {
                    if (e) {
                        m.text(G.file.allnum).attr("aria-label", "共" + G.file.allnum + "个文件");
                    }
                }
            }
        }, {
            key: "fullData",
            value: function x(e) {
                if (typeof e.total === "number") {
                    c.setAllNum(e);
                }
                if (this.folderId === "/") {
                    c.setRole(e);
                }
                this.fillTit(e);
                console.log("set cache", this.folderId, G.module());
                return c.setFileList(e.list, {}, this.module);
            }
        }, {
            key: "getData",
            value: function F() {
                if (this.isLoad) {
                    return;
                }
                this.isLoad = true;
                var e = {
                    folder_id: this.folderId,
                    start_index: this.startIndex,
                    cnt: this.pageSize
                };
                if (this.filterUin) {
                    e.filter_uin = this.filterUin;
                }
                if (this.sort && this.order) {
                    e.sort_by = this.sort;
                    e.sort_order = this.order;
                } else {
                    e.filter_code = this.filterCode;
                }
                this.showLoad();
                var t = this;
                d.getFilesList(e).done(function(e) {
                    t.showLoad(true);
                    if (!t.sort_by && t.startIndex === 0 || t.startIndex === 1) {
                        G.tab.resetTab();
                    }
                    if (e.file_list) {
                        t.startIndex += e.file_list.length;
                    } else {
                        t.isEnd = true;
                    }
                    if (e.next_index === 0) {
                        t.isEnd = true;
                    }
                    var a = {
                        list: e.file_list,
                        total: e.total_cnt,
                        userRole: e.user_role,
                        openFlag: e.open_flag
                    };
                    var i = t.fullData(a);
                    if (t.folderId === "/") {
                        t.role = a.userRole;
                    }
                    var n = window.requestAnimationFrame;
                    var r = window.cancelAnimationFrame;
                    if (!t.isRender) {
                        var o = void 0;
                        var l = function s() {
                            o = n(s);
                            if (t.cUploadFlag) {
                                t.render(i);
                                r(o);
                                console.debug("cancel request animation");
                            }
                        };
                        n(l);
                    } else {
                        t.render(i);
                    }
                }).fail(function(e) {
                    t.showLoad(true);
                    e && console.log(e);
                    if (e.ec !== 1e3) {
                        var a = "拉取文件列表失败";
                        if (_) {
                            if (G.mac) {
                                a += "，请稍后重试";
                            } else {
                                a += '，请稍后<a onclick="window.location.reload();">重试</a>';
                            }
                        }
                        b.trigger("toast.show", {
                            type: "fail",
                            text: a,
                            autoHide: !_
                        });
                    }
                });
            }
        }, {
            key: "appendContinueUpload",
            value: function T() {
                this.cUploadFlag = true;
            }
        }, {
            key: "getContinueUpload",
            value: function C() {
                var e = G.continueUploadMap[this.folderId];
                var t = [];
                if (e) {
                    for (var a in e) {
                        t.push(e[a]);
                    }
                }
                return t;
            }
        }, {
            key: "render",
            value: function S(e) {
                this.isLoad = false;
                var t = this.dom;
                var a = {};
                var i = false;
                if (G.info.isVisitor) {
                    a.actionHide = true;
                }
                if (this.filterUin) {
                    G.module(2);
                } else if (this.folderId === "/" && !this.noShow) {
                    G.module(0);
                } else {
                    G.module(1);
                }
                this.noShow = false;
                var n = e.file;
                if (e.clist) {
                    var r = e.clist;
                    n = r.concat(n);
                }
                var o = [];
                if (!this.isRender) {
                    var l = this.getContinueUpload();
                    for (var s = 0, f = l.length; s < f; s++) {
                        var d = l[s].filepath;
                        if (this.uploadingMap[d]) {
                            $.extend(l[s], this.uploadingMap[d]);
                            delete this.uploadingMap[d];
                        }
                    }
                    for (var c in this.uploadingMap) {
                        o.push(this.uploadingMap[c]);
                    }
                    n = l.concat(n);
                    n = o.concat(n);
                }
                var u = w({
                    list: n,
                    renderParams: a
                });
                var p = w({
                    list: e.folder,
                    renderParams: a
                });
                if (!this.isRender) {
                    if (!this.hasSetRole && this.folderId === "/") {
                        this.setRole(e);
                        this.hasSetRole = true;
                    }
                    i = true;
                    this.setshow();
                    this.isRender = true;
                    if (this.order === 1) {
                        t.html(u);
                        t.append(p);
                    } else {
                        t.html(p);
                        t.append(u);
                    }
                } else {
                    var v = $(".fold").last();
                    var m = t.find(".file").first();
                    if (v.length > 0) {
                        if (this.order === 1) {
                            v = $(".fold").first();
                            v.before(u);
                            t.append(p);
                        } else {
                            v.after(p);
                            t.append(u);
                        }
                    } else {
                        if (this.order === 1) {
                            t.append(u);
                            t.append(p);
                        } else {
                            v.after(p);
                            t.append(u);
                        }
                    }
                }
                t.find(".list-item").each(function(e) {
                    this.setAttribute("idx", e);
                });
                if (t[0].scrollHeight > $(".scroll-dom").height()) {
                    $(".list-thead").addClass("padding");
                } else {
                    $(".list-thead").removeClass("padding");
                }
                if (this.folderId === "/" && i) {
                    this.speedReport();
                }
            }
        }, {
            key: "showLoad",
            value: function M(e) {
                var t = $("#loaderDom");
                if (t.length === 0) {
                    $("body").append('<div class="loader" id="loaderDom"><div class="loading"></div></div>');
                    t = $("#loaderDom");
                }
                if (e) {
                    t.removeClass("open");
                } else {
                    t.addClass("open");
                }
            }
        }, {
            key: "speedReport",
            value: function D() {
                if (!window._timePoints["show"]) {
                    savePoint("show");
                    var e = {
                        20: window._timePoints["css"],
                        21: window._timePoints["zepto"],
                        22: window._timePoints["js"],
                        23: window._timePoints["start"]
                    };
                    if (localVersion === "isLocal") {
                        e[25] = window._timePoints["show"];
                    } else if (typeof nodeCost !== "undefined") {
                        e[26] = window._timePoints["show"];
                    } else {
                        e[24] = window._timePoints["show"];
                    }
                    var t = 1;
                    if (G.checkHttps()) {
                        t = 13;
                        try {
                            var a = v.getParameter("iframetime");
                            e[27] = a;
                        } catch (i) {}
                    }
                    QReport.huatuo({
                        appid: 10016,
                        flag1: 1772,
                        flag2: 1,
                        flag3: t,
                        speedTime: e
                    });
                }
            }
        } ]);
        return e;
    }();
    t.default = y;
    e.exports = y;
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    var i = a(25);
    var n = c(i);
    var r = a(26);
    var o = c(r);
    var l = a(261);
    var s = c(l);
    var f = a(262);
    var d = c(f);
    function c(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var u = a(84);
    var p = a(263);
    var v = a(54);
    var m = a(17);
    var h = $(G.handler);
    function g() {
        for (var e in G.filesClass) {
            var t = G.filesClass[e];
            t.sethide();
        }
    }
    var w = function() {
        function e(t) {
            (0, s.default)(this, e);
            this.keyword = t.keyword;
            this.newKey = true;
            this.skey = t.skey;
            this.cookie = 0;
            this.count = 30;
            this.isLoad = false;
            this.isRender = false;
            this.search_type = 0;
            this.app_id = G.mac ? 7 : 4;
            this.owner = true;
            this.other = true;
            this.getDom();
        }
        (0, d.default)(e, [ {
            key: "getDom",
            value: function t() {
                var t = function a(e) {
                    return '<section class="file-list" id="' + e + '"></section>';
                };
                var e = $("#fileListDom");
                e.after(t(this.skey));
                this.dom = $("#" + this.skey);
            }
        }, {
            key: "reset",
            value: function a(e) {
                this.isLoad = false;
                this.newKey = true;
                this.keyword = e.keyword;
                this.cookie = 0;
                this.owner = true;
                this.other = true;
                this.isRender = false;
            }
        }, {
            key: "changeHash",
            value: function i() {
                var e = location.hash;
                e = decodeURIComponent(e);
                var t = {
                    params: {
                        key: this.keyword
                    }
                };
                location.hash = e.replace(/&webParams={.+}/, "") + "&webParams=" + encodeURIComponent((0, 
                o.default)(t));
            }
        }, {
            key: "setshow",
            value: function r() {
                g();
                this.show = true;
                this.fillTit();
                this.dom.show();
                G.scrollHandler = this;
            }
        }, {
            key: "sethide",
            value: function l() {
                this.show = false;
                this.dom.hide();
            }
        }, {
            key: "fillTit",
            value: function f(e) {
                if (e) {
                    $(".sub-folder-name").text("共" + e.total + "个搜索结果");
                }
                $(".sub-folder").css("display", "flex");
                $(".root-folder").hide();
                $("#createNewFolder").hide();
                $(".more-menu").hide();
            }
        }, {
            key: "changeStatus",
            value: function c(e) {
                console.debug("changeStatus", e, this.keyword, (0, n.default)(this.keyword));
                G.module(3);
                if (this.keyword !== e.keyword) {
                    this.reset(e);
                    this.getData();
                    console.debug("get data");
                } else {
                    this.setshow();
                }
            }
        }, {
            key: "showLoad",
            value: function h(e) {
                var t = $("#loaderDom");
                if (t.length === 0) {
                    $("body").append('<div class="loader" id="loaderDom"><div class="loading"></div></div>');
                    t = $("#loaderDom");
                }
                if (e) {
                    t.removeClass("open");
                } else {
                    t.addClass("open");
                }
            }
        }, {
            key: "convert",
            value: function w(e) {
                e = e || [];
                function t(e) {
                    return e.gc === G.info.gc;
                }
                function a(e) {
                    return e.gc !== G.info.gc;
                }
                var i = {
                    ut: "upload_time",
                    owner_name: "uin_name"
                };
                var n = function r(e) {
                    var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
                        filters: {
                            selfGroupFilter: function r() {},
                            otherGroupFilter: function o() {}
                        }
                    };
                    function a(e, t, a) {
                        e = e.filter(t);
                        var n = {};
                        for (var r = e.length - 1; r >= 0; r--) {
                            var o = e[r];
                            n[o.id] = o;
                        }
                        var l = v.setFileList(e, i);
                        var s = l.file;
                        for (var f = s.length - 1; f >= 0; f--) {
                            var d = s[f].fp;
                            var c = G.fileMap()["/" + s[f].busid + d];
                            var u = n[d].match_word;
                            s[f].name = m.heightLight(c.name.replace(/&nbsp;/gi, " "), u);
                            s[f].suf = m.heightLight(c.suf, u);
                            if (a) {
                                s[f].otherGroupName = n[d]["group_name"];
                                s[f].gc = n[d]["gc"];
                            }
                        }
                        return s;
                    }
                    var n = {
                        selfGroupResult: a(e, t.filters.selfGroupFilter),
                        otherGroupResult: a(e, t.filters.otherGroupFilter, true)
                    };
                    return n;
                };
                return n(e, {
                    filters: {
                        selfGroupFilter: t,
                        otherGroupFilter: a
                    }
                });
            }
        }, {
            key: "getData",
            value: function b() {
                if (this.isLoad) {
                    return;
                }
                report("doSearch");
                G.module(3);
                this.isLoad = true;
                var e = {
                    key_word: this.keyword,
                    count: this.count,
                    app_id: this.app_id,
                    cookie: this.cookie
                };
                var t = this;
                u.search(e).done(function(e) {
                    $("body").attr("data-mode", "search");
                    if (t.newKey) {
                        G.tab.resetTab();
                    }
                    t.newKey = false;
                    t.cookie = e.cookie;
                    var a = t.convert(e.file_list);
                    a.owner = e.owner_total;
                    a.total = e.total;
                    t.render(a);
                }).fail(function(e) {
                    if (t.newKey) {
                        var a = "100%";
                        t.dom.html(t.noResultRender());
                        $(".search-empty").css("height", a || "160px");
                    }
                    t.showLoad(true);
                });
            }
        }, {
            key: "render",
            value: function _(e) {
                this.isLoad = false;
                G.module(3);
                if (!this.isRender) {
                    G.nowFolder = "/";
                    g();
                    this.setshow();
                    this.fillTit(e);
                    this.isRender = true;
                    $(".scroll-dom")[0].scrollTop = 0;
                }
                var t = e.selfGroupResult;
                var a = e.otherGroupResult;
                var i = e.owner;
                var n = e.total - e.owner;
                var r = false;
                var o = false;
                $(".root-folder").addClass("folder");
                if (i === 0 && n === 0) {
                    var l = this.noResultRender();
                    this.dom.html(l);
                    $(".search-empty").css("height", "100%");
                    return;
                }
                if (t.length > 0) {
                    r = p({
                        data: {
                            self: true,
                            first: this.owner,
                            list: t,
                            total: i,
                            name: "本群搜索结果",
                            gc: "0000"
                        },
                        renderParams: {
                            actionHide: false,
                            getByUinHide: false,
                            searchModule: true
                        },
                        batchMode: false
                    });
                } else {}
                if (a.length > 0) {
                    o = p({
                        data: {
                            self: false,
                            first: this.other,
                            list: a,
                            total: n,
                            name: "其他群的搜索结果",
                            gc: "1111"
                        },
                        renderParams: {
                            actionHide: false,
                            getByUinHide: false,
                            searchModule: true
                        },
                        batchMode: false
                    });
                }
                if (this.owner) {
                    report("showSearchRes");
                    this.dom.html("");
                    this.owner = false;
                    $("body").trigger("searchResult", true);
                }
                if (r) {
                    this.dom.append(r);
                }
                if (a.length > 0 && this.other) {
                    this.other = false;
                }
                if (o) {
                    this.dom.append(o);
                }
            }
        }, {
            key: "noResultRender",
            value: function k() {
                this.setshow();
                this.dom.height("100%");
                this.fillTit({
                    total: 0
                });
                var e = [ '<div class="search-empty"><div class="search-icon-dom">', '<div class="icons-search-empty"></div>', '<span class="empty-desc">很遗憾，', '没有找到与"', this.keyword, '"相关的文件</span></div></div>' ];
                var t = e.join("");
                return t;
            }
        } ]);
        return e;
    }();
    t.default = w;
}, function(e, t, a) {
    "use strict";
    var i = a(25);
    var n = l(i);
    var r = a(26);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = a(84);
    var f = a(54);
    var d = {};
    e.exports = d;
    function c(e, t) {
        if (typeof e.total === "number") {
            f.setAllNum(e);
        }
        f.setRole(e);
        return f.setFileList(e.list);
    }
    var u = void 0;
    d.getList = function(e) {
        e = e || {};
        var t = e.folderId || "/";
        var a = e.filterUin || undefined;
        var i = 0;
        var r = 30;
        var l = e.filterCode || 0;
        var f = false;
        var d = undefined;
        var u = false;
        var p = false;
        var v = e.sort_by || false;
        var m = e.sort_order || false;
        return function(h, g, w) {
            if (p) {
                return;
            }
            p = true;
            if (f) {
                g({
                    ec: 1e3,
                    em: "no more items"
                });
                return;
            }
            var b = {
                folder_id: t,
                start_index: i,
                cnt: r,
                filter_uin: a
            };
            if (v && m) {
                b.sort_by = v;
                b.sort_order = m;
            } else {
                b.filter_code = l;
            }
            var _ = (0, o.default)(b) === d;
            d = (0, o.default)(b);
            if (u && _) {
                console.info("same params will be ignored");
                return;
            }
            w && w();
            var k = function y(t) {
                p = false;
                u = true;
                var a = {
                    list: t.file_list,
                    total: t.total_cnt,
                    totalSpace: t.total_space,
                    usedSpace: t.used_space,
                    userRole: t.user_role,
                    openFlag: t.open_flag
                };
                var n = i;
                if (t.file_list && t.file_list.length) {
                    i = i + t.file_list.length;
                }
                if (t.next_index === 0) {
                    f = true;
                }
                h(c(a, l));
                if (typeof e.sort_by === "undefined" && n === 0 || n === 1) {
                    G.tab.resetTab();
                }
            };
            if ((typeof nodeData === "undefined" ? "undefined" : (0, n.default)(nodeData)) === "object") {
                k(nodeData);
                nodeData = false;
            } else {
                s.getFileList(b).done(function(e) {
                    k(e);
                }).fail(function(e) {
                    report("getListError");
                    p = false;
                    u = false;
                    g(e);
                });
            }
        };
    };
    d.getFileList = function(e) {
        s.getFileList(e).done(function(e) {
            if (e.total_cnt === 0 && folderId === "/") {
                suc(false);
                return;
            }
            var t = {
                list: e.file_list,
                total: e.total_cnt,
                totalSpace: e.total_space,
                usedSpace: e.used_space,
                userRole: e.user_role,
                openFlag: e.open_flag
            };
            if (e.file_list && e.file_list.length) {
                startIndex = startIndex + e.file_list.length;
            }
            if (e.next_index === 0) {
                isEnd = true;
            }
            suc(c(t));
        }).fail(function(e) {
            if (e.fc && e.fc === 1) {
                return;
            }
        });
    };
    d.getFilesList = function(e) {
        return s.getFileList(e);
    };
    d.setAllSpace = function(e, t) {
        s.getSpace().done(function(t) {
            var a = {
                totalSpace: t.total_space,
                usedSpace: t.used_space
            };
            f.setAllSpace(a);
            e(t);
        }).fail(function(e) {
            console.log(e);
        });
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<%\r\n  var item = locals;\r\n%>\r\n\r\n<div class="file-download file-status">\r\n  <div class="file-pres-status">\r\n    <span class="file-task-txt"><%-item.wording%></span>\r\n    <div class="file-parents">\r\n      <div class="width" style="width:<%-item.cPercent%>%"></div>\r\n    </div>\r\n  </div>\r\n  <div class="file-status-action <%-item.styles%>">\r\n    <a class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 <%=item.name%>" tabindex="-1"></a>\r\n    <a class="resume" data-action="task.resume" title="启动" aria-label="启动任务 <%=item.name%>" tabindex="-1"></a>\r\n    <a class="continue" data-action="task.continue" title="续传" aria-label="续传任务 <%=item.name%>" tabindex="-1"></a>\r\n    <a class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 <%=item.name%>" tabindex="-1"></a>\r\n    <a class="miss-close" onclick="G.removeTaskInDownLoad(<%-item.taskId%>,<%-item.filepath%>)"></a>\r\n  </div>\r\n</div>',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push("");
                    __stack.lineno = 1;
                    var e = locals;
                    buf.push('\n\n<div class="file-download file-status">\n  <div class="file-pres-status">\n    <span class="file-task-txt">', (__stack.lineno = 7, 
                    e.wording), '</span>\n    <div class="file-parents">\n      <div class="width" style="width:', (__stack.lineno = 9, 
                    e.cPercent), '%"></div>\n    </div>\n  </div>\n  <div class="file-status-action ', (__stack.lineno = 12, 
                    e.styles), '">\n    <a class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 ', escape((__stack.lineno = 13, 
                    e.name)), '" tabindex="-1"></a>\n    <a class="resume" data-action="task.resume" title="启动" aria-label="启动任务 ', escape((__stack.lineno = 14, 
                    e.name)), '" tabindex="-1"></a>\n    <a class="continue" data-action="task.continue" title="续传" aria-label="续传任务 ', escape((__stack.lineno = 15, 
                    e.name)), '" tabindex="-1"></a>\n    <a class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 ', escape((__stack.lineno = 16, 
                    e.name)), '" tabindex="-1"></a>\n    <a class="miss-close" onclick="G.removeTaskInDownLoad(', (__stack.lineno = 17, 
                    e.taskId), ",", (__stack.lineno = 17, e.filepath), ')"></a>\n  </div>\n</div>');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = {};
    var l = a(84);
    var s = a(54);
    var f = a(17);
    e.exports = o;
    G.searchFuncSingtons = {};
    o.search = function d(e) {
        var e = e || {};
        var t = e.succ;
        var a = e.fail;
        var i = e.beforeRequest;
        var r = e.isNew;
        var o = f.extend({
            key_word: "",
            search_type: 0,
            app_id: 4
        }, e.searchParams);
        if (G.mac) {
            o.app_id = 7;
        }
        var s = false;
        var d = (0, n.default)(o);
        if (r || G.searchFuncSingtons[d] == undefined) {
            G.searchFuncSingtons[d] = function() {
                var e = 25;
                var t = undefined;
                var a = 0;
                return function(n, f) {
                    if (a) {
                        console.log("no more items");
                        return;
                    }
                    if (s === true) {
                        return;
                    }
                    o["cookie"] = t;
                    o["count"] = e;
                    i && i();
                    s = true;
                    l.search(o).done(function(e) {
                        if (r) {
                            $("#searchReasult").text(e.total);
                            $(".nav").addClass("hide");
                            $("#searchNav").removeClass("hide");
                        }
                        a = e.is_end;
                        t = e.cookie;
                        n && n(e, d);
                        s = false;
                        $("#fileNum").addClass("hide");
                        $("#searchDom").css("display", "flex");
                        $("#folderName").addClass("hide");
                    }).fail(function(e) {
                        f && f(e);
                        s = false;
                        $("#searchReasult").text(0);
                        $("#searchDom").css("disolay", "none");
                        $("#folderName").addClass("hide");
                    });
                };
            }();
        }
        G.searchFuncSingtons[d](t, a);
    };
    window.search = o.search;
}, function(e, t, a) {
    "use strict";
    var i = a(256), n = a(257);
    function r(e, t) {
        var a = i(t);
        e.html(a);
    }
    function o(e) {
        var t = G.getDomPanel().find(".fold");
        var a = t.length ? t : G.getDomPanel();
        a.after(n({
            id: e
        }));
    }
    function l(e) {
        $("#searchDom").css("display", "none");
        if (e) {
            $("#fileNum").addClass("hide").attr("data-action", "menu.filenum");
            $("#folderName").removeClass("hide");
            $("#headerFolderName").text(e.fnameEsc);
            $("#createFolder").hide();
        } else {
            $("#fileNum").removeClass("hide").attr("data-action", "menu.filenum");
            $("#folderName").addClass("hide");
            if (G.canCreateFolder) {
                $("#createFolder").show();
            }
        }
    }
    e.exports = {
        render: r,
        updataFolderHeader: l
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<%\n	for(var i = 0,l=locals.list.length;i<l;i++){\n		var item = locals.list[i];\n		if(item.orcType === 2){\n%>\n	<div class="fold list-item <%if(item.succ){%>succ<%}%>" data-path="<%=item.id%>" id="<%=item.domid%>" data-dbaction="folder.open" data-action="list.select">\n		<div class="file-select"></div>\n		<div class="item-name item-name-adjust" data-dbaction="folder.open" tabindex="-1" data-path="<%=item.id%>" data-viewcntr="folder<%=item.domid%>" >\n			<div class="filev3-folder drag-dom" data-dbaction="folder.open"  data-path="<%=item.id%>" data-viewcntr="folder<%=item.domid%>" title="<%-item.fname%>&#10;文件个数：<%-item.filenum%>&#10;创建时间：<%=item.ctoStr%>&#10;创建人：<%-item.nick%>"></div>\n			<span class="name drag-dom" title="<%-item.fname%>&#10;文件个数：<%-item.filenum%>&#10;创建时间：<%=item.ctoStr%>&#10;创建人：<%-item.nick%>"><%- item.fname %></span>\n		</div>\n		<div class="item-time"  title="更新时间：<%=item.mtoStr%>">\n			<span class="drag-dom"><%= item.mtStr %></span>\n		</div>\n		<div class="item-size">－</div>\n		<div class="item-user">－</div>\n		<div class="item-download-times">－</div>\n		<div class="aria-hide">\n			<a tabindex="3" class="applaction-link"><%-item.fname%> 文件个数：<%-item.filenum%> 创建时间：<%=item.ctoStr%> 创建人：<%-item.nick%></a>\n			<button tabindex="3" data-focus="file.aria" data-action="folder.open"  data-path="<%=item.id%>" data-viewcntr="folder<%=item.domid%>" aria-label="打开文件夹:<%- item.fname %> ">文件夹<%- item.fname %> 更新时间：<%=item.mtoStr%></button>		\n		</div>	\n		<div class="item-action"><button role="button" aria-label="下载文件夹<%- item.fname %>" title="下载文件夹" class="v3-down" data-action="folder.downloadByBtn" tabindex="3"></button></div>\n	</div>\n<%\n}else{\n%>\n	<div class="file list-item <%=item.icon%> <%if(item.remoteType===2){%>temp<%}%> <%if(item.succ){%>succ<%}%> <%if(item.safeType){%>illegal<%}%>" id="<%=item.domid%>" data-path="<%=item.filepath%>" <%if(!locals.renderParams){%>id="<%=item.domid%>"<%}%> <%if(item.otherGroupName){%> data-dbaction="openGroupFile" data-uin="<%- item.gc %>"<%}%> data-action="list.select" <%if(item.preview){%>data-dbaction="file.preview"<%}else if(item.canContinueUpload){%>data-dbaction="task.continue"<%}{%>data-dbaction="file.downloadByDom"<%}%> <%if(item.safeType){%>title="该文件存在安全风险，无法正常使用"<%}%> data-id="<%-item.id%>"  tabindex="-1">\n		<div class="file-select">\n			<%if(locals.batchMode===undefined?true:locals.batchMode){%>\n				<input type="checkbox" class="cbox" data-action="file.check" aria-label="文件类型:<%=item.filetype%>,名称<%=item.fname%>,大小:<%=item.sizeStr%>,下载次数:<%=item.down%>次,上传人:<%=item.nick%>,上传时间:<%=item.ctStr%>" tabindex="3" value="<%=item.filepath%>" >\n			<%}%>\n		</div>	\n		<div class="item-name-wrap item-name-adjust" <%if(!item.safeType){%>title="<%- item.name %><%-item.suf%>&#10;创建时间：<%=item.ctoStr%>"<%}%>>\n			<div class="item-name" tabindex="-1">\n				<div class="file-icons" data-path="<%=item.filepath%>" <%if(item.preview){%>data-dbaction="file.preview"<%}%>>\n					<div class="drag-dom filev3-<%=item.icon%> <%if(item.previewObj){%>thumb<%}%>" <%if(item.previewObj){%>style="background-image:url(<%=item.previewObj.url%>);"<%}%>></div>\n					<i class="icons-check"></i>\n				</div>\n				<span class="name drag-dom">\n					<%- item.name %><%-item.suf%>\n				</span>\n			</div>\n			<% if(item.canEdit || item.remoteType === 2) { %>\n				<div class="item-tags">\n					<div class="overflow">\n						<%if(item.canEdit){%><span class="can-edit"></span><%}%>\n						<%if(item.remoteType ===2){%><span class="tmp"></span><%}%>\n					</div>\n				</div>\n			<% } %>\n		</div>\n		<div class="item-time" <%if(!item.safeType){%>title="更新时间：<%=item.mtoStr%>"<%}%> aria-live="polite" aria-atomic="false" aria-relevant="all">\n\n			<span class="drag-dom" <%if(item.canContinueUpload || item.status === \'pause\' || item.status === \'downloadprogress\'){%>style="display:none"<%}%>><%= item.mtStr %></span>\n			<%if(item.canContinueUpload || item.status === \'pause\' || item.status === \'downloadprogress\'){%>		\n			<div class="file-download file-status">\n			  <div class="file-pres-status">\n			    <span class="file-task-txt"><%-item.wording%></span>\n			    <div class="file-parents">\n			      <div class="width" style="width:<%-item.cPercent%>%"></div>\n			    </div>\n			  </div>\n			  <div class="file-status-action <%-item.styles%>">\n			    <a class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 <%=item.name%>" tabindex="-1"></a>\n			    <a class="resume" data-action="task.resume" title="启动" aria-label="启动任务 <%=item.name%>" tabindex="-1"></a>\n			    <a class="continue" data-action="task.continue" title="续传" aria-label="续传任务 <%=item.name%>" tabindex="-1"></a>\n			    <a class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 <%=item.name%>" tabindex="-1"></a>\n			    <a class="miss-close" onclick="G.removeTaskInDownLoad(<%-item.taskId%>,<%-item.filepath%>)"></a>\n			  </div>\n			</div>\n			<%}%>			\n		</div>\n		<div class="item-size" <%if(!item.safeType){%>title="文件大小：<%= item.sizeStr%>"<%}%>>\n			<span class="drag-dom"><%= item.sizeStr%></span>\n		</div>\n		<div class="item-user" <%if(!item.safeType){%>title="上传者：<%-item.nick%> (<%=item.uin%>)"<%}%> <%if(locals.renderParams&&locals.renderParams.getByUinHide===true){%>data-action=""<%}else{%>data-action="file.getByUin"<%}%> data-uin="<%=item.uin%>"><span><%- item.nick%></span></div>\n		<div class="item-download-times" title="下载次数：<%= item.down %>次"><span><%= item.down %>次</span></div>\n		<div class="item-action">\n			<%if(!item.safeType && !item.canContinueUpload){%>\n				<%if(item.isDown){%>\n					<button tabindex="-1" role="button" aria-label="在文件夹中打开" title="在文件夹中打开" class="v3-open" data-action="file.openFolder"></button>\n				<%}else{%>\n					<button tabindex="-1" role="button" aria-label="下载文件<%=item.fname%>" title="下载文件" class="v3-down" data-action="file.downloadByBtn"></button>\n				<%}%>\n			<%}%>\n		</div>\n		<div class="aria-hide">\n			<a class="applaction-link" tabindex="3">名称:<%=item.fname%>,文件类型:<%=item.filetype%>,大小:<%=item.sizeStr%>,下载次数:<%=item.down%>次,上传人:<%=item.nick%>,上传时间:<%=item.ctStr%>,<%if(item.succ){%>该文件已下载<%}%></a>\n			<%if(item.isDown){%>\n				<button role="button" tabindex="3" data-action="file.openFolder" class="file-aria-btn" data-focus="file.aria" aria-label="打开<%=item.fname%>"></button>\n			<%}else{%>\n				<button role="button" tabindex="3" data-action="file.downloadByBtn" class="file-aria-btn" data-focus="file.aria" aria-label="下载文件<%=item.fname%>"></button>\n			<%}%>\n			<%if((item.safeType === 0 && item.admin) || G.info.isAdmin){%>\n				<button data-focus="file.aria" role="button" aria-label="转发文件<%=item.fname%>" data-action="file.forward" tabindex="3">转发<%=item.fname%></button>\n				<button data-focus="file.aria" role="button" aria-label="转发文件<%=item.fname%>到手机" data-action="file.forwardMobile" tabindex="3">转发文件到手机<%=item.fname%></button>\n				<button data-focus="file.aria" role="button" aria-label="在文件夹中显示<%=item.fname%>" data-action="file.openFolderInBox" tabindex="3">在文件夹中显示<%=item.fname%></button>\n				<button data-focus="file.aria" role="button" aria-label="重命名文件<%=item.fname%>" data-action="file.showRename" data-blur="aria.fmg" tabindex="3">重命名<%=item.fname%></button>\n				<%if(item.remoteType===2){%><button data-focus="file.aria" role="button" aria-label="转存为永久文件<%=item.fname%>" data-action="file.permanent" tabindex="3">转存为永久文件<%=item.fname%></button><%}%>\n				<button data-focus="file.aria" role="button" aria-label="移动文件<%=item.fname%>" data-action="file.showMove" data-blur="aria.fmg" tabindex="3">移动文件<%=item.fname%></button>\n			<%}%>\n			<%if(item.safeType && item.admin || G.info.isAdmin){%>\n				<button data-focus="file.aria"  role="button" aria-label="删除文件<%=item.fname%>" data-action="file.delete" tabindex="3">删除<%=item.fname%></button>\n			<%}%>\n			<button data-focus="file.aria" role="button" aria-label="举报文件<%=item.fname%>" data-action="file.jubao" tabindex="3">举报文件<%=item.fname%></button>\n		</div>\n	</div>\n<%\n	}\n}\n%>\n',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push("");
                    __stack.lineno = 1;
                    for (var e = 0, t = locals.list.length; e < t; e++) {
                        var a = locals.list[e];
                        if (a.orcType === 2) {
                            buf.push('\n	<div class="fold list-item ');
                            __stack.lineno = 6;
                            if (a.succ) {
                                buf.push("succ");
                                __stack.lineno = 6;
                            }
                            buf.push('" data-path="', escape((__stack.lineno = 6, a.id)), '" id="', escape((__stack.lineno = 6, 
                            a.domid)), '" data-dbaction="folder.open" data-action="list.select">\n		<div class="file-select"></div>\n		<div class="item-name item-name-adjust" data-dbaction="folder.open" tabindex="-1" data-path="', escape((__stack.lineno = 8, 
                            a.id)), '" data-viewcntr="folder', escape((__stack.lineno = 8, a.domid)), '" >\n			<div class="filev3-folder drag-dom" data-dbaction="folder.open"  data-path="', escape((__stack.lineno = 9, 
                            a.id)), '" data-viewcntr="folder', escape((__stack.lineno = 9, a.domid)), '" title="', (__stack.lineno = 9, 
                            a.fname), "&#10;文件个数：", (__stack.lineno = 9, a.filenum), "&#10;创建时间：", escape((__stack.lineno = 9, 
                            a.ctoStr)), "&#10;创建人：", (__stack.lineno = 9, a.nick), '"></div>\n			<span class="name drag-dom" title="', (__stack.lineno = 10, 
                            a.fname), "&#10;文件个数：", (__stack.lineno = 10, a.filenum), "&#10;创建时间：", escape((__stack.lineno = 10, 
                            a.ctoStr)), "&#10;创建人：", (__stack.lineno = 10, a.nick), '">', (__stack.lineno = 10, 
                            a.fname), '</span>\n		</div>\n		<div class="item-time"  title="更新时间：', escape((__stack.lineno = 12, 
                            a.mtoStr)), '">\n			<span class="drag-dom">', escape((__stack.lineno = 13, a.mtStr)), '</span>\n		</div>\n		<div class="item-size">－</div>\n		<div class="item-user">－</div>\n		<div class="item-download-times">－</div>\n		<div class="aria-hide">\n			<a tabindex="3" class="applaction-link">', (__stack.lineno = 19, 
                            a.fname), " 文件个数：", (__stack.lineno = 19, a.filenum), " 创建时间：", escape((__stack.lineno = 19, 
                            a.ctoStr)), " 创建人：", (__stack.lineno = 19, a.nick), '</a>\n			<button tabindex="3" data-focus="file.aria" data-action="folder.open"  data-path="', escape((__stack.lineno = 20, 
                            a.id)), '" data-viewcntr="folder', escape((__stack.lineno = 20, a.domid)), '" aria-label="打开文件夹:', (__stack.lineno = 20, 
                            a.fname), ' ">文件夹', (__stack.lineno = 20, a.fname), " 更新时间：", escape((__stack.lineno = 20, 
                            a.mtoStr)), '</button>		\n		</div>	\n		<div class="item-action"><button role="button" aria-label="下载文件夹', (__stack.lineno = 22, 
                            a.fname), '" title="下载文件夹" class="v3-down" data-action="folder.downloadByBtn" tabindex="3"></button></div>\n	</div>\n');
                            __stack.lineno = 24;
                        } else {
                            buf.push('\n	<div class="file list-item ', escape((__stack.lineno = 27, a.icon)), " ");
                            __stack.lineno = 27;
                            if (a.remoteType === 2) {
                                buf.push("temp");
                                __stack.lineno = 27;
                            }
                            buf.push(" ");
                            __stack.lineno = 27;
                            if (a.succ) {
                                buf.push("succ");
                                __stack.lineno = 27;
                            }
                            buf.push(" ");
                            __stack.lineno = 27;
                            if (a.safeType) {
                                buf.push("illegal");
                                __stack.lineno = 27;
                            }
                            buf.push('" id="', escape((__stack.lineno = 27, a.domid)), '" data-path="', escape((__stack.lineno = 27, 
                            a.filepath)), '" ');
                            __stack.lineno = 27;
                            if (!locals.renderParams) {
                                buf.push('id="', escape((__stack.lineno = 27, a.domid)), '"');
                                __stack.lineno = 27;
                            }
                            buf.push(" ");
                            __stack.lineno = 27;
                            if (a.otherGroupName) {
                                buf.push(' data-dbaction="openGroupFile" data-uin="', (__stack.lineno = 27, a.gc), '"');
                                __stack.lineno = 27;
                            }
                            buf.push(' data-action="list.select" ');
                            __stack.lineno = 27;
                            if (a.preview) {
                                buf.push('data-dbaction="file.preview"');
                                __stack.lineno = 27;
                            } else if (a.canContinueUpload) {
                                buf.push('data-dbaction="task.continue"');
                                __stack.lineno = 27;
                            }
                            {
                                buf.push('data-dbaction="file.downloadByDom"');
                                __stack.lineno = 27;
                            }
                            buf.push(" ");
                            __stack.lineno = 27;
                            if (a.safeType) {
                                buf.push('title="该文件存在安全风险，无法正常使用"');
                                __stack.lineno = 27;
                            }
                            buf.push(' data-id="', (__stack.lineno = 27, a.id), '"  tabindex="-1">\n		<div class="file-select">\n			');
                            __stack.lineno = 29;
                            if (locals.batchMode === undefined ? true : locals.batchMode) {
                                buf.push('\n				<input type="checkbox" class="cbox" data-action="file.check" aria-label="文件类型:', escape((__stack.lineno = 30, 
                                a.filetype)), ",名称", escape((__stack.lineno = 30, a.fname)), ",大小:", escape((__stack.lineno = 30, 
                                a.sizeStr)), ",下载次数:", escape((__stack.lineno = 30, a.down)), "次,上传人:", escape((__stack.lineno = 30, 
                                a.nick)), ",上传时间:", escape((__stack.lineno = 30, a.ctStr)), '" tabindex="3" value="', escape((__stack.lineno = 30, 
                                a.filepath)), '" >\n			');
                                __stack.lineno = 31;
                            }
                            buf.push('\n		</div>	\n		<div class="item-name-wrap item-name-adjust" ');
                            __stack.lineno = 33;
                            if (!a.safeType) {
                                buf.push('title="', (__stack.lineno = 33, a.name), "", (__stack.lineno = 33, a.suf), "&#10;创建时间：", escape((__stack.lineno = 33, 
                                a.ctoStr)), '"');
                                __stack.lineno = 33;
                            }
                            buf.push('>\n			<div class="item-name" tabindex="-1">\n				<div class="file-icons" data-path="', escape((__stack.lineno = 35, 
                            a.filepath)), '" ');
                            __stack.lineno = 35;
                            if (a.preview) {
                                buf.push('data-dbaction="file.preview"');
                                __stack.lineno = 35;
                            }
                            buf.push('>\n					<div class="drag-dom filev3-', escape((__stack.lineno = 36, a.icon)), " ");
                            __stack.lineno = 36;
                            if (a.previewObj) {
                                buf.push("thumb");
                                __stack.lineno = 36;
                            }
                            buf.push('" ');
                            __stack.lineno = 36;
                            if (a.previewObj) {
                                buf.push('style="background-image:url(', escape((__stack.lineno = 36, a.previewObj.url)), ');"');
                                __stack.lineno = 36;
                            }
                            buf.push('></div>\n					<i class="icons-check"></i>\n				</div>\n				<span class="name drag-dom">\n					', (__stack.lineno = 40, 
                            a.name), "", (__stack.lineno = 40, a.suf), "\n				</span>\n			</div>\n			");
                            __stack.lineno = 43;
                            if (a.canEdit || a.remoteType === 2) {
                                buf.push('\n				<div class="item-tags">\n					<div class="overflow">\n						');
                                __stack.lineno = 46;
                                if (a.canEdit) {
                                    buf.push('<span class="can-edit"></span>');
                                    __stack.lineno = 46;
                                }
                                buf.push("\n						");
                                __stack.lineno = 47;
                                if (a.remoteType === 2) {
                                    buf.push('<span class="tmp"></span>');
                                    __stack.lineno = 47;
                                }
                                buf.push("\n					</div>\n				</div>\n			");
                                __stack.lineno = 50;
                            }
                            buf.push('\n		</div>\n		<div class="item-time" ');
                            __stack.lineno = 52;
                            if (!a.safeType) {
                                buf.push('title="更新时间：', escape((__stack.lineno = 52, a.mtoStr)), '"');
                                __stack.lineno = 52;
                            }
                            buf.push(' aria-live="polite" aria-atomic="false" aria-relevant="all">\n\n			<span class="drag-dom" ');
                            __stack.lineno = 54;
                            if (a.canContinueUpload || a.status === "pause" || a.status === "downloadprogress") {
                                buf.push('style="display:none"');
                                __stack.lineno = 54;
                            }
                            buf.push(">", escape((__stack.lineno = 54, a.mtStr)), "</span>\n			");
                            __stack.lineno = 55;
                            if (a.canContinueUpload || a.status === "pause" || a.status === "downloadprogress") {
                                buf.push('		\n			<div class="file-download file-status">\n			  <div class="file-pres-status">\n			    <span class="file-task-txt">', (__stack.lineno = 58, 
                                a.wording), '</span>\n			    <div class="file-parents">\n			      <div class="width" style="width:', (__stack.lineno = 60, 
                                a.cPercent), '%"></div>\n			    </div>\n			  </div>\n			  <div class="file-status-action ', (__stack.lineno = 63, 
                                a.styles), '">\n			    <a class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 ', escape((__stack.lineno = 64, 
                                a.name)), '" tabindex="-1"></a>\n			    <a class="resume" data-action="task.resume" title="启动" aria-label="启动任务 ', escape((__stack.lineno = 65, 
                                a.name)), '" tabindex="-1"></a>\n			    <a class="continue" data-action="task.continue" title="续传" aria-label="续传任务 ', escape((__stack.lineno = 66, 
                                a.name)), '" tabindex="-1"></a>\n			    <a class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 ', escape((__stack.lineno = 67, 
                                a.name)), '" tabindex="-1"></a>\n			    <a class="miss-close" onclick="G.removeTaskInDownLoad(', (__stack.lineno = 68, 
                                a.taskId), ",", (__stack.lineno = 68, a.filepath), ')"></a>\n			  </div>\n			</div>\n			');
                                __stack.lineno = 71;
                            }
                            buf.push('			\n		</div>\n		<div class="item-size" ');
                            __stack.lineno = 73;
                            if (!a.safeType) {
                                buf.push('title="文件大小：', escape((__stack.lineno = 73, a.sizeStr)), '"');
                                __stack.lineno = 73;
                            }
                            buf.push('>\n			<span class="drag-dom">', escape((__stack.lineno = 74, a.sizeStr)), '</span>\n		</div>\n		<div class="item-user" ');
                            __stack.lineno = 76;
                            if (!a.safeType) {
                                buf.push('title="上传者：', (__stack.lineno = 76, a.nick), " (", escape((__stack.lineno = 76, 
                                a.uin)), ')"');
                                __stack.lineno = 76;
                            }
                            buf.push(" ");
                            __stack.lineno = 76;
                            if (locals.renderParams && locals.renderParams.getByUinHide === true) {
                                buf.push('data-action=""');
                                __stack.lineno = 76;
                            } else {
                                buf.push('data-action="file.getByUin"');
                                __stack.lineno = 76;
                            }
                            buf.push(' data-uin="', escape((__stack.lineno = 76, a.uin)), '"><span>', (__stack.lineno = 76, 
                            a.nick), '</span></div>\n		<div class="item-download-times" title="下载次数：', escape((__stack.lineno = 77, 
                            a.down)), '次"><span>', escape((__stack.lineno = 77, a.down)), '次</span></div>\n		<div class="item-action">\n			');
                            __stack.lineno = 79;
                            if (!a.safeType && !a.canContinueUpload) {
                                buf.push("\n				");
                                __stack.lineno = 80;
                                if (a.isDown) {
                                    buf.push('\n					<button tabindex="-1" role="button" aria-label="在文件夹中打开" title="在文件夹中打开" class="v3-open" data-action="file.openFolder"></button>\n				');
                                    __stack.lineno = 82;
                                } else {
                                    buf.push('\n					<button tabindex="-1" role="button" aria-label="下载文件', escape((__stack.lineno = 83, 
                                    a.fname)), '" title="下载文件" class="v3-down" data-action="file.downloadByBtn"></button>\n				');
                                    __stack.lineno = 84;
                                }
                                buf.push("\n			");
                                __stack.lineno = 85;
                            }
                            buf.push('\n		</div>\n		<div class="aria-hide">\n			<a class="applaction-link" tabindex="3">名称:', escape((__stack.lineno = 88, 
                            a.fname)), ",文件类型:", escape((__stack.lineno = 88, a.filetype)), ",大小:", escape((__stack.lineno = 88, 
                            a.sizeStr)), ",下载次数:", escape((__stack.lineno = 88, a.down)), "次,上传人:", escape((__stack.lineno = 88, 
                            a.nick)), ",上传时间:", escape((__stack.lineno = 88, a.ctStr)), ",");
                            __stack.lineno = 88;
                            if (a.succ) {
                                buf.push("该文件已下载");
                                __stack.lineno = 88;
                            }
                            buf.push("</a>\n			");
                            __stack.lineno = 89;
                            if (a.isDown) {
                                buf.push('\n				<button role="button" tabindex="3" data-action="file.openFolder" class="file-aria-btn" data-focus="file.aria" aria-label="打开', escape((__stack.lineno = 90, 
                                a.fname)), '"></button>\n			');
                                __stack.lineno = 91;
                            } else {
                                buf.push('\n				<button role="button" tabindex="3" data-action="file.downloadByBtn" class="file-aria-btn" data-focus="file.aria" aria-label="下载文件', escape((__stack.lineno = 92, 
                                a.fname)), '"></button>\n			');
                                __stack.lineno = 93;
                            }
                            buf.push("\n			");
                            __stack.lineno = 94;
                            if (a.safeType === 0 && a.admin || G.info.isAdmin) {
                                buf.push('\n				<button data-focus="file.aria" role="button" aria-label="转发文件', escape((__stack.lineno = 95, 
                                a.fname)), '" data-action="file.forward" tabindex="3">转发', escape((__stack.lineno = 95, 
                                a.fname)), '</button>\n				<button data-focus="file.aria" role="button" aria-label="转发文件', escape((__stack.lineno = 96, 
                                a.fname)), '到手机" data-action="file.forwardMobile" tabindex="3">转发文件到手机', escape((__stack.lineno = 96, 
                                a.fname)), '</button>\n				<button data-focus="file.aria" role="button" aria-label="在文件夹中显示', escape((__stack.lineno = 97, 
                                a.fname)), '" data-action="file.openFolderInBox" tabindex="3">在文件夹中显示', escape((__stack.lineno = 97, 
                                a.fname)), '</button>\n				<button data-focus="file.aria" role="button" aria-label="重命名文件', escape((__stack.lineno = 98, 
                                a.fname)), '" data-action="file.showRename" data-blur="aria.fmg" tabindex="3">重命名', escape((__stack.lineno = 98, 
                                a.fname)), "</button>\n				");
                                __stack.lineno = 99;
                                if (a.remoteType === 2) {
                                    buf.push('<button data-focus="file.aria" role="button" aria-label="转存为永久文件', escape((__stack.lineno = 99, 
                                    a.fname)), '" data-action="file.permanent" tabindex="3">转存为永久文件', escape((__stack.lineno = 99, 
                                    a.fname)), "</button>");
                                    __stack.lineno = 99;
                                }
                                buf.push('\n				<button data-focus="file.aria" role="button" aria-label="移动文件', escape((__stack.lineno = 100, 
                                a.fname)), '" data-action="file.showMove" data-blur="aria.fmg" tabindex="3">移动文件', escape((__stack.lineno = 100, 
                                a.fname)), "</button>\n			");
                                __stack.lineno = 101;
                            }
                            buf.push("\n			");
                            __stack.lineno = 102;
                            if (a.safeType && a.admin || G.info.isAdmin) {
                                buf.push('\n				<button data-focus="file.aria"  role="button" aria-label="删除文件', escape((__stack.lineno = 103, 
                                a.fname)), '" data-action="file.delete" tabindex="3">删除', escape((__stack.lineno = 103, 
                                a.fname)), "</button>\n			");
                                __stack.lineno = 104;
                            }
                            buf.push('\n			<button data-focus="file.aria" role="button" aria-label="举报文件', escape((__stack.lineno = 105, 
                            a.fname)), '" data-action="file.jubao" tabindex="3">举报文件', escape((__stack.lineno = 105, 
                            a.fname)), "</button>\n		</div>\n	</div>\n");
                            __stack.lineno = 108;
                        }
                    }
                    buf.push("\n");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, , , , , , , , function(e, t, a) {
    "use strict";
    var i = function() {
        var e = /"|&|'|<|>|[\x00-\x20]|[\x7F-\xFF]|[\u0100-\u2700]/g;
        var t = /&\w+;|&#(\d+);/g;
        var a = /(^\s*)|(\s*$)/g;
        var i = {
            "&lt;": "<",
            "&gt;": ">",
            "&amp;": "&",
            "&nbsp;": " ",
            "&quot;": '"',
            "&copy;": ""
        };
        var n = function o(t) {
            t = t != undefined ? t : "";
            return typeof t != "string" ? t : t.replace(e, function(e) {
                var t = e.charCodeAt(0), a = [ "&#" ];
                t = t == 32 ? 160 : t;
                a.push(t);
                a.push(";");
                return a.join("");
            });
        };
        var r = function l(e) {
            e = e != undefined ? e : "";
            var a = typeof e != "string" ? e : e.replace(t, function(e, t) {
                var a = i[e];
                if (a == undefined) {
                    if (!isNaN(t)) {
                        a = String.fromCharCode(t == 160 ? 32 : t);
                    } else {
                        a = e;
                    }
                }
                return a;
            });
            a = a.replace(/&#x2028;/g, "\u2028");
            a = a.replace(/&#x2029;/g, "\u2029");
            return a;
        };
        return {
            encodeHtml: n,
            decodeHtml: r
        };
    }();
    e.exports = {
        encode: i.encodeHtml,
        decode: i.decodeHtml
    };
}, function(e, t, a) {
    "use strict";
    var i = a(84), n = {}, r = $(G.handler);
    e.exports = n;
    var o = 10, l = 3 * 60 * 1e3;
    function s(e) {
        var t = e.filepath;
        var a = e.remoteType;
        var i = e.fname;
        var n = e.fp;
        if (!n) {
            n = t.substr(4);
        }
        var r = a == 1 ? 0 : 1;
        var n = r + "<" + n + "<" + escape(i);
        return n;
    }
    function f(e) {
        var t = "";
        for (var a = 0; a < e.length; a++) {
            if (a > 0) {
                t += ":";
            }
            t += s(e[a]);
        }
        return t;
    }
    n.getThumb = function(e, t) {
        if (!G.flagThumb) {
            return;
        }
        var a = f(e);
        var n = {
            id: Math.floor(new Date().getTime() / 1e3),
            fp_list: a
        };
        i.getPreview(n).done(function(t) {
            if (t.ec === 0) {
                if (!t.address_list) {
                    t.address_list = [];
                }
                for (var a = 0, i = e.length; a < i; a++) {
                    var n = e[a], o = t.address_list[a];
                    o.t = new Date().getTime();
                    if (n) {
                        n.usedTime = 0;
                        G.previewCache[n.filepath] = o;
                        n.previewObj = o;
                        r.trigger("file.thumbUpdate", n);
                    }
                }
            }
        }).fail(function(e) {});
    };
    n.getOneThumb = function(e, t) {
        var a = new Date().getTime();
        try {
            if (a - e.previewObj.t < l && e.usedTime <= 3) {
                t(e);
                return;
            }
        } catch (n) {
            console.log(n);
        }
        var r = {
            id: Math.floor(new Date().getTime() / 1e3),
            fp_list: s(e)
        };
        i.getPreview(r).done(function(a) {
            if (a.ec === 0) {
                if (!a.address_list) {
                    a.address_list = [];
                }
                var i = a.address_list[0];
                i.t = new Date().getTime();
                e.usedTime = 0;
                e.previewObj = i;
                t(e);
            }
        }).fail(function(e) {});
    };
}, function(e, t, a) {
    "use strict";
    function i() {}
    e.exports = {
        "input.edit": i
    };
}, function(e, t, a) {
    "use strict";
    var i = a(180);
    var n = function r() {
        i.hideAll();
        if (G.activeElement) {
            G.activeElement.focus();
        }
    };
    e.exports = {
        "panel.close": n
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        folderTree: a(258),
        list: a(31)
    };
    var n = {
        folder: a(273)
    };
    var r = a(156);
    var o = a(276);
    var l = a(84);
    var s = a(54);
    var f = a(258);
    var d = a(17);
    var c = false;
    var u = false;
    var p = true;
    function v() {
        if ($('[data-keyup="folderTree.create"]').length) {
            console.log("can not try to create more than one folder at the same time");
            return;
        }
        report("createFolderInTree");
        p = true;
        i.folderTree.newFolder();
        i.folderTree.select("new");
        $("#inputFolderNameInFolderTree").val(d.getFolderNameDefault());
        $("#inputFolderNameInFolderTree")[0].focus();
        $("#inputFolderNameInFolderTree")[0].select();
        p = false;
    }
    function m(e) {
        if (p) {
            return;
        }
        e.keyCode = 13;
        h.call(this, e);
    }
    function h(e, t) {
        if (e && e.keyCode !== 13 && $("#inputFolderNameInFolderTree").length) {
            r["input.keyup"].call(this, e);
            return;
        }
        var a = $('[data-keyup="folderTree.create"]');
        if (!a.length) {
            t && t();
            return;
        }
        if (t) {
            u = t;
        }
        if (c) {
            return;
        }
        var o = $.trim(a.val());
        var d = r.folderName(o);
        if (!d) {
            return;
        }
        var p = {
            parent_id: "/",
            name: o
        };
        var v = this;
        c = true;
        l.createFolder(p).done(function(e) {
            var t = s.filterFolder(e.folder_info);
            s.addData(t);
            i.list.appendFold(t);
            var a = $(".folder-tree-box").find('[data-id="new"].folder-list-item');
            a.html(n.folder({
                item: t
            })).attr("data-id", t.id);
            if (G.folderTree.selected.id === "new") {
                f.select(t.id);
            }
            report("createFolderInTreeSuc");
            c = false;
            u && u();
            u = false;
        }).fail(function(e) {
            console.log("fail", e);
            c = false;
            var t = {
                134: "文件夹名称包含违禁词",
                313: "文件夹名已经存在",
                314: "创建文件夹失败",
                405: "文件夹个数已达上限",
                "default": "创建失败"
            };
            var a = Math.abs(e.ec);
            var i = $(".folder-tree-box").find(".bubble");
            i.html('<span class="bot"></span><span class="top"></span>' + (t[a] || t["default"])).show();
            setTimeout(function() {
                i.hide();
            }, 3e3);
        });
    }
    e.exports = {
        "folderTree.select": f.select,
        "folderTree.new": v,
        "folderTree.create": h,
        createInputBlur: m
    };
}, function(e, t, a) {
    "use strict";
    var i = a(87);
    var n = a(58);
    var r = a(57);
    var o = a(54);
    var l = function M() {
        G.activeElement = this;
    };
    var s = [ 65, 68, 0, 72, 74, 76, 77, 78, 79, 80, 82, 85, 89 ];
    var f = function D() {
        var e = $(document.activeElement).parents(".list-item");
        if (e.length === 0) {
            return false;
        }
        var t = e.data("path");
        var a = void 0;
        var i = o.getData(t);
        if (i.orcType === 2) {
            a = "fold";
        } else if (i.orcType == 1) {
            a = "file";
        }
        G.selectRow = i || {};
        G.selectRow.path = t;
        G.selectRow.type = a;
        G.selectRows = [ G.selectRow ];
        return true;
    };
    var d = function R() {
        if (f()) {
            if (G.selectRow.orcType === 2) {
                r["folder.open"](G.selectRow.id);
            }
        }
    };
    var c = function I() {
        if (f()) {
            if (G.selectRow.type === "file") {
                n["file.showRename"]();
            } else if (G.selectRow.type === "fold") {
                r["folder.showRenameFolder"]();
            }
        }
    };
    var u = function j() {
        if (f()) {
            if (G.selectRow.type === "file") {
                n["file.download"]();
            } else if (G.selectRow.type === "fold") {
                r["folder.download"]();
            }
        }
    };
    var p = function L() {
        if (f()) {
            if (G.selectRow.type === "fold") {
                r["folder.property"]();
            }
        }
    };
    var v = function O() {
        if (f()) {
            if (G.selectRow.type === "file") {
                n["file.showRename"]();
            } else if (G.selectRow.type === "fold") {
                r["folder.showRenameFolder"]();
            }
        }
    };
    var m = function P() {
        if (f()) {
            if (G.selectRow.type === "file") {
                n["file.preview"]();
            }
        }
    };
    var h = function N() {
        if (f()) {
            if (G.selectRow.type === "file") {
                n["file.showMove"]();
            }
        }
    };
    var g = function E() {
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
        if (f()) {
            if (G.selectRow.type === "file") {
                if (e) {
                    n["file.forwardMobile"]();
                } else {
                    n["file.forward"]();
                }
            }
        }
    };
    var w = function A() {
        if (f()) {
            if (G.selectRow.type === "file") {
                n["file.jubao"]();
            }
        }
    };
    G.nowIdx = 0;
    var b = function B(e) {
        var t = G.onlyGetDom().find(".item-name");
        if (!e) {
            G.nowIdx--;
        } else {
            G.nowIdx++;
        }
        var a = G.nowIdx;
        if (a < 0) {
            a = t.length - 1;
        } else if (a > t.length - 1) {
            a = 0;
        }
        t.eq(a).focus();
    };
    G.nowSelectMoveFolder = 0;
    var _ = function U(e) {
        if ($("#folderTreePanel").hasClass("open")) {
            var t = $("#folderTreePanel").find(".aria-hide");
            if (!e) {
                G.nowSelectMoveFolder--;
            } else {
                G.nowSelectMoveFolder++;
            }
            var a = G.nowSelectMoveFolder;
            if (a < 0) {
                a = t.length - 1;
            } else if (a > t.length - 1) {
                a = 0;
            }
            t.eq(a).focus();
            G.nowSelectMoveFolder = a;
        }
    };
    var k = function z(e) {
        switch (e) {
          case 37:
            _(0);
            break;

          case 39:
            _(1);
            break;

          case 38:
            b(0);
            break;

          case 40:
            b(1);
            break;

          case 65:
            $("#selectAllFile").click();
            break;

          case 66:
            $("#openBoxBtn").click();
            break;

          case 68:
            c();
            break;

          case 70:
            g();
            break;

          case 71:
            r["folder.open"]("/");
            break;

          case 72:
            g(true);
            break;

          case 74:
            w();
            break;

          case 76:
            doDownLoad();
            break;

          case 77:
            h();
            break;

          case 78:
            $("#createFolder button").click();
            break;

          case 79:
            d();
            break;

          case 80:
            p();
            break;

          case 82:
            v();
            break;

          case 85:
            $(".icons-upload-1").click();
            break;

          case 88:
            $(G.handler).trigger("panel.hideAll");
            break;

          case 89:
            m();
            break;
        }
    };
    var y = function q(e) {
        switch (e) {
          case 81:
            $("#ariaQuickTipsDom").focus();
            break;
        }
    };
    var x = false;
    var F = function H(e) {
        var t = $(e.target);
        if (e.target.classList.contains("applaction-link")) {
            var a = t.offset();
            e.clientX = 0;
            e.clientY = Math.abs(a.top);
            i.customMenu.call(this, e);
            x = true;
        }
    };
    var T = function Q(e) {
        if (e.altKey && e.shiftKey) {
            k.call(this, e.keyCode);
        } else if (e.ctrlKey) {
            y.call(this, e.keyCode);
        }
    };
    var C = function V() {
        var e = $("#boxListDom").find(".file2");
        e.each(function() {
            $(this).find(".aria-tips").attr("tabindex", 1);
            if (this.classList.contains("continue")) {
                $(this).find(".remove").attr("tabindex", 1);
                $(this).find(".continue").attr("tabindex", 1);
            } else if (this.classList.contains("pause")) {
                $(this).find(".resume").attr("tabindex", 1);
                $(this).find(".remove").attr("tabindex", 1);
            } else if (this.classList.contains("err")) {
                $(this).find(".pause").attr("tabindex", 1);
                $(this).find(".remove").attr("tabindex", 1);
            } else if (this.classList.contains("progress")) {
                $(this).find(".remove").attr("tabindex", 1);
            } else if (this.classList.contains("complete")) {}
        });
    };
    var S = function W() {
        $("#boxListDom .file-action a").attr("tabindex", "-1");
    };
    e.exports = {
        "aria.fmg": l,
        changeBoxTabIndex: C,
        removeBoxTabIndex: S,
        "aria.quick": T
    };
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(82);
    function l(e) {
        if (e.action === "offline") {} else if (e.action === "online") {}
    }
    var s = function d() {
        var e = parseInt($(this).data("uin"));
        o.openGroupInfoCard(e);
    };
    var f = function c() {
        var e = parseInt($(this).data("uin"));
        var t = G.fileMap()[$(this).data("path")] || {};
        var a = {
            action: "search",
            params: {
                keyword: G.searchKeyword,
                files: [ {
                    fileId: t.fp,
                    busId: t.busid
                } ]
            }
        };
        localStorage.setItem("notifyOtherGroup", encodeURIComponent((0, n.default)({
            gc: e,
            webParams: (0, n.default)(a),
            random: Math.random()
        })));
        o.openGroupFile(e, encodeURIComponent((0, n.default)(a)));
    };
    e.exports = {
        groupEvent: l,
        openGroupFile: f,
        openGroupInfoCard: s
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(82);
    var r = a(31);
    var o = a(53);
    var l = a(22);
    var s = $(G.handler);
    function f(e) {
        delete e.status;
        e.isDown = false;
        e.isDowning = false;
        e.succ = false;
        r.updateDownloadRow(e);
        l.remove(e);
    }
    function d(e, t) {
        s.trigger("menu.hide");
        var a = t === 1 ? "文件" : "`文件夹";
        if (window.external && window.external.isFileExist) {
            var r = window.external.isFileExist(e);
            if (r == "false" || r === false) {
                n.alert(2, "提示", "此" + a + "不存在，可能已被删除或被移动到其他位置");
                var o = i.getFile(e);
                f(o);
                return false;
            }
        } else {}
        if (window.external && window.external.openFile) {
            var l = window.external.openFile(e);
            if (l == "success") {
                return true;
            } else if (l !== "file cannot open") {
                return false;
            }
        }
        if (window.external && window.external.openFolder) {
            var d = window.external.openFolder(e);
            if (d == "success") {} else {
                n.alert(2, "提示", "此" + a + "不存在，可能已被删除或被移动到其他位置");
                return false;
            }
        } else {}
    }
    function c() {
        var e = G.selectRow;
        var t = e.localpath;
        s.trigger("menu.hide");
        if (typeof t === "string" && t.indexOf("OSRoot") < 0) {
            t = "OSRoot:\\" + t;
        }
        report("clkOpenFile", G.module());
        var a = G.getReportInfo(e);
        a.ver3 = 1;
        reportNew("folderRightMenuClick", a);
        if (window.external && window.external.isFileExist) {
            var i = window.external.isFileExist(t);
            if (i == "false" || i === false) {
                n.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                f(e);
                return false;
            }
        } else {}
        if (window.external && window.external.openFolder) {
            var r = window.external.openFolder(t);
            if (r == "success") {} else {
                n.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                return false;
            }
        } else {}
    }
    function u(e) {
        var t = true;
        if (!e) {
            var a = $(this).parents(".file");
            var r = a.data("path");
            e = i.getData(r);
            t = false;
        }
        var o = e.localpath;
        if (o && o.indexOf("OSRoot:\\") != 0) {
            o = "OSRoot:\\" + o;
        }
        var l = function v() {
            if (window.external && window.external.openFolder) {
                var t = window.external.openFolder(o);
                if (t == "success") {} else {
                    n.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                    f(e);
                    return false;
                }
            } else {}
        };
        s.trigger("menu.hide");
        if (window.external && window.external.isFileExist) {
            var d = window.external.isFileExist(o);
            if (d == "false" || d === false) {
                n.alert(2, "提示", "此文件不存在，可能已被删除或被移动到其他位置");
                f(e);
                return false;
            }
        } else {}
        if (t) {
            var c = [ "excel", "pdf", "ppt", "word", "text", "pic", "video", "music" ];
            if ($.inArray(e.icon, c) < 0) {
                l();
                return;
            }
            if (typeof o === "string" && o.indexOf("OSRoot") < 0) {
                o = "OSRoot:\\" + o;
            }
            report("clkOpenFile", G.module());
            if (window.external && window.external.openFile) {
                var u = window.external.openFile(o);
                if (u == "success") {
                    return true;
                } else if (u === "file cannot open") {
                    var p = n.confirm(2, "提示", "此文件无法识别并打开，是否在文件夹中查看该文件？");
                    if (p.errorCode === 0 && p.ret) {} else {
                        return false;
                    }
                }
            }
        }
        l();
    }
    function p() {
        var e = this;
        s.trigger("menu.hide");
        report("clkShowInFolder", G.module());
        while (!e.classList.contains("complete")) {
            e = e.parentNode;
        }
        var t = $(e);
        var a = t.data("path");
        var n = i.getData(a);
        try {
            if (n.suf == ".js") {
                return;
            }
            var r = n._localpath || n.localpath || n.localname;
            if (r && r.indexOf("OSRoot:\\") != 0) {
                r = "OSRoot:\\" + r;
            }
            var o = d(r, n.orcType);
            if (o == false) {}
        } catch (l) {}
    }
    function v() {
        var e = this;
        s.trigger("menu.hide");
        while (!e.classList.contains("complete")) {
            e = e.parentNode;
        }
        var t = $(e);
        var a = t.data("path");
        var r = i.getData(a);
        $("#boxTitle a").focus();
        if (r) {
            try {
                if (r.suf == ".js") {
                    return;
                }
                var o = r._localpath || r.localpath || r.localname;
                if (o) {
                    if (typeof o === "string" && o.indexOf("OSRoot:\\") != 0) {
                        o = "OSRoot:\\" + o;
                    }
                    var l = false;
                    if (window.external && window.external.openFolder) {
                        var d = window.external.openFolder(o);
                        if (d == "success") {
                            l = true;
                        } else {
                            n.alert(2, "提示", "此文件夹不存在，可能被删除或被移动到其他位置");
                        }
                    } else {}
                    if (l == false) {
                        f(r);
                    }
                } else {
                    f(r);
                }
            } catch (c) {}
        }
    }
    function m() {
        var e = G.selectRow;
        s.trigger("menu.hide");
        var t = G.getReportInfo(e);
        t.ver3 = 3;
        reportNew("fileRightMenuClick", t);
        if (e) {
            report("clkShowInFolder", G.module());
            try {
                if (e.suf == ".js") {
                    return;
                }
                var a = e.localpath;
                if (a) {
                    if (typeof a === "string" && a.indexOf("OSRoot:\\") != 0) {
                        a = "OSRoot:\\" + a;
                    }
                    var i = false;
                    if (window.external && window.external.openFolder) {
                        var r = window.external.openFolder(a);
                        if (r == "success") {
                            i = true;
                        } else {
                            n.alert(2, "提示", "此文件夹不存在，可能被删除或被移动到其他位置");
                        }
                    } else {}
                    if (i == false) {
                        f(e);
                    }
                } else {
                    f(e);
                }
            } catch (o) {}
        }
    }
    e.exports = {
        openByFolder: c,
        openByPath: u,
        openByBox: p,
        openByMenu: m,
        openFolderByBoxIco: v,
        changeOpenFolder2Download: f
    };
}, function(e, t, a) {
    "use strict";
    var i = a(277);
    var n = a(278);
    var r = a(279);
    var o = a(280);
    var l = a(281);
    var s = a(282);
    var f = a(283);
    var d = a(178);
    var c = a(284);
    var u = a(285);
    e.exports = {
        "box.toggle": i.toggle,
        "task.continue": n.continueUpload,
        "task.pause": o.pause,
        "task.remove": l.remove,
        "task.resume": s.resume,
        "task.clear": r.clear,
        "task.openFolder": d.openByBox,
        "task.openFolderIco": d.openFolderByBoxIco,
        "tips.close": u.closeTips,
        "tips.refesh": u.refeshVip,
        "tips.con": u.conVip,
        "tips.vipOk": u.vipTipsOk,
        "tips.vipCancel": u.vipTipsCancel,
        "tips.open": u.openVip,
        "task.clearHistory": r.clear,
        "task.openfail": c.toggle
    };
}, function(e, t, a) {
    "use strict";
    var i = a(25);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = {
        folderTreePanel: a(227)
    };
    var l = a(258);
    var s = $(G.handler);
    function f(e, t) {
        s.trigger("menu.hide");
        var a = void 0;
        if ((typeof t === "undefined" ? "undefined" : (0, n.default)(t)) === "object") {
            e.find(".panel-title span").text(t.title);
            e.find(".rename-hint").text(t.tips);
            e.find(".btn-ok").attr("data-action", t.action);
            a = e.find(".new-name");
            if (t.showValue) {
                a.val(t.showValue);
            }
        }
        e.find(".error-message").removeClass("show");
        e.addClass("open").focus();
        if (t && t.showValue) {
            a[0].inputStart = true;
            a[0].placeholder = t.tips;
            a[0].focus();
            a[0].select();
            setTimeout(function() {
                a[0].inputStart = false;
            }, 200);
        }
    }
    function d(e) {
        e.removeClass("open");
    }
    function c(e) {
        s.trigger("menu.hide");
        var t = $("#containerFolderTreePanel");
        t.html(o.folderTreePanel(e));
        l.render(t.find(".folder-tree-box"));
        t.find("#folderTreePanel").addClass("open");
    }
    function u(e, t) {
        s.trigger("menu.hide");
        e.addClass("open").focus();
        if (t) {
            if (t.hideAll) {
                e.find(".panel-footer").addClass("hide");
            } else {
                e.find(".panel-footer").removeClass("hide");
            }
            if (t.hideOk) {
                e.find(".btn-ok").addClass("hide");
            } else {
                e.find(".btn-ok").removeClass("hide");
            }
            if (t.closeText) {
                e.find(".btn-no").text("确定").val("确定");
            } else {
                e.find(".btn-no").text("取消").val("取消");
            }
            if (t.okBtnText) {
                e.find(".btn-ok").text(t.okBtnText).val(t.okBtnText);
            }
            if (t.module === 2) {
                e.find(".icons-new-alert").addClass("icons-fail-alert");
            } else {
                e.find("icons-new-alert").removeClass("icons-fail-alert");
            }
            e.find(".panel-title span").text(t.title);
            e.find(".panel-content").html(t.text);
            e.find(".btn-ok").attr("data-action", t.action);
        }
    }
    function p() {
        $(".panel-overlay").removeClass("open");
        console.log("hide all!");
    }
    s.bind("panel.hideAll", p);
    e.exports = {
        show: f,
        hide: d,
        hideAll: p,
        showFolderTreePanel: c,
        showBatchPanel: u
    };
}, , function(e, t, a) {
    "use strict";
    var i = {};
    var n = $("#groupSize");
    var r = $("#groupSizeBar");
    i.renderSpace = function o() {
        if (G.nowFolder !== "/") {
            return;
        }
        n.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        r.css("width", e + "%");
        $("#fileNum").removeClass("hide");
        $(".nav").addClass("hide");
        $("#normalNav").removeClass("hide");
    };
    e.exports = i;
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(17);
    var l = window.performance;
    var s = {};
    e.exports = s;
    var f = o.getParameter("gc");
    function d() {
        u = o.getCookie("skey");
        var e = 5381;
        for (var t = 0, a = u.length; t < a; ++t) {
            e += (e << 5) + u.charCodeAt(t);
        }
        var i = e & 2147483647;
        return i;
    }
    function c() {
        var e = o.getCookie("uin");
        if (!e) {
            return 0;
        }
        e += "";
        return e.replace(/^[\D0]+/g, "");
    }
    var u = o.getCookie("skey");
    var p = c();
    var v = o.getParameter("groupuin");
    var m = d();
    function h(e) {
        return false;
    }
    var g = [ "http://pan.qun.qq.com/cgi-bin/checkAuditFlag" ];
    var w = [];
    var b = [];
    var _ = {
        get_vip_info: 3,
        checkAuditFlag: 4,
        get_file_lsit: 5,
        get_group_space: 6,
        move_file: 7,
        rename_file: 8,
        create_folder: 9,
        rename_folder: 10,
        delete_folder: 11,
        thumbnail: 12
    };
    function k(e) {
        var t;
        if (e < 500) {
            t = 2220106;
        } else if (e < 2e3) {
            t = 2220107;
        } else if (e < 4e3) {
            t = 2220108;
        } else if (e < 6e3) {
            t = 2220109;
        } else if (e < 8e3) {
            t = 2220110;
        } else if (e < 1e4) {
            t = 2220111;
        } else if (e < 12e3) {
            t = 2220112;
        } else if (e < 15e3) {
            t = 2220113;
        } else if (e < 2e4) {
            t = 2220114;
        } else if (e < 25e3) {
            t = 2220115;
        } else if (e < 3e4) {
            t = 2220116;
        } else if (e < 4e4) {
            t = 2220117;
        } else if (e < 5e4) {
            t = 2220118;
        } else if (e < 6e4) {
            t = 2220119;
        } else {
            t = 2220120;
        }
        QReport.monitor(t);
    }
    function y(e, t) {
        var a = {
            get_vip_info: 3,
            checkAuditFlag: 4,
            get_file_list: 5,
            get_group_space: 6,
            move_file: 7,
            rename_file: 8,
            create_folder: 9,
            rename_folder: 10,
            delete_folder: 11,
            thumbnail: 12
        };
        var i = e.split("/");
        var n = a[i[i.length - 1]];
        if (n) {
            QReport.huatuo({
                appid: 10016,
                flag1: 1772,
                flag2: 1,
                flag3: n,
                speedTime: t
            });
        }
    }
    function x(e, t) {
        if (!l) {
            return;
        }
        if (e.indexOf("//") === 0) {
            if (G.checkHttps()) {
                e = "https:" + e;
            } else {
                e = "http:" + e;
            }
        }
        var a = e.substr(0, e.indexOf("?"));
        if (e.indexOf("?") < 0) {
            a = e;
        }
        if ($.inArray(e, b) < 0) {
            if (!l.getEntriesByName) {
                return;
            }
            var i = l.getEntriesByName(e)[0];
            if (!i) {
                return;
            }
            b.push(e);
            var r = {
                1: i.redirectEnd - i.redirectStart,
                2: i.domainLookupStart - i.fetchStart,
                3: i.domainLookupEnd - i.domainLookupStart,
                4: i.connectEnd - i.connectStart,
                5: i.responseStart - i.requestStart,
                6: i.responseEnd - i.responseStart,
                7: i.responseEnd - i.startTime,
                8: i.fetchStart,
                9: i.domainLookupStart
            };
            y(a, r);
            r.url = e;
            k(r[2]);
            if (r[2] > 5e3) {
                QReport.monitor(2220299);
                badjsReport.info((0, n.default)({
                    "重定向": r[1],
                    appcache: r[2],
                    dns: r[3],
                    tcp: r[4],
                    "接收": r[5],
                    "完成": r[6],
                    "总时间": r[7],
                    fetchStart: i.fetchStart,
                    dnsstart: i.domainLookupStart,
                    header: t.getAllResponseHeaders && t.getAllResponseHeaders() || false,
                    status: t.status,
                    t: "0427",
                    url: e,
                    "离线包": localVersion === "isLocal" ? "离线包请求" : "非离线包请求"
                }));
            }
        }
    }
    function F(e, t) {
        var a = Date.now();
        t = t || e.responseURL;
        e.done(function(i) {
            QReport.retcode({
                url: t,
                type: 1,
                code: i.ec,
                time: Date.now() - a,
                rate: 1
            });
            setTimeout(function() {
                x(t, e);
            }, 100);
            if (i.ec == 1) {
                console.log("1", "缺少登录态");
            }
        }).fail(function(e, i) {
            x(t);
            var n = {
                status: e.status,
                statusText: e.statusText
            };
            if (i == "timeout") {
                n.status = 999;
                n.statusText = "timeout";
            }
            var r = n.status;
            if (r === 0) {
                r === 9999;
            }
            QReport.retcode({
                url: t,
                type: r === 9999 ? 3 : 2,
                code: r,
                time: Date.now() - a,
                rate: 1
            });
        });
    }
    s.ajax = function(e) {
        var t = {
            type: "GET",
            dataType: "json",
            data: {
                src: "qpan",
                gc: e && e.data && e.data.gc || o.getParameter("groupuin")
            },
            xhrFields: {
                withCredentials: true
            },
            success: function n(e, t, a) {}
        };
        m && (t.data.bkn = d());
        $.extend(true, t, e);
        t.headers = {
            "Cache-Control": "no-cache,no-store"
        };
        if (t.type === "GET") {
            if (t.url.indexOf("?") < 0) {
                t.url += "?" + $.param(t.data);
            } else {
                t.url += "&" + $.param(t.data);
            }
            t.url += "&_ti=" + new Date().getTime();
            delete t.data;
        }
        var a = $.ajax(t);
        F(a, t.url);
        var i = {
            done: function r(e) {
                var i = 0;
                (function n(e, a) {
                    e.done(function(e) {
                        if (e.ec == 0) a(e);
                    });
                    e.fail(function() {
                        if (i >= 1 || h(t.url)) return;
                        i++;
                        e = $.ajax(t);
                        F(e, t.url);
                        n(e, a);
                    });
                })(a, e);
                return this;
            },
            fail: function l(e) {
                var i = 0;
                (function n(e, a) {
                    e.done(function(e) {
                        if (e.ec != 0) a(e);
                    });
                    e.fail(function(r, o) {
                        if (i >= 0) {
                            if (o == "timeout") {
                                report("cgiTimeout");
                                return a({
                                    ec: 504,
                                    msg: o
                                });
                            }
                            return a({
                                ec: r.status
                            });
                        }
                        i++;
                        e = $.ajax(t);
                        F(e, t.url);
                        n(e, a);
                    });
                })(a, e);
                return this;
            },
            timeout: function s(e) {
                a.fail(function(t, a) {
                    if (a == "timeout") e({
                        ec: 504,
                        msg: a
                    });
                });
                return this;
            },
            always: function f(e) {
                a.always(e);
                return this;
            },
            then: function c() {
                a.then.apply(a, arguments);
                return this;
            }
        };
        return i;
    };
    s.bkn = m;
}, function(e, t, a) {
    "use strict";
    var i = a(264);
    var n = a(265);
    var r = a(286);
    var o = $("#fileMoreMenu");
    function l() {
        var e = n(G.info);
        o.html(e);
    }
    function s() {
        var e = i({
            mac: G.mac
        });
        o.html(e);
    }
    function f(e, t) {
        var a = {
            data: false,
            list: false,
            isUploader: true
        };
        if (typeof t !== "undefined") {
            if (t.hasOwnProperty("length")) {
                a.list = t;
                var i = 0;
                a.list.every(function(e) {
                    if (G.info.uin !== e.uin) {
                        i++;
                    }
                    return true;
                });
                console.log(i, t.length);
                if (i === t.length) {
                    a.isUploader = false;
                }
            } else {
                a.data = t;
                G.info.uin !== t.uin && (a.isUploader = false);
            }
        }
        console.log(a);
        var n = r(a);
        e.html(n);
    }
    e.exports = {
        renderFolder: l,
        renderFile: s,
        renderCustomMenu: f
    };
}, function(e, t, a) {
    "use strict";
    var i = a(26);
    var n = l(i);
    var r = a(25);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = function(e) {
        if (e.BJ_REPORT) return e.BJ_REPORT;
        var t = [];
        var a = e.onerror;
        e.onerror = function(t, i, n, o, l) {
            var s = t;
            if (l && l.stack) {
                s = f(l);
            }
            if (r(s, "Event")) {
                s += s.type ? "--" + s.type + "--" + (s.target ? s.target.tagName + "--" + s.target.src : "") : "";
            }
            g.push({
                msg: s,
                target: i,
                rowNum: n,
                colNum: o
            });
            m();
            a && a.apply(e, arguments);
        };
        var i = {
            id: 0,
            uin: 0,
            url: "",
            combo: 1,
            ext: {},
            level: 4,
            ignore: [],
            random: 1,
            delay: 1e3,
            submit: null
        };
        var r = function w(e, t) {
            return Object.prototype.toString.call(e) === "[object " + (t || "Object") + "]";
        };
        var l = function b(e) {
            var t = typeof e === "undefined" ? "undefined" : (0, o.default)(e);
            return t === "object" && !!e;
        };
        var s = function _(e) {
            try {
                if (e.stack) {
                    var t = e.stack.match("http://[^\n]+");
                    t = t ? t[0] : "";
                    var a = t.match(":([0-9]+):([0-9]+)");
                    if (!a) {
                        a = [ 0, 0, 0 ];
                    }
                    var i = f(e);
                    return {
                        msg: i,
                        rowNum: a[1],
                        colNum: a[2],
                        target: t.replace(a[0], "")
                    };
                } else {
                    return e;
                }
            } catch (n) {
                return e;
            }
        };
        var f = function k(e) {
            var t = e.stack.replace(/\n/gi, "").split(/\bat\b/).slice(0, 5).join("@").replace(/\?[^:]+/gi, "");
            var a = e.toString();
            if (t.indexOf(a) < 0) {
                t = a + "@" + t;
            }
            return t;
        };
        var d = function y(e, t) {
            var a = [];
            var r = [];
            var o = [];
            if (l(e)) {
                e.level = e.level || i.level;
                for (var s in e) {
                    var f = e[s] || "";
                    if (f) {
                        if (l(f)) {
                            try {
                                f = (0, n.default)(f);
                            } catch (d) {
                                f = "[BJ_REPORT detect value stringify error] " + d.toString();
                            }
                        }
                        o.push(s + ":" + f);
                        a.push(s + "=" + encodeURIComponent(f));
                        r.push(s + "[" + t + "]=" + encodeURIComponent(f));
                    }
                }
            }
            return [ r.join("&"), o.join(","), a.join("&") ];
        };
        var c = [];
        var u = function x(e) {
            if (i.submit) {
                i.submit(e);
            } else {
                var t = new Image();
                c.push(t);
                t.src = e;
            }
        };
        var p = [];
        var v = 0;
        var m = function G(e) {
            if (!i.report) return;
            while (t.length) {
                var a = false;
                var n = t.shift();
                var o = d(n, p.length);
                for (var l = 0, s = i.ignore.length; l < s; l++) {
                    var f = i.ignore[l];
                    if (r(f, "RegExp") && f.test(o[1]) || r(f, "Function") && f(n, o[1])) {
                        a = true;
                        break;
                    }
                }
                if (!a) {
                    if (i.combo) {
                        p.push(o[0]);
                    } else {
                        u(i.report + o[2] + "&_t=" + +new Date());
                    }
                    i.onReport && i.onReport(i.id, n);
                }
            }
            var c = p.length;
            if (c) {
                var m = function h() {
                    clearTimeout(v);
                    u(i.report + p.join("&") + "&count=" + c + "&_t=" + +new Date());
                    v = 0;
                    p = [];
                };
                if (e) {
                    m();
                } else if (!v) {
                    v = setTimeout(m, i.delay);
                }
            }
        };
        function h(e) {
            var t = function i(e) {
                if (!e) return e;
                for (;e != unescape(e); ) {
                    e = unescape(e);
                }
                for (var t = [ "<", ">", "'", '"', "%3c", "%3e", "%27", "%22", "%253c", "%253e", "%2527", "%2522" ], a = [ "&#x3c;", "&#x3e;", "&#x27;", "&#x22;", "%26%23x3c%3B", "%26%23x3e%3B", "%26%23x27%3B", "%26%23x22%3B", "%2526%2523x3c%253B", "%2526%2523x3e%253B", "%2526%2523x27%253B", "%2526%2523x22%253B" ], i = 0; i < t.length; i++) {
                    e = e.replace(new RegExp(t[i], "gi"), a[i]);
                }
                return e;
            };
            var a;
            return t((a = document.cookie.match(RegExp("(^|;\\s*)" + e + "=([^;]*)(;|$)"))) ? unescape(a[2]) : null);
        }
        var g = {
            push: function F(e) {
                if (Math.random() >= i.random) {
                    return g;
                }
                t.push(l(e) ? s(e) : {
                    msg: e
                });
                m();
                return g;
            },
            report: function T(e) {
                e && g.push(e);
                m(true);
                return g;
            },
            info: function $(e) {
                if (!e) {
                    return g;
                }
                if (l(e)) {
                    e.level = 2;
                } else {
                    e = {
                        msg: e,
                        level: 2
                    };
                }
                g.push(e);
                return g;
            },
            debug: function C(e) {
                if (!e) {
                    return g;
                }
                if (l(e)) {
                    e.level = 1;
                } else {
                    e = {
                        msg: e,
                        level: 1
                    };
                }
                g.push(e);
                return g;
            },
            init: function S(e) {
                if (l(e)) {
                    for (var t in e) {
                        i[t] = e[t];
                    }
                }
                var a = parseInt(i.id, 10);
                if (a) {
                    i.report = (i.url || "//badjs2.qq.com/badjs") + "?id=" + a + "&uin=" + parseInt(i.uin || (document.cookie.match(/\buin=\D+(\d+)/) || [])[1], 10) + "&from=" + encodeURIComponent(location.href) + "&ext=" + (0, 
                    n.default)(i.ext) + "&";
                }
                return g;
            },
            __onerror__: e.onerror
        };
        return g;
    }(window);
    t.createReport = function(e) {
        e = e || {};
        var t = e.id;
        if (!t) throw new Error("id is required");
        s.init({
            id: t
        });
        return s;
    };
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.next = f;
    t.pref = d;
    var i = a(154);
    var n = a(30);
    var r = -1;
    var o = [];
    G.historyList = o;
    G.historyIdx = r;
    if (G.webParams) {
        o.push(G.webParams);
    }
    G.setHistory = function(e) {
        r++;
        if (o.length - r >= 1) {
            o = o.slice(0, r);
        }
        o.push(e);
        l();
    };
    var l = function c() {
        if (r > 0) {
            $(".history .left").removeClass("disable");
        } else {
            $(".history .left").addClass("disable");
        }
        if (r < o.length - 1) {
            $(".history .right").removeClass("disable");
        } else {
            $(".history .right").addClass("disable");
        }
    };
    G.isHistory = false;
    var s = function u() {
        G.isHistory = true;
        l();
        var e = o[r];
        if (e.action === "fileList") {
            i.renderFolder(e.params.folderId, e.params.fname);
        } else if (typeof e.key_word !== "undefined") {
            $("#inputSearch").val(e.key_word);
            n.search();
        }
    };
    function f() {
        if (G.isHistory) {
            return;
        }
        r++;
        if (r > o.length - 1) {
            r = o.length - 1;
            return;
        }
        s();
        reportNew("wayNext");
    }
    function d() {
        if (G.isHistory) {
            return;
        }
        r--;
        if (r < 0) {
            r = 0;
            return;
        }
        s();
        reportNew("wayPref");
    }
}, function(e, t, a) {
    "use strict";
    var i = a(25);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(55);
    var l = {
        newtask: a(287),
        taskcomplete: a(288),
        taskpause: a(289),
        taskresume: a(290),
        taskprogress: a(291),
        taskabort: a(292)
    };
    function s(e) {
        if ((typeof e === "undefined" ? "undefined" : (0, n.default)(e)) !== "object") {
            console.error("onFiletransporterEvent param parse error");
            return;
        }
        var t = e.event;
        var a = e.task;
        var i = {
            newtask: "newtask",
            taskcomplete: "taskcomplete",
            taskpause: "taskpause",
            taskresume: "taskresume",
            startprogress: "taskprogress",
            taskabort: "taskabort"
        };
        if (typeof i[t] !== "undefined" && typeof l[i[t]] !== "undefined") {
            a = o.get(a);
            l[i[t]](a);
            $(G.handler).trigger("task.startRefresh");
        }
    }
    e.exports = {
        fileEvent: s
    };
}, function(e, t, a) {
    "use strict";
    var i = a(266);
    var n = void 0;
    var r = void 0;
    function o(e) {
        if (!n) {
            var t = i();
            $("body").append(t);
            n = $("#jubaoDom");
            r = $("#jubaoIframe");
        }
        if (e) {
            n.addClass("open");
            r.attr("src", e).addClass("open");
        }
    }
    function l() {
        if (n) {
            n.removeClass("open");
            r.removeClass("open");
        }
    }
    e.exports = {
        show: o,
        hide: l
    };
}, function(e, t, a) {
    "use strict";
    var i = a(136);
    function n(e) {
        console.debug(" show upload");
        i.showUpload(e);
    }
    function r(e) {
        console.debug(" show upload files");
        var t = e.fileList;
        var a = [];
        for (var n = 0, r = t.length; n < r; n++) {
            var o = t[n];
            a.push(o.filepath);
        }
        i.batchuploadInFolder(G.nowFolder, a);
    }
    e.exports = {
        uploadEvent: n,
        dropEvent: r
    };
}, function(e, t, a) {
    var i = a(229);
    e.exports = function(e) {
        return Object(i(e));
    };
}, function(e, t, a) {
    var i = a(195), n = a(190), r = a(228)("IE_PROTO"), o = Object.prototype;
    e.exports = Object.getPrototypeOf || function(e) {
        e = n(e);
        if (i(e, r)) return e[r];
        if (typeof e.constructor == "function" && e instanceof e.constructor) {
            return e.constructor.prototype;
        }
        return e instanceof Object ? o : null;
    };
}, function(e, t, a) {
    var i = a(197), n = a(101), r = a(200);
    e.exports = function(e, t) {
        var a = (n.Object || {})[e] || Object[e], o = {};
        o[e] = t(a);
        i(i.S + i.F * r(function() {
            a(1);
        }), "Object", o);
    };
}, function(e, t, a) {
    var i = a(201)("wks"), n = a(203), r = a(194).Symbol, o = typeof r == "function";
    var l = e.exports = function(e) {
        return i[e] || (i[e] = o && r[e] || (o ? r : n)("Symbol." + e));
    };
    l.store = i;
}, function(e, t, a) {
    var i = e.exports = typeof window != "undefined" && window.Math == Math ? window : typeof self != "undefined" && self.Math == Math ? self : Function("return this")();
    if (typeof __g == "number") __g = i;
}, function(e, t, a) {
    var i = {}.hasOwnProperty;
    e.exports = function(e, t) {
        return i.call(e, t);
    };
}, function(e, t, a) {
    e.exports = !a(200)(function() {
        return Object.defineProperty({}, "a", {
            get: function() {
                return 7;
            }
        }).a != 7;
    });
}, function(e, t, a) {
    var i = a(194), n = a(101), r = a(230), o = a(220), l = "prototype";
    var s = function(e, t, a) {
        var f = e & s.F, d = e & s.G, c = e & s.S, u = e & s.P, p = e & s.B, v = e & s.W, m = d ? n : n[t] || (n[t] = {}), h = m[l], g = d ? i : c ? i[t] : (i[t] || {})[l], w, b, _;
        if (d) a = t;
        for (w in a) {
            b = !f && g && g[w] !== undefined;
            if (b && w in m) continue;
            _ = b ? g[w] : a[w];
            m[w] = d && typeof g[w] != "function" ? a[w] : p && b ? r(_, i) : v && g[w] == _ ? function(e) {
                var t = function(t, a, i) {
                    if (this instanceof e) {
                        switch (arguments.length) {
                          case 0:
                            return new e();

                          case 1:
                            return new e(t);

                          case 2:
                            return new e(t, a);
                        }
                        return new e(t, a, i);
                    }
                    return e.apply(this, arguments);
                };
                t[l] = e[l];
                return t;
            }(_) : u && typeof _ == "function" ? r(Function.call, _) : _;
            if (u) {
                (m.virtual || (m.virtual = {}))[w] = _;
                if (e & s.R && h && !h[w]) o(h, w, _);
            }
        }
    };
    s.F = 1;
    s.G = 2;
    s.S = 4;
    s.P = 8;
    s.B = 16;
    s.W = 32;
    s.U = 64;
    s.R = 128;
    e.exports = s;
}, function(e, t, a) {
    e.exports = a(220);
}, function(e, t, a) {
    var i = a(203)("meta"), n = a(231), r = a(195), o = a(214).f, l = 0;
    var s = Object.isExtensible || function() {
        return true;
    };
    var f = !a(200)(function() {
        return s(Object.preventExtensions({}));
    });
    var d = function(e) {
        o(e, i, {
            value: {
                i: "O" + ++l,
                w: {}
            }
        });
    };
    var c = function(e, t) {
        if (!n(e)) return typeof e == "symbol" ? e : (typeof e == "string" ? "S" : "P") + e;
        if (!r(e, i)) {
            if (!s(e)) return "F";
            if (!t) return "E";
            d(e);
        }
        return e[i].i;
    };
    var u = function(e, t) {
        if (!r(e, i)) {
            if (!s(e)) return true;
            if (!t) return false;
            d(e);
        }
        return e[i].w;
    };
    var p = function(e) {
        if (f && v.NEED && s(e) && !r(e, i)) d(e);
        return e;
    };
    var v = e.exports = {
        KEY: i,
        NEED: false,
        fastKey: c,
        getWeak: u,
        onFreeze: p
    };
}, function(e, t, a) {
    e.exports = function(e) {
        try {
            return !!e();
        } catch (t) {
            return true;
        }
    };
}, function(e, t, a) {
    var i = a(194), n = "__core-js_shared__", r = i[n] || (i[n] = {});
    e.exports = function(e) {
        return r[e] || (r[e] = {});
    };
}, function(e, t, a) {
    var i = a(214).f, n = a(195), r = a(193)("toStringTag");
    e.exports = function(e, t, a) {
        if (e && !n(e = a ? e : e.prototype, r)) i(e, r, {
            configurable: true,
            value: t
        });
    };
}, function(e, t, a) {
    var i = 0, n = Math.random();
    e.exports = function(e) {
        return "Symbol(".concat(e === undefined ? "" : e, ")_", (++i + n).toString(36));
    };
}, function(e, t, a) {
    var i = a(194), n = a(101), r = a(219), o = a(102), l = a(214).f;
    e.exports = function(e) {
        var t = n.Symbol || (n.Symbol = r ? {} : i.Symbol || {});
        if (e.charAt(0) != "_" && !(e in t)) l(t, e, {
            value: o.f(e)
        });
    };
}, function(e, t, a) {
    var i = a(215), n = a(209);
    e.exports = function(e, t) {
        var a = n(e), r = i(a), o = r.length, l = 0, s;
        while (o > l) if (a[s = r[l++]] === t) return s;
    };
}, function(e, t, a) {
    var i = a(215), n = a(218), r = a(217);
    e.exports = function(e) {
        var t = i(e), a = n.f;
        if (a) {
            var o = a(e), l = r.f, s = 0, f;
            while (o.length > s) if (l.call(e, f = o[s++])) t.push(f);
        }
        return t;
    };
}, function(e, t, a) {
    var i = a(232);
    e.exports = Array.isArray || function n(e) {
        return i(e) == "Array";
    };
}, function(e, t, a) {
    var i = a(231);
    e.exports = function(e) {
        if (!i(e)) throw TypeError(e + " is not an object!");
        return e;
    };
}, function(e, t, a) {
    var i = a(233), n = a(229);
    e.exports = function(e) {
        return i(n(e));
    };
}, function(e, t, a) {
    e.exports = function(e, t) {
        return {
            enumerable: !(e & 1),
            configurable: !(e & 2),
            writable: !(e & 4),
            value: t
        };
    };
}, function(e, t, a) {
    var i = a(208), n = a(234), r = a(235), o = a(228)("IE_PROTO"), l = function() {}, s = "prototype";
    var f = function() {
        var e = a(236)("iframe"), t = r.length, i = "<", n = ">", o;
        e.style.display = "none";
        a(237).appendChild(e);
        e.src = "javascript:";
        o = e.contentWindow.document;
        o.open();
        o.write(i + "script" + n + "document.F=Object" + i + "/script" + n);
        o.close();
        f = o.F;
        while (t--) delete f[s][r[t]];
        return f();
    };
    e.exports = Object.create || function d(e, t) {
        var a;
        if (e !== null) {
            l[s] = i(e);
            a = new l();
            l[s] = null;
            a[o] = e;
        } else a = f();
        return t === undefined ? a : n(a, t);
    };
}, function(e, t, a) {
    var i = a(209), n = a(216).f, r = {}.toString;
    var o = typeof window == "object" && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [];
    var l = function(e) {
        try {
            return n(e);
        } catch (t) {
            return o.slice();
        }
    };
    e.exports.f = function s(e) {
        return o && r.call(e) == "[object Window]" ? l(e) : n(i(e));
    };
}, function(e, t, a) {
    var i = a(217), n = a(210), r = a(209), o = a(225), l = a(195), s = a(238), f = Object.getOwnPropertyDescriptor;
    t.f = a(196) ? f : function d(e, t) {
        e = r(e);
        t = o(t, true);
        if (s) try {
            return f(e, t);
        } catch (a) {}
        if (l(e, t)) return n(!i.f.call(e, t), e[t]);
    };
}, function(e, t, a) {
    var i = a(208), n = a(238), r = a(225), o = Object.defineProperty;
    t.f = a(196) ? Object.defineProperty : function l(e, t, a) {
        i(e);
        t = r(t, true);
        i(a);
        if (n) try {
            return o(e, t, a);
        } catch (l) {}
        if ("get" in a || "set" in a) throw TypeError("Accessors not supported!");
        if ("value" in a) e[t] = a.value;
        return e;
    };
}, function(e, t, a) {
    var i = a(239), n = a(235);
    e.exports = Object.keys || function r(e) {
        return i(e, n);
    };
}, function(e, t, a) {
    var i = a(239), n = a(235).concat("length", "prototype");
    t.f = Object.getOwnPropertyNames || function r(e) {
        return i(e, n);
    };
}, function(e, t, a) {
    t.f = {}.propertyIsEnumerable;
}, function(e, t, a) {
    t.f = Object.getOwnPropertySymbols;
}, function(e, t, a) {
    e.exports = true;
}, function(e, t, a) {
    var i = a(214), n = a(210);
    e.exports = a(196) ? function(e, t, a) {
        return i.f(e, t, n(1, a));
    } : function(e, t, a) {
        e[t] = a;
        return e;
    };
}, function(e, t, a) {
    var i = a(241), n = a(229);
    e.exports = function(e) {
        return function(t, a) {
            var r = String(n(t)), o = i(a), l = r.length, s, f;
            if (o < 0 || o >= l) return e ? "" : undefined;
            s = r.charCodeAt(o);
            return s < 55296 || s > 56319 || o + 1 === l || (f = r.charCodeAt(o + 1)) < 56320 || f > 57343 ? e ? r.charAt(o) : s : e ? r.slice(o, o + 2) : (s - 55296 << 10) + (f - 56320) + 65536;
        };
    };
}, function(e, t, a) {
    "use strict";
    var i = a(219), n = a(197), r = a(198), o = a(220), l = a(195), s = a(224), f = a(240), d = a(202), c = a(191), u = a(193)("iterator"), p = !([].keys && "next" in [].keys()), v = "@@iterator", m = "keys", h = "values";
    var g = function() {
        return this;
    };
    e.exports = function(e, t, a, w, b, _, k) {
        f(a, t, w);
        var y = function(e) {
            if (!p && e in T) return T[e];
            switch (e) {
              case m:
                return function t() {
                    return new a(this, e);
                };

              case h:
                return function i() {
                    return new a(this, e);
                };
            }
            return function n() {
                return new a(this, e);
            };
        };
        var x = t + " Iterator", G = b == h, F = false, T = e.prototype, $ = T[u] || T[v] || b && T[b], C = $ || y(b), S = b ? !G ? C : y("entries") : undefined, M = t == "Array" ? T.entries || $ : $, D, R, I;
        if (M) {
            I = c(M.call(new e()));
            if (I !== Object.prototype) {
                d(I, x, true);
                if (!i && !l(I, u)) o(I, u, g);
            }
        }
        if (G && $ && $.name !== h) {
            F = true;
            C = function j() {
                return $.call(this);
            };
        }
        if ((!i || k) && (p || F || !T[u])) {
            o(T, u, C);
        }
        s[t] = C;
        s[x] = g;
        if (b) {
            D = {
                values: G ? C : y(h),
                keys: _ ? C : y(m),
                entries: S
            };
            if (k) for (R in D) {
                if (!(R in T)) r(T, R, D[R]);
            } else n(n.P + n.F * (p || F), t, D);
        }
        return D;
    };
}, function(e, t, a) {
    "use strict";
    var i = a(242), n = a(243), r = a(224), o = a(209);
    e.exports = a(222)(Array, "Array", function(e, t) {
        this._t = o(e);
        this._i = 0;
        this._k = t;
    }, function() {
        var e = this._t, t = this._k, a = this._i++;
        if (!e || a >= e.length) {
            this._t = undefined;
            return n(1);
        }
        if (t == "keys") return n(0, a);
        if (t == "values") return n(0, e[a]);
        return n(0, [ a, e[a] ]);
    }, "values");
    r.Arguments = r.Array;
    i("keys");
    i("values");
    i("entries");
}, function(e, t, a) {
    e.exports = {};
}, function(e, t, a) {
    var i = a(231);
    e.exports = function(e, t) {
        if (!i(e)) return e;
        var a, n;
        if (t && typeof (a = e.toString) == "function" && !i(n = a.call(e))) return n;
        if (typeof (a = e.valueOf) == "function" && !i(n = a.call(e))) return n;
        if (!t && typeof (a = e.toString) == "function" && !i(n = a.call(e))) return n;
        throw TypeError("Can't convert object to primitive value");
    };
}, function(e, t, a) {
    e.exports = function(e) {
        if (!e.webpackPolyfill) {
            e.deprecate = function() {};
            e.paths = [];
            e.children = [];
            e.webpackPolyfill = 1;
        }
        return e;
    };
}, function(e, t, a) {
    var i = a(293);
    e.exports = function n(e) {
        var t = [];
        var a = {};
        var n;
        var r = e || {};
        (function(e, a, r, o, l, s, f, d) {
            t.push('<!-- 移动文件/上传文件 公用模态框--><div id="folderTreePanel" role="panel" class="panel-overlay folder-tree-panel"><div class="panel"><div class="panel-title"><i class="icons-qq"></i><span>' + i.escape((n = e) == null ? "" : n) + '</span><div data-action="panel.close" data-dismiss="panel" aria-label="取消" class="close"></div></div><div class="panel-body"><div class="panel-content"><div class="selected-files"><span class="file-name">' + (null == (n = a) ? "" : n) + "</span>");
            if (r > 1) {
                t.push('						等 <span class="file-number">' + (null == (n = r) ? "" : n) + "</span> 个文件");
            }
            t.push('</div><div class="translateTo"><span class="translateTo-label">' + i.escape((n = o) == null ? "" : n) + '</span><span class="little-folder-icon"></span><div data-role="dest" class="selected-folder-name">' + (null == (n = l) ? "" : n) + '</div><div id="targetFolderName" aria-live="assertive" aria-atomic="true" aria-relevant="all" class="aria-hide"><span>已选中文件夹</span><span class="folder-name">' + (null == (n = l) ? "" : n) + '</span></div></div><div class="folder-tree-box"></div></div></div><div class="panel-footer">');
            if (s = f.info.isAdmin) {
                t.push('<input type="submit" value="新建文件夹" data-action="folderTree.new" tabindex="1" class="btn-create btn-common"/>');
            }
            t.push('<input type="submit" value="取消" data-action="panel.close" data-dismiss="panel" aris-label="取消移动文件" tabindex="1" class="btn-no btn-common btn-right"/><input type="submit" value="确定"' + i.attr("data-action", "" + d + "", true, false) + ' aria-label="确定移动文件" tabindex="1" class="btn-ok btn-common btn-right"/></div></div></div>');
        }).call(this, "title" in r ? r.title : typeof title !== "undefined" ? title : undefined, "firstFileName" in r ? r.firstFileName : typeof firstFileName !== "undefined" ? firstFileName : undefined, "fileNum" in r ? r.fileNum : typeof fileNum !== "undefined" ? fileNum : undefined, "action" in r ? r.action : typeof action !== "undefined" ? action : undefined, "destFolder" in r ? r.destFolder : typeof destFolder !== "undefined" ? destFolder : undefined, "canCreatFolder" in r ? r.canCreatFolder : typeof canCreatFolder !== "undefined" ? canCreatFolder : undefined, "G" in r ? r.G : typeof G !== "undefined" ? G : undefined, "okAction" in r ? r.okAction : typeof okAction !== "undefined" ? okAction : undefined);
        return t.join("");
    };
}, function(e, t, a) {
    var i = a(201)("keys"), n = a(203);
    e.exports = function(e) {
        return i[e] || (i[e] = n(e));
    };
}, function(e, t, a) {
    e.exports = function(e) {
        if (e == undefined) throw TypeError("Can't call method on  " + e);
        return e;
    };
}, function(e, t, a) {
    var i = a(244);
    e.exports = function(e, t, a) {
        i(e);
        if (t === undefined) return e;
        switch (a) {
          case 1:
            return function(a) {
                return e.call(t, a);
            };

          case 2:
            return function(a, i) {
                return e.call(t, a, i);
            };

          case 3:
            return function(a, i, n) {
                return e.call(t, a, i, n);
            };
        }
        return function() {
            return e.apply(t, arguments);
        };
    };
}, function(e, t, a) {
    e.exports = function(e) {
        return typeof e === "object" ? e !== null : typeof e === "function";
    };
}, function(e, t, a) {
    var i = {}.toString;
    e.exports = function(e) {
        return i.call(e).slice(8, -1);
    };
}, function(e, t, a) {
    var i = a(232);
    e.exports = Object("z").propertyIsEnumerable(0) ? Object : function(e) {
        return i(e) == "String" ? e.split("") : Object(e);
    };
}, function(e, t, a) {
    var i = a(214), n = a(208), r = a(215);
    e.exports = a(196) ? Object.defineProperties : function o(e, t) {
        n(e);
        var a = r(t), o = a.length, l = 0, s;
        while (o > l) i.f(e, s = a[l++], t[s]);
        return e;
    };
}, function(e, t, a) {
    e.exports = "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",");
}, function(e, t, a) {
    var i = a(231), n = a(194).document, r = i(n) && i(n.createElement);
    e.exports = function(e) {
        return r ? n.createElement(e) : {};
    };
}, function(e, t, a) {
    e.exports = a(194).document && document.documentElement;
}, function(e, t, a) {
    e.exports = !a(196) && !a(200)(function() {
        return Object.defineProperty(a(236)("div"), "a", {
            get: function() {
                return 7;
            }
        }).a != 7;
    });
}, function(e, t, a) {
    var i = a(195), n = a(209), r = a(245)(false), o = a(228)("IE_PROTO");
    e.exports = function(e, t) {
        var a = n(e), l = 0, s = [], f;
        for (f in a) if (f != o) i(a, f) && s.push(f);
        while (t.length > l) if (i(a, f = t[l++])) {
            ~r(s, f) || s.push(f);
        }
        return s;
    };
}, function(e, t, a) {
    "use strict";
    var i = a(211), n = a(210), r = a(202), o = {};
    a(220)(o, a(193)("iterator"), function() {
        return this;
    });
    e.exports = function(e, t, a) {
        e.prototype = i(o, {
            next: n(1, a)
        });
        r(e, t + " Iterator");
    };
}, function(e, t, a) {
    var i = Math.ceil, n = Math.floor;
    e.exports = function(e) {
        return isNaN(e = +e) ? 0 : (e > 0 ? n : i)(e);
    };
}, function(e, t, a) {
    e.exports = function() {};
}, function(e, t, a) {
    e.exports = function(e, t) {
        return {
            value: t,
            done: !!e
        };
    };
}, function(e, t, a) {
    e.exports = function(e) {
        if (typeof e != "function") throw TypeError(e + " is not a function!");
        return e;
    };
}, function(e, t, a) {
    var i = a(209), n = a(294), r = a(295);
    e.exports = function(e) {
        return function(t, a, o) {
            var l = i(t), s = n(l.length), f = r(o, s), d;
            if (e && a != a) while (s > f) {
                d = l[f++];
                if (d != d) return true;
            } else for (;s > f; f++) if (e || f in l) {
                if (l[f] === a) return e || f || 0;
            }
            return !e && -1;
        };
    };
}, , , , , , , , , , , function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '		<div class="panel">\n			<div class="panel-title">\n				<i class="icons-qq"></i>\n				<span>文件夹属性</span>\n				<div class="close" data-action="panel.close"></div>\n			</div>\n			<div class="panel-body">\n				<div class="panel-content">\n					<div class="folder-property-top">\n						<div class="files-folder filesmall-folder"></div>\n						<div class="folder-title">\n							<div class="folder-name"><%-locals.fname%></div>\n							<div class="folder-size">共<%=locals.filenum%>个文件</div>\n						</div>\n					</div>\n					<div class="folder-property-bottom">\n						<div class="created-at">\n							<span class="folder-property-label">创建时间:</span>\n							<span class="folder-property-content"><%=locals.ctStr%></span>\n						</div>\n						<div class="creator">\n							<span class="folder-property-label">创&nbsp;&nbsp;建&nbsp;&nbsp;人:</span>\n							<span class="folder-property-content"><%-locals.nick%></span>\n						</div>\n						<div class="updated-at">\n							<span class="folder-property-label">最后更新时间:</span>\n							<span class="folder-property-content"><%=locals.mtStr%></span>\n						</div>\n						<div class="updater">\n							<span class="folder-property-label">最&nbsp;后&nbsp;更&nbsp;新&nbsp;人:</span>\n							<span class="folder-property-content"><%-locals.mnick%></span>\n						</div>\n					</div>\n				</div>\n			</div>\n			<a href="javascript:void(0);" class="aria-hide" tabindex="3" aria-label="文件夹<%-locals.fname%>共<%=locals.filenum%>个文件 创建时间:<%=locals.ctStr%> 创建人:<%-locals.nick%> 最后更新人:<%-locals.mnick%>"></a>\n			<a href="javascript:void(0);" class="aria-hide" data-action="panel.close" tabindex="3" aria-label="关闭文件夹属性窗口"></a>\n			<%if(G.mac){%>\n				<div class="panel-footer">\n					<input aria-label="确定" type="submit" value="确定" class="btn-ok btn-common btn-right" data-action="panel.close" tabindex="2">\n				</div>\n			<%}%>\n		</div>\n\n',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('		<div class="panel">\n			<div class="panel-title">\n				<i class="icons-qq"></i>\n				<span>文件夹属性</span>\n				<div class="close" data-action="panel.close"></div>\n			</div>\n			<div class="panel-body">\n				<div class="panel-content">\n					<div class="folder-property-top">\n						<div class="files-folder filesmall-folder"></div>\n						<div class="folder-title">\n							<div class="folder-name">', (__stack.lineno = 12, 
                    locals.fname), '</div>\n							<div class="folder-size">共', escape((__stack.lineno = 13, 
                    locals.filenum)), '个文件</div>\n						</div>\n					</div>\n					<div class="folder-property-bottom">\n						<div class="created-at">\n							<span class="folder-property-label">创建时间:</span>\n							<span class="folder-property-content">', escape((__stack.lineno = 19, 
                    locals.ctStr)), '</span>\n						</div>\n						<div class="creator">\n							<span class="folder-property-label">创&nbsp;&nbsp;建&nbsp;&nbsp;人:</span>\n							<span class="folder-property-content">', (__stack.lineno = 23, 
                    locals.nick), '</span>\n						</div>\n						<div class="updated-at">\n							<span class="folder-property-label">最后更新时间:</span>\n							<span class="folder-property-content">', escape((__stack.lineno = 27, 
                    locals.mtStr)), '</span>\n						</div>\n						<div class="updater">\n							<span class="folder-property-label">最&nbsp;后&nbsp;更&nbsp;新&nbsp;人:</span>\n							<span class="folder-property-content">', (__stack.lineno = 31, 
                    locals.mnick), '</span>\n						</div>\n					</div>\n				</div>\n			</div>\n			<a href="javascript:void(0);" class="aria-hide" tabindex="3" aria-label="文件夹', (__stack.lineno = 36, 
                    locals.fname), "共", escape((__stack.lineno = 36, locals.filenum)), "个文件 创建时间:", escape((__stack.lineno = 36, 
                    locals.ctStr)), " 创建人:", (__stack.lineno = 36, locals.nick), " 最后更新人:", (__stack.lineno = 36, 
                    locals.mnick), '"></a>\n			<a href="javascript:void(0);" class="aria-hide" data-action="panel.close" tabindex="3" aria-label="关闭文件夹属性窗口"></a>\n			');
                    __stack.lineno = 38;
                    if (G.mac) {
                        buf.push('\n				<div class="panel-footer">\n					<input aria-label="确定" type="submit" value="确定" class="btn-ok btn-common btn-right" data-action="panel.close" tabindex="2">\n				</div>\n			');
                        __stack.lineno = 42;
                    }
                    buf.push("\n		</div>\n\n");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<section class="file-list" id="<%-locals.id%>"></section>',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('<section class="file-list" id="', (__stack.lineno = 1, locals.id), '"></section>');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(e, t, a) {
    "use strict";
    var i = a(37);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = {
        folderTree: a(274),
        newFloder: a(275)
    };
    var l = $("#containerFolderTreePanel");
    var s = a(17);
    function f(e, t) {
        G.folderTree = G.folderTree || {};
        var a = G.nowFolder === "/" ? {
            fname: "群文件",
            id: "/"
        } : G.folderMap()[G.nowFolder];
        if (G.folderTree && G.folderTree.selected) {
            G.folderTree.selected = a;
        }
        G.folderTree.container = $(e);
        var i = [];
        var r = (0, n.default)(G.folderMap());
        for (var l = r.length - 1; l >= 0; l--) {
            i.push(G.folderMap()[r[l]]);
        }
        i = s.quickSortByObjectAttr(i, "mt");
        $(e).html(o.folderTree({
            topFolder: G.topFolder,
            items: i
        }));
        d(a.id);
    }
    function d(e) {
        e = e || $(this).data("id");
        if (!e) {
            return;
        }
        if (!G.folderTree) {
            G.folderTree = {};
        }
        l.find(".active").removeClass("active").attr("aria-checked", false);
        var t = {};
        if (e === "/") {
            t = G.folderTree.selected = G.topFolder;
        } else if (e !== "new") {
            t = G.folderTree.selected = G.folderMap()[e];
        } else {
            t = {
                id: e
            };
            G.folderTree.selected = t;
        }
        $('.folder-list-item[data-id="' + t.id + '"]').addClass("active").attr("aria-checked", true);
        t.fname !== undefined && l.find('[data-role="dest"]').html(t.fname);
        l.find("span.folder-name").eq(0).text(t.fname);
        l.find("input.btn-ok").focus();
    }
    function c() {
        var e = G.folderTree.container.find(".secondary-folder-list li");
        if (e.length) {
            e.first().before(o.newFloder());
        } else {
            G.folderTree.container.find(".secondary-folder-list").append(o.newFloder());
        }
    }
    e.exports = {
        render: f,
        newFolder: c,
        select: d
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        102: "非群成员",
        103: "该文件不存在或已失效",
        106: "登录态校验失败",
        116: "没有权限",
        117: "没有权限",
        118: "没有权限",
        119: "没有权限",
        120: "没有权限",
        121: "没有权限",
        122: "没有权限",
        123: "没有权限",
        124: "没有权限",
        125: "没有权限",
        126: "没有权限",
        127: "没有权限",
        128: "没有权限",
        129: "没有权限",
        130: "没有权限",
        131: "没有权限",
        132: "文件存在安全风险",
        133: "文件安全性未知",
        134: "名称包含特殊/敏感字符，请重新输入。",
        313: "已存在同名文件夹，请重新命名",
        314: "创建文件夹失败",
        315: "删除文件夹失败",
        402: "文件数量已经超过限制",
        403: "可用空间不够",
        405: "创建失败，文件夹个数已达上限",
        25: "操作失败，空间不足.",
        317.1: "该文件夹不可删除",
        317.2: "无法修改名称"
    };
    var n = {
        deleteSuc: "删除成功",
        moveSuc: "转存成功",
        folderSuc: "新建文件夹成功",
        deleteFolderSuc: "删除文件夹成功"
    };
    var r = $(G.handler), o = a(180);
    var l = [ 134, 313, 405 ];
    function s(e, t) {
        e = Math.abs(e);
        if (i[e] && $.inArray(e, l) >= 0) {
            t.find(".error-message").text(i[e]).addClass("show").show();
        } else {
            var a = i[e] || "操作失败";
            r.trigger("toast.show", {
                type: "alert",
                text: a
            });
            o.hideAll();
        }
    }
    function f(e) {
        r.trigger("toast.show", {
            type: "alert",
            text: e
        });
    }
    function d(e) {
        r.trigger("toast.show", {
            type: "alert",
            text: e
        });
    }
    e.exports = {
        showError: s,
        showWait: f,
        showSuc: d
    };
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    var i = a(26);
    var n = r(i);
    t.edit = b;
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var o = a(54);
    var l = a(84);
    var s = a(82);
    var f = a(17);
    var d = a(31);
    var c = a(178);
    var u = $(G.handler);
    var p = 5485;
    G.editFileList = {};
    var v = "canedit" + f.getUin();
    var m = false;
    var h = function _() {
        var e = localStorage.getItem(v);
        if (!e) {
            return false;
        }
        try {
            e = JSON.parse(e);
            var t = +new Date();
            if (t - e.ts < e.t) {
                m = true;
                return true;
            }
        } catch (a) {}
        return false;
    };
    var g = function k(e, t) {
        var a = localStorage.getItem(v);
        try {
            if (a) {
                a = JSON.parse(a);
            } else {
                a = {};
            }
            a.t = 30 * 100;
            a.w = e;
            a.ts = +new Date();
            localStorage.setItem(v, (0, n.default)(a));
        } catch (i) {}
    };
    var w = function y() {
        l.getEditFlag().done(function(e) {
            if (e.ec === 0) {
                var t = e.req_interval;
                var a = e.is_white;
                g(a, t);
                m = e.is_white;
            } else {
                jumpToPage(0);
            }
        }).fail(function() {});
    };
    w();
    function b(e) {
        console.log("edit file:", e, m);
        if (e) {
            if (G.version >= p && e.admin && e.filetype === "文档" && m) {
                console.debug(" input and edit file:", e);
                var t = e.localpath;
                if (typeof t === "string" && t.indexOf("OSRoot") < 0) {
                    t = "OSRoot:\\" + t;
                }
                var a = window.external.isFileExist(t);
                if (a == "false" || a === false) {
                    s.alert(2, "提示", "此文件不存在，可能已被删除或被移动到其他位置");
                    c.changeOpenFolder2Download(e);
                    return false;
                }
                var i = {
                    filepath: e.filepath,
                    name: e.fnameEsc,
                    fp: e.fp,
                    md5: e.md5,
                    localpath: t
                };
                var r = s.onlineEditFile(e.parentId, (0, n.default)(i));
                console.debug("start online edit", r, " param is ", i);
                if (r == "success") {
                    G.editFileList[e.filepath] = 1;
                    return true;
                } else if (r === "file cannot open") {
                    var o = s.confirm(2, "提示", "此文件无法识别并打开，是否在文件夹中查看该文件？");
                    if (o.errorCode === 0 && o.ret) {
                        c.openByPath(e);
                    } else {
                        return false;
                    }
                }
            } else {
                c.openByPath(e);
            }
        }
    }
}, function(e, t, a) {
    "use strict";
    t.__esModule = true;
    t.default = function(e, t) {
        if (!(e instanceof t)) {
            throw new TypeError("Cannot call a class as a function");
        }
    };
}, function(e, t, a) {
    "use strict";
    t.__esModule = true;
    var i = a(296);
    var n = r(i);
    function r(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    t.default = function() {
        function e(e, t) {
            for (var a = 0; a < t.length; a++) {
                var i = t[a];
                i.enumerable = i.enumerable || false;
                i.configurable = true;
                if ("value" in i) i.writable = true;
                (0, n.default)(e, i.key, i);
            }
        }
        return function(t, a, i) {
            if (a) e(t.prototype, a);
            if (i) e(t, i);
            return t;
        };
    }();
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<%\n		var group = locals.data;\n		if(group.first){\n%>\n	<div class="group-title" data-gc="<%=group.gc%>">\n		<% if(group.self){ %>\n			<span class="group-name">本群搜索结果</span> <span>(<%=group.total%>)</span>\n		<% }else{%>\n			<span class="group-name"><%=group.name%></span> <span>(<%=group.total%>)</span>\n		<% } %>\n	</div>\n<%}%>\n	<div class="group-result group<%=group.gc%>">\n<%\n		for(var i = 0,l = group.list.length;i<l;i++){\n			var item = group.list[i];\n%>\n	<div class="file list-item <%=item.icon%> <%if(item.remoteType===2){%>temp<%}%> <%if(item.succ){%>succ<%}%>" id="search<%=item.domid%>" data-path="<%=item.filepath%>" <%if(!locals.renderParams){%>id="<%=item.domid%>"<%}%> <%if(!group.self){%> data-dbaction="openGroupFile" data-uin="<%- item.gc %>"<%}else if(item.preview){%>data-dbaction="file.preview"<%}else{%>data-dbaction="file.downloadByDom"<%}%> data-action="list.select">\n		<div class="item-name-wrap item-name-adjust" title="<%- item.fname %>&#10;创建时间：<%=item.ctoStr%>">\n			<div class="item-name" tabindex="-1" >\n				<div class="file-icons" data-path="<%=item.filepath%>" <%if(item.preview){%>data-dbaction="file.preview"<%}%>>\n					<div class="filev3-<%=item.icon%> <%if(item.previewObj){%>thumb<%}%> drag-dom" <%if(item.previewObj){%>style="background-image:url(<%=item.previewObj.url%>);"<%}%>></div>\n					<i class="icons-check"></i>\n				</div>\n				<span class="name drag-dom"><%- item.name %><%-item.suf%></span>\n			</div>\n			<% if(item.canEdit || item.remoteType === 2) { %>\n				<div class="item-tags">\n					<%if(item.canEdit){%><span class="can-edit"></span><%}%>\n					<%if(item.remoteType ===2){%><span class="tmp"></span><%}%>\n					&nbsp;\n				</div>\n			<% } %>\n		</div>\n		<div class="item-time" title="上传时间：<%=item.ctStr%>">\n			<span class="drag-dom">\n			<% if(group.self){ %>\n				<%= item.ctStr %>\n			<%}else{%>\n				<%= item.ctStr %>\n			<%}%>\n			</span>\n		</div>\n		<div class="item-size" title="文件大小：<%= item.sizeStr%>">\n			<span class="drag-dom"><%= item.sizeStr%></span>\n		</div>\n		<div class="item-user" title="上传者：<%-item.nick%> (<%=item.uin%>)"><span class="drag-dom"><%- item.nick%></span></div>\n		<div>\n			<div tabindex="3" aria-label="名称:<%=item.fname%>,文件类型:<%=item.filetype%>,大小:<%=item.sizeStr%>,下载次数:<%=item.down%>次,上传人:<%=item.nick%>,上传时间:<%=item.ctStr%><%if(item.succ){%>,该文件已下载<%}%>"></div>\n			<% if(!group.self){ %>\n				<a role="button" data-action="openGroupInfoCard" data-uin="<%- item.gc %>" class="aria-hide" tabindex="3">打开<%-item.gname%></a>\n			<% } %>\n		</div>\n		<div class="item-source">\n			<span>\n			<% if(group.self){ %>\n				&nbsp;\n			<%}else{%>\n				<span class="group-code" title="来源:<%-item.gname%>" data-action="openGroupInfoCard" data-uin="<%- item.gc %>"><%-item.gname%></span>\n			<%}%>\n			</span>\n		</div>\n	</div>\n<%\n	}\n%>\n	</div>\n',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push("");
                    __stack.lineno = 1;
                    var e = locals.data;
                    if (e.first) {
                        buf.push('\n	<div class="group-title" data-gc="', escape((__stack.lineno = 5, e.gc)), '">\n		');
                        __stack.lineno = 6;
                        if (e.self) {
                            buf.push('\n			<span class="group-name">本群搜索结果</span> <span>(', escape((__stack.lineno = 7, 
                            e.total)), ")</span>\n		");
                            __stack.lineno = 8;
                        } else {
                            buf.push('\n			<span class="group-name">', escape((__stack.lineno = 9, e.name)), "</span> <span>(", escape((__stack.lineno = 9, 
                            e.total)), ")</span>\n		");
                            __stack.lineno = 10;
                        }
                        buf.push("\n	</div>\n");
                        __stack.lineno = 12;
                    }
                    buf.push('\n	<div class="group-result group', escape((__stack.lineno = 13, e.gc)), '">\n');
                    __stack.lineno = 14;
                    for (var t = 0, a = e.list.length; t < a; t++) {
                        var i = e.list[t];
                        buf.push('\n	<div class="file list-item ', escape((__stack.lineno = 18, i.icon)), " ");
                        __stack.lineno = 18;
                        if (i.remoteType === 2) {
                            buf.push("temp");
                            __stack.lineno = 18;
                        }
                        buf.push(" ");
                        __stack.lineno = 18;
                        if (i.succ) {
                            buf.push("succ");
                            __stack.lineno = 18;
                        }
                        buf.push('" id="search', escape((__stack.lineno = 18, i.domid)), '" data-path="', escape((__stack.lineno = 18, 
                        i.filepath)), '" ');
                        __stack.lineno = 18;
                        if (!locals.renderParams) {
                            buf.push('id="', escape((__stack.lineno = 18, i.domid)), '"');
                            __stack.lineno = 18;
                        }
                        buf.push(" ");
                        __stack.lineno = 18;
                        if (!e.self) {
                            buf.push(' data-dbaction="openGroupFile" data-uin="', (__stack.lineno = 18, i.gc), '"');
                            __stack.lineno = 18;
                        } else if (i.preview) {
                            buf.push('data-dbaction="file.preview"');
                            __stack.lineno = 18;
                        } else {
                            buf.push('data-dbaction="file.downloadByDom"');
                            __stack.lineno = 18;
                        }
                        buf.push(' data-action="list.select">\n		<div class="item-name-wrap item-name-adjust" title="', (__stack.lineno = 19, 
                        i.fname), "&#10;创建时间：", escape((__stack.lineno = 19, i.ctoStr)), '">\n			<div class="item-name" tabindex="-1" >\n				<div class="file-icons" data-path="', escape((__stack.lineno = 21, 
                        i.filepath)), '" ');
                        __stack.lineno = 21;
                        if (i.preview) {
                            buf.push('data-dbaction="file.preview"');
                            __stack.lineno = 21;
                        }
                        buf.push('>\n					<div class="filev3-', escape((__stack.lineno = 22, i.icon)), " ");
                        __stack.lineno = 22;
                        if (i.previewObj) {
                            buf.push("thumb");
                            __stack.lineno = 22;
                        }
                        buf.push(' drag-dom" ');
                        __stack.lineno = 22;
                        if (i.previewObj) {
                            buf.push('style="background-image:url(', escape((__stack.lineno = 22, i.previewObj.url)), ');"');
                            __stack.lineno = 22;
                        }
                        buf.push('></div>\n					<i class="icons-check"></i>\n				</div>\n				<span class="name drag-dom">', (__stack.lineno = 25, 
                        i.name), "", (__stack.lineno = 25, i.suf), "</span>\n			</div>\n			");
                        __stack.lineno = 27;
                        if (i.canEdit || i.remoteType === 2) {
                            buf.push('\n				<div class="item-tags">\n					');
                            __stack.lineno = 29;
                            if (i.canEdit) {
                                buf.push('<span class="can-edit"></span>');
                                __stack.lineno = 29;
                            }
                            buf.push("\n					");
                            __stack.lineno = 30;
                            if (i.remoteType === 2) {
                                buf.push('<span class="tmp"></span>');
                                __stack.lineno = 30;
                            }
                            buf.push("\n					&nbsp;\n				</div>\n			");
                            __stack.lineno = 33;
                        }
                        buf.push('\n		</div>\n		<div class="item-time" title="上传时间：', escape((__stack.lineno = 35, 
                        i.ctStr)), '">\n			<span class="drag-dom">\n			');
                        __stack.lineno = 37;
                        if (e.self) {
                            buf.push("\n				", escape((__stack.lineno = 38, i.ctStr)), "\n			");
                            __stack.lineno = 39;
                        } else {
                            buf.push("\n				", escape((__stack.lineno = 40, i.ctStr)), "\n			");
                            __stack.lineno = 41;
                        }
                        buf.push('\n			</span>\n		</div>\n		<div class="item-size" title="文件大小：', escape((__stack.lineno = 44, 
                        i.sizeStr)), '">\n			<span class="drag-dom">', escape((__stack.lineno = 45, i.sizeStr)), '</span>\n		</div>\n		<div class="item-user" title="上传者：', (__stack.lineno = 47, 
                        i.nick), " (", escape((__stack.lineno = 47, i.uin)), ')"><span class="drag-dom">', (__stack.lineno = 47, 
                        i.nick), '</span></div>\n		<div>\n			<div tabindex="3" aria-label="名称:', escape((__stack.lineno = 49, 
                        i.fname)), ",文件类型:", escape((__stack.lineno = 49, i.filetype)), ",大小:", escape((__stack.lineno = 49, 
                        i.sizeStr)), ",下载次数:", escape((__stack.lineno = 49, i.down)), "次,上传人:", escape((__stack.lineno = 49, 
                        i.nick)), ",上传时间:", escape((__stack.lineno = 49, i.ctStr)), "");
                        __stack.lineno = 49;
                        if (i.succ) {
                            buf.push(",该文件已下载");
                            __stack.lineno = 49;
                        }
                        buf.push('"></div>\n			');
                        __stack.lineno = 50;
                        if (!e.self) {
                            buf.push('\n				<a role="button" data-action="openGroupInfoCard" data-uin="', (__stack.lineno = 51, 
                            i.gc), '" class="aria-hide" tabindex="3">打开', (__stack.lineno = 51, i.gname), "</a>\n			");
                            __stack.lineno = 52;
                        }
                        buf.push('\n		</div>\n		<div class="item-source">\n			<span>\n			');
                        __stack.lineno = 56;
                        if (e.self) {
                            buf.push("\n				&nbsp;\n			");
                            __stack.lineno = 58;
                        } else {
                            buf.push('\n				<span class="group-code" title="来源:', (__stack.lineno = 59, i.gname), '" data-action="openGroupInfoCard" data-uin="', (__stack.lineno = 59, 
                            i.gc), '">', (__stack.lineno = 59, i.gname), "</span>\n			");
                            __stack.lineno = 60;
                        }
                        buf.push("\n			</span>\n		</div>\n	</div>\n");
                        __stack.lineno = 64;
                    }
                    buf.push("\n	</div>\n");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '		<li class="item with-icon-item disable" id="filePreview" data-action="file.menupreview" aria-label="预览"><span class="icons-preview"></span><span class="menu-item-label">预览</span></li>\n		<%if(!G.mac){%>\n			<li class="item" id="fileFoward" data-action="file.forward" aria-label="转发">转发</li>\n			<li class="item" id="fileFowardTo" data-action="file.forwardMobile" aria-label="转发到手机" tabindex="1">转发到手机</li>\n		<%}%>\n		<li class="item save-as open-folder with-icon-item" id="fileOpenFolder" data-action="file.openFolderInBox" aria-label="在文件夹中显示" tabindex="1"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item rename" id="renameFile" data-action="file.showRename" aria-label="重命名" tabindex="1">重命名</li>\n		<li class="item forever disable" id="foreverFile" data-action="file.permanent" aria-label="转存为永久文件" tabindex="-1">转存为永久文件</li>\n		<%if(G.info.isAdmin){%>\n		<li class="item " id="fileMove" data-action="file.showMove" aria-label="移动" tabindex="-1">移动</li>\n		<%}%>\n		<li class="item jubao" id="fileJubao" data-action="file.jubao" aria-label="举报" tabindex="1">举报</li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item delete with-icon-item" data-action="file.delete" id="fileDelete" aria-label="删除" tabindex="1"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('		<li class="item with-icon-item disable" id="filePreview" data-action="file.menupreview" aria-label="预览"><span class="icons-preview"></span><span class="menu-item-label">预览</span></li>\n		');
                    __stack.lineno = 2;
                    if (!G.mac) {
                        buf.push('\n			<li class="item" id="fileFoward" data-action="file.forward" aria-label="转发">转发</li>\n			<li class="item" id="fileFowardTo" data-action="file.forwardMobile" aria-label="转发到手机" tabindex="1">转发到手机</li>\n		');
                        __stack.lineno = 5;
                    }
                    buf.push('\n		<li class="item save-as open-folder with-icon-item" id="fileOpenFolder" data-action="file.openFolderInBox" aria-label="在文件夹中显示" tabindex="1"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item rename" id="renameFile" data-action="file.showRename" aria-label="重命名" tabindex="1">重命名</li>\n		<li class="item forever disable" id="foreverFile" data-action="file.permanent" aria-label="转存为永久文件" tabindex="-1">转存为永久文件</li>\n		');
                    __stack.lineno = 10;
                    if (G.info.isAdmin) {
                        buf.push('\n		<li class="item " id="fileMove" data-action="file.showMove" aria-label="移动" tabindex="-1">移动</li>\n		');
                        __stack.lineno = 12;
                    }
                    buf.push('\n		<li class="item jubao" id="fileJubao" data-action="file.jubao" aria-label="举报" tabindex="1">举报</li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item delete with-icon-item" data-action="file.delete" id="fileDelete" aria-label="删除" tabindex="1"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '		<li class="download-item with-icon-item download-folder" id="folderDownloadLink" data-action="folder.download"><span class="icons-download"></span><span class="menu-item-label">下载</span></li>\n		<li class="with-icon-item open-in-folder disable" id="showInFolderLink" data-action="folder.openfolder"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<%if(locals.isAdmin){%>\n		<li class="rename-item" id="folderRenameLink" data-action="folder.showRenameFolder">重命名</li>\n		<%}%>\n		<li class="property-item" id="folderPropLink" data-action="folder.property">文件夹属性</li>\n		<li class="gap"></li>\n		<%if(locals.isAdmin){%>\n		<li class="delete-item with-icon-item" id="folderDeleteLink" data-action="folder.showDeleteFolder"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n		<%}else{%>\n		<li class="item jubao" data-action="file.jubao" id="folderJubaoLink" aria-label="举报" tabindex="1">举报</li>\n		<%}%>\n',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('		<li class="download-item with-icon-item download-folder" id="folderDownloadLink" data-action="folder.download"><span class="icons-download"></span><span class="menu-item-label">下载</span></li>\n		<li class="with-icon-item open-in-folder disable" id="showInFolderLink" data-action="folder.openfolder"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		');
                    __stack.lineno = 3;
                    if (locals.isAdmin) {
                        buf.push('\n		<li class="rename-item" id="folderRenameLink" data-action="folder.showRenameFolder">重命名</li>\n		');
                        __stack.lineno = 5;
                    }
                    buf.push('\n		<li class="property-item" id="folderPropLink" data-action="folder.property">文件夹属性</li>\n		<li class="gap"></li>\n		');
                    __stack.lineno = 8;
                    if (locals.isAdmin) {
                        buf.push('\n		<li class="delete-item with-icon-item" id="folderDeleteLink" data-action="folder.showDeleteFolder"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n		');
                        __stack.lineno = 10;
                    } else {
                        buf.push('\n		<li class="item jubao" data-action="file.jubao" id="folderJubaoLink" aria-label="举报" tabindex="1">举报</li>\n		');
                        __stack.lineno = 12;
                    }
                    buf.push("\n");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '  <div class="panel-con jubao-panel" id="jubaoDom">\r\n    <iframe class="frame-jubao" id="jubaoIframe" frameborder="0" scrolling="no"></iframe>\r\n  </div>',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('  <div class="panel-con jubao-panel" id="jubaoDom">\n    <iframe class="frame-jubao" id="jubaoIframe" frameborder="0" scrolling="no"></iframe>\n  </div>');
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, , , , , , , function(e, t, a) {
    var i = a(293);
    e.exports = function n(e) {
        var t = [];
        var a = {};
        var i;
        var n = e || {};
        (function(e) {
            t.push('<!--文件夹模板--><div class="whole-row"></div><div class="folder-info"><span class="little-folder-icon"></span><span class="folder-name">' + (null == (i = e.fname) ? "" : i) + "</span></div>");
        }).call(this, "item" in n ? n.item : typeof item !== "undefined" ? item : undefined);
        return t.join("");
    };
}, function(e, t, a) {
    var i = a(293);
    e.exports = function n(e) {
        var t = [];
        var a = {};
        var n;
        var r = e || {};
        (function(e, a) {
            t.push('<!--文件夹树模板--><ul data-action="file_active" role="tree" class="primary-folder-list"><li' + i.attr("data-id", "" + e.id + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"> </div><div class="folder-info"><span class="little-folder-icon"></span><span class="folder-name">' + (null == (n = e.fname) ? "" : n) + '</span><a href="javascript:void(0)"' + i.attr("data-id", "" + e.id + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + i.attr("aria-label", "选择文件夹:" + e.fname + "", true, false) + ' class="aria-hide"></a></div><ul class="secondary-folder-list">');
            (function() {
                var e = a;
                if ("number" == typeof e.length) {
                    for (var r = 0, o = e.length; r < o; r++) {
                        var l = e[r];
                        t.push("<li" + i.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><div class="little-folder-icon"></div><div class="folder-name">' + (null == (n = l && l.fname) ? "" : n) + '</div><a href="javascript:void(0)"' + i.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + i.attr("aria-label", "选择文件夹:" + (l && l.fname) + "", true, false) + ' class="aria-hide"></a></div></li>');
                    }
                } else {
                    var o = 0;
                    for (var r in e) {
                        o++;
                        var l = e[r];
                        t.push("<li" + i.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><div class="little-folder-icon"></div><div class="folder-name">' + (null == (n = l && l.fname) ? "" : n) + '</div><a href="javascript:void(0)"' + i.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + i.attr("aria-label", "选择文件夹:" + (l && l.fname) + "", true, false) + ' class="aria-hide"></a></div></li>');
                    }
                }
            }).call(this);
            t.push("</ul></li></ul>");
        }).call(this, "topFolder" in r ? r.topFolder : typeof topFolder !== "undefined" ? topFolder : undefined, "items" in r ? r.items : typeof items !== "undefined" ? items : undefined);
        return t.join("");
    };
}, function(e, t, a) {
    var i = a(293);
    e.exports = function n(e) {
        var t = [];
        var a = {};
        var i;
        t.push('<li data-id="new" data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><span class="little-folder-icon"></span><input id="inputFolderNameInFolderTree" value="新建文件夹" data-blur="createInputBlur" data-keyup="folderTree.create" autofocus="true" class="folder-name"/><div class="bubble"><span class="bot"></span><span class="top"></span>文件夹名称中含有违禁词</div></div></li>');
        return t.join("");
    };
}, function(e, t, a) {
    "use strict";
    var i = a(84), n = a(54), r = {};
    e.exports = r;
    r.createFolder = function(e, t) {
        i.createFolder(e).done(function(e) {
            t(e);
        }).fail(function(e) {});
    };
    r.renameFolder = function(e, t) {};
    r.deleteFolder = function(e, t) {};
}, function(e, t, a) {
    "use strict";
    var i = a(53);
    var n = a(176);
    var r = 299;
    var o = $("#box");
    var l = $(G.handler);
    var s = false;
    var f = false;
    function d() {
        report("clkTask");
        if (s) {
            u();
        } else {
            c();
            i.removePoint();
        }
    }
    function c() {
        report("showTask");
        if (!f) {
            i.firstRender();
        }
        f = true;
        s = true;
        o.addClass("open");
        $("#boxTitle a").focus();
        n.changeBoxTabIndex();
    }
    function u() {
        s = false;
        o.removeClass("open");
        n.removeBoxTabIndex();
        if (G.activeElement) {
            G.activeElement.focus();
        }
    }
    l.bind("box.hide", u);
    e.exports = {
        toggle: d
    };
}, function(e, t, a) {
    "use strict";
    var i = a(82);
    var n = a(54);
    function r(e) {
        var t = $(this).parents(".list-item");
        var a = t.data("path");
        var r = n.getTask(a);
        a = r.filepath;
        var o = r.remoteType || 1;
        var l = r.localpath;
        var s = r.fnameEsc || r.fname;
        if (r) {
            var f = i.addContinueUploadTask(a, l, s, o);
            $("#boxTitle a").focus();
        }
    }
    e.exports = {
        continueUpload: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(82);
    var n = a(53);
    var r = a(54);
    var o = a(22);
    function l() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("path");
        var a = r.getFile(t);
        r.clearComplete();
        n.clearComplete();
        i.clearClist();
        o.clearClist();
    }
    e.exports = {
        clear: l
    };
}, function(e, t, a) {
    "use strict";
    var i = a(82);
    var n = a(54);
    function r() {
        var e = $(this).parents(".list-item");
        var t = e.data("path");
        var a = e.data("id");
        var r = n.getTask(a, t);
        console.debug("pause task", r);
        var o = i.pauseTask(a);
        $("#boxTitle a").focus();
        report("clkTaskPause", typeof r.downloadtasktype === "undefined" ? 0 : 1);
    }
    e.exports = {
        pause: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(82);
    var n = a(17);
    var r = a(84);
    var o = a(54);
    var l = a(53);
    var s = a(31);
    var f = $(G.handler);
    var d = function p(e) {
        var t = e.type;
        var a = true;
        var n = e.filepath;
        report("clkTaskDelete");
        $("#boxTitle a").focus();
        var l = e.taskId || e.id;
        if (l) {
            var d = i.removeTask(l);
            a = true;
        }
        if (a) {
            if (e.orcType === 1) {
                if (e.id) {
                    o.remove(e.id);
                }
                if (e.type !== "download") {
                    o.remove(e.filepath);
                }
            }
            e.status = "remove";
            if (t && t.indexOf("upload") >= 0) {
                console.debug("remove task", e);
                if (n) {
                    var c = n.substr(4);
                    var u = n.substr(1, 3);
                    var p = {
                        app_id: G.appid,
                        bus_id: parseInt(u),
                        file_id: c,
                        parent_folder_id: G.nowFolder
                    };
                    r.deleteFile(p).done(function(t) {
                        o.remove(e);
                        s.removeRow(e);
                    }).fail(function(e) {
                        if (e.fc && e.fc === 1) {
                            return;
                        }
                    });
                } else {
                    f.trigger("client.updateTask", e);
                }
            } else if (t === "download") {
                i.removeCompleteTask(e.id);
                var v = o.getData(n);
                if (v) {
                    v.isDowning = false;
                }
                s.updateRow(v);
                console.debug("remove task : ", e);
            }
            i.clearClist();
        }
    };
    function c() {
        var e = $(this).parents(".list-item");
        var t = e.data("id");
        var a = e.data("path");
        var i = o.getTask(t);
        if (!i) {
            i = o.getTask(a);
        }
        if (!i) {
            i = o.getData(a);
            console.debug("remove :", i);
            d(i);
        } else {
            d(i);
        }
    }
    function u(e, t) {
        var a = o.getTask(e);
        if (!a) {
            a = o.getTask(t);
        }
        d(a);
    }
    G.removeTaskInDownLoad = u;
    f.bind("task.removeOne", function(e, t) {
        var a = i.removeTask(t);
    });
    e.exports = {
        remove: c,
        removeByDownLoad: u
    };
}, function(e, t, a) {
    "use strict";
    var i = a(82);
    var n = a(54);
    function r() {
        var e = $(this).parents(".list-item");
        var t = e.data("path");
        var a = n.getTask(t);
        var r = e.data("id");
        var o = a.id;
        if (!o) {
            a.id = r;
            o = r;
        }
        var l = i.resumeTask(o);
        report("clkTaskPause");
        $("#boxTitle a").focus();
    }
    e.exports = {
        resume: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(82);
    var n = a(128).refreshTime;
    var r = a(55);
    var o = $(G.handler);
    var l = 0;
    function s() {
        if (!l) {
            return;
        }
        clearTimeout(l);
        l = 0;
    }
    function f() {
        if (l) {
            return;
        }
        d();
    }
    function d() {
        var e = i.getTaskListAdv();
        var t = false;
        if (e.empty && e.status === "ok") {
            s();
        } else {
            var a = /progress|ready|scan|geturl/gi;
            var f = r.cleanMap(e.map);
            for (var c = 0, u = f.length; c < u; c++) {
                var p = f[c];
                o.trigger("client.updateTask", p);
                if (a.test(p.status)) {
                    t = true;
                }
            }
        }
        if (t) {
            l = setTimeout(d, n);
        } else {
            console.log("do stop refresh!");
            s();
        }
    }
    $(G.handler).bind("task.startRefresh", f);
    $(G.handler).bind("task.stopRefresh", s);
}, function(e, t, a) {
    "use strict";
    function i() {
        if (this.classList.contains("open")) {
            this.classList.remove("open");
        } else {
            report("clkTaskExp");
            this.classList.add("open");
        }
    }
    e.exports = {
        toggle: i
    };
}, function(e, t, a) {
    "use strict";
    var i = a(84), n = a(82), r = a(54), o = {};
    e.exports = o;
    o.closeTips = function() {};
    o.refeshVip = function() {
        i.checkVip().done(function(e) {}).fail(function(e) {});
    };
    o.conVip = function() {
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    o.vipTipsOk = function() {
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    o.vipTipsCancel = function() {};
    o.openVip = function() {};
}, function(module, exports, __webpack_require__) {
    module.exports = function anonymous(locals, filters, escape, rethrow) {
        escape = escape || function(e) {
            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#39;").replace(/"/g, "&quot;");
        };
        var __stack = {
            lineno: 1,
            input: '<a class="aria-hide aria-tips" tabindex="-1">右键菜单</a>\n<ul>\n<%\n	//todo 文件打开需要加个接口.\n	var data = locals.data,\n		list = locals.list,\n		isUploader = locals.isUploader;\n	if(!data && !list){\n%>\n	<li <%if(G.file.isTooMany){%>class="disabled"<%}else{%> data-action="file.upload"<%}%> tabindex="-1">上传</li>\n	<%if(G.canCreateFolder && G.nowFolder === \'/\'){%>\n	<li <%if(G.file.isTooMany){%>class="disabled"<%}else{%> data-action="folder.create"<%}%> title="新建文件夹" tabindex="-1">新建文件夹</li>\n	<%}%>\n	<li data-action="menu.refresh" onclick="window.location.reload();" tabindex="-1">刷新</li>\n<%}else if(data){%>\n	<%if(typeof data.othergroup !== \'undefined\'){%>\n		<li data-action="openGroupFile" data-uin="<%-data.gc%>" tabindex="-1">打开所在群</li>\n	<%}else{%>\n		<%if(data.orcType === 1){%>\n			<%if(data.icon !== \'pic\'){%>\n				<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.downloadByMenu"<%}%> aria-label="打开" data-path="<%=data.filepath%>" tabindex="-1">打开</li>\n			<%}else{%>\n				<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.menupreview"<%}%> aria-label="预览" tabindex="-1">预览</li>\n			<%}%>\n\n			<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="batch.downloadAction"<%}%> title="下载" tabindex="3" aria-label="下载文件" tabindex="-1">下载</li>\n			<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.saveAs"<%}%> title="另存为" tabindex="3" aria-label="另存文件" tabindex="-1">另存为</li>\n			<%if(!G.mac){%>\n			  <li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.forward"<%}%> aria-label="转发" tabindex="-1">转发</li>\n			  <li class="line <%if(data.safeType){%>disabled<%}%>" <%if(!data.safeType){%>data-action="file.forwardMobile"<%}%> aria-label="转发到手机" tabindex="-1">发送到手机</li>\n			<%}%>\n			<%if(data.admin && typeof data.issearch === \'undefined\'){%>\n				<li <%if(data.safeType || G.file.isTooMany){%>class="disabled"<%}else{%>data-action="file.showMove"<%}%> aria-label="移动" tabindex="-1">移动到</li>\n			<%}%>\n			<%if(G.info.isAdmin && data.temp){%>\n				<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.permanent"<%}%> aria-label="转存为永久文件" tabindex="-1" tabindex="-1">转存为永久文件</li>\n			<%}%>\n			<li <%if(data.safeType || (!G.info.isAdmin && !isUploader)){%>class="disabled"<%}else{%>data-action="file.showRename"<%}%> aria-label="重命名"  tabindex="-1">重命名</li>\n			<li <%if(!G.info.isAdmin && !isUploader){%>class="disabled"<%}else{%>data-action="file.delete"<%}%> id="fileDelete" aria-label="删除" tabindex="-1">删除</li>\n			<li data-action="file.jubao" aria-label="举报">举报</li>\n		<%}else if(data.orcType === 2){%>\n			<li class="line" data-action="folder.open" data-path="<%=data.id%>" tabindex="-1">打开</li>\n			<li <%if(!G.info.isAdmin){%>class="disabled"<%}else{%>data-action="folder.showRenameFolder"<%}%> tabindex="-1">重命名</li>\n			<li class="line" data-action="folder.property">文件夹属性</li>\n			<li <%if(!G.info.isAdmin){%>class="disabled"<%}else{%>data-action="folder.showDeleteFolder"<%}%> tabindex="-1">删除</li>\n		<%}%>\n	<%}%>\n<%}else if(list){%>\n	<li data-action="batch.downloadAction" title="下载" tabindex="3" aria-label="下载文件" tabindex="-1">下载</li>\n	<li class="line" data-action="file.batchSaveAs" tabindex="-1" aria-label="另存为">另存为</li>\n	<li <%if(!G.info.isAdmin && !isUploader){%>class="line disabled"<%}else{%>class="line" data-action="file.batchMove"<%}%> tabindex="-1" aria-label="移动到"">移动到</li>\n	<li <%if(!G.info.isAdmin && !isUploader){%>class="disabled"<%}else{%>data-action="file.batchDelete"<%}%> tabindex="-1" aria-label="删除">删除</li>\n<%}%>\n</ul>\n',
            filename: undefined
        };
        function rethrow(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        }
        try {
            var buf = [];
            with (locals || {}) {
                (function() {
                    buf.push('<a class="aria-hide aria-tips" tabindex="-1">右键菜单</a>\n<ul>\n');
                    __stack.lineno = 3;
                    var e = locals.data, t = locals.list, a = locals.isUploader;
                    if (!e && !t) {
                        buf.push("\n	<li ");
                        __stack.lineno = 10;
                        if (G.file.isTooMany) {
                            buf.push('class="disabled"');
                            __stack.lineno = 10;
                        } else {
                            buf.push(' data-action="file.upload"');
                            __stack.lineno = 10;
                        }
                        buf.push(' tabindex="-1">上传</li>\n	');
                        __stack.lineno = 11;
                        if (G.canCreateFolder && G.nowFolder === "/") {
                            buf.push("\n	<li ");
                            __stack.lineno = 12;
                            if (G.file.isTooMany) {
                                buf.push('class="disabled"');
                                __stack.lineno = 12;
                            } else {
                                buf.push(' data-action="folder.create"');
                                __stack.lineno = 12;
                            }
                            buf.push(' title="新建文件夹" tabindex="-1">新建文件夹</li>\n	');
                            __stack.lineno = 13;
                        }
                        buf.push('\n	<li data-action="menu.refresh" onclick="window.location.reload();" tabindex="-1">刷新</li>\n');
                        __stack.lineno = 15;
                    } else if (e) {
                        buf.push("\n	");
                        __stack.lineno = 16;
                        if (typeof e.othergroup !== "undefined") {
                            buf.push('\n		<li data-action="openGroupFile" data-uin="', (__stack.lineno = 17, 
                            e.gc), '" tabindex="-1">打开所在群</li>\n	');
                            __stack.lineno = 18;
                        } else {
                            buf.push("\n		");
                            __stack.lineno = 19;
                            if (e.orcType === 1) {
                                buf.push("\n			");
                                __stack.lineno = 20;
                                if (e.icon !== "pic") {
                                    buf.push("\n				<li ");
                                    __stack.lineno = 21;
                                    if (e.safeType) {
                                        buf.push('class="disabled"');
                                        __stack.lineno = 21;
                                    } else {
                                        buf.push('data-action="file.downloadByMenu"');
                                        __stack.lineno = 21;
                                    }
                                    buf.push(' aria-label="打开" data-path="', escape((__stack.lineno = 21, e.filepath)), '" tabindex="-1">打开</li>\n			');
                                    __stack.lineno = 22;
                                } else {
                                    buf.push("\n				<li ");
                                    __stack.lineno = 23;
                                    if (e.safeType) {
                                        buf.push('class="disabled"');
                                        __stack.lineno = 23;
                                    } else {
                                        buf.push('data-action="file.menupreview"');
                                        __stack.lineno = 23;
                                    }
                                    buf.push(' aria-label="预览" tabindex="-1">预览</li>\n			');
                                    __stack.lineno = 24;
                                }
                                buf.push("\n\n			<li ");
                                __stack.lineno = 26;
                                if (e.safeType) {
                                    buf.push('class="disabled"');
                                    __stack.lineno = 26;
                                } else {
                                    buf.push('data-action="batch.downloadAction"');
                                    __stack.lineno = 26;
                                }
                                buf.push(' title="下载" tabindex="3" aria-label="下载文件" tabindex="-1">下载</li>\n			<li ');
                                __stack.lineno = 27;
                                if (e.safeType) {
                                    buf.push('class="disabled"');
                                    __stack.lineno = 27;
                                } else {
                                    buf.push('data-action="file.saveAs"');
                                    __stack.lineno = 27;
                                }
                                buf.push(' title="另存为" tabindex="3" aria-label="另存文件" tabindex="-1">另存为</li>\n			');
                                __stack.lineno = 28;
                                if (!G.mac) {
                                    buf.push("\n			  <li ");
                                    __stack.lineno = 29;
                                    if (e.safeType) {
                                        buf.push('class="disabled"');
                                        __stack.lineno = 29;
                                    } else {
                                        buf.push('data-action="file.forward"');
                                        __stack.lineno = 29;
                                    }
                                    buf.push(' aria-label="转发" tabindex="-1">转发</li>\n			  <li class="line ');
                                    __stack.lineno = 30;
                                    if (e.safeType) {
                                        buf.push("disabled");
                                        __stack.lineno = 30;
                                    }
                                    buf.push('" ');
                                    __stack.lineno = 30;
                                    if (!e.safeType) {
                                        buf.push('data-action="file.forwardMobile"');
                                        __stack.lineno = 30;
                                    }
                                    buf.push(' aria-label="转发到手机" tabindex="-1">发送到手机</li>\n			');
                                    __stack.lineno = 31;
                                }
                                buf.push("\n			");
                                __stack.lineno = 32;
                                if (e.admin && typeof e.issearch === "undefined") {
                                    buf.push("\n				<li ");
                                    __stack.lineno = 33;
                                    if (e.safeType || G.file.isTooMany) {
                                        buf.push('class="disabled"');
                                        __stack.lineno = 33;
                                    } else {
                                        buf.push('data-action="file.showMove"');
                                        __stack.lineno = 33;
                                    }
                                    buf.push(' aria-label="移动" tabindex="-1">移动到</li>\n			');
                                    __stack.lineno = 34;
                                }
                                buf.push("\n			");
                                __stack.lineno = 35;
                                if (G.info.isAdmin && e.temp) {
                                    buf.push("\n				<li ");
                                    __stack.lineno = 36;
                                    if (e.safeType) {
                                        buf.push('class="disabled"');
                                        __stack.lineno = 36;
                                    } else {
                                        buf.push('data-action="file.permanent"');
                                        __stack.lineno = 36;
                                    }
                                    buf.push(' aria-label="转存为永久文件" tabindex="-1" tabindex="-1">转存为永久文件</li>\n			');
                                    __stack.lineno = 37;
                                }
                                buf.push("\n			<li ");
                                __stack.lineno = 38;
                                if (e.safeType || !G.info.isAdmin && !a) {
                                    buf.push('class="disabled"');
                                    __stack.lineno = 38;
                                } else {
                                    buf.push('data-action="file.showRename"');
                                    __stack.lineno = 38;
                                }
                                buf.push(' aria-label="重命名"  tabindex="-1">重命名</li>\n			<li ');
                                __stack.lineno = 39;
                                if (!G.info.isAdmin && !a) {
                                    buf.push('class="disabled"');
                                    __stack.lineno = 39;
                                } else {
                                    buf.push('data-action="file.delete"');
                                    __stack.lineno = 39;
                                }
                                buf.push(' id="fileDelete" aria-label="删除" tabindex="-1">删除</li>\n			<li data-action="file.jubao" aria-label="举报">举报</li>\n		');
                                __stack.lineno = 41;
                            } else if (e.orcType === 2) {
                                buf.push('\n			<li class="line" data-action="folder.open" data-path="', escape((__stack.lineno = 42, 
                                e.id)), '" tabindex="-1">打开</li>\n			<li ');
                                __stack.lineno = 43;
                                if (!G.info.isAdmin) {
                                    buf.push('class="disabled"');
                                    __stack.lineno = 43;
                                } else {
                                    buf.push('data-action="folder.showRenameFolder"');
                                    __stack.lineno = 43;
                                }
                                buf.push(' tabindex="-1">重命名</li>\n			<li class="line" data-action="folder.property">文件夹属性</li>\n			<li ');
                                __stack.lineno = 45;
                                if (!G.info.isAdmin) {
                                    buf.push('class="disabled"');
                                    __stack.lineno = 45;
                                } else {
                                    buf.push('data-action="folder.showDeleteFolder"');
                                    __stack.lineno = 45;
                                }
                                buf.push(' tabindex="-1">删除</li>\n		');
                                __stack.lineno = 46;
                            }
                            buf.push("\n	");
                            __stack.lineno = 47;
                        }
                        buf.push("\n");
                        __stack.lineno = 48;
                    } else if (t) {
                        buf.push('\n	<li data-action="batch.downloadAction" title="下载" tabindex="3" aria-label="下载文件" tabindex="-1">下载</li>\n	<li class="line" data-action="file.batchSaveAs" tabindex="-1" aria-label="另存为">另存为</li>\n	<li ');
                        __stack.lineno = 51;
                        if (!G.info.isAdmin && !a) {
                            buf.push('class="line disabled"');
                            __stack.lineno = 51;
                        } else {
                            buf.push('class="line" data-action="file.batchMove"');
                            __stack.lineno = 51;
                        }
                        buf.push(' tabindex="-1" aria-label="移动到"">移动到</li>\n	<li ');
                        __stack.lineno = 52;
                        if (!G.info.isAdmin && !a) {
                            buf.push('class="disabled"');
                            __stack.lineno = 52;
                        } else {
                            buf.push('data-action="file.batchDelete"');
                            __stack.lineno = 52;
                        }
                        buf.push(' tabindex="-1" aria-label="删除">删除</li>\n');
                        __stack.lineno = 53;
                    }
                    buf.push("\n</ul>\n");
                })();
            }
            return buf.join("");
        } catch (err) {
            rethrow(err, __stack.input, __stack.filename, __stack.lineno);
        }
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        upload: 2186487,
        continueupload: 2186489,
        download: 2186490
    };
    var n = a(55);
    var r = a(31);
    function o(e) {
        e.taskStarttime = parseInt(new Date().getTime() / 1e3, 10);
        if (!(e.type === "download" && e.downloadtasktype === 2)) {
            if (e.onlineedit === 1) {
                r.fileInEditRow(e);
            } else {}
            $(G.handler).trigger("client.addTask", e);
        } else {
            var t = e.foldertaskid;
            var a = n.getOneTask(t);
            if (a) {
                if (!a.fileTaskList) {
                    a.fileTaskList = [];
                }
                a.fileTaskList.push(e.id);
            }
        }
        QReport.monitor(i[e.type]);
    }
    e.exports = o;
}, function(e, t, a) {
    "use strict";
    var i = a(260);
    var n = r(i);
    function r(e) {
        if (e && e.__esModule) {
            return e;
        } else {
            var t = {};
            if (e != null) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) t[a] = e[a];
                }
            }
            t.default = e;
            return t;
        }
    }
    var o = a(54);
    var l = a(31);
    var s = a(53);
    var f = a(20);
    var d = a(22);
    var c = $(G.handler);
    var u = a(129);
    var p = a(126);
    var v = a(178);
    var m = 5485;
    function h(e) {
        var t = o.task2file(e);
        if (!G.file) {
            G.file = {};
        }
        if (G.file && typeof G.file.cu === "undefined") {
            G.file.cu = 0;
        }
        console.debug("------任务完成 " + e.type + "---------", e);
        if (G.continueUploadMap[e.parentId] && G.continueUploadMap[e.parentId][e.filepath]) {
            delete G.continueUploadMap[e.parentId][e.filepath];
        }
        if (e.status === "downloadcomplete") {
            if (e.downloadtasktype !== 2) {
                if (!G.saveasList[t.filepath]) {
                    if (G.version < m) {
                        v.openByPath(t);
                    } else {
                        n.edit(t);
                    }
                } else {
                    delete G.saveasList[t.filepath];
                }
            }
            if (t.parentId && t.parentId !== "/") {
                var a = o.getData(t.parentId);
                if (a) {
                    a.downNum++;
                    if (a.downNum === a.filenum) {
                        a.isDown = true;
                        a.succ = true;
                        l.updateRow(a);
                    }
                }
            }
            s.addBoxRow(t);
        } else {
            G.file.cu += t.size;
            G.file.capacityused = p.getSize(G.file.cu);
            l.renderSpace();
            if (t.folderpath === G.nowFolder || !t.folderpath) {
                if (e.onlineedit === 1) {
                    var i = o.getData(t.oldfilepath);
                    console.debug("upload complete and update old file:", e, t, i);
                    if (e.delete_file_id !== "") {
                        console.debug("update old file");
                        t.md5 = t.newMd5;
                        t.localpath = i.localpath;
                        t.down = i.down;
                        l.removeRow(i);
                        l.appendFile(t);
                    } else {
                        i.isDown = false;
                        t.localpath = i.localpath;
                        delete i.localpath;
                        delete i.lp;
                        console.debug("no need delete old file!", i, t);
                        l.updateEditFileRow(t);
                        d.remove(i);
                        l.appendFile(t);
                        o.updateAllNum({
                            files: [ t ],
                            action: "add"
                        });
                    }
                } else {
                    console.debug("更新文件", t);
                    l.updateDownloadRow(t);
                    s.addBoxRow(t);
                }
            } else {
                var r = o.getData(e.folderpath);
                r.filenum++;
                var h = parseInt(new Date().getTime() / 1e3, 10);
                r.mt = h;
                r.mtStr = u.dayStr(h);
                r.toFirst = true;
                l.updateRow(r);
            }
            f.init(G.file.isTooMany || G.file.isFull, e.status);
            o.updateAllNum({
                files: [ t ],
                action: "add"
            });
        }
        d.set(t);
        report("showTaskShow");
        c.trigger("client.updateTask", e);
    }
    e.exports = h;
}, function(e, t, a) {
    "use strict";
    var i = $(G.handler);
    function n(e) {
        i.trigger("client.updateTask", e);
    }
    e.exports = n;
}, function(e, t, a) {
    "use strict";
    var i = $(G.handler);
    function n(e) {
        i.trigger("client.updateTask", e);
    }
    e.exports = n;
}, function(e, t, a) {
    "use strict";
    var i = $(G.handler);
    function n(e) {
        e.createtime = parseInt(new Date().getTime() / 1e3, 10);
        if (e.status === "uploadprogress") {
            setTimeout(function() {
                $(G.handler).trigger("box.show", e);
            }, 20);
        }
        if (e.remotetype === 1) {}
        if (e.type === "download") {}
        i.trigger("client.updateTask", e);
    }
    e.exports = n;
}, function(e, t, a) {
    "use strict";
    var i = a(82);
    var n = $(G.handler);
    var r = {
        upload: {
            cancel: 2186633,
            remove: 2186634,
            scanfail: 2186635,
            uploadsecurityfail: 2186636,
            uploadgeturlfail: 2186637,
            uploadfail: 2186491,
            _default: 2186638
        },
        continueupload: {
            cancel: 2186639,
            remove: 2186640,
            scanfail: 2186641,
            uploadsecurityfail: 2186642,
            uploadgeturlfail: 2186643,
            uploadfail: 2186491,
            _default: 2186644
        },
        download: {
            cancel: 2186645,
            remove: 2186646,
            downloadgeturlfail: 2186647,
            downloadfail: 386331,
            _default: 2186648
        }
    };
    function o(e) {
        var t = e.filepath;
        var a = e.localpath;
        var n = e.filename_esc || e.filename;
        var r = e.remotetype;
        i.addContinueUploadTask(t, a, n, r);
    }
    function l(e) {
        n.trigger("client.updateTask", e);
        if (e.onlineedit === 1) {}
        var t = r[e.type];
        var a = t[e.status];
        if (a) {
            QReport.monitor(a);
        }
        if (e.errorcode || e.securityattri) {
            var i = e.errorcode;
            if (i === 32221991) {
                o(e);
                return;
            } else if (i === 12029) {}
        }
    }
    e.exports = l;
}, function(e, t, a) {
    "use strict";
    t.merge = function r(e, t) {
        if (arguments.length === 1) {
            var a = e[0];
            for (var n = 1; n < e.length; n++) {
                a = r(a, e[n]);
            }
            return a;
        }
        var o = e["class"];
        var l = t["class"];
        if (o || l) {
            o = o || [];
            l = l || [];
            if (!Array.isArray(o)) o = [ o ];
            if (!Array.isArray(l)) l = [ l ];
            e["class"] = o.concat(l).filter(i);
        }
        for (var s in t) {
            if (s != "class") {
                e[s] = t[s];
            }
        }
        return e;
    };
    function i(e) {
        return e != null && e !== "";
    }
    t.joinClasses = n;
    function n(e) {
        return Array.isArray(e) ? e.map(n).filter(i).join(" ") : e;
    }
    t.cls = function o(e, a) {
        var i = [];
        for (var r = 0; r < e.length; r++) {
            if (a && a[r]) {
                i.push(t.escape(n([ e[r] ])));
            } else {
                i.push(n(e[r]));
            }
        }
        var o = n(i);
        if (o.length) {
            return ' class="' + o + '"';
        } else {
            return "";
        }
    };
    t.attr = function l(e, a, i, n) {
        if ("boolean" == typeof a || null == a) {
            if (a) {
                return " " + (n ? e : e + '="' + e + '"');
            } else {
                return "";
            }
        } else if (0 == e.indexOf("data") && "string" != typeof a) {
            return " " + e + "='" + JSON.stringify(a).replace(/'/g, "&apos;") + "'";
        } else if (i) {
            return " " + e + '="' + t.escape(a) + '"';
        } else {
            return " " + e + '="' + a + '"';
        }
    };
    t.attrs = function s(e, a) {
        var i = [];
        var r = Object.keys(e);
        if (r.length) {
            for (var o = 0; o < r.length; ++o) {
                var l = r[o], s = e[l];
                if ("class" == l) {
                    if (s = n(s)) {
                        i.push(" " + l + '="' + s + '"');
                    }
                } else {
                    i.push(t.attr(l, s, false, a));
                }
            }
        }
        return i.join("");
    };
    t.escape = function f(e) {
        var t = String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        if (t === "" + e) return e; else return t;
    };
    t.rethrow = function d(e, t, i, n) {
        if (!(e instanceof Error)) throw e;
        if ((typeof window != "undefined" || !t) && !n) {
            e.message += " on line " + i;
            throw e;
        }
        try {
            n = n || a(!function c() {
                var e = new Error('Cannot find module "fs"');
                e.code = "MODULE_NOT_FOUND";
                throw e;
            }()).readFileSync(t, "utf8");
        } catch (r) {
            d(e, null, i);
        }
        var o = 3, l = n.split("\n"), s = Math.max(i - o, 0), f = Math.min(l.length, i + o);
        var o = l.slice(s, f).map(function(e, t) {
            var a = t + s + 1;
            return (a == i ? "  > " : "    ") + a + "| " + e;
        }).join("\n");
        e.path = t;
        e.message = (t || "Jade") + ":" + i + "\n" + o + "\n\n" + e.message;
        throw e;
    };
}, function(e, t, a) {
    var i = a(241), n = Math.min;
    e.exports = function(e) {
        return e > 0 ? n(i(e), 9007199254740991) : 0;
    };
}, function(e, t, a) {
    var i = a(241), n = Math.max, r = Math.min;
    e.exports = function(e, t) {
        e = i(e);
        return e < 0 ? n(e + t, 0) : r(e, t);
    };
}, function(e, t, a) {
    e.exports = {
        "default": a(297),
        __esModule: true
    };
}, function(e, t, a) {
    a(298);
    var i = a(101).Object;
    e.exports = function n(e, t, a) {
        return i.defineProperty(e, t, a);
    };
}, function(e, t, a) {
    var i = a(197);
    i(i.S + i.F * !a(196), "Object", {
        defineProperty: a(214).f
    });
} ]);